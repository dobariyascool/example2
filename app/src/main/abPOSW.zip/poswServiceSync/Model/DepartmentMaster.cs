﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poswLibrary
{
    public class DepartmentMaster
    {
        public short DepartmentMasterId { get; set; }
        public string ShortName { get; set; }
        public string DepartmentName { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsSync { get; set; }
        public short? SyncId { get; set; }
        public DateTime? TransactionDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }

        /// Extra
        public string Business { get; set; }

        internal void SetClassObject(poswDepartmentMasterDAL objDepartmentMasterDAL)
        {
            this.DepartmentMasterId = Convert.ToInt16(objDepartmentMasterDAL.DepartmentMasterId);
            this.ShortName = Convert.ToString(objDepartmentMasterDAL.ShortName);
            this.DepartmentName = Convert.ToString(objDepartmentMasterDAL.DepartmentName);
            this.Description = Convert.ToString(objDepartmentMasterDAL.Description);
            this.IsEnabled = Convert.ToBoolean(objDepartmentMasterDAL.IsEnabled);
            this.IsDeleted = Convert.ToBoolean(objDepartmentMasterDAL.IsDeleted);
            this.linktoBusinessMasterId = Convert.ToInt16(objDepartmentMasterDAL.linktoBusinessMasterId);
            this.IsSync = Convert.ToBoolean(objDepartmentMasterDAL.IsSync);
            if (objDepartmentMasterDAL.SyncId != null)
            {
                this.SyncId = Convert.ToInt16(objDepartmentMasterDAL.SyncId);
            }
            if (objDepartmentMasterDAL.TransactionDateTime != null)
            {
                this.TransactionDateTime = Convert.ToDateTime(objDepartmentMasterDAL.TransactionDateTime);
            }
            if (objDepartmentMasterDAL.linktoUserMasterIdUpdatedBy != null)
            {
                this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objDepartmentMasterDAL.linktoUserMasterIdUpdatedBy);
            }
            if (objDepartmentMasterDAL.UpdateDateTime != null)
            {
                this.UpdateDateTime = Convert.ToDateTime(objDepartmentMasterDAL.UpdateDateTime);
            }
            /// Extra
            this.Business = Convert.ToString(objDepartmentMasterDAL.Business);
        }

        internal static List<DepartmentMaster> SetListObject(List<poswDepartmentMasterDAL> lstDepartmentMasterDAL)
        {
            List<DepartmentMaster> lstDepartmentMaster = new List<DepartmentMaster>();
            DepartmentMaster objDepartmentMaster = null;

            foreach (poswDepartmentMasterDAL objDepartmentMasterDAL in lstDepartmentMasterDAL)
            {
                objDepartmentMaster = new DepartmentMaster();
                objDepartmentMaster.DepartmentMasterId = Convert.ToInt16(objDepartmentMasterDAL.DepartmentMasterId);
                objDepartmentMaster.ShortName = Convert.ToString(objDepartmentMasterDAL.ShortName);
                objDepartmentMaster.DepartmentName = Convert.ToString(objDepartmentMasterDAL.DepartmentName);
                objDepartmentMaster.Description = Convert.ToString(objDepartmentMasterDAL.Description);
                objDepartmentMaster.IsEnabled = Convert.ToBoolean(objDepartmentMasterDAL.IsEnabled);
                objDepartmentMaster.IsDeleted = Convert.ToBoolean(objDepartmentMasterDAL.IsDeleted);
                objDepartmentMaster.linktoBusinessMasterId = Convert.ToInt16(objDepartmentMasterDAL.linktoBusinessMasterId);
                objDepartmentMaster.IsSync = Convert.ToBoolean(objDepartmentMasterDAL.IsSync);
                if (objDepartmentMasterDAL.SyncId != null)
                {
                    objDepartmentMaster.SyncId = Convert.ToInt16(objDepartmentMasterDAL.SyncId);
                }
                if (objDepartmentMasterDAL.TransactionDateTime != null)
                {
                    objDepartmentMaster.TransactionDateTime = Convert.ToDateTime(objDepartmentMasterDAL.TransactionDateTime);
                }
                if (objDepartmentMasterDAL.linktoUserMasterIdUpdatedBy != null)
                {
                    objDepartmentMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objDepartmentMasterDAL.linktoUserMasterIdUpdatedBy);
                }
                if (objDepartmentMasterDAL.UpdateDateTime != null)
                {
                    objDepartmentMaster.UpdateDateTime = Convert.ToDateTime(objDepartmentMasterDAL.UpdateDateTime);
                }

                /// Extra
                objDepartmentMaster.Business = Convert.ToString(objDepartmentMasterDAL.Business);
                lstDepartmentMaster.Add(objDepartmentMaster);
            }
            return lstDepartmentMaster;
        }
    }
}
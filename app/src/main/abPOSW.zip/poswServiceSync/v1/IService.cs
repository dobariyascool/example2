﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using poswLibrary;

namespace poswServiceSync
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        [WebGet(UriTemplate = "SelectAllDepartmentMaster/{businessMasterId}")]
        List<DepartmentMaster> SelectAllDepartmentMaster(short businessMasterId);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateDepartmentMasterResponse")]
        bool UpdateDepartmentMasterResponse(List<poswResponseDAL> lstResponse);

        [OperationContract]
        [WebInvoke(UriTemplate = "SyncAllDepartmentMaster")]
        List<poswResponseDAL> SyncAllDepartmentMaster(List<poswDepartmentMasterDAL> lstDepartmentMaster);  

        // TODO: Add your service operations here
    } 

   
}

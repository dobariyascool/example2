using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswFeedbackTran
    /// </summary>
    public class poswFeedbackTranDAL
    {
        #region Properties
        public int FeedbackTranId { get; set; }
        public int linktoFeedbackMasterId { get; set; }
        public int linktoFeedbackQuestionMasterId { get; set; }
        public int? linktoFeedbackAnswerMasterId { get; set; }
        public string Answer { get; set; }

        /// Extra
        public string FeedbackQuestion { get; set; }
        public string FeedbackAnswer { get; set; }
        public string FeedbackTranIds { get; set; }
        public DateTime FeebackFromDate { get; set; }
        public DateTime FeebackToDate { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int QuestionType { get; set; }
        public string AnswerMultiOrSingle { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.FeedbackTranId = Convert.ToInt32(sqlRdr["FeedbackTranId"]);
                this.linktoFeedbackMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackMasterId"]);
                this.linktoFeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackQuestionMasterId"]);
                if (sqlRdr["linktoFeedbackAnswerMasterId"] != DBNull.Value)
                {
                    this.linktoFeedbackAnswerMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackAnswerMasterId"]);
                }
                this.Answer = Convert.ToString(sqlRdr["Answer"]);

                /// Extra
                this.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                this.FeedbackAnswer = Convert.ToString(sqlRdr["FeedbackAnswer"]);
                return true;
            }
            return false;
        }

        private List<poswFeedbackTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswFeedbackTranDAL> lstFeedbackTran = new List<poswFeedbackTranDAL>();
            poswFeedbackTranDAL objFeedbackTran = null;
            while (sqlRdr.Read())
            {
                objFeedbackTran = new poswFeedbackTranDAL();

                objFeedbackTran.linktoFeedbackMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackMasterId"]);
                objFeedbackTran.linktoFeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackQuestionMasterId"]);

                /// Extra 
                objFeedbackTran.FeedbackTranIds = Convert.ToString(sqlRdr["FeedbackTranIds"]);
                objFeedbackTran.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                objFeedbackTran.FeedbackAnswer = Convert.ToString(sqlRdr["FeedbackAnswer"]);

                objFeedbackTran.Name = Convert.ToString(sqlRdr["Name"]);
                objFeedbackTran.Email = Convert.ToString(sqlRdr["Email"]);
                objFeedbackTran.Phone = Convert.ToString(sqlRdr["Phone"]);
                objFeedbackTran.Answer = Convert.ToString(sqlRdr["Answer"]);
                if (Convert.ToInt16(sqlRdr["QuestionType"]) == poswFeedbackQuestionType.Rating.GetHashCode())
                {
                    objFeedbackTran.Answer = Convert.ToString(sqlRdr["Answer"]) + " Stars";
                }
                if (sqlRdr["AnswerMultiOrSingle"] != DBNull.Value)
                {
                    objFeedbackTran.Answer = Convert.ToString(sqlRdr["AnswerMultiOrSingle"]);
                }

                lstFeedbackTran.Add(objFeedbackTran);
            }

            return lstFeedbackTran;
        }
        #endregion

        #region Insert
        public static poswRecordStatus InsertFeedbackTran(int linktoFeedbackMasterId, List<poswFeedbackTranDAL> lstFeedbackTranDAL, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            poswRecordStatus rs = poswRecordStatus.Error;
            try
            {
                SqlCmd = new SqlCommand("poswFeedbackTran_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (poswFeedbackTranDAL objFeedbackTranDAL in lstFeedbackTranDAL)
                {

                    SqlCmd.Parameters.Add("@FeedbackTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@linktoFeedbackMasterId", SqlDbType.Int).Value = linktoFeedbackMasterId;
                    SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = objFeedbackTranDAL.linktoFeedbackQuestionMasterId;

                    if (objFeedbackTranDAL.linktoFeedbackAnswerMasterId > 0)
                    {
                        SqlCmd.Parameters.Add("@linktoFeedbackAnswerMasterId", SqlDbType.Int).Value = objFeedbackTranDAL.linktoFeedbackAnswerMasterId;
                    }

                    SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = objFeedbackTranDAL.Answer;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                    rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    SqlCmd.Parameters.Clear();
                }
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<poswFeedbackTranDAL> SelectAllFeedbackTranByCustomerPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackTranQuestionWisePageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoFeedbackQuestionMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
                }
                if (this.FeebackFromDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FeebackDate", SqlDbType.Date).Value = this.FeebackFromDate;
                }
                if (this.FeebackToDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FeebackDateTo", SqlDbType.Date).Value = this.FeebackToDate;
                }
                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@linktoFeedbackMasterId", SqlDbType.Int).Value = this.linktoFeedbackMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswFeedbackTranDAL> lstFeedbackTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstFeedbackTranDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Commented
        //private List<poswFeedbackTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        //{
        //    List<poswFeedbackTranDAL> lstFeedbackTran = new List<poswFeedbackTranDAL>();
        //    poswFeedbackTranDAL objFeedbackTran = null;
        //    while (sqlRdr.Read())
        //    {
        //        objFeedbackTran = new poswFeedbackTranDAL();
        //        objFeedbackTran.FeedbackTranId = Convert.ToInt32(sqlRdr["FeedbackTranId"]);
        //        objFeedbackTran.linktoFeedbackMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackMasterId"]);
        //        objFeedbackTran.linktoFeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackQuestionMasterId"]);
        //        if (sqlRdr["linktoFeedbackAnswerMasterId"] != DBNull.Value)
        //        {
        //            objFeedbackTran.linktoFeedbackAnswerMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackAnswerMasterId"]);
        //        }
        //        objFeedbackTran.Answer = Convert.ToString(sqlRdr["Answer"]);

        //        /// Extra
        //        objFeedbackTran.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
        //        objFeedbackTran.FeedbackAnswer = Convert.ToString(sqlRdr["FeedbackAnswer"]);
        //        lstFeedbackTran.Add(objFeedbackTran); 
        //    }
        //    return lstFeedbackTran;
        //}
        //#region Insert
        //public poswRecordStatus InsertFeedbackTran()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackTran_Insert", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
        //        SqlCmd.Parameters.Add("@linktoFeedbackMasterId", SqlDbType.Int).Value = this.linktoFeedbackMasterId;
        //        SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
        //        SqlCmd.Parameters.Add("@linktoFeedbackAnswerMasterId", SqlDbType.Int).Value = this.linktoFeedbackAnswerMasterId;
        //        SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = this.Answer;
        //        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCon.Open();
        //        SqlCmd.ExecuteNonQuery();
        //        SqlCon.Close();

        //        this.FeedbackTranId = Convert.ToInt32(SqlCmd.Parameters["@FeedbackTranId"].Value);
        //        poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
        //        return rs;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return poswRecordStatus.Error;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        //#endregion

        //#region Update
        //public poswRecordStatus UpdateFeedbackTran()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackTran_Update", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackTranId", SqlDbType.Int).Value = this.FeedbackTranId;
        //        SqlCmd.Parameters.Add("@linktoFeedbackMasterId", SqlDbType.Int).Value = this.linktoFeedbackMasterId;
        //        SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
        //        SqlCmd.Parameters.Add("@linktoFeedbackAnswerMasterId", SqlDbType.Int).Value = this.linktoFeedbackAnswerMasterId;
        //        SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = this.Answer;
        //        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCon.Open();
        //        SqlCmd.ExecuteNonQuery();
        //        SqlCon.Close();

        //        poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
        //        return rs;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return poswRecordStatus.Error;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        //#endregion

        //#region Delete
        //public poswRecordStatus DeleteFeedbackTran(SqlTransaction SqlTran, SqlConnection SqlCon)
        //{
        //    SqlCommand SqlCmd = null;
        //    try
        //    {
        //        SqlCmd = new SqlCommand("poswFeedbackTran_Delete", SqlCon, SqlTran);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackTranId", SqlDbType.Int).Value = this.FeedbackTranId;
        //        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCmd.ExecuteNonQuery();

        //        poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
        //        return rs;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return poswRecordStatus.Error;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //    }
        //}
        //#endregion

        //#region Select
        //public bool SelectFeedbackTran()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    SqlDataReader SqlRdr = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackTran_Select", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackTranId", SqlDbType.Int).Value = this.FeedbackTranId;

        //        SqlCon.Open();
        //        SqlRdr = SqlCmd.ExecuteReader();
        //        bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
        //        SqlRdr.Close();
        //        SqlCon.Close();

        //        return IsSelected;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return false;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        //#endregion
        //public List<poswFeedbackTranDAL> SelectAllFeedbackTranPageWise(short startRowIndex, short pageSize, out short totalRecords)
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    SqlDataReader SqlRdr = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackTranPageWise_SelectAll", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@linktoFeedbackMasterId", SqlDbType.Int).Value = this.linktoFeedbackMasterId;


        //        SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
        //        SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
        //        SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCon.Open();
        //        SqlRdr = SqlCmd.ExecuteReader();
        //        List<poswFeedbackTranDAL> lstFeedbackTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
        //        SqlRdr.Close();
        //        SqlCon.Close();

        //        totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
        //        return lstFeedbackTranDAL;
        //    }
        //    catch (Exception ex)
        //    {
        //        totalRecords = 0;
        //        poswGlobalsDAL.SaveError(ex);
        //        return null;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        #endregion
    }
}

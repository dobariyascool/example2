using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswBusinessInfoQuestionMaster
	/// </summary>
	public class poswBusinessInfoQuestionMasterDAL
	{
		#region Properties
		public int BusinessInfoQuestionMasterId { get; set; }
		public short linktoBusinessTypeMasterId { get; set; }
		public string Question { get; set; }
		public short QuestionType { get; set; }
		public int? SortOrder { get; set; }
		public bool IsEnabled { get; set; }

		/// Extra
		public string BusinessType { get; set; }
        public string Answer { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.BusinessInfoQuestionMasterId = Convert.ToInt32(sqlRdr["BusinessInfoQuestionMasterId"]);
				this.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
				this.Question = Convert.ToString(sqlRdr["Question"]);
				this.QuestionType = Convert.ToInt16(sqlRdr["QuestionType"]);
				if (sqlRdr["SortOrder"] != DBNull.Value)
				{
					this.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
				}
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

				/// Extra
				this.BusinessType = Convert.ToString(sqlRdr["BusinessType"]);
				return true;
			}
			return false;
		}

		private List<poswBusinessInfoQuestionMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
            int QuestionNumber = 1;
			List<poswBusinessInfoQuestionMasterDAL> lstBusinessInfoQuestionMaster = new List<poswBusinessInfoQuestionMasterDAL>();
			poswBusinessInfoQuestionMasterDAL objBusinessInfoQuestionMaster = null;
			while (sqlRdr.Read())
			{
				objBusinessInfoQuestionMaster = new poswBusinessInfoQuestionMasterDAL();
				objBusinessInfoQuestionMaster.BusinessInfoQuestionMasterId = Convert.ToInt32(sqlRdr["BusinessInfoQuestionMasterId"]);
				objBusinessInfoQuestionMaster.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
                objBusinessInfoQuestionMaster.Question = Convert.ToString(QuestionNumber.ToString() +":  " +  Convert.ToString(sqlRdr["Question"]));
				objBusinessInfoQuestionMaster.QuestionType = Convert.ToInt16(sqlRdr["QuestionType"]);
				if (sqlRdr["SortOrder"] != DBNull.Value)
				{
					objBusinessInfoQuestionMaster.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
				}
				objBusinessInfoQuestionMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

				/// Extra
				//objBusinessInfoQuestionMaster.BusinessType = Convert.ToString(sqlRdr["BusinessType"]);
                objBusinessInfoQuestionMaster.Answer = Convert.ToString(sqlRdr["Answer"]);
				lstBusinessInfoQuestionMaster.Add(objBusinessInfoQuestionMaster);
                QuestionNumber++;
			}
			return lstBusinessInfoQuestionMaster;
		}
		#endregion

		#region Select
		public bool SelectBusinessInfoQuestionMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessInfoQuestionMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@BusinessInfoQuestionMasterId", SqlDbType.Int).Value = this.BusinessInfoQuestionMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
        public List<poswBusinessInfoQuestionMasterDAL> SelectAllBusinessInfoQuestionMaster(short linktoBusinessMasterId)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessInfoQuestionMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				if (this.linktoBusinessTypeMasterId > 0)
				{
					SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessTypeMasterId;
				}
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswBusinessInfoQuestionMasterDAL> lstBusinessInfoQuestionMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				
				return lstBusinessInfoQuestionMasterDAL;
			}
			catch (Exception ex)
			{
				
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
        #endregion
	}
}

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswOrderMaster
    /// </summary>
    public class poswOrderMasterDAL
    {
        #region Properties
        public long OrderMasterId { get; set; }
        public string OrderNumber { get; set; }
        public DateTime OrderDateTime { get; set; }
        public string linktoTableMasterIds { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public int? linktoBookingMasterId { get; set; }
        public double TotalAmount { get; set; }
        public double TotalTax { get; set; }
        public double Discount { get; set; }
        public double ExtraAmount { get; set; }
        public short TotalItemPoint { get; set; }
        public short TotalDeductedPoint { get; set; }
        public string Remark { get; set; }
        public bool IsPreOrder { get; set; }
        public long? linktoSalesMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public int? linktoCustomerAddressTranId { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double BalanceAmount { get; set; }
        public short linktoBusinessMasterId { get; set; }


        /// Extra
        public string User { get; set; }
        public string TableName { get; set; }
        public string OrderType { get; set; }
        public string OrderStatus { get; set; }
        public string OrderDateTimeString { get; set; }
        public DateTime OrderToDateTime { get; set; }
        public string StatusName { get; set; }
        public short OrderStatusMasterId { get; set; }
        public short OrderTypeMasterId { get; set; }
        public int linktoOfferMasterId { get; set; }
        public string OfferCode { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public double DailyOrder { get; set; }
        public double WeeklyOrder { get; set; }
        public double MonthlyOrder { get; set; }
        public string Month { get; set; }
        public string Year { get; set; }
        public string LeastSellingDayName { get; set; }
        #endregion

        #region Class Methods
        private List<poswOrderMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswOrderMasterDAL> lstOrderMaster = new List<poswOrderMasterDAL>();
            poswOrderMasterDAL objOrderMaster = null;
            while (sqlRdr.Read())
            {
                objOrderMaster = new poswOrderMasterDAL();
                objOrderMaster.OrderMasterId = Convert.ToInt64(sqlRdr["OrderMasterId"]);
                objOrderMaster.OrderNumber = Convert.ToString(sqlRdr["OrderNumber"]);
                objOrderMaster.OrderDateTime = Convert.ToDateTime(sqlRdr["OrderDateTime"]);
                objOrderMaster.linktoTableMasterIds = Convert.ToString(sqlRdr["linktoTableMasterIds"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objOrderMaster.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                    objOrderMaster.User = Convert.ToString(sqlRdr["Customer"]);
                    objOrderMaster.Phone = Convert.ToString(sqlRdr["CustomerPhone"]);
                    objOrderMaster.Email = Convert.ToString(sqlRdr["CustomerEmail"]);

                }

                objOrderMaster.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                if (sqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                {
                    objOrderMaster.linktoOrderStatusMasterId = Convert.ToInt16(sqlRdr["linktoOrderStatusMasterId"]);
                }
                if (sqlRdr["linktoBookingMasterId"] != DBNull.Value)
                {
                    objOrderMaster.linktoBookingMasterId = Convert.ToInt32(sqlRdr["linktoBookingMasterId"]);
                }
                objOrderMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objOrderMaster.TotalTax = Convert.ToDouble(sqlRdr["TotalTax"]);
                objOrderMaster.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                objOrderMaster.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                objOrderMaster.TotalItemPoint = Convert.ToInt16(sqlRdr["TotalItemPoint"]);
                objOrderMaster.TotalDeductedPoint = Convert.ToInt16(sqlRdr["TotalDeductedPoint"]);
                objOrderMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objOrderMaster.IsPreOrder = Convert.ToBoolean(sqlRdr["IsPreOrder"]);
                if (sqlRdr["linktoSalesMasterId"] != DBNull.Value)
                {
                    objOrderMaster.linktoSalesMasterId = Convert.ToInt64(sqlRdr["linktoSalesMasterId"]);
                }
                objOrderMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objOrderMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                /// Extra
                //objOrderMaster.User = Convert.ToString(sqlRdr["User"]);
                objOrderMaster.OrderType = Convert.ToString(sqlRdr["OrderType"]);
                objOrderMaster.OrderStatus = Convert.ToString(sqlRdr["OrderStatus"]);
                objOrderMaster.TableName = Convert.ToString(sqlRdr["TableName"]);
                lstOrderMaster.Add(objOrderMaster);
            }
            return lstOrderMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertOrderMaster(List<poswItemMasterDAL> lstItemMasterDAL, List<poswOrderTaxTranDAL> lstOrderTaxTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswOrderMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                //SqlCmd.Parameters.Add("@OrderNumber", SqlDbType.VarChar).Value = this.OrderNumber;
                SqlCmd.Parameters.Add("@OrderDateTime", SqlDbType.DateTime).Value = this.OrderDateTime;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@TotalItemPoint", SqlDbType.SmallInt).Value = this.TotalItemPoint;
                SqlCmd.Parameters.Add("@TotalDeductedPoint", SqlDbType.SmallInt).Value = this.TotalDeductedPoint;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsPreOrder", SqlDbType.Bit).Value = this.IsPreOrder;
                SqlCmd.Parameters.Add("@linktoCustomerAddressTranId", SqlDbType.Int).Value = this.linktoCustomerAddressTranId;
                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = this.linktoSalesMasterId;
                if (this.linktoOfferMasterId > 0 && (!string.IsNullOrEmpty(this.OfferCode)))
                {
                    SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                    SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                }
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OrderMasterId = Convert.ToInt64(SqlCmd.Parameters["@OrderMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                poswOrderItemTranDAL objOrderItemTranDAL = null;
                poswOrderItemModifierTranDAL objOrderItemModifierTranDAL = null;
                long OrderItemTranId = 0;
                foreach (var item in lstItemMasterDAL)
                {
                    if (item.ItemType == poswItemType.Item.GetHashCode())
                    {
                        objOrderItemTranDAL = new poswOrderItemTranDAL();
                        objOrderItemTranDAL.linktoOrderMasterId = this.OrderMasterId;
                        objOrderItemTranDAL.linktoItemMasterId = item.ItemMasterId;
                        objOrderItemTranDAL.Quantity = Convert.ToInt16(item.Quentity);
                        objOrderItemTranDAL.Rate = item.Rate;
                        objOrderItemTranDAL.ItemPoint = item.ItemPoint;
                        objOrderItemTranDAL.DeductedPoint = 00;
                        objOrderItemTranDAL.DiscountAmount = 00;
                        objOrderItemTranDAL.DiscountPercentage = 00;
                        if (!string.IsNullOrEmpty(item.Remark))
                        {
                            objOrderItemTranDAL.ItemRemark = item.Remark.Replace('*', ' ').ToString().Trim();
                        }
                        objOrderItemTranDAL.TotalRate = item.TotalAmount;
                        rs = objOrderItemTranDAL.InsertOrderItemTran(SqlCon, SqlTran);

                        OrderItemTranId = objOrderItemTranDAL.OrderItemTranId;
                    }
                    else if (item.ItemType == poswItemType.Modifier.GetHashCode())
                    {
                        objOrderItemModifierTranDAL = new poswOrderItemModifierTranDAL();
                        objOrderItemModifierTranDAL.linktoOrderItemTranId = OrderItemTranId;
                        objOrderItemModifierTranDAL.linktoItemMasterModifierId = item.linktoItemMasterIdModifier;
                        objOrderItemModifierTranDAL.Rate = item.Rate;
                        rs = objOrderItemModifierTranDAL.InsertOrderItemModifierTran(SqlCon, SqlTran);
                    }

                    if (rs != poswRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                foreach (poswOrderTaxTranDAL objOrderTaxTranDAL in lstOrderTaxTranDAL)
                {
                    objOrderTaxTranDAL.linktoOrderMasterId = this.OrderMasterId;
                    rs = objOrderTaxTranDAL.InsertOrderTaxTran(SqlCon, SqlTran);
                    if (rs != poswRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateOrderMaster(List<poswItemMasterDAL> lstItemMasterDAL, List<poswOrderTaxTranDAL> lstOrderTaxTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswOrderMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterId", SqlDbType.BigInt).Value = this.OrderMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@TotalItemPoint", SqlDbType.SmallInt).Value = this.TotalItemPoint;
                SqlCmd.Parameters.Add("@TotalDeductedPoint", SqlDbType.SmallInt).Value = this.TotalDeductedPoint;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != poswRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                poswOrderItemTranDAL objOrderItemTranDAL = null;
                poswOrderItemModifierTranDAL objOrderItemModifierTranDAL = null;
                long OrderItemTranId = 0;
                foreach (var item in lstItemMasterDAL)
                {
                    if (item.ItemType == poswItemType.Item.GetHashCode())
                    {
                        objOrderItemTranDAL = new poswOrderItemTranDAL();
                        objOrderItemTranDAL.linktoOrderMasterId = this.OrderMasterId;
                        objOrderItemTranDAL.linktoItemMasterId = item.ItemMasterId;
                        objOrderItemTranDAL.Quantity = Convert.ToInt16(item.Quentity);
                        objOrderItemTranDAL.Rate = item.Rate;
                        objOrderItemTranDAL.ItemPoint = item.ItemPoint;
                        objOrderItemTranDAL.DeductedPoint = 00;
                        objOrderItemTranDAL.ItemRemark = item.Remark;
                        objOrderItemTranDAL.TotalRate = item.TotalAmount;
                        rs = objOrderItemTranDAL.InsertOrderItemTran(SqlCon, sqlTran);

                        OrderItemTranId = objOrderItemTranDAL.OrderItemTranId;
                    }
                    else if (item.ItemType == poswItemType.Modifier.GetHashCode())
                    {
                        objOrderItemModifierTranDAL = new poswOrderItemModifierTranDAL();
                        objOrderItemModifierTranDAL.linktoOrderItemTranId = OrderItemTranId;
                        objOrderItemModifierTranDAL.linktoItemMasterModifierId = item.linktoItemMasterIdModifier;
                        objOrderItemModifierTranDAL.Rate = item.Rate;
                        rs = objOrderItemModifierTranDAL.InsertOrderItemModifierTran(SqlCon, sqlTran);
                    }

                    if (rs != poswRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                foreach (poswOrderTaxTranDAL objOrderTaxTranDAL in lstOrderTaxTranDAL)
                {
                    objOrderTaxTranDAL.linktoOrderMasterId = this.OrderMasterId;
                    rs = objOrderTaxTranDAL.InsertOrderTaxTran(SqlCon, sqlTran);
                    if (rs != poswRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;

            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }

        public poswRecordStatus UpdateOrderMasterTableMasterIds(SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {

                SqlCmd = new SqlCommand("poswOrderMasterTableMasterIds_Update", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;

            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Select
        public bool SelectOrderMasterDailyWeeklyMonthlyOrders()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterDailyWeeklyMonthlyOrders_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                while (SqlRdr.Read())
                {

                    if (SqlRdr["DailyOrder"] != DBNull.Value)
                    {
                        this.DailyOrder = Convert.ToDouble(SqlRdr["DailyOrder"]);
                    }
                    if (SqlRdr["WeeklyOrder"] != DBNull.Value)
                    {
                        this.WeeklyOrder = Convert.ToDouble(SqlRdr["WeeklyOrder"]);
                    }
                    if (SqlRdr["MonthlyOrder"] != DBNull.Value)
                    {
                        this.MonthlyOrder = Convert.ToDouble(SqlRdr["MonthlyOrder"]);
                    }
                    return true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return false;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectOrderMasterLeastSellingDayOfLastWeek(DateTime? FromDate, DateTime? CurrentDate, bool IsDateRange) 
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterLeastSellingDay_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CancelOrderStatus", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                if (FromDate != null)
                {
                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                }
                if (CurrentDate != null)
                {
                    SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = CurrentDate;
                }
                else
                {
                    SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                }
                SqlCmd.Parameters.Add("@IsDateRange", SqlDbType.Bit).Value = IsDateRange;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                while (SqlRdr.Read())
                {
                    this.OrderDateTimeString = Convert.ToString(SqlRdr["OrderDate"]);
                    this.LeastSellingDayName = Convert.ToString(SqlRdr["theDayName"]);
                    this.NetAmount = Convert.ToDouble(SqlRdr["SellingAmt"]);
                    return true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return false;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswOrderMasterDAL> SelectAllOrderMasterPageWise(short startRowIndex, short pageSize, bool IsCancelled, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderNumber", SqlDbType.VarChar).Value = this.OrderNumber;
                if (this.linktoOrderTypeMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                }
                SqlCmd.Parameters.Add("@OrderDateTime", SqlDbType.DateTime).Value = this.OrderDateTime;
                SqlCmd.Parameters.Add("@OrderToDateTime", SqlDbType.DateTime).Value = this.OrderToDateTime;
                SqlCmd.Parameters.Add("@IsPreOrder", SqlDbType.Bit).Value = this.IsPreOrder;
                SqlCmd.Parameters.Add("@IsCancelled", SqlDbType.Bit).Value = IsCancelled;
                if (this.linktoOrderStatusMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                poswOrderMasterDAL objOrderMasterDAL = null;
                List<poswOrderMasterDAL> lstOrderMasterDAL = new List<poswOrderMasterDAL>();
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new poswOrderMasterDAL();

                    objOrderMasterDAL.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    objOrderMasterDAL.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    objOrderMasterDAL.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]);
                    objOrderMasterDAL.User = Convert.ToString(SqlRdr["Customer"]);
                    objOrderMasterDAL.Phone = Convert.ToString(SqlRdr["CustomerPhone"]);
                    objOrderMasterDAL.Email = Convert.ToString(SqlRdr["CustomerEmail"]);
                    objOrderMasterDAL.linktoOrderTypeMasterId = Convert.ToInt16(SqlRdr["linktoOrderTypeMasterId"]);
                    objOrderMasterDAL.linktoCustomerMasterId = Convert.ToInt16(SqlRdr["linktoCustomerMasterId"]);
                    objOrderMasterDAL.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    objOrderMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    objOrderMasterDAL.TotalTax = Convert.ToDouble(SqlRdr["TotalTax"]);
                    objOrderMasterDAL.Discount = Convert.ToDouble(SqlRdr["Discount"]);
                    objOrderMasterDAL.ExtraAmount = Convert.ToDouble(SqlRdr["ExtraAmount"]);
                    objOrderMasterDAL.TotalItemPoint = Convert.ToInt16(SqlRdr["TotalItemPoint"]);
                    objOrderMasterDAL.TotalDeductedPoint = Convert.ToInt16(SqlRdr["TotalDeductedPoint"]);
                    objOrderMasterDAL.Remark = Convert.ToString(SqlRdr["Remark"]);
                    objOrderMasterDAL.IsPreOrder = Convert.ToBoolean(SqlRdr["IsPreOrder"]);
                    if (SqlRdr["linktoSalesMasterId"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoSalesMasterId = Convert.ToInt64(SqlRdr["linktoSalesMasterId"]);
                    }
                    objOrderMasterDAL.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
                    if (SqlRdr["UpdateDateTime"] != DBNull.Value)
                    {
                        objOrderMasterDAL.UpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
                    }
                    if (SqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoOrderStatusMasterId = Convert.ToInt16(SqlRdr["linktoOrderStatusMasterId"]);
                    }
                    objOrderMasterDAL.OrderStatus = Convert.ToString(SqlRdr["OrderStatus"]);
                    if (SqlRdr["OrderPaymentCount"] != DBNull.Value && Convert.ToInt32(SqlRdr["OrderPaymentCount"]) > 0 || IsCancelled)
                    {
                        objOrderMasterDAL.IsPreOrder = true;
                    }
                    else
                    {
                        objOrderMasterDAL.IsPreOrder = false;
                    }
                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOrderMasterDAL> SelectAllOrderMasterByCustomerIdPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterByCustomerMasterIdPageWise_SelectAll", SqlCon);

                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.SmallInt).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                poswOrderMasterDAL objOrderMasterDAL = null;
                List<poswOrderMasterDAL> lstOrderMasterDAL = new List<poswOrderMasterDAL>();
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new poswOrderMasterDAL();
                    objOrderMasterDAL.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    objOrderMasterDAL.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    objOrderMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    objOrderMasterDAL.TotalTax = Convert.ToDouble(SqlRdr["TotalTax"]);
                    objOrderMasterDAL.NetAmount = Convert.ToInt16(SqlRdr["NetAmount"]);
                    objOrderMasterDAL.PaidAmount = Convert.ToInt16(SqlRdr["PaidAmount"]);
                    objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    objOrderMasterDAL.linktoCustomerMasterId = Convert.ToInt16(SqlRdr["linktoCustomerMasterId"]);
                    objOrderMasterDAL.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]);

                    ///IsPreOrder is used whether any amount is paid or not for Order (Android)
                    if (SqlRdr["OrderPaymentCount"] != DBNull.Value && Convert.ToInt32(SqlRdr["OrderPaymentCount"]) > 0)
                    {
                        objOrderMasterDAL.IsPreOrder = true;
                    }
                    else
                    {
                        objOrderMasterDAL.IsPreOrder = false;
                    }

                    if (SqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoOrderStatusMasterId = Convert.ToInt16(SqlRdr["linktoOrderStatusMasterId"]);
                    }
                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }

        }

        public static List<poswOrderMasterDAL> SelectAllOrderMasterOrderNumber()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterOrderNumber_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderMasterDAL> lstOrderMasterDAL = new List<poswOrderMasterDAL>();
                poswOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new poswOrderMasterDAL();
                    objOrderMasterDAL.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    objOrderMasterDAL.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswOrderMasterDAL> SelectAllOrderTypeOrderTypeName(short linktoBusinessTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderTypeOrderTypeName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = linktoBusinessTypeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderMasterDAL> lstOrderMasterDAL = new List<poswOrderMasterDAL>();
                poswOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new poswOrderMasterDAL();
                    objOrderMasterDAL.OrderTypeMasterId = Convert.ToInt16(SqlRdr["OrderTypeMasterId"]);
                    objOrderMasterDAL.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswOrderMasterDAL> SelectAllOrderStatusByStatusName(short linktoBusinessTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderStatusStatusName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = linktoBusinessTypeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderMasterDAL> lstOrderMasterDAL = new List<poswOrderMasterDAL>();
                poswOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new poswOrderMasterDAL();
                    objOrderMasterDAL.OrderStatusMasterId = Convert.ToInt16(SqlRdr["OrderStatusMasterId"]);
                    objOrderMasterDAL.StatusName = Convert.ToString(SqlRdr["StatusName"]);
                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOrderMasterDAL> SelectAllOrderMasterOrderTypeWiseChart()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterOrderTypeWiseChart_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = poswGlobalsDAL.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = poswGlobalsDAL.ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderMasterDAL> lstSalesMasterDAL = new List<poswOrderMasterDAL>();
                poswOrderMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new poswOrderMasterDAL();
                    objSalesMasterDAL.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    objSalesMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["OrdersInPercentage"]);
                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOrderMasterDAL> SelectAllOrderMasterDateWise(DateTime FromDate, DateTime ToDate, int startRowIndex, int pageSize, out int totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterDateWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (FromDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = FromDate;
                }
                if (ToDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = ToDate;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.Int).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderMasterDAL> lstOrderMasterDAL = new List<poswOrderMasterDAL>();
                poswOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new poswOrderMasterDAL();
                    objOrderMasterDAL.OrderDateTimeString = Convert.ToDateTime(SqlRdr["OrderDateTime"]).ToShortDateString();
                    objOrderMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["ToatlAmount"]);
                    objOrderMasterDAL.Discount = Convert.ToDouble(SqlRdr["Discount"]);
                    objOrderMasterDAL.TotalTax = Convert.ToDouble(SqlRdr["TotalTax"]);
                    objOrderMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmont"]);
                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();
                totalRecords = (int)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOrderMasterDAL> SelectAllOrderMasterYearlyRevenueChart(string year)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterYearlyRevenue_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = year;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderMasterDAL> lstSalesMasterDAL = new List<poswOrderMasterDAL>();
                poswOrderMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new poswOrderMasterDAL();
                    objSalesMasterDAL.Month = Convert.ToString(SqlRdr["months"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["Revenue"]);
                    objSalesMasterDAL.Year = Convert.ToString(SqlRdr["years"]);
                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

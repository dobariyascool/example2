using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswUnitMaster
	/// </summary>
	public class poswUnitMasterDAL
	{
		#region Properties
		public short UnitMasterId { get; set; }
		public string ShortName { get; set; }
		public string UnitName { get; set; }
		public string Description { get; set; }
		public short linktoBusinessMasterId { get; set; }
		public bool IsEnabled { get; set; }
		public bool IsDeleted { get; set; }

		/// Extra
		public string Business { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.UnitMasterId = Convert.ToInt16(sqlRdr["UnitMasterId"]);
				this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
				this.UnitName = Convert.ToString(sqlRdr["UnitName"]);
				this.Description = Convert.ToString(sqlRdr["Description"]);
				this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

				return true;
			}
			return false;
		}

		private List<poswUnitMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswUnitMasterDAL> lstUnitMaster = new List<poswUnitMasterDAL>();
			poswUnitMasterDAL objUnitMaster = null;
			while (sqlRdr.Read())
			{
				objUnitMaster = new poswUnitMasterDAL();
				objUnitMaster.UnitMasterId = Convert.ToInt16(sqlRdr["UnitMasterId"]);
				objUnitMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
				objUnitMaster.UnitName = Convert.ToString(sqlRdr["UnitName"]);
				objUnitMaster.Description = Convert.ToString(sqlRdr["Description"]);
				objUnitMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				objUnitMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				objUnitMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

				lstUnitMaster.Add(objUnitMaster);
			}
			return lstUnitMaster;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertUnitMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswUnitMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@UnitMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
				SqlCmd.Parameters.Add("@UnitName", SqlDbType.VarChar).Value = this.UnitName;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.UnitMasterId = Convert.ToInt16(SqlCmd.Parameters["@UnitMasterId"].Value);
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public poswRecordStatus UpdateUnitMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswUnitMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@UnitMasterId", SqlDbType.SmallInt).Value = this.UnitMasterId;
				SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
				SqlCmd.Parameters.Add("@UnitName", SqlDbType.VarChar).Value = this.UnitName;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public poswRecordStatus DeleteUnitMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswUnitMaster_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@UnitMasterId", SqlDbType.SmallInt).Value = this.UnitMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectUnitMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswUnitMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@UnitMasterId", SqlDbType.SmallInt).Value = this.UnitMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<poswUnitMasterDAL> SelectAllUnitMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswUnitMasterPageWise_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
				SqlCmd.Parameters.Add("@UnitName", SqlDbType.VarChar).Value = this.UnitName;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

				SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
				SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
				SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswUnitMasterDAL> lstUnitMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
				return lstUnitMasterDAL;
			}
			catch (Exception ex)
			{
				totalRecords = 0;
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public static List<poswUnitMasterDAL> SelectAllUnitMasterUnitName()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUnitMasterUnitName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswUnitMasterDAL> lstUnitMasterDAL = new List<poswUnitMasterDAL>();
                poswUnitMasterDAL objUnitMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objUnitMasterDAL = new poswUnitMasterDAL();
                    objUnitMasterDAL.UnitMasterId = Convert.ToInt16(SqlRdr["UnitMasterId"]);
                    objUnitMasterDAL.UnitName = Convert.ToString(SqlRdr["UnitName"]);
                    lstUnitMasterDAL.Add(objUnitMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstUnitMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
		#endregion
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace poswLibrary
{
    public class poswDashboardDAL
    {
        public int linktoBusinessMasterId { get; set; }
        public int RegisteredUserBooking { get; set; }
        public int CanceledBooking { get; set; }
        public int CanceledOrder { get; set; }

        public int PreOrder { get; set; } 

        #region SelectAll Methods

        public bool SelectDashBoardCounter()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswDashboardCounter_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@BookingStatusCanceled", SqlDbType.SmallInt).Value = poswBookingStatus.Canceled.GetHashCode();
                SqlCmd.Parameters.Add("@BookingStatusNew", SqlDbType.SmallInt).Value = poswBookingStatus.New.GetHashCode();
                SqlCmd.Parameters.Add("@OrderStatus", SqlDbType.SmallInt).Value = poswOrderStatus.Canceled.GetHashCode();
                SqlCmd.Parameters.Add("@BookingFromDateTime", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@BookingToDateTime", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime().AddMonths(1);
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = poswCustomerType.Registered_User.GetHashCode();
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@CustomerBooking", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CanceledBooking", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CanceledOrder", SqlDbType.SmallInt).Direction = ParameterDirection.Output; 

                SqlCmd.Parameters.Add("@PreOrder", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                SqlRdr.Close();
                SqlCon.Close();

                this.RegisteredUserBooking = Convert.ToInt16(SqlCmd.Parameters["@CustomerBooking"].Value);
                this.CanceledBooking = Convert.ToInt16(SqlCmd.Parameters["@CanceledBooking"].Value); 
                this.CanceledOrder = Convert.ToInt16(SqlCmd.Parameters["@CanceledOrder"].Value);
                this.PreOrder = Convert.ToInt16(SqlCmd.Parameters["@PreOrder"].Value);

                return true;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion
    }
}

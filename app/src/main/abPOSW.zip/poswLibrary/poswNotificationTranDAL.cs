using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswNotificationTran
	/// </summary>
	public class poswNotificationTranDAL
	{
		#region Properties
		public long NotificationTranId { get; set; }
		public int linktoNotificationMasterId { get; set; }
		public int linktoCustomerMasterId { get; set; }
		public DateTime ReadDateTime { get; set; }

		/// Extra
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.NotificationTranId = Convert.ToInt64(sqlRdr["NotificationTranId"]);
				this.linktoNotificationMasterId = Convert.ToInt32(sqlRdr["linktoNotificationMasterId"]);
				this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
				this.ReadDateTime = Convert.ToDateTime(sqlRdr["ReadDateTime"]);

				/// Extra
				return true;
			}
			return false;
		}

		private List<poswNotificationTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswNotificationTranDAL> lstNotificationTran = new List<poswNotificationTranDAL>();
			poswNotificationTranDAL objNotificationTran = null;
			while (sqlRdr.Read())
			{
				objNotificationTran = new poswNotificationTranDAL();
				objNotificationTran.NotificationTranId = Convert.ToInt64(sqlRdr["NotificationTranId"]);
				objNotificationTran.linktoNotificationMasterId = Convert.ToInt32(sqlRdr["linktoNotificationMasterId"]);
				objNotificationTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
				objNotificationTran.ReadDateTime = Convert.ToDateTime(sqlRdr["ReadDateTime"]);

				/// Extra
				lstNotificationTran.Add(objNotificationTran);
			}
			return lstNotificationTran;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswNotificationTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoNotificationMasterId", SqlDbType.Int).Value = this.linktoNotificationMasterId;
				SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
				SqlCmd.Parameters.Add("@ReadDateTime", SqlDbType.DateTime).Value = this.ReadDateTime;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.NotificationTranId = Convert.ToInt64(SqlCmd.Parameters["@NotificationTranId"].Value);
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public poswRecordStatus UpdateNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswNotificationTran_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationTranId", SqlDbType.BigInt).Value = this.NotificationTranId;
				SqlCmd.Parameters.Add("@linktoNotificationMasterId", SqlDbType.Int).Value = this.linktoNotificationMasterId;
				SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
				SqlCmd.Parameters.Add("@ReadDateTime", SqlDbType.DateTime).Value = this.ReadDateTime;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswNotificationTran_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationTranId", SqlDbType.BigInt).Value = this.NotificationTranId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<poswNotificationTranDAL> SelectAllNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswNotificationTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswNotificationTranDAL> lstNotificationTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstNotificationTranDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

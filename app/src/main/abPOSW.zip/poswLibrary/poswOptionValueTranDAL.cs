using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswOptionValueTran
    /// </summary>

    [Serializable]
    public class poswOptionValueTranDAL
    {
        #region Properties
        public int OptionValueTranId { get; set; }
        public short linktoOptionMasterId { get; set; }
        public string OptionValue { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDeleted { get; set; }

        public string OptionName { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.OptionValueTranId = Convert.ToInt32(sqlRdr["OptionValueTranId"]);
                this.linktoOptionMasterId = Convert.ToInt16(sqlRdr["linktoOptionMasterId"]);
                this.OptionValue = Convert.ToString(sqlRdr["OptionValue"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                this.OptionName = Convert.ToString(sqlRdr["OptionName"]);
                return true;
            }
            return false;
        }

        private List<poswOptionValueTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswOptionValueTranDAL> lstOptionValueTran = new List<poswOptionValueTranDAL>();
            poswOptionValueTranDAL objOptionValueTran = null;
            while (sqlRdr.Read())
            {
                objOptionValueTran = new poswOptionValueTranDAL();
                objOptionValueTran.OptionValueTranId = Convert.ToInt32(sqlRdr["OptionValueTranId"]);
                objOptionValueTran.linktoOptionMasterId = Convert.ToInt16(sqlRdr["linktoOptionMasterId"]);
                objOptionValueTran.OptionValue = Convert.ToString(sqlRdr["OptionValue"]);
                objOptionValueTran.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objOptionValueTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                objOptionValueTran.OptionName = Convert.ToString(sqlRdr["OptionName"]);
                lstOptionValueTran.Add(objOptionValueTran);
            }
            return lstOptionValueTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertOptionValueTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOptionValueTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OptionValueTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOptionMasterId", SqlDbType.SmallInt).Value = this.linktoOptionMasterId;
                SqlCmd.Parameters.Add("@OptionValue", SqlDbType.VarChar).Value = this.OptionValue;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.OptionValueTranId = Convert.ToInt32(SqlCmd.Parameters["@OptionValueTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus InsertOptionValueTran(List<poswOptionValueTranDAL> lstOptionValueTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            StringBuilder sbValues = new StringBuilder();
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswOptionValueTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                poswRecordStatus rs = poswRecordStatus.Error;
                foreach (poswOptionValueTranDAL obj in lstOptionValueTranDAL)
                {
                    SqlCmd.Parameters.Add("@OptionValueTranId", SqlDbType.Int).Value = obj.OptionValueTranId;
                    SqlCmd.Parameters.Add("@linktoOptionMasterId", SqlDbType.SmallInt).Value = obj.linktoOptionMasterId;
                    SqlCmd.Parameters.Add("@OptionValue", SqlDbType.VarChar).Value = obj.OptionValue;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = obj.IsDeleted;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;                   
                    SqlCmd.ExecuteNonQuery();
                    this.OptionValueTranId = Convert.ToInt32(SqlCmd.Parameters["@OptionValueTranId"].Value);
                    rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == poswRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                    if (rs == poswRecordStatus.RecordAlreadyExist)
                    {
                        sbValues.Append(obj.OptionValue + ", ");
                    }
                    SqlCmd.Parameters.Clear();
                }
                if (sbValues.Length > 0)
                {
                    sbValues.Length -= 2;
                    this.OptionValue = Convert.ToString(sbValues);
                    SqlTran.Commit();
                    SqlCon.Close();
                    return poswRecordStatus.RecordAlreadyExist;
                }
                this.OptionValue = Convert.ToString(sbValues);
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteOptionValueTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOptionValueTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OptionValueTranId", SqlDbType.Int).Value = this.OptionValueTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public static List<poswOptionValueTranDAL> SelectAllOptionValueTranOptionName(short linktoOptionMasterId, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOptionValueTranByOption_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOptionMasterId", SqlDbType.SmallInt).Value = linktoOptionMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOptionValueTranDAL> lstOptionValueTranDAL = new List<poswOptionValueTranDAL>();
                poswOptionValueTranDAL objOptionValueTranDAL = null;
                while (SqlRdr.Read())
                {
                    objOptionValueTranDAL = new poswOptionValueTranDAL();
                    objOptionValueTranDAL.OptionValueTranId = Convert.ToInt16(SqlRdr["OptionValueTranId"]);
                    objOptionValueTranDAL.linktoOptionMasterId = Convert.ToInt16(SqlRdr["linktoOptionMasterId"]);
                    objOptionValueTranDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    objOptionValueTranDAL.OptionValue = Convert.ToString(SqlRdr["OptionValue"]);
                    lstOptionValueTranDAL.Add(objOptionValueTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOptionValueTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOptionValueTranDAL> SelectAllOptionValueTranByItemMasterId(int linktoItemMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOptionValueTranByItemMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = linktoItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOptionValueTranDAL> lstOptionValueTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOptionValueTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswAreaMaster
    /// </summary>
    public class poswAreaMasterDAL
    {
        #region Properties
        public short AreaMasterId { get; set; }
        public string AreaName { get; set; }
        public string ZipCode { get; set; }
        public short linktoCityMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string City { get; set; }
        public short StateMasterId { get; set; }
        public short CityMasterId { get; set; }
        public short linktoCountryMasterId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.AreaMasterId = Convert.ToInt16(sqlRdr["AreaMasterId"]);
                this.AreaName = Convert.ToString(sqlRdr["AreaName"]);
                this.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                this.linktoCityMasterId = Convert.ToInt16(sqlRdr["linktoCityMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                ///// Extra 
                this.CityMasterId = Convert.ToInt16(sqlRdr["CityMasterId"]);
                this.StateMasterId = Convert.ToInt16(sqlRdr["StateMasterId"]);
                this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                return true;
            }
            return false;
        }

        private List<poswAreaMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswAreaMasterDAL> lstAreaMaster = new List<poswAreaMasterDAL>();
            poswAreaMasterDAL objAreaMaster = null;
            while (sqlRdr.Read())
            {
                objAreaMaster = new poswAreaMasterDAL();
                objAreaMaster.AreaMasterId = Convert.ToInt16(sqlRdr["AreaMasterId"]);
                objAreaMaster.AreaName = Convert.ToString(sqlRdr["AreaName"]);
                objAreaMaster.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                objAreaMaster.linktoCityMasterId = Convert.ToInt16(sqlRdr["linktoCityMasterId"]);
                objAreaMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objAreaMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objAreaMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objAreaMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objAreaMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objAreaMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                /// Extra
                objAreaMaster.City = Convert.ToString(sqlRdr["City"]);

                lstAreaMaster.Add(objAreaMaster);
            }
            return lstAreaMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertAreaMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAreaMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@AreaName", SqlDbType.VarChar).Value = this.AreaName;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.AreaMasterId = Convert.ToInt16(SqlCmd.Parameters["@AreaMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateAreaMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAreaMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaMasterId", SqlDbType.SmallInt).Value = this.AreaMasterId;
                SqlCmd.Parameters.Add("@AreaName", SqlDbType.VarChar).Value = this.AreaName;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteAreaMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAreaMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaMasterId", SqlDbType.SmallInt).Value = this.AreaMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectAreaMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAreaMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaMasterId", SqlDbType.SmallInt).Value = this.AreaMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswAreaMasterDAL> SelectAllAreaMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAreaMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaName", SqlDbType.VarChar).Value = this.AreaName;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswAreaMasterDAL> lstAreaMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstAreaMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswAreaMasterDAL> SelectAllAreaMasterAreaNameByCity(int linktoCityMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAreaMasterCityWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = linktoCityMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswAreaMasterDAL> lstAreaMasterDAL = new List<poswAreaMasterDAL>();
                poswAreaMasterDAL objAreaMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objAreaMasterDAL = new poswAreaMasterDAL();
                    objAreaMasterDAL.AreaMasterId = Convert.ToInt16(SqlRdr["AreaMasterId"]);
                    objAreaMasterDAL.AreaName = Convert.ToString(SqlRdr["AreaName"]);
                    lstAreaMasterDAL.Add(objAreaMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstAreaMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswAreaMasterDAL> SelectAllAreaMasterAreaName()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAreaMasterAreaName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswAreaMasterDAL> lstAreaMasterDAL = new List<poswAreaMasterDAL>();
                poswAreaMasterDAL objAreaMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objAreaMasterDAL = new poswAreaMasterDAL();
                    objAreaMasterDAL.AreaMasterId = Convert.ToInt16(SqlRdr["AreaMasterId"]);
                    objAreaMasterDAL.AreaName = Convert.ToString(SqlRdr["AreaName"]);
                    lstAreaMasterDAL.Add(objAreaMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstAreaMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

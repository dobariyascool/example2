using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswCustomerAddressTran
    /// </summary>
    /// 
    [Serializable]
    public class poswCustomerAddressTranDAL
    {
        #region Properties
        public int CustomerAddressTranId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string CustomerName { get; set; }
        public short AddressType { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public short? linktoCountryMasterId { get; set; }
        public short? linktoStateMasterId { get; set; }
        public short? linktoCityMasterId { get; set; }
        public short? linktoAreaMasterId { get; set; }
        public string ZipCode { get; set; }
        public bool IsPrimary { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short? linktoUserMasterIdCreatedBy { get; set; }
        public bool IsDeleted { get; set; }

        /// Extra
        public int TempCustomerAddressTranId { get; set; }
        public string Customer { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
        public string Email { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.CustomerAddressTranId = Convert.ToInt32(sqlRdr["CustomerAddressTranId"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                if (sqlRdr["CustomerName"] != DBNull.Value)
                {
                    this.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                }
                if (sqlRdr["AddressType"] != DBNull.Value)
                {
                    this.AddressType = Convert.ToInt16(sqlRdr["AddressType"]);
                }
                if (sqlRdr["Phone"] != DBNull.Value)
                {
                    this.Phone = Convert.ToString(sqlRdr["Phone"]);
                }
                this.Address = Convert.ToString(sqlRdr["Address"]);
                if (sqlRdr["linktoCountryMasterId"] != DBNull.Value)
                {
                    this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                }
                if (sqlRdr["linktoStateMasterId"] != DBNull.Value)
                {
                    this.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                }
                if (sqlRdr["linktoCityMasterId"] != DBNull.Value)
                {
                    this.linktoCityMasterId = Convert.ToInt16(sqlRdr["linktoCityMasterId"]);
                }
                if (sqlRdr["linktoAreaMasterId"] != DBNull.Value)
                {
                    this.linktoAreaMasterId = Convert.ToInt16(sqlRdr["linktoAreaMasterId"]);
                }
                this.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                this.IsPrimary = Convert.ToBoolean(sqlRdr["IsPrimary"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdCreatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                }
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                this.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                this.Country = Convert.ToString(sqlRdr["Country"]);
                this.State = Convert.ToString(sqlRdr["State"]);
                this.City = Convert.ToString(sqlRdr["City"]);
                this.Area = Convert.ToString(sqlRdr["Area"]);
                return true;
            }
            return false;
        }

        private List<poswCustomerAddressTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswCustomerAddressTranDAL> lstCustomerAddressTran = new List<poswCustomerAddressTranDAL>();
            poswCustomerAddressTranDAL objCustomerAddressTran = null;
            int TempCustomerAddressTranId = 1;
            while (sqlRdr.Read())
            {
                objCustomerAddressTran = new poswCustomerAddressTranDAL();
                objCustomerAddressTran.CustomerAddressTranId = Convert.ToInt32(sqlRdr["CustomerAddressTranId"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                objCustomerAddressTran.Address = Convert.ToString(sqlRdr["Address"]);
                if (sqlRdr["AddressType"] != DBNull.Value)
                {
                    objCustomerAddressTran.AddressType = Convert.ToInt16(sqlRdr["AddressType"]);
                }
                if (sqlRdr["CustomerName"] != DBNull.Value)
                {
                    objCustomerAddressTran.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                }
                if (sqlRdr["linktoCountryMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                }
                if (sqlRdr["linktoStateMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                }
                if (sqlRdr["linktoCityMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoCityMasterId = Convert.ToInt16(sqlRdr["linktoCityMasterId"]);
                }
                if (sqlRdr["linktoAreaMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoAreaMasterId = Convert.ToInt16(sqlRdr["linktoAreaMasterId"]);
                }
                objCustomerAddressTran.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                if (sqlRdr["Phone"] != DBNull.Value)
                {
                    objCustomerAddressTran.Phone = Convert.ToString(sqlRdr["Phone"]);
                }
                objCustomerAddressTran.IsPrimary = Convert.ToBoolean(sqlRdr["IsPrimary"]);
                objCustomerAddressTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdCreatedBy"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                }
                objCustomerAddressTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                if (sqlRdr["Country"] != DBNull.Value)
                {
                    objCustomerAddressTran.Country = Convert.ToString(sqlRdr["Country"]);
                }
                if (sqlRdr["State"] != DBNull.Value)
                {
                    objCustomerAddressTran.State =  ", " + Convert.ToString(sqlRdr["State"]);
                }
                if (sqlRdr["City"] != DBNull.Value)
                {
                    objCustomerAddressTran.City = ", " + Convert.ToString(sqlRdr["City"]);
                }
                if (sqlRdr["Area"] != DBNull.Value)
                {
                    objCustomerAddressTran.Area =  Convert.ToString(sqlRdr["Area"]);
                }
                if (sqlRdr["Phone"] != DBNull.Value)
                {
                    objCustomerAddressTran.Phone = Convert.ToString(sqlRdr["Phone"]);
                }
                if (sqlRdr["Email"] != DBNull.Value)
                {
                    objCustomerAddressTran.Email = Convert.ToString(sqlRdr["Email"]);
                }
                if (sqlRdr["CustomerName"] != DBNull.Value)
                {
                    objCustomerAddressTran.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                }
                objCustomerAddressTran.TempCustomerAddressTranId = TempCustomerAddressTranId;
                lstCustomerAddressTran.Add(objCustomerAddressTran);
                TempCustomerAddressTranId++;
            }
            return lstCustomerAddressTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertCustomerAddressTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerAddressTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerAddressTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                if (this.linktoCustomerMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                }
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@AddressType", SqlDbType.SmallInt).Value = this.AddressType;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.SmallInt).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@IsPrimary", SqlDbType.Bit).Value = this.IsPrimary;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                if (this.linktoUserMasterIdCreatedBy > 0)
                {
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                }
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.CustomerAddressTranId = Convert.ToInt32(SqlCmd.Parameters["@CustomerAddressTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus InsertCustomerAddressTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswCustomerAddressTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerAddressTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@AddressType", SqlDbType.SmallInt).Value = this.AddressType;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.SmallInt).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@IsPrimary", SqlDbType.Bit).Value = this.IsPrimary;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.CustomerAddressTranId = Convert.ToInt32(SqlCmd.Parameters["@CustomerAddressTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update

        public poswRecordStatus UpdateCustomerAddressTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswCustomerAddressTran_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerAddressTranId", SqlDbType.Int).Value = this.CustomerAddressTranId;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@AddressType", SqlDbType.SmallInt).Value = this.AddressType;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.SmallInt).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@IsPrimary", SqlDbType.Bit).Value = this.IsPrimary;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public poswRecordStatus UpdateCustomerAddressTran()
        {
            SqlCommand SqlCmd = null;
            SqlConnection SqlCon = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerAddressTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerAddressTranId", SqlDbType.Int).Value = this.CustomerAddressTranId;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@AddressType", SqlDbType.SmallInt).Value = this.AddressType;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.SmallInt).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@IsPrimary", SqlDbType.Bit).Value = this.IsPrimary;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteCustomerAddressTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerAddressTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerAddressTranId", SqlDbType.Int).Value = this.CustomerAddressTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCustomerAddressTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerAddressTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerAddressTranId", SqlDbType.Int).Value = this.CustomerAddressTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswCustomerAddressTranDAL> SelectAllCustomerAddressTranPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerAddressTranPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.SmallInt).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCustomerAddressTranDAL> lstCustomerAddressTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstCustomerAddressTranDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswCustomerAddressTranDAL> SelectAllCustomerAddressTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;

            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerAddressTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCustomerAddressTranDAL> lstCustomerAddressTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();
                return lstCustomerAddressTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }

        }
        #endregion
    }
}

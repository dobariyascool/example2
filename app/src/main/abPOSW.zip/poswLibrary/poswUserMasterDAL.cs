﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    public class poswUserMasterDAL
    {
        #region Properties
        public short UserMasterId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public short linktoRoleMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public DateTime? LastLoginDateTime { get; set; }
        public short LoginFailCount { get; set; }
        public DateTime? LastLockoutDateTime { get; set; }
        public DateTime? LastPasswordChangedDateTime { get; set; }
        public string Comment { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? linktoBusinessGroupMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        public string FCMToken { get; set; }

        //Extra
        public string Role { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.UserMasterId = Convert.ToInt16(sqlRdr["UserMasterId"]);
                this.Username = Convert.ToString(sqlRdr["Username"]);
                this.Password = Convert.ToString(sqlRdr["Password"]);
                this.linktoRoleMasterId = Convert.ToInt16(sqlRdr["linktoRoleMasterId"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["LastLoginDateTime"] != DBNull.Value)
                {
                    this.LastLoginDateTime = Convert.ToDateTime(sqlRdr["LastLoginDateTime"]);
                }
                this.LoginFailCount = Convert.ToInt16(sqlRdr["LoginFailCount"]);
                if (sqlRdr["LastLockoutDateTime"] != DBNull.Value)
                {
                    this.LastLockoutDateTime = Convert.ToDateTime(sqlRdr["LastLockoutDateTime"]);
                }
                if (sqlRdr["LastPasswordChangedDateTime"] != DBNull.Value)
                {
                    this.LastPasswordChangedDateTime = Convert.ToDateTime(sqlRdr["LastPasswordChangedDateTime"]);
                }
                if (sqlRdr["Comment"] != DBNull.Value)
                {
                    this.Comment = Convert.ToString(sqlRdr["Comment"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["BusinessTypeMasterId"] != DBNull.Value)
                {
                    this.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["BusinessTypeMasterId"]);
                }
                if (sqlRdr["BusinessGroupMasterId"] != DBNull.Value)
                {
                    this.linktoBusinessGroupMasterId = Convert.ToInt16(sqlRdr["BusinessGroupMasterId"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                this.Role = Convert.ToString(sqlRdr["Role"]);
             
                return true;
            }
            return false;
        }

        private List<poswUserMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswUserMasterDAL> lstUserMaster = new List<poswUserMasterDAL>();
            poswUserMasterDAL objUserMaster = null;
            while (sqlRdr.Read())
            {
                objUserMaster = new poswUserMasterDAL();
                objUserMaster.UserMasterId = Convert.ToInt16(sqlRdr["UserMasterId"]);
                objUserMaster.Username = Convert.ToString(sqlRdr["Username"]);
                objUserMaster.Password = Convert.ToString(sqlRdr["Password"]);
                objUserMaster.linktoRoleMasterId = Convert.ToInt16(sqlRdr["linktoRoleMasterId"]);
                objUserMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objUserMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objUserMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objUserMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["LastLoginDateTime"] != DBNull.Value)
                {
                    objUserMaster.LastLoginDateTime = Convert.ToDateTime(sqlRdr["LastLoginDateTime"]);
                }
                objUserMaster.LoginFailCount = Convert.ToInt16(sqlRdr["LoginFailCount"]);
                if (sqlRdr["LastLockoutDateTime"] != DBNull.Value)
                {
                    objUserMaster.LastLockoutDateTime = Convert.ToDateTime(sqlRdr["LastLockoutDateTime"]);
                }
                if (sqlRdr["LastPasswordChangedDateTime"] != DBNull.Value)
                {
                    objUserMaster.LastPasswordChangedDateTime = Convert.ToDateTime(sqlRdr["LastPasswordChangedDateTime"]);
                }
                if (sqlRdr["Comment"] != DBNull.Value)
                {
                    objUserMaster.Comment = Convert.ToString(sqlRdr["Comment"]);
                }
                objUserMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["IsEnabled"] != DBNull.Value)
                {
                    objUserMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                }
                objUserMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                if (sqlRdr["Role"] != DBNull.Value)
                {
                    objUserMaster.Role = Convert.ToString(sqlRdr["Role"]);
                }
                if (sqlRdr["FCMToken"] != DBNull.Value)
                {
                    objUserMaster.FCMToken = Convert.ToString(sqlRdr["FCMToken"]);
                }
               
                lstUserMaster.Add(objUserMaster);
            }
            return lstUserMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertUserMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Username", SqlDbType.VarChar).Value = this.Username;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@LoginFailCount", SqlDbType.SmallInt).Value = this.LoginFailCount;
                SqlCmd.Parameters.Add("@LastLockoutDateTime", SqlDbType.DateTime).Value = this.LastLockoutDateTime;
                SqlCmd.Parameters.Add("@LastPasswordChangedDateTime", SqlDbType.DateTime).Value = this.LastPasswordChangedDateTime;
                SqlCmd.Parameters.Add("@Comment", SqlDbType.VarChar).Value = this.Comment;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.UserMasterId = Convert.ToInt16(SqlCmd.Parameters["@UserMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateUserMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@Username", SqlDbType.VarChar).Value = this.Username;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@LoginFailCount", SqlDbType.SmallInt).Value = this.LoginFailCount;
                SqlCmd.Parameters.Add("@LastLockoutDateTime", SqlDbType.DateTime).Value = this.LastLockoutDateTime;
                SqlCmd.Parameters.Add("@LastPasswordChangedDateTime", SqlDbType.DateTime).Value = this.LastPasswordChangedDateTime;
                SqlCmd.Parameters.Add("@Comment", SqlDbType.VarChar).Value = this.Comment;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateUserMasterLoginFailedCount()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMasterLoginFailedCount_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateUserMasterLastLoginDateTime()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMasterLastLoginDateTime_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateUserMasterPassword()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMasterPassword_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateUserMasterFCMToken()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMasterFCMToken_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.VarChar).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@FCMToken", SqlDbType.VarChar).Value = this.FCMToken;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectUserMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectUserMasterByUsername()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMasterByUsername_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Username", SqlDbType.VarChar).Value = this.Username;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswUserMasterDAL> SelectAllUserMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = this.Username;
                if (this.linktoRoleMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswUserMasterDAL> lstUserMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstUserMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswUserMasterDAL> SelectAllUserMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserMasterByBusinessMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
            
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswUserMasterDAL> lstUserMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();
             
                return lstUserMasterDAL;
            }
            catch (Exception ex)
            {             
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswOfferTypeMaster
	/// </summary>
	public class poswOfferTypeMasterDAL
	{
		#region Properties
		public short OfferTypeMasterId { get; set; }
		public string OfferType { get; set; }
		public string Description { get; set; }

		/// Extra
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.OfferTypeMasterId = Convert.ToInt16(sqlRdr["OfferTypeMasterId"]);
				this.OfferType = Convert.ToString(sqlRdr["OfferType"]);
				this.Description = Convert.ToString(sqlRdr["Description"]);

				/// Extra
				return true;
			}
			return false;
		}

		private List<poswOfferTypeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswOfferTypeMasterDAL> lstOfferTypeMaster = new List<poswOfferTypeMasterDAL>();
			poswOfferTypeMasterDAL objOfferTypeMaster = null;
			while (sqlRdr.Read())
			{
				objOfferTypeMaster = new poswOfferTypeMasterDAL();
				objOfferTypeMaster.OfferTypeMasterId = Convert.ToInt16(sqlRdr["OfferTypeMasterId"]);
				objOfferTypeMaster.OfferType = Convert.ToString(sqlRdr["OfferType"]);
				objOfferTypeMaster.Description = Convert.ToString(sqlRdr["Description"]);

				/// Extra
				lstOfferTypeMaster.Add(objOfferTypeMaster);
			}
			return lstOfferTypeMaster;
		}
		#endregion

		#region Select
		public bool SelectOfferTypeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferTypeMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferTypeMasterId", SqlDbType.SmallInt).Value = this.OfferTypeMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<poswOfferTypeMasterDAL> SelectAllOfferTypeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferTypeMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswOfferTypeMasterDAL> lstOfferTypeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstOfferTypeMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public static List<poswOfferTypeMasterDAL> SelectAllOfferTypeMasterOfferType()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferTypeMasterOfferType_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswOfferTypeMasterDAL> lstOfferTypeMasterDAL = new List<poswOfferTypeMasterDAL>();
				poswOfferTypeMasterDAL objOfferTypeMasterDAL = null;
				while (SqlRdr.Read())
				{
					objOfferTypeMasterDAL = new poswOfferTypeMasterDAL();
					objOfferTypeMasterDAL.OfferTypeMasterId = Convert.ToInt16(SqlRdr["OfferTypeMasterId"]);
					objOfferTypeMasterDAL.OfferType = Convert.ToString(SqlRdr["OfferType"]);
					lstOfferTypeMasterDAL.Add(objOfferTypeMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstOfferTypeMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

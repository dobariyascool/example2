using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswCountryMaster
    /// </summary>
    public class poswCountryMasterDAL
    {
        #region Properties
        public short CountryMasterId { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public bool IsEnabled { get; set; }
        #endregion

        #region Class Method
        private List<poswCountryMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswCountryMasterDAL> lstCountryMaster = new List<poswCountryMasterDAL>();
            poswCountryMasterDAL objCountryMaster = null;
            while (sqlRdr.Read())
            {
                objCountryMaster = new poswCountryMasterDAL();
                objCountryMaster.CountryMasterId = Convert.ToInt16(sqlRdr["CountryMasterId"]);
                objCountryMaster.CountryName = Convert.ToString(sqlRdr["CountryName"]);
                objCountryMaster.CountryCode = Convert.ToString(sqlRdr["CountryCode"]);
                objCountryMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                lstCountryMaster.Add(objCountryMaster);
            }
            return lstCountryMaster;
        }
        #endregion

        #region SelectAll
        public List<poswCountryMasterDAL> SelectAllCountryMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCountryMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CountryName", SqlDbType.VarChar).Value = this.CountryName;
                SqlCmd.Parameters.Add("@CountryCode", SqlDbType.VarChar).Value = this.CountryCode;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCountryMasterDAL> lstCountryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstCountryMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswCountryMasterDAL> SelectAllCountryMasterCountryName()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCountryMasterCountryName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCountryMasterDAL> lstCountryMasterDAL = new List<poswCountryMasterDAL>();
                poswCountryMasterDAL objCountryMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCountryMasterDAL = new poswCountryMasterDAL();
                    objCountryMasterDAL.CountryMasterId = Convert.ToInt16(SqlRdr["CountryMasterId"]);
                    objCountryMasterDAL.CountryName = Convert.ToString(SqlRdr["CountryName"]);
                    lstCountryMasterDAL.Add(objCountryMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCountryMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

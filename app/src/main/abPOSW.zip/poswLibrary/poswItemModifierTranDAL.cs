using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswItemModifierTran
    /// </summary>
    public class poswItemModifierTranDAL
    {
        #region Properties
        public int ItemModifierTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public int linktoItemMasterIdModifier { get; set; }

        // Extra
        public string ItemModifier {get;set;}
        #endregion

        #region Class Methods
        private List<poswItemModifierTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswItemModifierTranDAL> lstItemModifierTran = new List<poswItemModifierTranDAL>();
            poswItemModifierTranDAL objItemModifierTran = null;
            while (sqlRdr.Read())
            {
                objItemModifierTran = new poswItemModifierTranDAL();
                objItemModifierTran.ItemModifierTranId = Convert.ToInt32(sqlRdr["ItemModifierTranId"]);
                objItemModifierTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                objItemModifierTran.linktoItemMasterIdModifier = Convert.ToInt32(sqlRdr["linktoItemMasterIdModifier"]);
                objItemModifierTran.ItemModifier = Convert.ToString(sqlRdr["ItemModifier"]);
                lstItemModifierTran.Add(objItemModifierTran);
            }
            return lstItemModifierTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertAllItemModifierTran(string linktoItemMasterIdModifiers, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswItemModifierTran_InsertAll", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterIdModifiers", SqlDbType.VarChar).Value = linktoItemMasterIdModifiers;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll

        public List<poswItemModifierTranDAL> SelectAllItemModifierTran(SqlConnection sqlCon = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                if (sqlCon == null)
                {
                    SqlCon = poswObjectFactoryDAL.CreateConnection();
                    SqlCmd = new SqlCommand("poswItemModifierTran_SelectAll", SqlCon);
                }
                else
                {
                    SqlCmd = new SqlCommand("poswItemModifierTran_SelectAll", sqlCon);
                }
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;

                if (sqlCon == null)
                {
                    SqlCon.Open();
                }
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemModifierTranDAL> lstItemModifierTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                if (sqlCon == null)
                {
                    SqlCon.Close();
                }

                return lstItemModifierTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                if (sqlCon == null)
                {
                    poswObjectFactoryDAL.DisposeConnection(SqlCon);
                }
            }
        }
        #endregion
    }
}

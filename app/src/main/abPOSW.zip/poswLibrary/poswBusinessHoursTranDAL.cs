using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBusinessHoursTran
    /// </summary>
    public class poswBusinessHoursTranDAL
    {
        #region Properties
        public short BusinessHoursTranId { get; set; }
        public short DayOfWeek { get; set; }
        public TimeSpan OpeningTime { get; set; }
        public TimeSpan ClosingTime { get; set; }
        public TimeSpan? BreakStartTime { get; set; }
        public TimeSpan? BreakEndTime { get; set; }
        public short linktoBusinessMasterId { get; set; }

        /// Extra
        public string Business { get; set; }
        List<poswBusinessHoursTranDAL> lstBusinessHoursTranDAL { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BusinessHoursTranId = Convert.ToInt16(sqlRdr["BusinessHoursTranId"]);
                this.DayOfWeek = Convert.ToInt16(sqlRdr["DayOfWeek"]);
                this.OpeningTime = TimeSpan.Parse(sqlRdr["OpeningTime"].ToString());
                this.ClosingTime = TimeSpan.Parse(sqlRdr["ClosingTime"].ToString());
                if (sqlRdr["BreakStartTime"] != DBNull.Value)
                {
                    this.BreakStartTime = TimeSpan.Parse(sqlRdr["BreakStartTime"].ToString());
                }
                if (sqlRdr["BreakEndTime"] != DBNull.Value)
                {
                    this.BreakEndTime = TimeSpan.Parse(sqlRdr["BreakEndTime"].ToString());
                }                
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);                
                return true;
            }
            return false;
        }

        private List<poswBusinessHoursTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswBusinessHoursTranDAL> lstBusinessHoursTran = new List<poswBusinessHoursTranDAL>();
            poswBusinessHoursTranDAL objBusinessHoursTran = null;
            while (sqlRdr.Read())
            {
                objBusinessHoursTran = new poswBusinessHoursTranDAL();
                objBusinessHoursTran.BusinessHoursTranId = Convert.ToInt16(sqlRdr["BusinessHoursTranId"]);
                objBusinessHoursTran.DayOfWeek = Convert.ToInt16(sqlRdr["DayOfWeek"]);
                objBusinessHoursTran.OpeningTime = TimeSpan.Parse(sqlRdr["OpeningTime"].ToString());
                objBusinessHoursTran.ClosingTime = TimeSpan.Parse(sqlRdr["ClosingTime"].ToString());
                if (sqlRdr["BreakStartTime"] != DBNull.Value)
                {
                   objBusinessHoursTran.BreakStartTime = TimeSpan.Parse(sqlRdr["BreakStartTime"].ToString());
                }
                if (sqlRdr["BreakEndTime"] != DBNull.Value)
                {
                    objBusinessHoursTran.BreakEndTime = TimeSpan.Parse(sqlRdr["BreakEndTime"].ToString());
                }
                objBusinessHoursTran.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);          
                lstBusinessHoursTran.Add(objBusinessHoursTran);
            }
            return lstBusinessHoursTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertBusinessHoursTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessHoursTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessHoursTranId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@DayOfWeek", SqlDbType.SmallInt).Value = this.DayOfWeek;
                SqlCmd.Parameters.Add("@OpeningTime", SqlDbType.Time).Value = this.OpeningTime;
                SqlCmd.Parameters.Add("@ClosingTime", SqlDbType.Time).Value = this.ClosingTime;              
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BusinessHoursTranId = Convert.ToInt16(SqlCmd.Parameters["@BusinessHoursTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateBusinessHoursTran(List<poswBusinessHoursTranDAL> lstBusinessHoursTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            poswRecordStatus rs = poswRecordStatus.Error;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswBusinessHoursTran_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (poswBusinessHoursTranDAL obj in lstBusinessHoursTranDAL)
                {
                    SqlCmd.Parameters.Add("@BusinessHoursTranId", SqlDbType.SmallInt).Value = obj.BusinessHoursTranId;
                    SqlCmd.Parameters.Add("@DayOfWeek", SqlDbType.SmallInt).Value = obj.DayOfWeek;
                    SqlCmd.Parameters.Add("@OpeningTime", SqlDbType.Time).Value = obj.OpeningTime;
                    SqlCmd.Parameters.Add("@ClosingTime", SqlDbType.Time).Value = obj.ClosingTime;
                    if(obj.BreakStartTime != null && obj.BreakEndTime != null)
                    {
                        SqlCmd.Parameters.Add("@BreakStartTime", SqlDbType.Time).Value = obj.BreakStartTime;
                        SqlCmd.Parameters.Add("@BreakEndTime", SqlDbType.Time).Value = obj.BreakEndTime;
                    }
                    
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.ExecuteNonQuery();
                    rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                    if (rs != poswRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }

                    SqlCmd.Parameters.Clear();
                }
                SqlTran.Commit();
                SqlCon.Close();

                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteBusinessHoursTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessHoursTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessHoursTranId", SqlDbType.SmallInt).Value = this.BusinessHoursTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static poswRecordStatus DeleteAllBusinessHoursTran(string businessHoursTranIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessHoursTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessHoursTranIds", SqlDbType.VarChar).Value = businessHoursTranIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBusinessHoursTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessHoursTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessHoursTranId", SqlDbType.SmallInt).Value = this.BusinessHoursTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswBusinessHoursTranDAL> SelectAllBusinessHoursTranPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessHours_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessHoursTranDAL> lstBusinessHoursTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstBusinessHoursTranDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswBusinessHoursTranDAL> SelectAllBusinessHoursTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessHours_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessHoursTranDAL> lstBusinessHoursTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessHoursTranDAL;
            }
            catch (Exception ex)
            {

                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

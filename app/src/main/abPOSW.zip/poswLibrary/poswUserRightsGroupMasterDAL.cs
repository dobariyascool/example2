using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for crmUserRightsGroupMaster
	/// </summary>
	public class poswUserRightsGroupMasterDAL
	{
		#region Properties
		public short UserRightsGroupMasterId { get; set; }
		public string UserRightsGroup { get; set; }
		public short? SortOrder { get; set; }
		#endregion

		#region Class Methods
		private List<poswUserRightsGroupMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswUserRightsGroupMasterDAL> lstUserRightsGroupMaster = new List<poswUserRightsGroupMasterDAL>();
			poswUserRightsGroupMasterDAL objUserRightsGroupMaster = null;
			while (sqlRdr.Read())
			{
				objUserRightsGroupMaster = new poswUserRightsGroupMasterDAL();
				objUserRightsGroupMaster.UserRightsGroupMasterId = Convert.ToInt16(sqlRdr["UserRightsGroupMasterId"]);
				objUserRightsGroupMaster.UserRightsGroup = Convert.ToString(sqlRdr["UserRightsGroup"]);
                //if (sqlRdr["SortOrder"] != DBNull.Value)
                //{
                //    objUserRightsGroupMaster.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                //}
				lstUserRightsGroupMaster.Add(objUserRightsGroupMaster);
			}
			return lstUserRightsGroupMaster;
		}
		#endregion

		#region SelectAll
		public List<poswUserRightsGroupMasterDAL> SelectAllUserRightsGroupMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL .CreateConnection();
				SqlCmd = new SqlCommand("poswUserRightsGroupMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;


				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswUserRightsGroupMasterDAL> lstUserRightsGroupMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstUserRightsGroupMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.IO;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswCustomerMaster
    /// </summary>

    public class poswCustomerMasterDAL
    {
        #region Properties
        public int CustomerMasterId { get; set; }
        public string ShortName { get; set; }
        public string CustomerName { get; set; }
        public string Password { get; set; }
        public string Description { get; set; }
        public string ContactPersonName { get; set; }
        public string Designation { get; set; }
        public string Address { get; set; }
        public short? linktoCountryMasterId { get; set; }
        public short? linktoStateMasterId { get; set; }
        public short? linktoCityMasterId { get; set; }
        public short? linktoAreaMasterId { get; set; }
        public string ZipCode { get; set; }
        public string Phone1 { get; set; }
        public bool IsPhone1DND { get; set; }
        public string Phone2 { get; set; }
        public bool? IsPhone2DND { get; set; }
        public string Email1 { get; set; }
        public string Email2 { get; set; }
        public string Fax { get; set; }
        public string ImageName { get; set; }
        public DateTime? BirthDate { get; set; }
        public DateTime? AnniversaryDate { get; set; }
        public short CustomerType { get; set; }
        public bool? IsFavourite { get; set; }
        public bool? IsCredit { get; set; }
        public double OpeningBalance { get; set; }
        public short CreditDays { get; set; }
        public double CreditBalance { get; set; }
        public double CreditLimit { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? LastLoginDateTime { get; set; }
        public short linktoSourceMasterId { get; set; }
        public string Gender { get; set; }
        public short linktoCustomerAddressTranId { get; set; }
        public DateTime? CreateFromDateTime { get; set; }
        public DateTime? CreateToDateTime { get; set; }

        /// Extra
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
        public string ImagePhysicalName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public string PrimaryAddress { get; set; }
        public string GooglePlusUserId { get; set; }
        public string FacebookUserId { get; set; }
        public int? AgeMinRange { get; set; }
        public int? AgeMaxRange { get; set; }
        public bool? IsVerified { get; set; }
        public bool IsSignIn { get; set; }
        public string FCMToken { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "customer/";
            if (sqlRdr.Read())
            {
                this.CustomerMasterId = Convert.ToInt32(sqlRdr["CustomerMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.ContactPersonName = Convert.ToString(sqlRdr["ContactPersonName"]);
                this.Designation = Convert.ToString(sqlRdr["Designation"]);
                //this.Address = Convert.ToString(sqlRdr["Address"]);
                this.Password = Convert.ToString(sqlRdr["Password"]);
                if (sqlRdr["linktoCountryMasterId"] != DBNull.Value)
                {
                    this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                }
                if (sqlRdr["linktoStateMasterId"] != DBNull.Value)
                {
                    this.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                }
                if (sqlRdr["linktoCityMasterId"] != DBNull.Value)
                {
                    this.linktoCityMasterId = Convert.ToInt16(sqlRdr["linktoCityMasterId"]);
                }
                if (sqlRdr["linktoAreaMasterId"] != DBNull.Value)
                {
                    this.linktoAreaMasterId = Convert.ToInt16(sqlRdr["linktoAreaMasterId"]);
                }
                //this.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                this.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                this.IsPhone1DND = Convert.ToBoolean(sqlRdr["IsPhone1DND"]);
                this.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                if (sqlRdr["IsPhone2DND"] != DBNull.Value)
                {
                    this.IsPhone2DND = Convert.ToBoolean(sqlRdr["IsPhone2DND"]);
                }
                this.Email1 = Convert.ToString(sqlRdr["Email1"]);
                this.Email2 = Convert.ToString(sqlRdr["Email2"]);
                this.Fax = Convert.ToString(sqlRdr["Fax"]);
                this.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                if (sqlRdr["BirthDate"] != DBNull.Value)
                {
                    this.BirthDate = Convert.ToDateTime(sqlRdr["BirthDate"]);
                }
                if (sqlRdr["AnniversaryDate"] != DBNull.Value)
                {
                    this.AnniversaryDate = Convert.ToDateTime(sqlRdr["AnniversaryDate"]);
                }
                this.CustomerType = Convert.ToInt16(sqlRdr["CustomerType"]);
                if (sqlRdr["IsFavourite"] != DBNull.Value)
                {
                    this.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                }
                if (sqlRdr["IsCredit"] != DBNull.Value)
                {
                    this.IsCredit = Convert.ToBoolean(sqlRdr["IsCredit"]);
                }
                this.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                this.CreditDays = Convert.ToInt16(sqlRdr["CreditDays"]);
                this.CreditBalance = Convert.ToDouble(sqlRdr["CreditBalance"]);
                this.CreditLimit = Convert.ToDouble(sqlRdr["CreditLimit"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdCreatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["LastLoginDateTime"] != DBNull.Value)
                {
                    this.LastLoginDateTime = Convert.ToDateTime(sqlRdr["LastLoginDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.Gender = Convert.ToString(sqlRdr["Gender"]);
                if (sqlRdr["CustomerAddressTranId"] != DBNull.Value)
                {
                    this.linktoCustomerAddressTranId = Convert.ToInt16(sqlRdr["CustomerAddressTranId"]);
                }
                /// Extra
                //this.Country = Convert.ToString(sqlRdr["Country"]);
                //this.State = Convert.ToString(sqlRdr["State"]);
                //this.City = Convert.ToString(sqlRdr["City"]);
                //this.Area = Convert.ToString(sqlRdr["Area"]);
                if (sqlRdr["GooglePlusUserId"] == DBNull.Value && sqlRdr["FacebookUserId"] == DBNull.Value)
                {
                    if (sqlRdr["ImageName"] != DBNull.Value)
                    {
                        this.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);

                        this.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                        this.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                        this.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                        this.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                        this.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                    }
                    else
                    {
                        this.ImagePhysicalName = "img/NoImage.png";

                        this.xs_ImagePhysicalName = "img/NoImage.png";
                        this.sm_ImagePhysicalName = "img/NoImage.png";
                        this.md_ImagePhysicalName = "img/NoImage.png";
                        this.lg_ImagePhysicalName = "img/NoImage.png";
                        this.xl_ImagePhysicalName = "img/NoImage.png";
                    }
                }
                else
                {
                    if (sqlRdr["ImageName"] != DBNull.Value)
                    {
                        this.ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        this.xs_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        this.sm_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        this.md_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        this.lg_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        this.xl_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                    }
                    else
                    {
                        this.ImagePhysicalName = "img/NoImage.png";

                        this.xs_ImagePhysicalName = "img/NoImage.png";
                        this.sm_ImagePhysicalName = "img/NoImage.png";
                        this.md_ImagePhysicalName = "img/NoImage.png";
                        this.lg_ImagePhysicalName = "img/NoImage.png";
                        this.xl_ImagePhysicalName = "img/NoImage.png";
                    }
                }
                if (sqlRdr["GooglePlusUserId"] != DBNull.Value)
                {
                    this.GooglePlusUserId = Convert.ToString(sqlRdr["GooglePlusUserId"]);
                }
                if (sqlRdr["FacebookUserId"] != DBNull.Value)
                {
                    this.FacebookUserId = Convert.ToString(sqlRdr["FacebookUserId"]);
                }
                if (sqlRdr["AgeMinRange"] != DBNull.Value)
                {
                    this.AgeMinRange = Convert.ToInt32(sqlRdr["AgeMinRange"]);
                }
                if (sqlRdr["AgeMaxRange"] != DBNull.Value)
                {
                    this.AgeMaxRange = Convert.ToInt32(sqlRdr["AgeMaxRange"]);
                }
                if (sqlRdr["IsVerified"] != DBNull.Value)
                {
                    this.IsVerified = Convert.ToBoolean(sqlRdr["IsVerified"]);
                }
                return true;
            }
            return false;
        }

        private List<poswCustomerMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "customer/";
            List<poswCustomerMasterDAL> lstCustomerMaster = new List<poswCustomerMasterDAL>();
            poswCustomerMasterDAL objCustomerMaster = null;
            while (sqlRdr.Read())
            {
                objCustomerMaster = new poswCustomerMasterDAL();
                objCustomerMaster.CustomerMasterId = Convert.ToInt32(sqlRdr["CustomerMasterId"]);
                objCustomerMaster.Password = Convert.ToString(sqlRdr["Password"]);
                objCustomerMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objCustomerMaster.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                objCustomerMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objCustomerMaster.ContactPersonName = Convert.ToString(sqlRdr["ContactPersonName"]);
                objCustomerMaster.Designation = Convert.ToString(sqlRdr["Designation"]);
                objCustomerMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                objCustomerMaster.IsPhone1DND = Convert.ToBoolean(sqlRdr["IsPhone1DND"]);
                objCustomerMaster.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                if (sqlRdr["IsPhone2DND"] != DBNull.Value)
                {
                    objCustomerMaster.IsPhone2DND = Convert.ToBoolean(sqlRdr["IsPhone2DND"]);
                }
                objCustomerMaster.Email1 = Convert.ToString(sqlRdr["Email1"]);
                objCustomerMaster.Email2 = Convert.ToString(sqlRdr["Email2"]);
                objCustomerMaster.Fax = Convert.ToString(sqlRdr["Fax"]);
                objCustomerMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                if (sqlRdr["BirthDate"] != DBNull.Value)
                {
                    objCustomerMaster.BirthDate = Convert.ToDateTime(sqlRdr["BirthDate"]);
                }
                if (sqlRdr["AnniversaryDate"] != DBNull.Value)
                {
                    objCustomerMaster.AnniversaryDate = Convert.ToDateTime(sqlRdr["AnniversaryDate"]);
                }
                objCustomerMaster.CustomerType = Convert.ToInt16(sqlRdr["CustomerType"]);
                if (sqlRdr["IsFavourite"] != DBNull.Value)
                {
                    objCustomerMaster.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                }
                if (sqlRdr["IsCredit"] != DBNull.Value)
                {
                    objCustomerMaster.IsCredit = Convert.ToBoolean(sqlRdr["IsCredit"]);
                }
                objCustomerMaster.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                objCustomerMaster.CreditDays = Convert.ToInt16(sqlRdr["CreditDays"]);
                objCustomerMaster.CreditBalance = Convert.ToDouble(sqlRdr["CreditBalance"]);
                objCustomerMaster.CreditLimit = Convert.ToDouble(sqlRdr["CreditLimit"]);
                objCustomerMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objCustomerMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdCreatedBy"] != DBNull.Value)
                {
                    objCustomerMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                }
                objCustomerMaster.Gender = Convert.ToString(sqlRdr["Gender"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCustomerMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);

                }
                if (sqlRdr["LastLoginDateTime"] != DBNull.Value)
                {
                    objCustomerMaster.LastLoginDateTime = Convert.ToDateTime(sqlRdr["LastLoginDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCustomerMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objCustomerMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objCustomerMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                
                if (sqlRdr["GooglePlusUserId"] == DBNull.Value && sqlRdr["FacebookUserId"] == DBNull.Value)
                {
                    if (sqlRdr["ImageName"] != DBNull.Value)
                    {
                        objCustomerMaster.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);

                        objCustomerMaster.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                    }
                    else
                    {
                        objCustomerMaster.ImagePhysicalName = "img/NoImage.png";

                        objCustomerMaster.xs_ImagePhysicalName = "img/NoImage.png";
                        objCustomerMaster.sm_ImagePhysicalName = "img/NoImage.png";
                        objCustomerMaster.md_ImagePhysicalName = "img/NoImage.png";
                        objCustomerMaster.lg_ImagePhysicalName = "img/NoImage.png";
                        objCustomerMaster.xl_ImagePhysicalName = "img/NoImage.png";
                    }
                }
                else
                {
                    if (sqlRdr["ImageName"] != DBNull.Value)
                    {
                        objCustomerMaster.ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.xs_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.sm_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.md_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.lg_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                        objCustomerMaster.xl_ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                    }
                    else
                    {
                        objCustomerMaster.ImagePhysicalName = "img/NoImage.png";

                        objCustomerMaster.xs_ImagePhysicalName = "img/NoImage.png";
                        objCustomerMaster.sm_ImagePhysicalName = "img/NoImage.png";
                        objCustomerMaster.md_ImagePhysicalName = "img/NoImage.png";
                        objCustomerMaster.lg_ImagePhysicalName = "img/NoImage.png";
                        objCustomerMaster.xl_ImagePhysicalName = "img/NoImage.png";
                    }
                }
                if (sqlRdr["GooglePlusUserId"] != DBNull.Value)
                {
                    objCustomerMaster.GooglePlusUserId = Convert.ToString(sqlRdr["GooglePlusUserId"]);
                }
                if (sqlRdr["FacebookUserId"] != DBNull.Value)
                {
                    objCustomerMaster.FacebookUserId = Convert.ToString(sqlRdr["FacebookUserId"]);
                }
                if (sqlRdr["AgeMinRange"] != DBNull.Value)
                {
                    objCustomerMaster.AgeMinRange = Convert.ToInt32(sqlRdr["AgeMinRange"]);
                }
                if (sqlRdr["AgeMaxRange"] != DBNull.Value)
                {
                    objCustomerMaster.AgeMaxRange = Convert.ToInt32(sqlRdr["AgeMaxRange"]);
                }
                if (sqlRdr["IsVerified"] != DBNull.Value)
                {
                    objCustomerMaster.IsVerified = Convert.ToBoolean(sqlRdr["IsVerified"]);
                }             
                lstCustomerMaster.Add(objCustomerMaster);
            }
            return lstCustomerMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertCustomerMaster(List<poswCustomerAddressTranDAL> lstCustomerAddressTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswCustomerMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ContactPersonName", SqlDbType.VarChar).Value = this.ContactPersonName;
                SqlCmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = this.Designation;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsPhone1DND", SqlDbType.Bit).Value = this.IsPhone1DND;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@IsPhone2DND", SqlDbType.Bit).Value = this.IsPhone2DND;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.Date).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@CreditDays", SqlDbType.SmallInt).Value = this.CreditDays;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                if (this.linktoUserMasterIdCreatedBy > 0)
                {
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                }
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@GooglePlusUserId", SqlDbType.VarChar).Value = this.GooglePlusUserId;
                SqlCmd.Parameters.Add("@FacebookUserId", SqlDbType.VarChar).Value = this.FacebookUserId;
                if (this.AgeMinRange > 0)
                {
                    SqlCmd.Parameters.Add("@AgeMinRange", SqlDbType.Int).Value = this.AgeMinRange;
                }
                if (this.AgeMaxRange > 0)
                {
                    SqlCmd.Parameters.Add("@AgeMaxRange", SqlDbType.Int).Value = this.AgeMaxRange;
                }
                SqlCmd.Parameters.Add("@IsVerified", SqlDbType.Bit).Value = this.IsVerified;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.CustomerMasterId = Convert.ToInt32(SqlCmd.Parameters["@CustomerMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                if (lstCustomerAddressTranDAL != null)
                {
                    foreach (poswCustomerAddressTranDAL objCustomerAddressTranDAL in lstCustomerAddressTranDAL)
                    {
                        objCustomerAddressTranDAL.linktoCustomerMasterId = this.CustomerMasterId;
                        rs = objCustomerAddressTranDAL.InsertCustomerAddressTran(SqlCon, SqlTran);
                        if (rs != poswRecordStatus.Success)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }

        public poswRecordStatus InsertCustomerMaster(poswCustomerAddressTranDAL objCustomerAddressTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswCustomerMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ContactPersonName", SqlDbType.VarChar).Value = this.ContactPersonName;
                SqlCmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = this.Designation;
                //SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                //SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                //SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                //SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = this.linktoCityMasterId;
                //SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.SmallInt).Value = this.linktoAreaMasterId;
                //SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsPhone1DND", SqlDbType.Bit).Value = this.IsPhone1DND;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@IsPhone2DND", SqlDbType.Bit).Value = this.IsPhone2DND;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.Date).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@CreditDays", SqlDbType.SmallInt).Value = this.CreditDays;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                if (this.linktoUserMasterIdCreatedBy > 0)
                {
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                }
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@FCMToken", SqlDbType.VarChar).Value = this.FCMToken;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@GooglePlusUserId", SqlDbType.VarChar).Value = this.GooglePlusUserId;
                SqlCmd.Parameters.Add("@FacebookUserId", SqlDbType.VarChar).Value = this.FacebookUserId;
                if (this.AgeMinRange > 0)
                {
                    SqlCmd.Parameters.Add("@AgeMinRange", SqlDbType.Int).Value = this.AgeMinRange;
                }
                if (this.AgeMaxRange > 0)
                {
                    SqlCmd.Parameters.Add("@AgeMaxRange", SqlDbType.Int).Value = this.AgeMaxRange;
                }
                SqlCmd.Parameters.Add("@IsVerified", SqlDbType.Bit).Value = this.IsVerified;
                SqlCmd.Parameters.Add("@IsSignIn", SqlDbType.Bit).Value = this.IsSignIn;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.CustomerMasterId = Convert.ToInt32(SqlCmd.Parameters["@CustomerMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                if (objCustomerAddressTranDAL != null)
                {
                    objCustomerAddressTranDAL.linktoCustomerMasterId = this.CustomerMasterId;
                    rs = objCustomerAddressTranDAL.InsertCustomerAddressTran(SqlCon, SqlTran);
                    if (rs != poswRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateCustomerMaster(List<poswCustomerAddressTranDAL> lstCustomerAddressTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswCustomerMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ContactPersonName", SqlDbType.VarChar).Value = this.ContactPersonName;
                SqlCmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = this.Designation;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsPhone1DND", SqlDbType.Bit).Value = this.IsPhone1DND;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@IsPhone2DND", SqlDbType.Bit).Value = this.IsPhone2DND;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.Date).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@CreditDays", SqlDbType.SmallInt).Value = this.CreditDays;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                foreach (poswCustomerAddressTranDAL objCustomerAddressTranDAL in lstCustomerAddressTranDAL)
                {
                    objCustomerAddressTranDAL.linktoCustomerMasterId = this.CustomerMasterId;
                    if (objCustomerAddressTranDAL.CustomerAddressTranId > 0)
                    {
                        rs = objCustomerAddressTranDAL.UpdateCustomerAddressTran(SqlCon, SqlTran);
                    }
                    else
                    {
                        rs = objCustomerAddressTranDAL.InsertCustomerAddressTran(SqlCon, SqlTran);
                    }
                    if (rs != poswRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateCustomerMasterProfile(poswCustomerAddressTranDAL objCustomerAddressTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswCustomerMasterProfile_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.Date).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                objCustomerAddressTranDAL.linktoCustomerMasterId = this.CustomerMasterId;
                if (objCustomerAddressTranDAL.CustomerAddressTranId > 0)
                {
                    rs = objCustomerAddressTranDAL.UpdateCustomerAddressTran(SqlCon, SqlTran);
                }
                else
                {
                    rs = objCustomerAddressTranDAL.InsertCustomerAddressTran(SqlCon, SqlTran);
                }
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateCustomerMasterLastLoginDateTime()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterLastLoginDateTime_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.SmallInt).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateCustomerMasterPassword()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterPassword_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.VarChar).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateCustomerMasterbyId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterById_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.VarChar).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Birthdate", SqlDbType.DateTime).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@Anniversarydate", SqlDbType.DateTime).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        
        #endregion

        #region Delete
        public poswRecordStatus DeleteCustomerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCustomerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectCustomerMasterForBooking()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterForBooking_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelect = false;
                if (SqlRdr.Read())
                {
                    this.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    if (SqlRdr["Phone1"] != DBNull.Value)
                    {
                        this.Phone1 = Convert.ToString(SqlRdr["Phone1"]);
                    }
                    this.CustomerType = Convert.ToInt16(SqlRdr["CustomerType"]);
                    if (SqlRdr["Email1"] != DBNull.Value)
                    {
                        this.Email1 = Convert.ToString(SqlRdr["Email1"]);
                    }
                    if (SqlRdr["PrimaryAddress"] != DBNull.Value)
                    {
                        this.PrimaryAddress = Convert.ToString(SqlRdr["PrimaryAddress"]);
                    }
                    IsSelect = true;

                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelect;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;  
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectCustomerMasterByEmail()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();

                SqlCmd = new SqlCommand("poswCustomerMasterByEmail_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.VarChar).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "customer/";
                if (SqlRdr.Read())
                {
                    this.CustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    this.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    this.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    this.Phone1 = Convert.ToString(SqlRdr["Phone1"]);
                    this.Email1 = Convert.ToString(SqlRdr["Email1"]);
                    this.Password = Convert.ToString(SqlRdr["Password"]);
                    this.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    this.linktoSourceMasterId = Convert.ToInt16(SqlRdr["linktoSourceMasterId"]);
                    this.ImageName = Convert.ToString(SqlRdr["ImageName"]);
                    if (SqlRdr["GooglePlusUserId"] != DBNull.Value)
                    {
                        this.GooglePlusUserId = Convert.ToString(SqlRdr["GooglePlusUserId"]);
                    }
                    if (SqlRdr["FacebookUserId"] != DBNull.Value)
                    {
                        this.FacebookUserId = Convert.ToString(SqlRdr["FacebookUserId"]);
                    }
                    if (SqlRdr["AgeMinRange"] != DBNull.Value)
                    {
                        this.AgeMinRange = Convert.ToInt32(SqlRdr["AgeMinRange"]);
                    }
                    if (SqlRdr["AgeMaxRange"] != DBNull.Value)
                    {
                        this.AgeMaxRange = Convert.ToInt32(SqlRdr["AgeMaxRange"]);
                    }
                    if (SqlRdr["IsVerified"] != DBNull.Value)
                    {
                        this.IsVerified = Convert.ToBoolean(SqlRdr["IsVerified"]);
                    }
                    if (SqlRdr["GooglePlusUserId"] == DBNull.Value && SqlRdr["FacebookUserId"] == DBNull.Value)
                    {
                        if (SqlRdr["ImageName"] != DBNull.Value)
                        {
                            this.ImagePhysicalName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);

                            this.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                            this.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                            this.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                            this.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                            this.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);
                        }
                        else
                        {
                            this.ImagePhysicalName = "img/NoImage.png";

                            this.xs_ImagePhysicalName = "img/NoImage.png";
                            this.sm_ImagePhysicalName = "img/NoImage.png";
                            this.md_ImagePhysicalName = "img/NoImage.png";
                            this.lg_ImagePhysicalName = "img/NoImage.png";
                            this.xl_ImagePhysicalName = "img/NoImage.png";
                        }
                    }
                    else
                    {
                        if (SqlRdr["ImageName"] != DBNull.Value)
                        {
                            this.ImagePhysicalName = Convert.ToString(SqlRdr["ImageName"]);

                            this.xs_ImagePhysicalName = Convert.ToString(SqlRdr["ImageName"]);
                            this.sm_ImagePhysicalName = Convert.ToString(SqlRdr["ImageName"]);
                            this.md_ImagePhysicalName = Convert.ToString(SqlRdr["ImageName"]);
                            this.lg_ImagePhysicalName = Convert.ToString(SqlRdr["ImageName"]);
                            this.xl_ImagePhysicalName = Convert.ToString(SqlRdr["ImageName"]);
                        }
                        else
                        {
                            this.ImagePhysicalName = "img/NoImage.png";

                            this.xs_ImagePhysicalName = "img/NoImage.png";
                            this.sm_ImagePhysicalName = "img/NoImage.png";
                            this.md_ImagePhysicalName = "img/NoImage.png";
                            this.lg_ImagePhysicalName = "img/NoImage.png";
                            this.xl_ImagePhysicalName = "img/NoImage.png";
                        }
                    }
                    return true;
                }
                SqlRdr.Close();
                SqlCon.Close();
                return false;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectCustomerByEmailForgotPassword()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterForgotPassword_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;
                if (SqlRdr.Read())
                {
                    this.CustomerMasterId = Convert.ToInt16(SqlRdr["CustomerMasterId"]);
                    this.Email1 = Convert.ToString(SqlRdr["Email1"]);
                    this.Password = Convert.ToString(SqlRdr["Password"]);
                    this.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);

                    string ToEmailAddress, EmailBody;
                    //To Registered USER
                    ToEmailAddress = this.Email1;
                    EmailBody = File.ReadAllText(System.Configuration.ConfigurationManager.AppSettings["emailtemplates"] + "ForgotPassword.html");
                    EmailBody = EmailBody.Replace("#PASSWORD#", this.Password);
                    EmailBody = EmailBody.Replace("#EMAIL#", this.Email1);
                    EmailBody = EmailBody.Replace("#FULLNAME#", this.CustomerName);
                    poswGlobalsDAL.SendEmail(ToEmailAddress, "Password Change - likeat.com", EmailBody);

                    return IsSelected = true;
                }

                SqlCon.Close();
                SqlRdr.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;

            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }


        public bool SelectCustomerMasterCreditroCreditBalance()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterCreditorCreditBalance_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                while (SqlRdr.Read())
                {
                    this.CreditBalance = Convert.ToDouble(SqlRdr["CreditBalance"]);
                    return true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return false;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswCustomerMasterDAL> SelectAllCustomerMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.SmallInt).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCustomerMasterDAL> lstCustomerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstCustomerMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswCustomerMasterDAL> SelectAllCustomerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCustomerMasterDAL> lstCustomerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMasterDAL;
            }
            catch (Exception ex)
            {             
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswCustomerMasterDAL> SelectAllCustomerMasterCustomerName()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCustomerMasterDAL> lstCustomerMasterDAL = new List<poswCustomerMasterDAL>();
                poswCustomerMasterDAL objCustomerMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCustomerMasterDAL = new poswCustomerMasterDAL();
                    objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    objCustomerMasterDAL.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    objCustomerMasterDAL.CustomerType = Convert.ToInt16(SqlRdr["CustomerType"]);
                    lstCustomerMasterDAL.Add(objCustomerMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

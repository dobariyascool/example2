using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswSubscriberMaster
    /// </summary>
    public class poswSubscriberMasterDAL
    {
        #region Properties
        public int SubscriberMasterId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Gender { get; set; }
        public DateTime SubscribeDateTime { get; set; }
        public DateTime? UnsubscribeDateTime { get; set; }
        public string ReasonForUnsubscribe { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }

        /// Extra
        #endregion

        #region Class Methods
        private List<poswSubscriberMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswSubscriberMasterDAL> lstSubscriberMaster = new List<poswSubscriberMasterDAL>();
            poswSubscriberMasterDAL objSubscriberMaster = null;
            while (sqlRdr.Read())
            {
                objSubscriberMaster = new poswSubscriberMasterDAL();
                objSubscriberMaster.SubscriberMasterId = Convert.ToInt32(sqlRdr["SubscriberMasterId"]);
                objSubscriberMaster.Name = Convert.ToString(sqlRdr["Name"]);
                objSubscriberMaster.Email = Convert.ToString(sqlRdr["Email"]);
                objSubscriberMaster.Phone = Convert.ToString(sqlRdr["Phone"]);
                objSubscriberMaster.Gender = Convert.ToString(sqlRdr["Gender"]);
                objSubscriberMaster.SubscribeDateTime = Convert.ToDateTime(sqlRdr["SubscribeDateTime"]);
                if (sqlRdr["UnsubscribeDateTime"] != DBNull.Value)
                {
                    objSubscriberMaster.UnsubscribeDateTime = Convert.ToDateTime(sqlRdr["UnsubscribeDateTime"]);
                }
                objSubscriberMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objSubscriberMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                lstSubscriberMaster.Add(objSubscriberMaster);
            }
            return lstSubscriberMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertSubscriberMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswSubscriberMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SubscriberMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@SubscribeDateTime", SqlDbType.DateTime).Value = this.SubscribeDateTime;
                SqlCmd.Parameters.Add("@UnsubscribeDateTime", SqlDbType.DateTime).Value = this.UnsubscribeDateTime;
                SqlCmd.Parameters.Add("@ReasonForUnsubscribe", SqlDbType.VarChar).Value = this.ReasonForUnsubscribe;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.SubscriberMasterId = Convert.ToInt32(SqlCmd.Parameters["@SubscriberMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateSubscriberMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswSubscriberMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SubscriberMasterId", SqlDbType.Int).Value = this.SubscriberMasterId;
                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateSubscriberMasterOnUnsubscribe()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswSubscriberMasterOnUnsubscribe_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SubscriberMasterId", SqlDbType.Int).Value = this.SubscriberMasterId;
                SqlCmd.Parameters.Add("@UnsubscribeDateTime", SqlDbType.DateTime).Value = this.UnsubscribeDateTime;
                SqlCmd.Parameters.Add("@ReasonForUnsubscribe", SqlDbType.VarChar).Value = this.ReasonForUnsubscribe;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswSubscriberMasterDAL> SelectAllSubscriberMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswSubscriberMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswSubscriberMasterDAL> lstSubscriberMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstSubscriberMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

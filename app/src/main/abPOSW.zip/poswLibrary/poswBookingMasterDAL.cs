using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Globalization;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBookingMaster
    /// </summary>
    /// 
    [Serializable]
    public class poswBookingMasterDAL
    {
        #region Properties
        public int BookingMasterId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public TimeSpan? FromTime { get; set; }
        public TimeSpan? ToTime { get; set; }
        public short linktoTableMasterId { get; set; }
        public bool? IsHourly { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public string BookingPersonName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public short NoOfAdults { get; set; }
        public short NoOfChildren { get; set; }
        public double TotalAmount { get; set; }
        public short DiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double ExtraAmount { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double BalanceAmount { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDeleted { get; set; }
        public short? BookingStatus { get; set; }
        public bool? IsPreOrder { get; set; }


        /// Extra
        public string TableName { get; set; }
        public string UserCreatedBy { get; set; }
        public string UserUpdatedBy { get; set; }
        public string Business { get; set; }
        public string BookingUser { get; set; }
        public Boolean PaymentStatus { get; set; }
        public string Address { get; set; }
        public string CustomerName { get; set; }
        public int CustomerType { get; set; }
        public bool IsAssigned { get; set; }
        public bool IsCancelled { get; set; }
        public short OrderStatus { get; set; }
        public string OrderRemark { get; set; }
        public long linktoOrderMasterId { get; set; }
        public string BookingStatusName { get; set; }
        public short OrderNumber { get; set; }
        public string TablesMasterIds { get; set; }
        public TimeSpan TimeSlot { get; set; }
        public short TimeDuration { get; set; }
        #endregion

        #region  Booking Master Hourly Properties

        public string T0 { get; set; }
        public string T1 { get; set; }
        public string T2 { get; set; }
        public string T3 { get; set; }
        public string T4 { get; set; }
        public string T5 { get; set; }
        public string T6 { get; set; }
        public string T7 { get; set; }
        public string T8 { get; set; }
        public string T9 { get; set; }
        public string T10 { get; set; }
        public string T11 { get; set; }
        public string T12 { get; set; }
        public string T13 { get; set; }
        public string T14 { get; set; }
        public string T15 { get; set; }
        public string T16 { get; set; }
        public string T17 { get; set; }
        public string T18 { get; set; }
        public string T19 { get; set; }
        public string T20 { get; set; }
        public string T21 { get; set; }
        public string T22 { get; set; }
        public string T23 { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BookingMasterId = Convert.ToInt32(sqlRdr["BookingMasterId"]);
                this.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                this.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                if (sqlRdr["FromTime"] != DBNull.Value)
                {
                    this.FromTime = sqlRdr.GetTimeSpan(sqlRdr.GetOrdinal("FromTime"));
                }
                if (sqlRdr["ToTime"] != DBNull.Value)
                {
                    this.ToTime = sqlRdr.GetTimeSpan(sqlRdr.GetOrdinal("ToTime"));
                }
                if (sqlRdr["BookingPersonName"] != DBNull.Value)
                {
                    this.BookingPersonName = Convert.ToString(sqlRdr["BookingPersonName"]);
                }
                if (sqlRdr["IsHourly"] != DBNull.Value)
                {
                    this.IsHourly = Convert.ToBoolean(sqlRdr["IsHourly"]);
                }

                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                    this.BookingUser = Convert.ToString(sqlRdr["CustomerName"]);
                    if (sqlRdr["Phone"] == DBNull.Value && sqlRdr["Email"] == DBNull.Value)
                    {
                        if (sqlRdr["CustomerEmailPhone"] != DBNull.Value)
                        {
                            this.Email = Convert.ToString(sqlRdr["CustomerEmailPhone"]).Split(',')[0];
                            this.Phone = Convert.ToString(sqlRdr["CustomerEmailPhone"]).Split(',')[1];
                        }
                    }
                    else
                    {
                        this.Phone = Convert.ToString(sqlRdr["Phone"]);
                        this.Email = Convert.ToString(sqlRdr["Email"]);
                    }
                }
                this.NoOfAdults = Convert.ToInt16(sqlRdr["NoOfAdults"]);
                this.NoOfChildren = Convert.ToInt16(sqlRdr["NoOfChildren"]);
                this.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                this.DiscountPercentage = Convert.ToInt16(sqlRdr["DiscountPercentage"]);
                this.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                this.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                this.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                this.PaidAmount = Convert.ToDouble(sqlRdr["PaidAmount"]);
                this.BalanceAmount = Convert.ToDouble(sqlRdr["BalanceAmount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                if (sqlRdr["IsPreOrder"] != DBNull.Value)
                {
                    this.IsPreOrder = Convert.ToBoolean(sqlRdr["IsPreOrder"]);
                }

                /// Extra
                this.TableName = Convert.ToString(sqlRdr["TableName"]);
                this.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
                this.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
                this.Business = Convert.ToString(sqlRdr["Business"]);
                if (sqlRdr["CustomerType"] != DBNull.Value)
                {
                    this.CustomerType = Convert.ToInt16(sqlRdr["CustomerType"]);
                }

                return true;
            }
            return false;
        }

        private List<poswBookingMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswBookingMasterDAL> lstBookingMaster = new List<poswBookingMasterDAL>();
            poswBookingMasterDAL objBookingMaster = null;
            while (sqlRdr.Read())
            {
                objBookingMaster = new poswBookingMasterDAL();
                objBookingMaster.BookingMasterId = Convert.ToInt32(sqlRdr["BookingMasterId"]);
                objBookingMaster.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                objBookingMaster.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                if (sqlRdr["FromTime"] != DBNull.Value)
                {
                    objBookingMaster.FromTime = sqlRdr.GetTimeSpan(sqlRdr.GetOrdinal("FromTime"));
                }
                if (sqlRdr["ToTime"] != DBNull.Value)
                {
                    objBookingMaster.ToTime = sqlRdr.GetTimeSpan(sqlRdr.GetOrdinal("ToTime"));
                }
                if (sqlRdr["IsHourly"] != DBNull.Value)
                {
                    objBookingMaster.IsHourly = Convert.ToBoolean(sqlRdr["IsHourly"]);
                }
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objBookingMaster.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                    objBookingMaster.BookingUser = Convert.ToString(sqlRdr["Customer"]);
                }
                objBookingMaster.NoOfAdults = Convert.ToInt16(sqlRdr["NoOfAdults"]);
                objBookingMaster.NoOfChildren = Convert.ToInt16(sqlRdr["NoOfChildren"]);
                objBookingMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objBookingMaster.DiscountPercentage = Convert.ToInt16(sqlRdr["DiscountPercentage"]);
                objBookingMaster.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                objBookingMaster.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                objBookingMaster.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                objBookingMaster.PaidAmount = Convert.ToDouble(sqlRdr["PaidAmount"]);
                objBookingMaster.BalanceAmount = Convert.ToDouble(sqlRdr["BalanceAmount"]);
                objBookingMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objBookingMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objBookingMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objBookingMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objBookingMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objBookingMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objBookingMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objBookingMaster.Phone = Convert.ToString(sqlRdr["Phone"]);
                objBookingMaster.Email = Convert.ToString(sqlRdr["Email"]);
                /// Extra

                objBookingMaster.TableName = Convert.ToString(sqlRdr["TableName"]);
                objBookingMaster.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
                objBookingMaster.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
                objBookingMaster.Business = Convert.ToString(sqlRdr["Business"]);
                lstBookingMaster.Add(objBookingMaster);
            }
            return lstBookingMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertBookingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswBookingMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@IsHourly", SqlDbType.Bit).Value = this.IsHourly;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@BookingPersonName", SqlDbType.VarChar).Value = this.BookingPersonName;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.SmallInt).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                this.BookingMasterId = Convert.ToInt32(SqlCmd.Parameters["@BookingMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                poswBookingTableTranDAL objBooingTableTranDAL = new poswBookingTableTranDAL();
                objBooingTableTranDAL.linktoBookingMasterId = this.BookingMasterId;

                rs = objBooingTableTranDAL.InsertAllBookingTableTran(this.TablesMasterIds, SqlCon, SqlTran); ;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }

        public poswRecordStatus InsertBookingMasterBookingDetails()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;

            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@IsHourly", SqlDbType.Bit).Value = this.IsHourly;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@BookingPersonName", SqlDbType.VarChar).Value = this.BookingPersonName;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@BookingStatus", SqlDbType.SmallInt).Value = this.BookingStatus;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.SmallInt).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BookingMasterId = Convert.ToInt32(SqlCmd.Parameters["@BookingMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);

            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateBookingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswBookingMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.Int).Value = this.BookingMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@IsHourly", SqlDbType.Bit).Value = this.IsHourly;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@BookingPersonName", SqlDbType.VarChar).Value = this.BookingPersonName;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.SmallInt).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@IsPreOrder", SqlDbType.Bit).Value = this.IsPreOrder;
                SqlCmd.Parameters.Add("@BookingStatus", SqlDbType.SmallInt).Value = this.BookingStatus;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                this.BookingMasterId = Convert.ToInt32(SqlCmd.Parameters["@BookingMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                poswBookingTableTranDAL objBooingTableTranDAL = new poswBookingTableTranDAL();
                objBooingTableTranDAL.linktoBookingMasterId = this.BookingMasterId;

                rs = objBooingTableTranDAL.InsertAllBookingTableTran(this.TablesMasterIds, SqlCon, SqlTran); ;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                if (Convert.ToBoolean(this.IsPreOrder))
                {
                    poswOrderMasterDAL objOrderMasterDAL = new poswOrderMasterDAL();
                    objOrderMasterDAL.linktoBookingMasterId = this.BookingMasterId;
                    objOrderMasterDAL.linktoTableMasterIds = this.TablesMasterIds;
                    objOrderMasterDAL.UpdateDateTime = this.UpdateDateTime;
                    rs = objOrderMasterDAL.UpdateOrderMasterTableMasterIds(SqlCon, SqlTran);
                    if (rs != poswRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateBookingMasterBookingCancel()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterBookingCancle_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.Int).Value = this.BookingMasterId;
                SqlCmd.Parameters.Add("@BookingStatus", SqlDbType.SmallInt).Value = this.BookingStatus;
                SqlCmd.Parameters.Add("@OrderStatus", SqlDbType.SmallInt).Value = this.OrderStatus;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BookingMasterId = Convert.ToInt32(SqlCmd.Parameters["@BookingMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region Select
        public bool SelectBookingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.Int).Value = this.BookingMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectBookingMasterVerify()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMaster_Verify", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.TablesMasterIds;
                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.SmallInt).Value = this.BookingMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate.Date;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate.Date;
                SqlCmd.Parameters.Add("@ISHourly", SqlDbType.Bit).Value = this.IsHourly;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;


                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;
                if (SqlRdr.Read())
                {
                    this.BookingMasterId = Convert.ToInt32(SqlRdr["BookingMasterId"]);
                    this.TableName = Convert.ToString(SqlRdr["TableNames"]);
                    this.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectBookingMasterVerifyForRegisteredUser()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterForCustomer_Verify", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.TablesMasterIds;
                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.SmallInt).Value = this.BookingMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate.Date;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate.Date;
                SqlCmd.Parameters.Add("@ISHourly", SqlDbType.Bit).Value = this.IsHourly;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@TotalPerson", SqlDbType.Int).Value = this.NoOfAdults + this.NoOfChildren;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;
                if (SqlRdr.Read())
                {
                    this.BookingMasterId = Convert.ToInt32(SqlRdr["BookingMasterId"]);
                    this.TableName = Convert.ToString(SqlRdr["TableNames"]);
                    this.BookingUser = Convert.ToString(SqlRdr["BookingUser"]);
                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectBookingMasterIfBookingAvailable()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterAvilableBooking_select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@TotalPerson", SqlDbType.Int).Value = this.NoOfAdults + this.NoOfChildren;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;
                if (SqlRdr.Read())
                {
                    if (Convert.ToInt32(SqlRdr["TotalFreeTable"]) > 0)
                    {
                        IsSelected = true;
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectBookingPaymentCancel()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterForPayment_Verify", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.SmallInt).Value = this.BookingMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                if (SqlRdr.Read())
                {
                    return true;
                }

                SqlRdr.Close();
                SqlCon.Close();

                return false;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswBookingMasterDAL> SelectAllBookingMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.FromDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                }
                if (this.ToDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                }

                if (this.linktoTableMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.SmallInt).Value = this.linktoTableMasterId;
                }

                SqlCmd.Parameters.Add("@IsHourly", SqlDbType.Bit).Value = this.IsHourly;

                if (this.linktoCustomerMasterId != null)
                {
                    SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                }

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBookingMasterDAL> lstBookingMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstBookingMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswBookingMasterDAL> SelectAllBookingMasterByCustomerMasterRegisteredUserPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterCustomerPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.FromDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                }
                if (this.ToDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                }
                if (this.linktoCustomerMasterId != null)
                {
                    SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                }
                if (this.BookingStatus != null)
                {
                    SqlCmd.Parameters.Add("@BookingStatus", SqlDbType.Int).Value = this.BookingStatus;
                }
                SqlCmd.Parameters.Add("@IsAssigned", SqlDbType.Bit).Value = this.IsAssigned;
                SqlCmd.Parameters.Add("@IsCancelled", SqlDbType.Bit).Value = this.IsCancelled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = poswCustomerType.Registered_User.GetHashCode();
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBookingMasterDAL> lstBookingMasterDAL = new List<poswBookingMasterDAL>();
                poswBookingMasterDAL objBookingMaster = null;
                while (SqlRdr.Read())
                {
                    objBookingMaster = new poswBookingMasterDAL();
                    objBookingMaster.BookingMasterId = Convert.ToInt32(SqlRdr["BookingMasterId"]);
                    objBookingMaster.BookingPersonName = Convert.ToString(SqlRdr["BookingPersonName"]);
                    objBookingMaster.Email = Convert.ToString(SqlRdr["Email"]);
                    objBookingMaster.Phone = Convert.ToString(SqlRdr["Phone"]);
                    objBookingMaster.linktoCustomerMasterId = Convert.ToInt32(SqlRdr["linktoCustomerMasterId"]);
                    objBookingMaster.FromDate = Convert.ToDateTime(SqlRdr["FromDate"]);
                    objBookingMaster.ToDate = Convert.ToDateTime(SqlRdr["ToDate"]);
                    objBookingMaster.BookingStatus = Convert.ToInt16(SqlRdr["BookingStatus"]);
                    if (SqlRdr["FromTime"] != DBNull.Value)
                    {
                        objBookingMaster.FromTime = SqlRdr.GetTimeSpan(SqlRdr.GetOrdinal("FromTime"));
                    }
                    if (SqlRdr["ToTime"] != DBNull.Value)
                    {
                        objBookingMaster.ToTime = SqlRdr.GetTimeSpan(SqlRdr.GetOrdinal("ToTime"));
                    }
                    if (SqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                    {
                        objBookingMaster.BookingUser = Convert.ToString(SqlRdr["CustomerName"]);
                    }
                    objBookingMaster.NoOfAdults = Convert.ToInt16(SqlRdr["NoOfAdults"]);
                    objBookingMaster.NoOfChildren = Convert.ToInt16(SqlRdr["NoOfChildren"]);
                    if (Convert.ToInt16(SqlRdr["IsAssigned"]) >= 1)
                    {
                        objBookingMaster.IsAssigned = true;
                    }
                    else
                    {
                        objBookingMaster.IsAssigned = false;
                    }
                    if (SqlRdr["IsPreOrder"] != DBNull.Value)
                    {
                        objBookingMaster.IsPreOrder = Convert.ToBoolean(SqlRdr["IsPreOrder"]);
                    }
                    if (SqlRdr["linktoOrderMasterId"] != DBNull.Value)
                    {
                        objBookingMaster.linktoOrderMasterId = Convert.ToInt64(SqlRdr["linktoOrderMasterId"]);
                    }
                    if (SqlRdr["OrderNumber"] != DBNull.Value)
                    {
                        objBookingMaster.OrderNumber = Convert.ToInt16(SqlRdr["OrderNumber"]);
                    }
                    lstBookingMasterDAL.Add(objBookingMaster);
                }
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstBookingMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswBookingMasterDAL> SelectAllBookingMasterByCustomerMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterByCustomerMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.SmallInt).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                poswBookingMasterDAL objBookingMaster = null;
                List<poswBookingMasterDAL> lstBookingMasterDAL = new List<poswBookingMasterDAL>();
                while (SqlRdr.Read())
                {
                    objBookingMaster = new poswBookingMasterDAL();
                    objBookingMaster.BookingMasterId = Convert.ToInt32(SqlRdr["BookingMasterId"]);
                    objBookingMaster.BookingPersonName = Convert.ToString(SqlRdr["BookingPersonName"]);
                    objBookingMaster.Phone = Convert.ToString(SqlRdr["Phone"]);
                    objBookingMaster.Email = Convert.ToString(SqlRdr["Email"]);
                    objBookingMaster.FromDate = Convert.ToDateTime(SqlRdr["FromDate"]);
                    objBookingMaster.ToDate = Convert.ToDateTime(SqlRdr["ToDate"]);
                    if (SqlRdr["FromTime"] != DBNull.Value)
                    {
                        objBookingMaster.FromTime = SqlRdr.GetTimeSpan(SqlRdr.GetOrdinal("FromTime"));
                    }
                    if (SqlRdr["ToTime"] != DBNull.Value)
                    {
                        objBookingMaster.ToTime = SqlRdr.GetTimeSpan(SqlRdr.GetOrdinal("ToTime"));
                    }
                    if (SqlRdr["IsPreOrder"] != DBNull.Value)
                    {
                        objBookingMaster.IsPreOrder = Convert.ToBoolean(SqlRdr["IsPreOrder"]);
                    }
                    objBookingMaster.NoOfAdults = Convert.ToInt16(SqlRdr["NoOfAdults"]);
                    objBookingMaster.NoOfChildren = Convert.ToInt16(SqlRdr["NoOfChildren"]);
                    objBookingMaster.Remark = Convert.ToString(SqlRdr["Remark"]);
                    objBookingMaster.BookingStatus = Convert.ToInt16(SqlRdr["BookingStatus"]);
                    if (SqlRdr["OrderRemark"] != DBNull.Value)
                    {
                        objBookingMaster.OrderRemark = Convert.ToString(SqlRdr["OrderRemark"]);
                    }
                    objBookingMaster.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);
                    objBookingMaster.PaymentStatus = Convert.ToBoolean(SqlRdr["PaymentStatus"]);
                    poswBookingStatus enumStatus = (poswBookingStatus)objBookingMaster.BookingStatus;
                    objBookingMaster.BookingStatusName = enumStatus.ToString();

                    if (objBookingMaster.BookingStatus == poswBookingStatus.New.GetHashCode())
                    {
                        objBookingMaster.BookingStatusName = "Pending";
                    }

                    lstBookingMasterDAL.Add(objBookingMaster);
                }
                SqlRdr.Close();
                SqlCon.Close();
                return lstBookingMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswBookingMasterDAL> SelectAllBookingMasterByCustomerMasterIdPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterByCustomerMasterIdPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.SmallInt).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                poswBookingMasterDAL objBookingMaster = null;
                List<poswBookingMasterDAL> lstBookingMasterDAL = new List<poswBookingMasterDAL>();
                while (SqlRdr.Read())
                {
                    objBookingMaster = new poswBookingMasterDAL();
                    objBookingMaster.BookingMasterId = Convert.ToInt32(SqlRdr["BookingMasterId"]);
                    objBookingMaster.BookingPersonName = Convert.ToString(SqlRdr["BookingPersonName"]);
                    objBookingMaster.Phone = Convert.ToString(SqlRdr["Phone"]);
                    objBookingMaster.Email = Convert.ToString(SqlRdr["Email"]);
                    objBookingMaster.FromDate = Convert.ToDateTime(SqlRdr["FromDate"]);
                    objBookingMaster.ToDate = Convert.ToDateTime(SqlRdr["ToDate"]);
                    if (SqlRdr["FromTime"] != DBNull.Value)
                    {
                        objBookingMaster.FromTime = SqlRdr.GetTimeSpan(SqlRdr.GetOrdinal("FromTime"));
                    }
                    if (SqlRdr["ToTime"] != DBNull.Value)
                    {
                        objBookingMaster.ToTime = SqlRdr.GetTimeSpan(SqlRdr.GetOrdinal("ToTime"));
                    }

                    ///IsPreOrder is used whether any amount is paid or not for Booking (Android)
                    if (SqlRdr["BookingPaymentCount"] != DBNull.Value && Convert.ToInt32(SqlRdr["BookingPaymentCount"]) > 0)
                    {
                        objBookingMaster.IsPreOrder = true;
                    }
                    else
                    {
                        objBookingMaster.IsPreOrder = false;
                    }

                    objBookingMaster.NoOfAdults = Convert.ToInt16(SqlRdr["NoOfAdults"]);
                    objBookingMaster.NoOfChildren = Convert.ToInt16(SqlRdr["NoOfChildren"]);
                    objBookingMaster.Remark = Convert.ToString(SqlRdr["Remark"]);
                    if (SqlRdr["BookingStatus"] != DBNull.Value)
                    {
                        objBookingMaster.BookingStatus = Convert.ToInt16(SqlRdr["BookingStatus"]);
                        poswBookingStatus enumStatus = (poswBookingStatus)objBookingMaster.BookingStatus;
                        objBookingMaster.BookingStatusName = enumStatus.ToString();
                        if (objBookingMaster.BookingStatus == poswBookingStatus.New.GetHashCode())
                        {
                            objBookingMaster.BookingStatusName = "Pending";
                        }
                    }
                    if (SqlRdr["OrderRemark"] != DBNull.Value)
                    {
                        objBookingMaster.OrderRemark = Convert.ToString(SqlRdr["OrderRemark"]);
                    }
                    objBookingMaster.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);
                    lstBookingMasterDAL.Add(objBookingMaster);
                }
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstBookingMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswBookingMasterDAL> SelectAllBookingMasterGetTimeSlots()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterGetTimeSlots_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@BookingDate", SqlDbType.DateTime).Value = this.FromDate;
                SqlCmd.Parameters.Add("@TimeDuration", SqlDbType.SmallInt).Value = this.TimeDuration;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBookingMasterDAL> lstBookingMasterDAL = new List<poswBookingMasterDAL>();
                poswBookingMasterDAL objBookingMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objBookingMasterDAL = new poswBookingMasterDAL();
                    objBookingMasterDAL.TimeSlot = TimeSpan.Parse(Convert.ToDateTime(SqlRdr["TimeSlot"]).ToString("HH:mm:ss"), CultureInfo.InvariantCulture);
                    lstBookingMasterDAL.Add(objBookingMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstBookingMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Booking Master Hourly
        private List<poswBookingMasterDAL> SetListPropertiesFromSqlDataReaderHourly(SqlDataReader sqlRdr)
        {
            List<poswBookingMasterDAL> lstBookingMaster = new List<poswBookingMasterDAL>();
            poswBookingMasterDAL objBookingMaster = null;

            while (sqlRdr.Read())
            {
                objBookingMaster = new poswBookingMasterDAL();

                objBookingMaster.linktoTableMasterId = Convert.ToInt16(sqlRdr["TableMasterId"]);

                objBookingMaster.TableName = Convert.ToString(sqlRdr["TableName"]);

                //if (sqlRdr["IsHourly"] != DBNull.Value)
                //{
                //    objBookingMaster.IsHourly = Convert.ToBoolean(sqlRdr["IsHourly"]);
                //}
                //else
                //{
                //    objBookingMaster.IsHourly = true;
                //}
                objBookingMaster.T0 = Convert.ToString(sqlRdr["T0"]);
                objBookingMaster.T1 = Convert.ToString(sqlRdr["T1"]);
                objBookingMaster.T2 = Convert.ToString(sqlRdr["T2"]);
                objBookingMaster.T3 = Convert.ToString(sqlRdr["T3"]);
                objBookingMaster.T4 = Convert.ToString(sqlRdr["T4"]);
                objBookingMaster.T5 = Convert.ToString(sqlRdr["T5"]);
                objBookingMaster.T6 = Convert.ToString(sqlRdr["T6"]);
                objBookingMaster.T7 = Convert.ToString(sqlRdr["T7"]);
                objBookingMaster.T8 = Convert.ToString(sqlRdr["T8"]);
                objBookingMaster.T9 = Convert.ToString(sqlRdr["T9"]);
                objBookingMaster.T10 = Convert.ToString(sqlRdr["T10"]);
                objBookingMaster.T11 = Convert.ToString(sqlRdr["T11"]);
                objBookingMaster.T12 = Convert.ToString(sqlRdr["T12"]);
                objBookingMaster.T13 = Convert.ToString(sqlRdr["T13"]);
                objBookingMaster.T14 = Convert.ToString(sqlRdr["T14"]);
                objBookingMaster.T15 = Convert.ToString(sqlRdr["T15"]);
                objBookingMaster.T16 = Convert.ToString(sqlRdr["T16"]);
                objBookingMaster.T17 = Convert.ToString(sqlRdr["T17"]);
                objBookingMaster.T18 = Convert.ToString(sqlRdr["T18"]);
                objBookingMaster.T19 = Convert.ToString(sqlRdr["T19"]);
                objBookingMaster.T20 = Convert.ToString(sqlRdr["T20"]);
                objBookingMaster.T21 = Convert.ToString(sqlRdr["T21"]);
                objBookingMaster.T22 = Convert.ToString(sqlRdr["T22"]);
                objBookingMaster.T23 = Convert.ToString(sqlRdr["T23"]);

                lstBookingMaster.Add(objBookingMaster);
            }
            return lstBookingMaster;
        }

        public List<poswBookingMasterDAL> SelectAllBookingMasterOnHourly()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterHourlyChart_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.FromDate != new DateTime())
                {

                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                }

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBookingMasterDAL> lstBookingMasterDAL = SetListPropertiesFromSqlDataReaderHourly(SqlRdr);

                SqlRdr.Close();
                SqlCon.Close();

                return lstBookingMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public DataTable SelectAllBookingMasterOnDaily()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;

            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingMasterDailyChart_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.FromDate != new DateTime())
                {

                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                }
                if (this.ToDate != new DateTime())
                {

                    SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                }

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();

                SqlDataAdapter SqlDa = new SqlDataAdapter(SqlCmd);
                DataTable Dt = new DataTable();
                SqlDa.Fill(Dt);

                SqlCon.Close();

                return Dt;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                //posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);

            }
        }
        #endregion
    }
}

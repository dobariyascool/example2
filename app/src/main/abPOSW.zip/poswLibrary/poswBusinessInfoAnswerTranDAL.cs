using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBusinessInfoAnswerTran
    /// </summary>
    public class poswBusinessInfoAnswerTranDAL
    {
        #region Properties
        public int BusinessInfoAnswerTranId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int linktoBusinessInfoQuestionMasterId { get; set; }
        public int? linktoBusinessInfoAnswerMasterId { get; set; }
        public string Answer { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }

        /// Extra
        public string Business { get; set; }
        public string BusinessInfoQuestion { get; set; }
        public string BusinessInfoAnswer { get; set; }
        public string UserCreatedBy { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BusinessInfoAnswerTranId = Convert.ToInt32(sqlRdr["BusinessInfoAnswerTranId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(sqlRdr["linktoBusinessInfoQuestionMasterId"]);
                if (sqlRdr["linktoBusinessInfoAnswerMasterId"] != DBNull.Value)
                {
                    this.linktoBusinessInfoAnswerMasterId = Convert.ToInt32(sqlRdr["linktoBusinessInfoAnswerMasterId"]);
                }
                this.Answer = Convert.ToString(sqlRdr["Answer"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);

                /// Extra
                this.Business = Convert.ToString(sqlRdr["Business"]);
                this.BusinessInfoQuestion = Convert.ToString(sqlRdr["BusinessInfoQuestion"]);
                this.BusinessInfoAnswer = Convert.ToString(sqlRdr["BusinessInfoAnswer"]);
                this.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
                return true;
            }
            return false;
        }

        private List<poswBusinessInfoAnswerTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswBusinessInfoAnswerTranDAL> lstBusinessInfoAnswerTran = new List<poswBusinessInfoAnswerTranDAL>();
            poswBusinessInfoAnswerTranDAL objBusinessInfoAnswerTran = null;
            while (sqlRdr.Read())
            {
                objBusinessInfoAnswerTran = new poswBusinessInfoAnswerTranDAL();
                objBusinessInfoAnswerTran.BusinessInfoAnswerTranId = Convert.ToInt32(sqlRdr["BusinessInfoAnswerTranId"]);
                objBusinessInfoAnswerTran.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objBusinessInfoAnswerTran.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(sqlRdr["linktoBusinessInfoQuestionMasterId"]);
                if (sqlRdr["linktoBusinessInfoAnswerMasterId"] != DBNull.Value)
                {
                    objBusinessInfoAnswerTran.linktoBusinessInfoAnswerMasterId = Convert.ToInt32(sqlRdr["linktoBusinessInfoAnswerMasterId"]);
                }
                objBusinessInfoAnswerTran.Answer = Convert.ToString(sqlRdr["Answer"]);
                objBusinessInfoAnswerTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objBusinessInfoAnswerTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);

                /// Extra
                objBusinessInfoAnswerTran.Business = Convert.ToString(sqlRdr["Business"]);
                objBusinessInfoAnswerTran.BusinessInfoQuestion = Convert.ToString(sqlRdr["BusinessInfoQuestion"]);
                objBusinessInfoAnswerTran.BusinessInfoAnswer = Convert.ToString(sqlRdr["BusinessInfoAnswer"]);
                objBusinessInfoAnswerTran.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
                lstBusinessInfoAnswerTran.Add(objBusinessInfoAnswerTran);
            }
            return lstBusinessInfoAnswerTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertBusinessInfoAnswerTran(List<poswBusinessInfoAnswerTranDAL> lstBusinessInfoAnswerTranDAL)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            poswRecordStatus rs = poswRecordStatus.Error;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();


                short linktoBusinessMasterId = lstBusinessInfoAnswerTranDAL.First().linktoBusinessMasterId;
                rs = DeleteBusinessInfoAnswerTran(SqlCon, SqlTran, linktoBusinessMasterId);
                
                if (rs == poswRecordStatus.Error)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
				SqlCmd = new SqlCommand("poswBusinessInfoAnswerTran_Insert", SqlCon, SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;
               
                foreach(poswBusinessInfoAnswerTranDAL obj in lstBusinessInfoAnswerTranDAL)
                {
                   
                    SqlCmd.Parameters.Add("@linktoBusinessInfoQuestionMasterId", SqlDbType.Int).Value = obj.linktoBusinessInfoQuestionMasterId;
                    SqlCmd.Parameters.Add("@linktoBusinessInfoAnswerMasterId", SqlDbType.Int).Value = obj.linktoBusinessInfoAnswerMasterId;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = obj.Answer;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = obj.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = obj.linktoUserMasterIdCreatedBy;
				    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.ExecuteNonQuery();
                   
                    rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == poswRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                    SqlCmd.Parameters.Clear();
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
				
			}
			catch (Exception ex)
            {
                SqlTran.Rollback();
                SqlCon.Close();
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
			}
		}
        #endregion

        #region Update
        public poswRecordStatus UpdateBusinessInfoAnswerTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessInfoAnswerTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessInfoAnswerTranId", SqlDbType.Int).Value = this.BusinessInfoAnswerTranId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessInfoQuestionMasterId", SqlDbType.Int).Value = this.linktoBusinessInfoQuestionMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessInfoAnswerMasterId", SqlDbType.Int).Value = this.linktoBusinessInfoAnswerMasterId;
                SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = this.Answer;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteBusinessInfoAnswerTran(SqlConnection SqlCon, SqlTransaction SqlTran, short linktoBusinessMasterId)
        {
           
            SqlCommand SqlCmd = null;
            try
            {
               
                SqlCmd = new SqlCommand("poswBusinessInfoAnswerTran_Delete", SqlCon,SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.ExecuteNonQuery();
              
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
               
            }
        }
        #endregion

        #region Select
        public bool SelectBusinessInfoAnswerTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessInfoAnswerTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessInfoAnswerTranId", SqlDbType.Int).Value = this.BusinessInfoAnswerTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswBusinessInfoAnswerTranDAL> SelectAllBusinessInfoAnswerTranPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessInfoAnswerTranPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }
                if (this.linktoUserMasterIdCreatedBy > 0)
                {
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                }


                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessInfoAnswerTranDAL> lstBusinessInfoAnswerTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstBusinessInfoAnswerTranDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswPaymentTypeMaster
	/// </summary>
	public class poswPaymentTypeMasterDAL
	{
		#region Properties
		public short PaymentTypeMasterId { get; set; }
		public string ShortName { get; set; }
		public string PaymentType { get; set; }
		public string Description { get; set; }
		public short? linktoPaymentTypeCategoryMasterId { get; set; }
		public bool IsEnabled { get; set; }
		public short? linktoBusinessMasterId { get; set; }
		public short? linktoUserMasterIdCreatedBy { get; set; }
		public DateTime CreateDateTime { get; set; }
		public short? linktoUserMasterIdUpdatedBy { get; set; }
		public DateTime? UpdateDateTime { get; set; }

		/// Extra
		public string PaymentTypeCategory { get; set; }
		public string Business { get; set; }
		public string UserCreatedBy { get; set; }
		public string UserUpdatedBy { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.PaymentTypeMasterId = Convert.ToInt16(sqlRdr["PaymentTypeMasterId"]);
				this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
				this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
				this.Description = Convert.ToString(sqlRdr["Description"]);
				this.linktoPaymentTypeCategoryMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeCategoryMasterId"]);
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
				this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
				}
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}

				/// Extra
				this.PaymentTypeCategory = Convert.ToString(sqlRdr["PaymentTypeCategory"]);
				this.Business = Convert.ToString(sqlRdr["Business"]);
				this.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
				this.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
				return true;
			}
			return false;
		}

		private List<poswPaymentTypeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswPaymentTypeMasterDAL> lstPaymentTypeMaster = new List<poswPaymentTypeMasterDAL>();
			poswPaymentTypeMasterDAL objPaymentTypeMaster = null;
			while (sqlRdr.Read())
			{
				objPaymentTypeMaster = new poswPaymentTypeMasterDAL();
				objPaymentTypeMaster.PaymentTypeMasterId = Convert.ToInt16(sqlRdr["PaymentTypeMasterId"]);
				objPaymentTypeMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
				objPaymentTypeMaster.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
				objPaymentTypeMaster.Description = Convert.ToString(sqlRdr["Description"]);
				objPaymentTypeMaster.linktoPaymentTypeCategoryMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeCategoryMasterId"]);
				objPaymentTypeMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				objPaymentTypeMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				objPaymentTypeMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
				objPaymentTypeMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					objPaymentTypeMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
				}
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					objPaymentTypeMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}

				/// Extra
				objPaymentTypeMaster.PaymentTypeCategory = Convert.ToString(sqlRdr["PaymentTypeCategory"]);
				objPaymentTypeMaster.Business = Convert.ToString(sqlRdr["Business"]);
				objPaymentTypeMaster.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
				objPaymentTypeMaster.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
				lstPaymentTypeMaster.Add(objPaymentTypeMaster);
			}
			return lstPaymentTypeMaster;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertPaymentTypeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswPaymentTypeMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@PaymentTypeMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
				SqlCmd.Parameters.Add("@PaymentType", SqlDbType.VarChar).Value = this.PaymentType;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@linktoPaymentTypeCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeCategoryMasterId;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
				SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.PaymentTypeMasterId = Convert.ToInt16(SqlCmd.Parameters["@PaymentTypeMasterId"].Value);
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public poswRecordStatus UpdatePaymentTypeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswPaymentTypeMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@PaymentTypeMasterId", SqlDbType.SmallInt).Value = this.PaymentTypeMasterId;
				SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
				SqlCmd.Parameters.Add("@PaymentType", SqlDbType.VarChar).Value = this.PaymentType;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@linktoPaymentTypeCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeCategoryMasterId;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public poswRecordStatus DeletePaymentTypeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswPaymentTypeMaster_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@PaymentTypeMasterId", SqlDbType.SmallInt).Value = this.PaymentTypeMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectPaymentTypeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswPaymentTypeMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@PaymentTypeMasterId", SqlDbType.SmallInt).Value = this.PaymentTypeMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<poswPaymentTypeMasterDAL> SelectAllPaymentTypeMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswPaymentTypeMasterPageWise_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
				SqlCmd.Parameters.Add("@PaymentType", SqlDbType.VarChar).Value = this.PaymentType;
				if (this.linktoPaymentTypeCategoryMasterId > 0)
				{
					SqlCmd.Parameters.Add("@linktoPaymentTypeCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeCategoryMasterId;
				}
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				if (this.linktoBusinessMasterId > 0)
				{
					SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				}

				SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
				SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
				SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswPaymentTypeMasterDAL> lstPaymentTypeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
				return lstPaymentTypeMasterDAL;
			}
			catch (Exception ex)
			{
				totalRecords = 0;
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public static List<poswPaymentTypeMasterDAL> SelectAllPaymentTypeMasterPaymentType(short linktoBusinessMasterId)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswPaymentTypeMasterPaymentType_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswPaymentTypeMasterDAL> lstPaymentTypeMasterDAL = new List<poswPaymentTypeMasterDAL>();
				poswPaymentTypeMasterDAL objPaymentTypeMasterDAL = null;
				while (SqlRdr.Read())
				{
					objPaymentTypeMasterDAL = new poswPaymentTypeMasterDAL();
					objPaymentTypeMasterDAL.PaymentTypeMasterId = Convert.ToInt16(SqlRdr["PaymentTypeMasterId"]);
					objPaymentTypeMasterDAL.PaymentType = Convert.ToString(SqlRdr["PaymentType"]);
					lstPaymentTypeMasterDAL.Add(objPaymentTypeMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstPaymentTypeMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

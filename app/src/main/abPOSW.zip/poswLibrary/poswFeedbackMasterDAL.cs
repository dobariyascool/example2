using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswFeedbackMaster
    /// </summary>
    public class poswFeedbackMasterDAL
    {
        #region Properties
        public int FeedbackMasterId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Feedback { get; set; }
        public DateTime FeedbackFromTime { get; set; }
        public DateTime FeedbackToTime { get; set; }
        public short FeedbackType { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public DateTime FeedbackDateTime { get; set; }
        /// Extra
        public string RegisteredUser { get; set; }
        public string Business { get; set; }
        #endregion

        #region Class Methods
        private List<poswFeedbackMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswFeedbackMasterDAL> lstFeedbackMaster = new List<poswFeedbackMasterDAL>();
            poswFeedbackMasterDAL objFeedbackMaster = null;
            while (sqlRdr.Read())
            {
                objFeedbackMaster = new poswFeedbackMasterDAL();
                objFeedbackMaster.FeedbackMasterId = Convert.ToInt32(sqlRdr["FeedbackMasterId"]);
                objFeedbackMaster.Name = Convert.ToString(sqlRdr["Name"]);
                objFeedbackMaster.Email = Convert.ToString(sqlRdr["Email"]);
                objFeedbackMaster.Phone = Convert.ToString(sqlRdr["Phone"]);
                objFeedbackMaster.Feedback = Convert.ToString(sqlRdr["Feedback"]);
                objFeedbackMaster.FeedbackFromTime = Convert.ToDateTime(sqlRdr["FeedbackDateTime"]);
                objFeedbackMaster.FeedbackType = Convert.ToInt16(sqlRdr["FeedbackType"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objFeedbackMaster.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                objFeedbackMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                /// Extra
                objFeedbackMaster.RegisteredUser = Convert.ToString(sqlRdr["Customer"]);
                objFeedbackMaster.Business = Convert.ToString(sqlRdr["Business"]);
                lstFeedbackMaster.Add(objFeedbackMaster);
            }
            return lstFeedbackMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertFeedbackMaster(List<poswFeedbackTranDAL> lstFeedbackTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswFeedbackMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Feedback", SqlDbType.VarChar).Value = this.Feedback;
                SqlCmd.Parameters.Add("@FeedbackDateTime", SqlDbType.DateTime).Value = this.FeedbackDateTime;
                SqlCmd.Parameters.Add("@FeedbackType", SqlDbType.SmallInt).Value = this.FeedbackType;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.FeedbackMasterId = Convert.ToInt32(SqlCmd.Parameters["@FeedbackMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == poswRecordStatus.Success)
                {
                    if (lstFeedbackTranDAL != null && lstFeedbackTranDAL.Count > 0)
                    {
                        if (poswFeedbackTranDAL.InsertFeedbackTran(this.FeedbackMasterId, lstFeedbackTranDAL, SqlCon, SqlTran) == poswRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            return poswRecordStatus.Error;
                        }
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return poswRecordStatus.Error;
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region DeleteAll
        public static poswRecordStatus DeleteAllFeedbackMaster(string feedbackMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackMasterIds", SqlDbType.VarChar).Value = feedbackMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswFeedbackMasterDAL> SelectAllFeedbackMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                if (this.FeedbackFromTime != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FeedbackFromDate", SqlDbType.DateTime).Value = this.FeedbackFromTime;
                }
                if (this.FeedbackToTime != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FeedbackToDate", SqlDbType.DateTime).Value = this.FeedbackToTime;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswFeedbackMasterDAL> lstFeedbackMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstFeedbackMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Commented

        // DO NOT DELETE
        //private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        //{
        //    if (sqlRdr.Read())
        //    {
        //        this.FeedbackMasterId = Convert.ToInt32(sqlRdr["FeedbackMasterId"]);
        //        this.Name = Convert.ToString(sqlRdr["Name"]);
        //        this.Email = Convert.ToString(sqlRdr["Email"]);
        //        this.Phone = Convert.ToString(sqlRdr["Phone"]);
        //        this.Feedback = Convert.ToString(sqlRdr["Feedback"]);
        //        this.FeedbackFromTime = Convert.ToDateTime(sqlRdr["FeedbackDateTime"]);
        //        this.FeedbackType = Convert.ToInt16(sqlRdr["FeedbackType"]);
       
        //        this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

        //        /// Extra
        //        this.RegisteredUser = Convert.ToString(sqlRdr["RegisteredUser"]);
        //        this.Business = Convert.ToString(sqlRdr["Business"]);
        //        return true;
        //    }
        //    return false;
        //}
        //#region Insert
        //public poswRecordStatus InsertFeedbackMaster()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackMaster_Insert", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
        //        SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
        //        SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
        //        SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
        //        SqlCmd.Parameters.Add("@Feedback", SqlDbType.VarChar).Value = this.Feedback;
        //        SqlCmd.Parameters.Add("@FeedbackDateTime", SqlDbType.DateTime).Value = this.FeedbackFromTime;
        //        SqlCmd.Parameters.Add("@FeedbackType", SqlDbType.SmallInt).Value = this.FeedbackType;
        
        //        SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
        //        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCon.Open();
        //        SqlCmd.ExecuteNonQuery();
        //        SqlCon.Close();

        //        this.FeedbackMasterId = Convert.ToInt32(SqlCmd.Parameters["@FeedbackMasterId"].Value);
        //        poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
        //        return rs;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return poswRecordStatus.Error;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        //#endregion

        //#region Update
        //public poswRecordStatus UpdateFeedbackMaster()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackMaster_Update", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackMasterId", SqlDbType.Int).Value = this.FeedbackMasterId;
        //        SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
        //        SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
        //        SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
        //        SqlCmd.Parameters.Add("@Feedback", SqlDbType.VarChar).Value = this.Feedback;
        //        SqlCmd.Parameters.Add("@FeedbackDateTime", SqlDbType.DateTime).Value = this.FeedbackFromTime;
        //        SqlCmd.Parameters.Add("@FeedbackType", SqlDbType.SmallInt).Value = this.FeedbackType;
        
        //        SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
        //        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCon.Open();
        //        SqlCmd.ExecuteNonQuery();
        //        SqlCon.Close();

        //        poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
        //        return rs;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return poswRecordStatus.Error;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        //#endregion

        //#region Delete
        //public poswRecordStatus DeleteFeedbackMaster()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    SqlTransaction SqlTran = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCon.Open();
        //        SqlTran = SqlCon.BeginTransaction();
        //        SqlCmd = new SqlCommand("poswFeedbackMaster_Delete", SqlCon, SqlTran);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackMasterId", SqlDbType.Int).Value = this.FeedbackMasterId;
        //        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCmd.ExecuteNonQuery();

        //        poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

        //        if (rs != poswRecordStatus.Success)
        //        {
        //            SqlTran.Rollback();
        //            SqlCon.Close();
        //            return rs;
        //        }
        //        else
        //        {
        //            poswFeedbackTranDAL objFeedbackTranDAL = new poswFeedbackTranDAL();
        //            objFeedbackTranDAL.linktoFeedbackMasterId = this.FeedbackMasterId;

        //            rs = objFeedbackTranDAL.DeleteFeedbackTran(SqlTran, SqlCon);
        //            if (rs != poswRecordStatus.Success)
        //            {
        //                SqlTran.Rollback();
        //                SqlCon.Close();
        //                return rs;
        //            }
        //        }


        //        return rs;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return poswRecordStatus.Error;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        //#endregion
        //#region Select
        //public bool SelectFeedbackMaster()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    SqlDataReader SqlRdr = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackMaster_Select", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackMasterId", SqlDbType.Int).Value = this.FeedbackMasterId;

        //        SqlCon.Open();
        //        SqlRdr = SqlCmd.ExecuteReader();
        //        bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
        //        SqlRdr.Close();
        //        SqlCon.Close();

        //        return IsSelected;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return false;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        //#endregion
        #endregion
    }
}

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswTaxMaster
    /// </summary>
    public class poswTaxMasterDAL
    {
        #region Properties
        public short TaxMasterId { get; set; }
        public string TaxName { get; set; }
        public string TaxCaption { get; set; }
        public short TaxIndex { get; set; }
        public double TaxRate { get; set; }
        public bool IsPercentage { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public double DefaultTaxRate { get; set; }
        public int linktoItemMasterId { get; set; }
        #endregion

        #region Class Methods
        private List<poswTaxMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswTaxMasterDAL> lstTaxMaster = new List<poswTaxMasterDAL>();
            poswTaxMasterDAL objTaxMaster = null;
            while (sqlRdr.Read())
            {
                objTaxMaster = new poswTaxMasterDAL();
                objTaxMaster.TaxMasterId = Convert.ToInt16(sqlRdr["TaxMasterId"]);
                objTaxMaster.TaxName = Convert.ToString(sqlRdr["TaxName"]);
                objTaxMaster.TaxCaption = Convert.ToString(sqlRdr["TaxCaption"]);
                objTaxMaster.TaxIndex = Convert.ToInt16(sqlRdr["TaxIndex"]);
                objTaxMaster.TaxRate = Convert.ToDouble(sqlRdr["TaxRate"]);
                objTaxMaster.IsPercentage = Convert.ToBoolean(sqlRdr["IsPercentage"]);
                objTaxMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objTaxMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objTaxMaster.CreatedDateTime = Convert.ToDateTime(sqlRdr["CreatedDateTime"]);
                objTaxMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objTaxMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objTaxMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                lstTaxMaster.Add(objTaxMaster);
            }
            return lstTaxMaster;
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateTaxMaster(List<poswTaxMasterDAL> lstTaxMasterDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                poswRecordStatus rs = poswRecordStatus.Error;
                foreach (poswTaxMasterDAL objTaxMasterDAL in lstTaxMasterDAL)
                {
                    SqlCmd = new SqlCommand("poswTaxMaster_Update", SqlCon);
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlCmd.Parameters.Add("@TaxMasterId", SqlDbType.SmallInt).Value = objTaxMasterDAL.TaxMasterId;
                    SqlCmd.Parameters.Add("@TaxCaption", SqlDbType.VarChar).Value = objTaxMasterDAL.TaxCaption;
                    SqlCmd.Parameters.Add("@TaxRate", SqlDbType.Money).Value = objTaxMasterDAL.TaxRate;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objTaxMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@IsPercentage", SqlDbType.Bit).Value = objTaxMasterDAL.IsPercentage;
                    SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = objTaxMasterDAL.UpdateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = objTaxMasterDAL.linktoUserMasterIdUpdatedBy;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                    rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    SqlCmd.Parameters.Clear();
                }
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswTaxMasterDAL> SelectAllTaxMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTaxMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswTaxMasterDAL> lstTaxMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstTaxMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswTaxMasterDAL> SelectAllTaxMasterByBusinessMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTaxMasterByBusinessMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswTaxMasterDAL> lstTaxMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstTaxMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswTaxMasterDAL> SelectAllItemRateTaxForBillSummaryTran(string linktoItemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemRateTranTaxForBillSummary_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterIds", SqlDbType.VarChar).Value = linktoItemMasterIds;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                
                List<poswTaxMasterDAL> lstTaxMasterDAL = new List<poswTaxMasterDAL>();
                poswTaxMasterDAL objTaxMasterDAL = null;
                
                while (SqlRdr.Read())
                {
                    objTaxMasterDAL = new poswTaxMasterDAL();
                    objTaxMasterDAL.TaxRate = Convert.ToDouble(SqlRdr["TotalTaxRate"]);
                    objTaxMasterDAL.TaxCaption = Convert.ToString(SqlRdr["TaxCaption"]);
                    objTaxMasterDAL.TaxIndex = Convert.ToInt16(SqlRdr["TaxIndex"]);                    
                    objTaxMasterDAL.DefaultTaxRate = Convert.ToDouble(SqlRdr["DefaultTaxRate"]);
                    objTaxMasterDAL.TaxMasterId = Convert.ToInt16(SqlRdr["TaxMasterId"]);
                    objTaxMasterDAL.linktoItemMasterId = Convert.ToInt16(SqlRdr["ItemMasterId"]);
                    lstTaxMasterDAL.Add(objTaxMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstTaxMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

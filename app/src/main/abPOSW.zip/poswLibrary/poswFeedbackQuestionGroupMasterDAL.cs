using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswFeedbackQuestionGroupMaster
	/// </summary>
	public class poswFeedbackQuestionGroupMasterDAL
	{
		#region Properties
		public short FeedbackQuestionGroupMasterId { get; set; }
		public short linktoBusinessMasterId { get; set; }
		public string GroupName { get; set; }
		public bool IsDeleted { get; set; }

		/// Extra
		public string Business { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.FeedbackQuestionGroupMasterId = Convert.ToInt16(sqlRdr["FeedbackQuestionGroupMasterId"]);
				this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				this.GroupName = Convert.ToString(sqlRdr["GroupName"]);
				this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

				/// Extra
				this.Business = Convert.ToString(sqlRdr["Business"]);
				return true;
			}
			return false;
		}

		private List<poswFeedbackQuestionGroupMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswFeedbackQuestionGroupMasterDAL> lstFeedbackQuestionGroupMaster = new List<poswFeedbackQuestionGroupMasterDAL>();
			poswFeedbackQuestionGroupMasterDAL objFeedbackQuestionGroupMaster = null;
			while (sqlRdr.Read())
			{
				objFeedbackQuestionGroupMaster = new poswFeedbackQuestionGroupMasterDAL();
				objFeedbackQuestionGroupMaster.FeedbackQuestionGroupMasterId = Convert.ToInt16(sqlRdr["FeedbackQuestionGroupMasterId"]);
				objFeedbackQuestionGroupMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				objFeedbackQuestionGroupMaster.GroupName = Convert.ToString(sqlRdr["GroupName"]);
				objFeedbackQuestionGroupMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

				/// Extra
				objFeedbackQuestionGroupMaster.Business = Convert.ToString(sqlRdr["Business"]);
				lstFeedbackQuestionGroupMaster.Add(objFeedbackQuestionGroupMaster);
			}
			return lstFeedbackQuestionGroupMaster;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertFeedbackQuestionGroupMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswFeedbackQuestionGroupMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@FeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@GroupName", SqlDbType.VarChar).Value = this.GroupName;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.FeedbackQuestionGroupMasterId = Convert.ToInt16(SqlCmd.Parameters["@FeedbackQuestionGroupMasterId"].Value);
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public poswRecordStatus DeleteFeedbackQuestionGroupMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswFeedbackQuestionGroupMaster_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@FeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Value = this.FeedbackQuestionGroupMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<poswFeedbackQuestionGroupMasterDAL> SelectAllFeedbackQuestionGroupMasterGroupName()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswFeedbackQuestionGroupMasterGroupName_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswFeedbackQuestionGroupMasterDAL> lstFeedbackQuestionGroupMasterDAL = new List<poswFeedbackQuestionGroupMasterDAL>();
				poswFeedbackQuestionGroupMasterDAL objFeedbackQuestionGroupMasterDAL = null;
				while (SqlRdr.Read())
				{
					objFeedbackQuestionGroupMasterDAL = new poswFeedbackQuestionGroupMasterDAL();
					objFeedbackQuestionGroupMasterDAL.FeedbackQuestionGroupMasterId = Convert.ToInt16(SqlRdr["FeedbackQuestionGroupMasterId"]);
					objFeedbackQuestionGroupMasterDAL.GroupName = Convert.ToString(SqlRdr["GroupName"]);
					lstFeedbackQuestionGroupMasterDAL.Add(objFeedbackQuestionGroupMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstFeedbackQuestionGroupMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

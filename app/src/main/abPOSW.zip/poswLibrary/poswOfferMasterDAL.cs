using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswOfferMaster
    /// </summary>
    public class poswOfferMasterDAL
    {
        #region Properties
        public int OfferMasterId { get; set; }
        public short linktoOfferTypeMasterId { get; set; }
        public string OfferTitle { get; set; }
        public string OfferContent { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public TimeSpan? FromTime { get; set; }
        public TimeSpan? ToTime { get; set; }
        public double? MinimumBillAmount { get; set; }
        public double Discount { get; set; }
        public bool IsDiscountPercentage { get; set; }
        public int? RedeemCount { get; set; }
        public string OfferCode { get; set; }
        public string ImagePhysicalName { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string TermsAndConditions { get; set; }
        public bool IsForCustomers { get; set; }
        public int? BuyItemCount { get; set; }
        public int? GetItemCount { get; set; }
        public string linktoOrderTypeMasterIds { get; set; }
        public bool? IsOnline { get; set; }
        public bool? IsForApp { get; set; }
        public bool IsForAllDays { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }

        /// Extra
        public string ImageName { get; set; }
        public string xsImagePhysicalName { get; set; }
        public string smImagePhysicalName { get; set; }
        public string mdImagePhysicalName { get; set; }
        public string lgImagePhysicalName { get; set; }
        public string xlImagePhysicalName { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public List<poswOfferCodesTranDAL> lstOfferCodesTranDAL { get; set; }
        public List<poswOfferItemsTranDAL> lstOfferItemsTranDAL { get; set; }
        public List<poswOfferDaysTranDAL> lstOfferDaysTranDAL { get; set; }
        public string ValidDays { get; set; }
        public string ValidItems { get; set; }
        public string ValidBuyItems { get; set; }
        public string ValidGetItems { get; set; }
        public string OfferDiscount { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "offer/";
            if (sqlRdr.Read())
            {
                this.OfferMasterId = Convert.ToInt32(sqlRdr["OfferMasterId"]);
                this.linktoOfferTypeMasterId = Convert.ToInt16(sqlRdr["linktoOfferTypeMasterId"]);
                this.OfferTitle = Convert.ToString(sqlRdr["OfferTitle"]);
                this.OfferContent = Convert.ToString(sqlRdr["OfferContent"]);
                if (sqlRdr["FromDate"] != DBNull.Value)
                {
                    this.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                }
                if (sqlRdr["ToDate"] != DBNull.Value)
                {
                    this.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                }
                if (sqlRdr["FromTime"] != DBNull.Value)
                {
                    this.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
                }
                if (sqlRdr["ToTime"] != DBNull.Value)
                {
                    this.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
                }
                if (sqlRdr["MinimumBillAmount"] != DBNull.Value)
                {
                    this.MinimumBillAmount = Convert.ToDouble(sqlRdr["MinimumBillAmount"]);
                }
                this.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                this.IsDiscountPercentage = Convert.ToBoolean(sqlRdr["IsDiscountPercentage"]);
                if (sqlRdr["RedeemCount"] != DBNull.Value)
                {
                    this.RedeemCount = Convert.ToInt32(sqlRdr["RedeemCount"]);
                }
                this.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);
                this.ImagePhysicalName = Convert.ToString(sqlRdr["ImagePhysicalName"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.TermsAndConditions = Convert.ToString(sqlRdr["TermsAndConditions"]);
                if (sqlRdr["IsForCustomers"] != DBNull.Value)
                {
                    this.IsForCustomers = Convert.ToBoolean(sqlRdr["IsForCustomers"]);
                }
                if (sqlRdr["BuyItemCount"] != DBNull.Value)
                {
                    this.BuyItemCount = Convert.ToInt32(sqlRdr["BuyItemCount"]);
                }
                if (sqlRdr["GetItemCount"] != DBNull.Value)
                {
                    this.GetItemCount = Convert.ToInt32(sqlRdr["GetItemCount"]);
                }
                this.linktoOrderTypeMasterIds = Convert.ToString(sqlRdr["linktoOrderTypeMasterIds"]);
                if (sqlRdr["IsOnline"] != DBNull.Value)
                {
                    this.IsOnline = Convert.ToBoolean(sqlRdr["IsOnline"]);
                }
                if (sqlRdr["IsForApp"] != DBNull.Value)
                {
                    this.IsForApp = Convert.ToBoolean(sqlRdr["IsForApp"]);
                }
                if (sqlRdr["IsForAllDays"] != DBNull.Value)
                {
                    this.IsForAllDays = Convert.ToBoolean(sqlRdr["IsForAllDays"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                this.ImageName = Convert.ToString(sqlRdr["ImagePhysicalName"]);
                if (sqlRdr["ImagePhysicalName"] != DBNull.Value)
                {
                    this.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImagePhysicalName"]);

                    this.xsImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    this.smImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    this.mdImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    this.lgImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    this.xlImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                }
                else
                {
                    this.ImagePhysicalName = "img/NoImage.png";

                    this.xsImagePhysicalName = "img/NoImage.png";
                    this.smImagePhysicalName = "img/NoImage.png";
                    this.mdImagePhysicalName = "img/NoImage.png";
                    this.lgImagePhysicalName = "img/NoImage.png";
                    this.xlImagePhysicalName = "img/NoImage.png";
                }
                if (sqlRdr["ValidDays"] != DBNull.Value)
                {
                    this.ValidDays = Convert.ToString(sqlRdr["ValidDays"]);
                }
                if (sqlRdr["ValidItems"] != DBNull.Value)
                {
                    this.ValidItems = Convert.ToString(sqlRdr["ValidItems"]);
                }
                if (sqlRdr["ValidBuyItems"] != DBNull.Value)
                {
                    this.ValidBuyItems = Convert.ToString(sqlRdr["ValidBuyItems"]);
                }
                if (sqlRdr["ValidGetItems"] != DBNull.Value)
                {
                    this.ValidGetItems = Convert.ToString(sqlRdr["ValidGetItems"]);
                }
                return true;
            }
            return false;
        }

        private List<poswOfferMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "offer/";
            List<poswOfferMasterDAL> lstOfferMaster = new List<poswOfferMasterDAL>();
            poswOfferMasterDAL objOfferMaster = null;
            while (sqlRdr.Read())
            {
                objOfferMaster = new poswOfferMasterDAL();
                objOfferMaster.OfferMasterId = Convert.ToInt32(sqlRdr["OfferMasterId"]);
                objOfferMaster.linktoOfferTypeMasterId = Convert.ToInt16(sqlRdr["linktoOfferTypeMasterId"]);
                objOfferMaster.OfferTitle = Convert.ToString(sqlRdr["OfferTitle"]);
                objOfferMaster.OfferContent = Convert.ToString(sqlRdr["OfferContent"]);
                if (sqlRdr["FromDate"] != DBNull.Value)
                {
                    objOfferMaster.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                }
                if (sqlRdr["ToDate"] != DBNull.Value)
                {
                    objOfferMaster.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                }
                if (sqlRdr["FromTime"] != DBNull.Value)
                {
                    objOfferMaster.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
                }
                if (sqlRdr["ToTime"] != DBNull.Value)
                {
                    objOfferMaster.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
                }
                if (sqlRdr["MinimumBillAmount"] != DBNull.Value)
                {
                    objOfferMaster.MinimumBillAmount = Convert.ToDouble(sqlRdr["MinimumBillAmount"]);
                }
                objOfferMaster.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                objOfferMaster.IsDiscountPercentage = Convert.ToBoolean(sqlRdr["IsDiscountPercentage"]);
                if (sqlRdr["RedeemCount"] != DBNull.Value)
                {
                    objOfferMaster.RedeemCount = Convert.ToInt32(sqlRdr["RedeemCount"]);
                }
                else
                {
                    objOfferMaster.RedeemCount = 0;
                }
                objOfferMaster.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);
                objOfferMaster.ImagePhysicalName = Convert.ToString(sqlRdr["ImagePhysicalName"]);
                objOfferMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objOfferMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objOfferMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objOfferMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objOfferMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objOfferMaster.TermsAndConditions = Convert.ToString(sqlRdr["TermsAndConditions"]);
                if (sqlRdr["IsForCustomers"] != DBNull.Value)
                {
                    objOfferMaster.IsForCustomers = Convert.ToBoolean(sqlRdr["IsForCustomers"]);
                }
                if (sqlRdr["BuyItemCount"] != DBNull.Value)
                {
                    objOfferMaster.BuyItemCount = Convert.ToInt32(sqlRdr["BuyItemCount"]);
                }
                if (sqlRdr["GetItemCount"] != DBNull.Value)
                {
                    objOfferMaster.GetItemCount = Convert.ToInt32(sqlRdr["GetItemCount"]);
                }
                objOfferMaster.linktoOrderTypeMasterIds = Convert.ToString(sqlRdr["linktoOrderTypeMasterIds"]);
                if (sqlRdr["IsOnline"] != DBNull.Value)
                {
                    objOfferMaster.IsOnline = Convert.ToBoolean(sqlRdr["IsOnline"]);
                }
                if (sqlRdr["IsForApp"] != DBNull.Value)
                {
                    objOfferMaster.IsForApp = Convert.ToBoolean(sqlRdr["IsForApp"]);
                }
                if (sqlRdr["IsForAllDays"] != DBNull.Value)
                {
                    objOfferMaster.IsForAllDays = Convert.ToBoolean(sqlRdr["IsForAllDays"]);
                }
                objOfferMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objOfferMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                objOfferMaster.ImageName = Convert.ToString(sqlRdr["ImagePhysicalName"]);
                if (sqlRdr["ImagePhysicalName"] != DBNull.Value)
                {
                    objOfferMaster.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImagePhysicalName"]);

                    objOfferMaster.xsImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    objOfferMaster.smImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    objOfferMaster.mdImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    objOfferMaster.lgImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    objOfferMaster.xlImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                }
                else
                {
                    objOfferMaster.ImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.xsImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.smImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.mdImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.lgImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.xlImagePhysicalName = "img/NoImage.png";
                }
                lstOfferMaster.Add(objOfferMaster);
            }
            return lstOfferMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOfferTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOfferTypeMasterId;
                SqlCmd.Parameters.Add("@OfferTitle", SqlDbType.VarChar).Value = this.OfferTitle;
                SqlCmd.Parameters.Add("@OfferContent", SqlDbType.VarChar).Value = this.OfferContent;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@MinimumBillAmount", SqlDbType.Money).Value = this.MinimumBillAmount;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
                SqlCmd.Parameters.Add("@IsDiscountPercentage", SqlDbType.Bit).Value = this.IsDiscountPercentage;
                SqlCmd.Parameters.Add("@RedeemCount", SqlDbType.Int).Value = this.RedeemCount;
                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@ImagePhysicalName", SqlDbType.VarChar).Value = this.ImagePhysicalName;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@TermsAndConditions", SqlDbType.VarChar).Value = this.TermsAndConditions;
                SqlCmd.Parameters.Add("@IsForCustomers", SqlDbType.Bit).Value = this.IsForCustomers;
                SqlCmd.Parameters.Add("@BuyItemCount", SqlDbType.Int).Value = this.BuyItemCount;
                SqlCmd.Parameters.Add("@GetItemCount", SqlDbType.Int).Value = this.GetItemCount;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterIds", SqlDbType.VarChar).Value = this.linktoOrderTypeMasterIds;
                SqlCmd.Parameters.Add("@IsOnline", SqlDbType.Bit).Value = this.IsOnline;
                SqlCmd.Parameters.Add("@IsForApp", SqlDbType.Bit).Value = this.IsForApp;
                SqlCmd.Parameters.Add("@IsForAllDays", SqlDbType.Bit).Value = this.IsForAllDays;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.OfferMasterId = Convert.ToInt32(SqlCmd.Parameters["@OfferMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus InsertOfferMasterNew()
        {
            SqlConnection SqlCon = null;
            SqlTransaction SqlTran = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswOfferMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOfferTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOfferTypeMasterId;
                SqlCmd.Parameters.Add("@OfferTitle", SqlDbType.VarChar).Value = this.OfferTitle;
                SqlCmd.Parameters.Add("@OfferContent", SqlDbType.VarChar).Value = this.OfferContent;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@MinimumBillAmount", SqlDbType.Money).Value = this.MinimumBillAmount;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
                SqlCmd.Parameters.Add("@IsDiscountPercentage", SqlDbType.Bit).Value = this.IsDiscountPercentage;
                SqlCmd.Parameters.Add("@IsForApp", SqlDbType.Bit).Value = this.IsForApp;
                SqlCmd.Parameters.Add("@BuyItemCount", SqlDbType.Int).Value = this.BuyItemCount;
                SqlCmd.Parameters.Add("@GetItemCount", SqlDbType.Int).Value = this.GetItemCount;
                SqlCmd.Parameters.Add("@IsForAllDays", SqlDbType.Bit).Value = this.IsForAllDays;
                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@ImagePhysicalName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@TermsAndConditions", SqlDbType.VarChar).Value = this.TermsAndConditions;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@IsForCustomers", SqlDbType.Bit).Value = this.IsForCustomers;
                SqlCmd.Parameters.Add("@IsOnline", SqlDbType.Bit).Value = this.IsOnline;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterIds", SqlDbType.VarChar).Value = this.linktoOrderTypeMasterIds;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OfferMasterId = Convert.ToInt32(SqlCmd.Parameters["@OfferMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == poswRecordStatus.Error || rs == poswRecordStatus.RecordAlreadyExist)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                if (IsForCustomers)
                {
                    foreach (poswOfferCodesTranDAL objOfferCodesTran in lstOfferCodesTranDAL)
                    {
                        objOfferCodesTran.linktoOfferMasterId = this.OfferMasterId;
                        rs = objOfferCodesTran.InsertOfferCodesTran(SqlCon, SqlTran);

                        if (rs == poswRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }

                if (linktoOfferTypeMasterId != Convert.ToInt16(poswOfferType.All_Items.GetHashCode()))
                {
                    lstOfferItemsTranDAL.ForEach(j => j.linktoOfferMasterId = this.OfferMasterId);

                    DataTable dtOfferItem = new DataTable();
                    List<string> ExtraCollumn = new List<string>();

                    ExtraCollumn.Add("linktoItemMasterIds");
                    ExtraCollumn.Add("OfferItemTypeIds");

                    dtOfferItem = poswGlobalsDAL.ToDataTable(lstOfferItemsTranDAL, ExtraCollumn);
                    poswOfferItemsTranDAL objOfferItemsTranDAL = new poswOfferItemsTranDAL();
                    objOfferItemsTranDAL.linktoOfferMasterId = this.OfferMasterId;
                    rs = objOfferItemsTranDAL.InsertAllOfferItemsTran(SqlCon, SqlTran, dtOfferItem);
                    if (rs == poswRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                if (!IsForAllDays)
                {
                    foreach (poswOfferDaysTranDAL objOfferDaysTran in lstOfferDaysTranDAL)
                    {
                        objOfferDaysTran.linktoOfferMasterId = this.OfferMasterId;
                        rs = objOfferDaysTran.InsertOfferDaysTran(SqlCon, SqlTran);

                        if (rs == poswRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }

        #endregion

        #region Update
        public poswRecordStatus UpdateOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlTransaction SqlTran = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswOfferMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Value = this.OfferMasterId;
                SqlCmd.Parameters.Add("@linktoOfferTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOfferTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterIds", SqlDbType.VarChar).Value = this.linktoOrderTypeMasterIds;
                SqlCmd.Parameters.Add("@OfferTitle", SqlDbType.VarChar).Value = this.OfferTitle;
                SqlCmd.Parameters.Add("@OfferContent", SqlDbType.VarChar).Value = this.OfferContent;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@MinimumBillAmount", SqlDbType.Money).Value = this.MinimumBillAmount;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
                SqlCmd.Parameters.Add("@IsDiscountPercentage", SqlDbType.Bit).Value = this.IsDiscountPercentage;
                SqlCmd.Parameters.Add("@BuyItemCount", SqlDbType.Int).Value = this.BuyItemCount;
                SqlCmd.Parameters.Add("@GetItemCount", SqlDbType.Int).Value = this.GetItemCount;
                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@ImagePhysicalName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@TermsAndConditions", SqlDbType.VarChar).Value = this.TermsAndConditions;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@IsForCustomers", SqlDbType.Bit).Value = this.IsForCustomers;
                SqlCmd.Parameters.Add("@IsOnline", SqlDbType.Bit).Value = this.IsOnline;
                SqlCmd.Parameters.Add("@IsForAllDays", SqlDbType.Bit).Value = this.IsForAllDays;
                SqlCmd.Parameters.Add("@IsForApp", SqlDbType.Bit).Value = this.IsForApp;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == poswRecordStatus.Error || rs == poswRecordStatus.RecordAlreadyExist)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                poswOfferCodesTranDAL objOfferCodesTran = new poswOfferCodesTranDAL();
                if (IsForCustomers)
                {
                    objOfferCodesTran.linktoOfferMasterId = this.OfferMasterId;
                    rs = objOfferCodesTran.DeleteOfferCodesTran(SqlCon, SqlTran);

                    if (rs == poswRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }

                    foreach (poswOfferCodesTranDAL objOfferCodesTranDAL in lstOfferCodesTranDAL)
                    {
                        objOfferCodesTran = new poswOfferCodesTranDAL();
                        objOfferCodesTran.linktoOfferMasterId = OfferMasterId;
                        objOfferCodesTran.OfferCode = objOfferCodesTranDAL.OfferCode;
                        objOfferCodesTran.linktoCustomerMasterId = objOfferCodesTranDAL.linktoCustomerMasterId;
                        objOfferCodesTran.linktoUserMasterIdCreatedBy = objOfferCodesTranDAL.linktoUserMasterIdCreatedBy;
                        objOfferCodesTran.CreateDateTime = objOfferCodesTranDAL.CreateDateTime;

                        rs = objOfferCodesTran.InsertOfferCodesTran(SqlCon, SqlTran);

                        if (rs == poswRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                else
                {
                    objOfferCodesTran.linktoOfferMasterId = OfferMasterId;
                    rs = objOfferCodesTran.DeleteOfferCodesTran(SqlCon, SqlTran);

                    if (rs == poswRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                if (linktoOfferTypeMasterId != poswOfferType.All_Items.GetHashCode())
                {

                    lstOfferItemsTranDAL.ForEach(j => j.linktoOfferMasterId = this.OfferMasterId);

                    DataTable dtOfferItem = new DataTable();
                    List<string> ExtraCollumn = new List<string>();
                    ExtraCollumn.Add("linktoItemMasterIds");
                    ExtraCollumn.Add("OfferItemTypeIds");

                    dtOfferItem = poswGlobalsDAL.ToDataTable(lstOfferItemsTranDAL, ExtraCollumn);
                    poswOfferItemsTranDAL objOfferItemsTranDAL = new poswOfferItemsTranDAL();
                    objOfferItemsTranDAL.linktoOfferMasterId = this.OfferMasterId;
                    rs = objOfferItemsTranDAL.InsertAllOfferItemsTran(SqlCon, SqlTran, dtOfferItem);
                    if (rs == poswRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                else
                {
                    poswOfferItemsTranDAL objOfferItemsTran = new poswOfferItemsTranDAL();
                    objOfferItemsTran.linktoOfferMasterId = OfferMasterId;
                    rs = objOfferItemsTran.DeleteOfferItemsTran(SqlCon, SqlTran);

                    if (rs == poswRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                poswOfferDaysTranDAL objOfferDaysTran = new poswOfferDaysTranDAL();
                objOfferDaysTran.linktoOfferMasterId = this.OfferMasterId;
                rs = objOfferDaysTran.DeleteOfferDaysTran(SqlCon, SqlTran);
                if (rs == poswRecordStatus.Error)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                poswOfferDaysTranDAL objOfferDaysTranTemp = null;
                foreach (poswOfferDaysTranDAL objOfferDaysTranDAL in lstOfferDaysTranDAL)
                {
                    objOfferDaysTranTemp = new poswOfferDaysTranDAL();
                    objOfferDaysTranTemp.linktoOfferMasterId = this.OfferMasterId;
                    objOfferDaysTranTemp.Day = objOfferDaysTranDAL.Day;
                    objOfferDaysTranTemp.FromTime = objOfferDaysTranDAL.FromTime;
                    objOfferDaysTranTemp.ToTime = objOfferDaysTranDAL.ToTime;
                    objOfferDaysTranTemp.IsEnabled = objOfferDaysTranDAL.IsEnabled;
                    rs = objOfferDaysTranTemp.InsertOfferDaysTran(SqlCon, SqlTran);

                    if (rs == poswRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #region Comment Code
        //if (IsForAllDays)
        //{
        //    poswOfferDaysTranDAL objOfferDaysTran = new poswOfferDaysTranDAL();
        //    objOfferDaysTran.linktoOfferMasterId = this.OfferMasterId;
        //    rs = objOfferDaysTran.DeleteOfferDaysTran(SqlCon, SqlTran);
        //    if (rs == poswRecordStatus.Error)
        //    {
        //        SqlTran.Rollback();
        //        SqlCon.Close();
        //        return rs;
        //    }
        //}
        //else
        //{
        //    poswOfferDaysTranDAL objOfferDaysTran = null;

        //    foreach (poswOfferDaysTranDAL objOfferDaysTranDAL in lstOfferDaysTranDAL)
        //    {
        //        objOfferDaysTran = new poswOfferDaysTranDAL();
        //        objOfferDaysTran.linktoOfferMasterId = this.OfferMasterId;
        //        objOfferDaysTran.Day = objOfferDaysTranDAL.Day;
        //        objOfferDaysTran.FromTime = objOfferDaysTranDAL.FromTime;
        //        objOfferDaysTran.ToTime = objOfferDaysTranDAL.ToTime;
        //        objOfferDaysTran.IsEnabled = objOfferDaysTranDAL.IsEnabled;
        //        if (objOfferDaysTranDAL.OfferDaysTranId > 0)
        //        {
        //            objOfferDaysTran.OfferDaysTranId = objOfferDaysTranDAL.OfferDaysTranId;
        //            rs = objOfferDaysTran.UpdateOfferDaysTran(SqlCon, SqlTran);
        //        }
        //        else
        //        {
        //            rs = objOfferDaysTran.InsertOfferDaysTran(SqlCon, SqlTran);
        //        }

        //        if (rs == poswRecordStatus.Error)
        //        {
        //            SqlTran.Rollback();
        //            SqlCon.Close();
        //            return rs;
        //        }
        //    }
        //}


        //public poswRecordStatus UpdateOfferMaster()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswOfferMaster_Update", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Value = this.OfferMasterId;
        //        SqlCmd.Parameters.Add("@linktoOfferTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOfferTypeMasterId;
        //        SqlCmd.Parameters.Add("@OfferTitle", SqlDbType.VarChar).Value = this.OfferTitle;
        //        SqlCmd.Parameters.Add("@OfferContent", SqlDbType.VarChar).Value = this.OfferContent;
        //        SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
        //        SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
        //        SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
        //        SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
        //        SqlCmd.Parameters.Add("@MinimumBillAmount", SqlDbType.Money).Value = this.MinimumBillAmount;
        //        SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
        //        SqlCmd.Parameters.Add("@IsDiscountPercentage", SqlDbType.Bit).Value = this.IsDiscountPercentage;
        //        SqlCmd.Parameters.Add("@RedeemCount", SqlDbType.Int).Value = this.RedeemCount;
        //        SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
        //        SqlCmd.Parameters.Add("@ImagePhysicalName", SqlDbType.VarChar).Value = this.ImagePhysicalName;
        //        SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
        //        SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
        //        SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
        //        SqlCmd.Parameters.Add("@TermsAndConditions", SqlDbType.VarChar).Value = this.TermsAndConditions;
        //        SqlCmd.Parameters.Add("@IsForCustomers", SqlDbType.Bit).Value = this.IsForCustomers;
        //        SqlCmd.Parameters.Add("@BuyItemCount", SqlDbType.Int).Value = this.BuyItemCount;
        //        SqlCmd.Parameters.Add("@GetItemCount", SqlDbType.Int).Value = this.GetItemCount;
        //        SqlCmd.Parameters.Add("@linktoOrderTypeMasterIds", SqlDbType.VarChar).Value = this.linktoOrderTypeMasterIds;
        //        SqlCmd.Parameters.Add("@IsOnline", SqlDbType.Bit).Value = this.IsOnline;
        //        SqlCmd.Parameters.Add("@IsForApp", SqlDbType.Bit).Value = this.IsForApp;
        //        SqlCmd.Parameters.Add("@IsForAllDays", SqlDbType.Bit).Value = this.IsForAllDays;
        //        SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
        //        SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
        //        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCon.Open();
        //        SqlCmd.ExecuteNonQuery();
        //        SqlCon.Close();

        //        poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
        //        return rs;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return poswRecordStatus.Error;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        #endregion

        #endregion

        #region Delete
        public poswRecordStatus DeleteOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Value = this.OfferMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Value = this.OfferMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);

                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectOfferMasterOfferCodeVerification(short linktoOrderTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMasterOffeCodeVerification_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@MinimumBillAmount", SqlDbType.Money).Value = this.MinimumBillAmount;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;

                if (SqlRdr.Read())
                {
                    this.OfferMasterId = Convert.ToInt32(SqlRdr["OfferMasterId"]);
                    this.linktoOfferTypeMasterId = Convert.ToInt16(SqlRdr["linktoOfferTypeMasterId"]);
                    this.Discount = Convert.ToDouble(SqlRdr["Discount"]);
                    this.IsDiscountPercentage = Convert.ToBoolean(SqlRdr["IsDiscountPercentage"]);
                    if (SqlRdr["BuyItemCount"] != DBNull.Value)
                    {
                        this.BuyItemCount = Convert.ToInt32(SqlRdr["BuyItemCount"]);
                    }
                    if (SqlRdr["GetItemCount"] != DBNull.Value)
                    {
                        this.GetItemCount = Convert.ToInt32(SqlRdr["GetItemCount"]);
                    }

                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswOfferMasterDAL> SelectAllOfferMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferTitle", SqlDbType.VarChar).Value = this.OfferTitle;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOfferMasterDAL> lstOfferMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOfferMasterDAL> SelectAllOfferMasterByFormDateTimePageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMasterByFromDateTimePageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.FromDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOfferMasterDAL> lstOfferMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOfferMasterDAL> SelectAllOfferMasterByFormDateTime(out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMasterByFromDateTime_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.FromDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
               
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOfferMasterDAL> lstOfferMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOfferMasterDAL> SelectAllOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "offer/";
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOfferMasterDAL> lstOfferMasterDAL = new List<poswOfferMasterDAL>();
                poswOfferMasterDAL objOfferMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOfferMasterDAL = new poswOfferMasterDAL();
                    if (SqlRdr["OfferMasterId"] != DBNull.Value)
                    {
                        objOfferMasterDAL.OfferMasterId = Convert.ToInt32(SqlRdr["OfferMasterId"]);
                        objOfferMasterDAL.OfferTitle = Convert.ToString(SqlRdr["OfferTitle"]);
                        if (SqlRdr["OfferContent"] != DBNull.Value)
                        {
                            objOfferMasterDAL.OfferContent = Convert.ToString(SqlRdr["OfferContent"]);
                        }
                        if (SqlRdr["ToDate"] != DBNull.Value)
                        {
                            objOfferMasterDAL.ToDate = Convert.ToDateTime(SqlRdr["ToDate"]);
                        }
                        if (SqlRdr["ToTime"] != DBNull.Value)
                        {
                            objOfferMasterDAL.ToTime = TimeSpan.Parse(SqlRdr["ToTime"].ToString());
                        }
                        if (SqlRdr["ImagePhysicalName"] != DBNull.Value)
                        {
                            objOfferMasterDAL.smImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImagePhysicalName"]);
                            objOfferMasterDAL.mdImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImagePhysicalName"]);
                            objOfferMasterDAL.xlImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImagePhysicalName"]);
                        }
                        else
                        {
                            objOfferMasterDAL.smImagePhysicalName = "img/NoImage.png";
                            objOfferMasterDAL.mdImagePhysicalName = "img/NoImage.png";
                            objOfferMasterDAL.xlImagePhysicalName = "img/NoImage.png";
                        }
                        if (SqlRdr["OfferDiscount"] != DBNull.Value)
                        {
                            objOfferMasterDAL.OfferDiscount = Convert.ToString(SqlRdr["OfferDiscount"]);
                        }
                        objOfferMasterDAL.OfferCode = Convert.ToString(SqlRdr["OfferCode"]);
                    }

                    objOfferMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    lstOfferMasterDAL.Add(objOfferMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOfferMasterDAL> SelectAllOfferMasterByCustomerMasterRegisteredUser()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "offer/";
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMasterByCustomerMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.SmallInt).Value = this.linktoCustomerMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOfferMasterDAL> lstOfferMasterDAL = new List<poswOfferMasterDAL>();
                poswOfferMasterDAL objOfferMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOfferMasterDAL = new poswOfferMasterDAL();
                    if (SqlRdr["OfferMasterId"] != DBNull.Value)
                    {
                        objOfferMasterDAL.OfferMasterId = Convert.ToInt32(SqlRdr["OfferMasterId"]);
                        objOfferMasterDAL.OfferTitle = Convert.ToString(SqlRdr["OfferTitle"]);
                        if (SqlRdr["OfferContent"] != DBNull.Value)
                        {
                            objOfferMasterDAL.OfferContent = Convert.ToString(SqlRdr["OfferContent"]);
                        }
                        if (SqlRdr["ToDate"] != DBNull.Value)
                        {
                            objOfferMasterDAL.ToDate = Convert.ToDateTime(SqlRdr["ToDate"]);
                        }
                        if (SqlRdr["ToTime"] != DBNull.Value)
                        {
                            objOfferMasterDAL.ToTime = TimeSpan.Parse(SqlRdr["ToTime"].ToString());
                        }
                        objOfferMasterDAL.Discount = Convert.ToDouble(SqlRdr["Discount"]);
                        objOfferMasterDAL.IsDiscountPercentage = Convert.ToBoolean(SqlRdr["IsDiscountPercentage"]);

                        if (SqlRdr["UserOfferCode"] != DBNull.Value)
                        {
                            objOfferMasterDAL.OfferCode = Convert.ToString(SqlRdr["UserOfferCode"]);
                        }
                        if (SqlRdr["ImagePhysicalName"] != DBNull.Value)
                        {
                            objOfferMasterDAL.smImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImagePhysicalName"]);
                            objOfferMasterDAL.xlImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImagePhysicalName"]);
                        }
                        else
                        {
                            objOfferMasterDAL.smImagePhysicalName = "img/NoImage.png";
                            objOfferMasterDAL.xlImagePhysicalName = "img/NoImage.png";
                        }

                    }

                    objOfferMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    lstOfferMasterDAL.Add(objOfferMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOfferMasterDAL> SelectAllOfferMasterOfferTitle()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferMasterOfferTitle_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOfferMasterDAL> lstOfferMasterDAL = new List<poswOfferMasterDAL>();
                poswOfferMasterDAL objOfferMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOfferMasterDAL = new poswOfferMasterDAL();

                    objOfferMasterDAL.OfferMasterId = Convert.ToInt32(SqlRdr["OfferMasterId"]);
                    objOfferMasterDAL.OfferTitle = Convert.ToString(SqlRdr["OfferTitle"]);
                    lstOfferMasterDAL.Add(objOfferMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

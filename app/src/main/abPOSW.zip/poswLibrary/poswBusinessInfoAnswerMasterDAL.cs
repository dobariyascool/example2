using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswBusinessInfoAnswerMaster
	/// </summary>
	public class poswBusinessInfoAnswerMasterDAL
	{
		#region Properties
		public int BusinessInfoAnswerMasterId { get; set; }
		public int linktoBusinessInfoQuestionMasterId { get; set; }
		public string Answer { get; set; }
		public bool IsEnabled { get; set; }

		/// Extra
		public string BusinessInfoQuestion { get; set; }
        public string QuestionType { get; set; }
        public bool IsAnswer { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.BusinessInfoAnswerMasterId = Convert.ToInt32(sqlRdr["BusinessInfoAnswerMasterId"]);
				this.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(sqlRdr["linktoBusinessInfoQuestionMasterId"]);
				this.Answer = Convert.ToString(sqlRdr["Answer"]);
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

				/// Extra
				//this.BusinessInfoQuestion = Convert.ToString(sqlRdr["BusinessInfoQuestion"]);
				return true;
			}
			return false;
		}

		private List<poswBusinessInfoAnswerMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswBusinessInfoAnswerMasterDAL> lstBusinessInfoAnswerMaster = new List<poswBusinessInfoAnswerMasterDAL>();
			poswBusinessInfoAnswerMasterDAL objBusinessInfoAnswerMaster = null;
			while (sqlRdr.Read())
			{
				objBusinessInfoAnswerMaster = new poswBusinessInfoAnswerMasterDAL();
				objBusinessInfoAnswerMaster.BusinessInfoAnswerMasterId = Convert.ToInt32(sqlRdr["BusinessInfoAnswerMasterId"]);
				objBusinessInfoAnswerMaster.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(sqlRdr["linktoBusinessInfoQuestionMasterId"]);
				objBusinessInfoAnswerMaster.Answer = Convert.ToString(sqlRdr["Answer"]);
				objBusinessInfoAnswerMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

				/// Extra
				//objBusinessInfoAnswerMaster.BusinessInfoQuestion = Convert.ToString(sqlRdr["BusinessInfoQuestion"]);
                objBusinessInfoAnswerMaster.IsAnswer = Convert.ToBoolean(sqlRdr["IsAnswer"]);
				lstBusinessInfoAnswerMaster.Add(objBusinessInfoAnswerMaster);
			}
			return lstBusinessInfoAnswerMaster;
		}
		#endregion

		#region Select
		public bool SelectBusinessInfoAnswerMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessInfoAnswerMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@BusinessInfoAnswerMasterId", SqlDbType.Int).Value = this.BusinessInfoAnswerMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

        public List<poswBusinessInfoAnswerMasterDAL> SelectAllBusinessInfoAnswerMaster(short linktoBusinessMasterId)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessInfoAnswerMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswBusinessInfoAnswerMasterDAL> lstBusinessInfoAnswerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstBusinessInfoAnswerMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public static List<poswBusinessInfoAnswerMasterDAL> SelectAllBusinessInfoAnswerMasterByBusinessMasterId(short linktoBusinessTypeMasterId, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessInfoAnswerMasterByBusinessTypeMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = linktoBusinessTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessInfoAnswerMasterDAL> lstBusinessInfoAnswerMasterDAL = new List<poswBusinessInfoAnswerMasterDAL>();
                poswBusinessInfoAnswerMasterDAL objBusinessInfoAnswerMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objBusinessInfoAnswerMasterDAL = new poswBusinessInfoAnswerMasterDAL();
                    objBusinessInfoAnswerMasterDAL.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(SqlRdr["BusinessInfoQuestionMasterId"]);
                    objBusinessInfoAnswerMasterDAL.BusinessInfoQuestion = Convert.ToString(SqlRdr["BusinessInfoQuestion"]);
                    objBusinessInfoAnswerMasterDAL.QuestionType = Convert.ToString(SqlRdr["QuestionType"]);
                    objBusinessInfoAnswerMasterDAL.Answer = Convert.ToString(SqlRdr["Answer"]);
                    lstBusinessInfoAnswerMasterDAL.Add(objBusinessInfoAnswerMasterDAL);
                    
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessInfoAnswerMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
    
		#endregion
	}
}

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswItemCategoryTran
	/// </summary>
	public class poswItemCategoryTranDAL
	{
		#region Properties
		public int ItemCategoryTranId { get; set; }
		public int linktoItemMasterId { get; set; }
		public short linktoCategoryMasterId { get; set; }
		#endregion

		#region Class Methods
		private List<poswItemCategoryTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswItemCategoryTranDAL> lstItemCategoryTran = new List<poswItemCategoryTranDAL>();
			poswItemCategoryTranDAL objItemCategoryTran = null;
			while (sqlRdr.Read())
			{
				objItemCategoryTran = new poswItemCategoryTranDAL();
				objItemCategoryTran.ItemCategoryTranId = Convert.ToInt32(sqlRdr["ItemCategoryTranId"]);
				objItemCategoryTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				objItemCategoryTran.linktoCategoryMasterId = Convert.ToInt16(sqlRdr["linktoCategoryMasterId"]);
				lstItemCategoryTran.Add(objItemCategoryTran);
			}
			return lstItemCategoryTran;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertAllItemCategoryTran(string linktoCategoryMasterIds,SqlConnection SqlCon,SqlTransaction sqlTran )
		{
			//SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
                //SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemCategoryTran_InsertAll", SqlCon, sqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCmd.Parameters.Add("@linktoCategoryMasterIds", SqlDbType.VarChar).Value = linktoCategoryMasterIds;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				//SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				//SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				//poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<poswItemCategoryTranDAL> SelectAllItemCategoryTran(SqlConnection sqlCon = null)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				if (sqlCon == null)
				{
					SqlCon = poswObjectFactoryDAL.CreateConnection();
					SqlCmd = new SqlCommand("poswItemCategoryTran_SelectAll", SqlCon);
				}
				else
				{
					SqlCmd = new SqlCommand("poswItemCategoryTran_SelectAll", sqlCon);
				}
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;

				if (sqlCon == null)
				{
					SqlCon.Open();
				}
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswItemCategoryTranDAL> lstItemCategoryTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				if (sqlCon == null)
				{
					SqlCon.Close();
				}

				return lstItemCategoryTranDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				if (sqlCon == null)
				{
					poswObjectFactoryDAL.DisposeConnection(SqlCon);
				}
			}
		}
		#endregion
	}
}

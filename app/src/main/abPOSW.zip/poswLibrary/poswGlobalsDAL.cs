﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Web;
using System.Collections.Generic;
using System.Net;
using System.Text.RegularExpressions;
using System.Data;
using System.Reflection;
using System.Data.SqlClient;

namespace poswLibrary
{
    public class poswGlobalsDAL
    {
        public const string UniqueKey = "yyyy-MM-dd_HH.mm.ss.ffff";
        public const string AuthenticationKey = "dsLh4MIqFHW5tjzSLD6JNJcL7ArwlhH/KqyTqeZEHi7MA/H8gWfNyrm7LxC9mBItJ4krl3PIF3Bl9yHsSfsecrofBNZyUoCth1bvReVO91hL3TggVVBHjft7tHVp+OtW";
        //public const string AuthenticationKey = "2ibAQWn/jPF4PM+0nVuWfhLeLP9CVXQhbsPTPCY8baB4NXhvg2pViq7S7SX0BtElGKK4hpunqoO2QSgrKupG8A==";
        public const string EncryptionKey = "31BF3856AD364E35";
        //Date Format
        public static string DateFormat = "MM'/'dd'/'yyyy";
        public static string TimeFormat = "HH:mm tt";
        public static string apiKeyabPOSW = "AIzaSyCY5MD4Uau63OXDCqGzeEy5jt0RoTdqHiw";
        public static string senderIdabPOSW = "346462002582";
        public static string apiKeyabPOSA = "AIzaSyA-BC2k7RlxIz_ufeoiS3kN9ssmyaMepxI";
        public static string senderIdabPOSA = "337715065990";
        public static DateTime FromDate;
        public static DateTime ToDate;
        public static void SaveError(Exception ex)
        {
            System.Threading.ThreadAbortException tae = ex as System.Threading.ThreadAbortException;
            if (tae != null)
            {
                return;
            }
            try
            {
                /// Insert error into ErrorLog table
                poswErrorLogDAL _objErrorLogDAL = new poswErrorLogDAL();
                _objErrorLogDAL.ErrorDateTime = poswGlobalsDAL.GetCurrentDateTime();
                _objErrorLogDAL.ErrorMessage = ex.Message;
                _objErrorLogDAL.ErrorStackTrace = ex.StackTrace;

                if (_objErrorLogDAL.InsertErrorLog() == poswRecordStatus.Error)
                {
                    /// Write error into ErrorLog file if error not inserted
                    string _strErrorLogFile = System.Configuration.ConfigurationManager.AppSettings["rootpath"] + System.Configuration.ConfigurationManager.AppSettings["ErrorFilePath"];
                    StringBuilder _sb = new StringBuilder();
                    _sb.AppendLine("Error DateTime    : " + poswGlobalsDAL.GetCurrentDateTime().ToString("s"));
                    _sb.AppendLine("Error Message     : " + ex.Message);
                    _sb.AppendLine("Error StackTrace  : " + ex.StackTrace);
                    _sb.AppendLine(string.Empty.PadRight(100, '-'));
                    File.WriteAllText(_strErrorLogFile, _sb.ToString());
                }
            }
            catch
            {
            }
            poswMessagesDAL.ShowMessage("An unexpected error occurred." + Environment.NewLine + Environment.NewLine + ex.Message, poswMessageIcon.Error);
        }

        public static string GetCleanFileName(string fileName)
        {
            string FileName = Regex.Replace(fileName, "[^a-zA-Z0-9_.]", "_");
            FileName = Path.GetFileNameWithoutExtension(FileName) + "_" + GetRandomString(6) + Path.GetExtension(FileName);
            return FileName;
        }

        public static string GetRandomString(int length)
        {
            //It will generate string with combination of small,capital letters and numbers
            char[] charArr = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".ToCharArray();
            string randomString = string.Empty;
            Random objRandom = new Random();
            for (int i = 0; i < length; i++)
            {
                //Don't Allow Repetation of Characters
                int x = objRandom.Next(1, charArr.Length);
                if (!randomString.Contains(charArr.GetValue(x).ToString()))
                {
                    randomString += charArr.GetValue(x);
                }
                else
                {
                    i--;
                }
            }
            return randomString;
        }

        public static bool CreateThumbImages(string imageName, string imageSavePath)
        {
            try
            {
                abHelper.ImageProcessing img = new abHelper.ImageProcessing(System.Configuration.ConfigurationManager.AppSettings["abLibAuthKey"]);

                // for extra small device 
                int Width = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["xsWidth"]);
                int Height = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["xsHeight"]);
                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "xs_" + imageName, Width, Height, false);

                // for small device 
                Width = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["smWidth"]);
                Height = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["smHeight"]);
                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "sm_" + imageName, Width, Height, false);

                // for medium device 
                Width = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["mdWidth"]);
                Height = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["mdHeight"]);
                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "md_" + imageName, Width, Height, false);

                // for large device 
                Width = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["lgWidth"]);
                Height = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["lgHeight"]);
                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "lg_" + imageName, Width, Height, false);

                // for extra large device 
                Width = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["xlWidth"]);
                Height = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["xlHeight"]);
                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "xl_" + imageName, Width, Height, false);

                File.Delete(imageSavePath + imageName);
                return true;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
        }

        public static bool DeleteThumbImages(string imageName, string imageSavePath)
        {
            try
            {
                // for extra small device 
                if (File.Exists(imageSavePath + "xs_" + imageName))
                {
                    File.Delete(imageSavePath + "xs_" + imageName);
                }

                // for small device 
                if (File.Exists(imageSavePath + "sm_" + imageName))
                {
                    File.Delete(imageSavePath + "sm_" + imageName);
                }

                // for medium device 
                if (File.Exists(imageSavePath + "md_" + imageName))
                {
                    File.Delete(imageSavePath + "md_" + imageName);
                }

                // for large device 
                if (File.Exists(imageSavePath + "lg_" + imageName))
                {
                    File.Delete(imageSavePath + "lg_" + imageName);
                }

                // for extra large device 
                if (File.Exists(imageSavePath + "xl_" + imageName))
                {
                    File.Delete(imageSavePath + "xl_" + imageName);
                }

                return true;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
        }

        public static bool CheckUserRights(poswUserRights UserRight)
        {
            List<poswUserRightsTranDAL> lstUserRightsTranDAL;
            try
            {
                if (HttpContext.Current.Session[poswSessionsDAL.UserSession] == null)
                {
                    return false;
                }
                if (((poswUser)HttpContext.Current.Session[poswSessionsDAL.UserSession]).linktoRoleMasterId == 1)
                {
                    return true;
                }
                lstUserRightsTranDAL = (List<poswUserRightsTranDAL>)HttpContext.Current.Session[poswSessionsDAL.UserAccessControl];
                if (lstUserRightsTranDAL == null)
                {
                    return false;
                }
                if (lstUserRightsTranDAL.Find(x => x.linktoUserRightsMasterId == Convert.ToInt16(UserRight)) != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                lstUserRightsTranDAL = null;
            }
        }

        public static DateTime GetCurrentDateTime()
        {
            TimeZoneInfo tzIndia = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.Now.ToUniversalTime(), tzIndia);
        }

        public static DataTable ToDataTable<T>(List<T> items, List<string> ExtraCollumns)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            foreach (string extraCollumn in ExtraCollumns)
            {
                dataTable.Columns.Remove(extraCollumn);
            }

            //put a breakpoint here and check datatable
            return dataTable;
        }

        public static string Decript(string cipherText)
        {
            abHelper.Rijndael rijndaelKey = new abHelper.Rijndael(AuthenticationKey, EncryptionKey);
            return rijndaelKey.Decrypt(cipherText);
        }

        public static string Encrypt(string plainText)
        {
            abHelper.Rijndael rijndaelKey = new abHelper.Rijndael(AuthenticationKey, EncryptionKey);
            return rijndaelKey.Encrypt(plainText);
        }

        #region Email
        public static void SendEmail(string ToEmail, string sub, string msg)
        {
            SendEmail(ToEmail, sub, msg, null);
        }

        public static void SendEmail(string ToEmail, string sub, string msg, string attachmentFileName)
        {
            try
            {
                if (!string.IsNullOrEmpty(ToEmail))
                {

                    abHelper.Mail sendmail = new abHelper.Mail(System.Configuration.ConfigurationManager.AppSettings["abLibAuthKey"]);
                    sendmail.Subject = sub;
                    sendmail.ToMailAddresses = ToEmail;
                    sendmail.FromMailAddress = System.Configuration.ConfigurationManager.AppSettings["FromMailAddress"];

                    if (!string.IsNullOrEmpty(attachmentFileName))
                    {
                        sendmail.AttachmentFilesWithPath = attachmentFileName;
                    }

                    sendmail.Host = System.Configuration.ConfigurationManager.AppSettings["EmailSMTP"];
                    sendmail.Port = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EmailPort"]);
                    sendmail.IsSSL = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["EmailIsSSL"]);
                    sendmail.IsBodyHTML = true;
                    sendmail.Body = msg;
                    sendmail.Send();
                }
            }
            catch
            {
            }
        }
        #endregion

        #region SMS
        public static void SendSMS(string senderMobile, string msg, string receiverMobile)
        {
            try
            {
                //string user = System.Configuration.ConfigurationManager.AppSettings["MobileUser"];
                //string pwd = System.Configuration.ConfigurationManager.AppSettings["MobilePassword"];
                ////string myrecipient = "9426823910";
                ////msg = "You having a new booking, please check your V-GETIT bookings.";
                //HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create("http://smsidea.co.in/sendsms.aspx?mobile=" + user + "&pass=" + pwd + "&senderid=SMSWEB&to=" + senderMobile + "&msg=" + msg);

                //HttpWebResponse myResp = (HttpWebResponse)myReq.GetResponse();
                //System.IO.StreamReader respStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                //string responseString = respStreamReader.ReadToEnd();
                //respStreamReader.Close();
                //myResp.Close();
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
            }
        }

        #endregion
    }

    #region poswSession
    public class poswSessionsDAL
    {
        public static string UserSession = "UserSession";
        public static string MessageSession = "MessageSession";
        public static string DataSession = "DataSession";
        public static string UserAccessControl = "lstAccessControl";
        public static string BusinessSession = "BusinessSession";
        public static string CartPreOrderSession = "CartPreOrderSession";
        public static string CartOrderSession = "CartOrderSession";
        public static string RegisterUserSession = "RegisterUserSession";
        public static string Refresh = "Refresh";

        #region Session Methods

        public static void FillPropertySession()
        {
            poswBusinessMasterDAL objBusinessMasterDAL;
            try
            {
                objBusinessMasterDAL = new poswBusinessMasterDAL();
                objBusinessMasterDAL.BusinessMasterId = 1;
                objBusinessMasterDAL.linktoBusinessTypeMasterId = 1;
                HttpContext.Current.Session[poswSessionsDAL.BusinessSession] = new poswBusiness(objBusinessMasterDAL);



                //objPropertyMasterDAL.WebsiteUrl = HttpContext.Current.Request.Url.Host.ToLower();
                //if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["site"]))
                //{
                //    objPropertyMasterDAL.WebsiteUrl = HttpContext.Current.Request.QueryString["site"].ToLower();
                //}
                //if (HttpContext.Current.Session[cmsSessionsDAL.PropertySession] != null && (((cmsProperty)HttpContext.Current.Session[cmsSessionsDAL.PropertySession]).WebsiteUrl == objPropertyMasterDAL.WebsiteUrl))
                //{
                //    return;
                //}
                //if (objPropertyMasterDAL.SelectPropertyMaster())
                //{
                //    if (objPropertyMasterDAL.IsEnabled)
                //    {
                //        HttpContext.Current.Session[cmsSessionsDAL.PropertySession] = new cmsProperty(objPropertyMasterDAL);
                //    }
                //    else
                //    {
                //        //"Your Domain is Expired. Please contact Site Administrator.";                                        
                //    }
                //}
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                // HttpContext.Current.Response.Redirect("Error.aspx", false);
            }
            finally
            {
                objBusinessMasterDAL = null;
            }
        }

        public static void CheckSession()
        {
            if (HttpContext.Current.Session[poswSessionsDAL.UserSession] == null)
            {
                poswMessagesDAL.ShowMessage(poswMessagesDAL.NotLoggedIn, poswMessageIcon.Information);
                if (!HttpContext.Current.Request.Url.AbsolutePath.Contains("default.aspx"))
                {
                    HttpContext.Current.Response.Redirect("login.aspx?page=" + HttpContext.Current.Request.Url.AbsolutePath.Replace("/", string.Empty)); // DO NOT ADD false HERE
                }
                else
                {
                    HttpContext.Current.Response.Redirect("login.aspx"); // DO NOT ADD false HERE
                }
            }
        }

        public static void CheckFrontEndSession()
        {
            if (HttpContext.Current.Session[poswSessionsDAL.RegisterUserSession] == null)
            {
                poswMessagesDAL.ShowMessage(poswMessagesDAL.NotLoggedIn, poswMessageIcon.Information);
                if (!HttpContext.Current.Request.Url.AbsolutePath.Contains("default.aspx"))
                {
                    HttpContext.Current.Response.Redirect("default.aspx"); // DO NOT ADD false HERE
                }
            }
        }

        public static bool GetSession()
        {
            return HttpContext.Current.Session[poswSessionsDAL.UserSession] != null ? true : false;
        }

        public static void SetSessionKeyValue(string key, object value)
        {
            Hashtable htSession;
            if (HttpContext.Current.Session[poswSessionsDAL.DataSession] != null)
            {
                htSession = (Hashtable)HttpContext.Current.Session[poswSessionsDAL.DataSession];
            }
            else
            {
                htSession = new Hashtable();
                HttpContext.Current.Session[poswSessionsDAL.DataSession] = htSession;
            }
            if (htSession.ContainsKey(key))
            {
                htSession[key] = value;
            }
            else
            {
                htSession.Add(key, value);
            }
        }

        public static object GetSessionKeyValue(string key)
        {
            if (HttpContext.Current.Session[poswSessionsDAL.DataSession] != null)
            {
                Hashtable htSession = (Hashtable)HttpContext.Current.Session[poswSessionsDAL.DataSession];

                if (htSession.ContainsKey(key))
                {
                    return htSession[key];
                }
            }
            return null;
        }

        public static void RemoveSessionKeyValue(string key)
        {
            if (HttpContext.Current.Session[poswSessionsDAL.DataSession] != null)
            {
                Hashtable htSession = (Hashtable)HttpContext.Current.Session[poswSessionsDAL.DataSession];

                if (htSession.ContainsKey(key))
                {
                    htSession.Remove(key);
                }
            }
        }

        public static void RemoveSession()
        {
            HttpContext.Current.Session[poswSessionsDAL.DataSession] = null;
        }
        #endregion
    }
    #endregion

    #region poswMessageDAL
    public class poswMessagesDAL
    {
        public static string PermissionRequired = "alert('You need Special Permission for use this feature.Please contact your administrator.');";
        public static string NotLoggedIn = "You are not logged in or your login session expired, Please login again.";
        public static string Exception = "There was some problem processing your request, Please try after some time.";
        public static string AlreadyExist = "Record already exist.";
        public static string NotFound = "No record found.";
        public static string NotValid = "Enter valid Number";
        public static string InsertSuccess = "Record saved successfully.";
        public static string InsertFail = "Failed to save record.";
        public static string UpdateSuccess = "Record updated successfully.";
        public static string UpdateFail = "Failed to update record.";
        public static string DeleteSuccess = "Record deleted successfully.";
        public static string DeleteFail = "Failed to delete record.";
        public static string SelectFail = "Failed to get record.";
        public static string SelectAllFail = "Failed to get record(s).";
        public static string InsertAllSuccess = "Record(s) saved successfully.";
        public static string InsertAllFail = "Failed to save record(s).";
        public static string UpdateAllSuccess = "Record(s) updated successfully.";
        public static string UpdateAllFail = "Failed to update record(s).";
        public static string DeleteAllSuccess = "Record(s) deleted successfully.";
        public static string DeleteAllFail = "Failed to delete record(s).";
        public static string SelectRecord = "Please select atleast one record.";
        public static string DataLostWarning = "Your changes will not be saved, Are you sure you want to close?";
        public static string AlreadyInUse = "Cannot delete {0} because it is in use.";
        public static string RecordAlreadyExists = "{0} Record already exist.";

        public static void ShowMessage(string message, poswMessageIcon messageIcon)
        {
            Hashtable htSession = new Hashtable();
            htSession.Add("Message", message);
            htSession.Add("MessageIcon", messageIcon);
            HttpContext.Current.Session[poswSessionsDAL.MessageSession] = htSession;
        }

    }
    #endregion

    #region EventsDAL

    public class poswEventsDAL
    {
        #region Properties

        public string UserName { get; set; }
        public DateTime? EventDate { get; set; }
        public string EventType { get; set; }
        public short type { get; set; }
        public string PersonMobile { get; set; }
        public short linktoBusinessMasterId { get; set; }

        #endregion

        #region Class Methods
        private List<poswEventsDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswEventsDAL> lstEvents = new List<poswEventsDAL>();
            poswEventsDAL objEvent = null;
            while (sqlRdr.Read())
            {
                objEvent = new poswEventsDAL();
                objEvent.UserName = Convert.ToString(sqlRdr["UserName"]);               
                objEvent.EventDate = Convert.ToDateTime(sqlRdr["EventDate"]);
                objEvent.type = Convert.ToInt16(sqlRdr["EventType"]);
                if (sqlRdr["PersonMobile"] != DBNull.Value)
                {
                    objEvent.PersonMobile = Convert.ToString(sqlRdr["PersonMobile"]);       
                }
                lstEvents.Add(objEvent);
            }
            return lstEvents;
        }
        #endregion

        public List<poswEventsDAL> SelectEventsPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswEventsPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@EventType", SqlDbType.VarChar).Value = this.EventType; 

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswEventsDAL> lstEventsDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstEventsDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

    }

    #endregion

    #region Record Status
    public enum poswRecordStatus
    {
        RecordNotFound = -3,
        RecordAlreadyExist = -2,
        Error = -1,
        Success = 0
    }
    #endregion

    #region User Rights
    public enum poswUserRights
    {
        ViewRoles = 1,
        AddEditRole = 2,
        ManagePermissions = 3,
        ViewUsers = 4,
        AddEditUser = 5,
        DeleteUser = 6,
        ViewCountry = 7,
        AddEditCountry = 8,
        ViewStates = 9,
        AddEditState = 10,
        ViewPriority = 11,
        AddEditPriority = 12,
        ViewTaskStatus = 13,
        AddEditTaskStatus = 14,
        ViewEnquiryStatus = 15,
        AddEditEnquiryStatus = 16,
        ViewFeedbackType = 17,
        AddEditFeedbackType = 18,
        ViewContactCategory = 19,
        AddEditContactCategory = 20,
        ViewContact = 21,
        AddEditContact = 22,
        ViewDesignation = 23,
        AddEditDesignation = 24,
        ViewEmployee = 25,
        AddEditEmployee = 26,
        ViewProjects = 27,
        AddEditProject = 28,
        ViewTasks = 29,
        AddEditTask = 30,
        DeleteTask = 31,
        AddTaskResponse = 32,
        ViewLeaves = 33,
        AddEditLeave = 34,
        DeleteLeave = 35,
        ApproveDeclineLeave = 37,
        ViewWorkLog = 38,
        AddEditWorkLog = 39,
        ViewTasktype = 40,
        AddEditTaskType = 41,
        DeleteTaskType = 42,
        ViewClients = 43,
        AddEditClient = 44,
        ViewEmployeeTimeLog = 45,
        AddEditEmployeeTimeLog = 46,
        ViewFeedBacks = 47,
        ReplyFeedback = 48,
        ViewEnquiry = 49,
        EditEnquiry = 50,
        ViewJobApplications = 51,
        AddEditJobApplication = 52,
        ViewSubscribers = 53,
        AddEditSubscriber = 54,
        ViewStandardCategory = 55,
        AddEditStandardCategory = 56,
        DeleteStandardCategory = 57,
        ViewStandards = 58,
        AddEditStandards = 59,
        DeleteStandards = 60,
        ViewProjectTypes = 61,
        AddEditProjectTypes = 62,
        DeleteProjectTypes = 63,
        ViewTestTypes = 64,
        AddEditTestTypes = 65,
        DeleteTestTypes = 66
    }
    #endregion

    #region Enum
    public enum poswMessageIcon
    {
        None,
        Success,
        Error,
        Information,
        Warning
    }

    public enum poswExport
    {
        None,
        PDF,
        Excel,
        HTML
    }

    public enum poswBusinessDescription
    {
        About_Us,
        Privacy_Policy
    }

    public enum poswItemType
    {
        Item = 0,
        Modifier = 2,
        Combo_Item = 3,
        None = 1
    }

    public enum poswOrderStatus
    {
        Cooking = 1,
        Ready = 2,
        Served = 3,
        Canceled = 4,
        Left = 8,
        Delivered = 10
    }

    public enum poswFeedbackQuestionType
    {
        Input = 1,
        Rating = 2,
        Single_Select = 3,
        Multi_Select = 4
    }

    public enum poswCustomerType
    {
        Customer = 1,
        Registered_User = 2,
        Creditor = 3
    }

    public enum poswOrderType
    {
        Dine_In = 1,
        Take_Away = 2,
        Home_Delivery = 3
    }

    public enum poswOfferType
    {
        All_Items = 1,
        On_Selected_Items = 2,
        Buy_Get_Item_Free = 3,
        Buy_Get_Item_Discount = 4
    }

    public enum poswOfferItemType
    {
        OnEach = 1,
        BuyItems = 2,
        GetItems = 3
    }

    public enum poswBusinessInfoQuestionType
    {
        Input = 1,
        Single_Select = 2,
        Multi_Select = 3
    }

    public enum poswBookingStatus
    {
        New = 1,
        Modified = 2,
        Confirmed = 3,
        Canceled = 4
    }

    public enum poswSourceType
    {
        Desktop = 1,
        Web = 2,
        Android_Desktop = 3,
        Android_Web = 4,
        IOS_Desktop = 5,
        IOS_Web = 6
    }

    public enum poswAddressType
    {
        Home = 1,
        Office = 2
    }

    public enum poswBannerType
    {
        Item = 1,
        Offer = 2,
        Category = 3,
        General = 4
    }

    public enum poswCustomerFCMType
    {
        All = 1,
        Birthdays = 2,
        Anniversary = 3,      
    }
    #endregion

    #region DropDownItem
    public class poswDropDownItem
    {
        public static string Select = "- SELECT -";
        public static string All = "- ALL -";
    }
    #endregion

    #region poswErrorStatus

    public class ErrorStatus
    {
        public int ErrorCode { get; set; }
        public long ErrorNumber { get; set; }
        public string ErrorMsg { get; set; }

        public ErrorStatus()
        {
            this.ErrorMsg = string.Empty;
        }
    }

    #endregion
}

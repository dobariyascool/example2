﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Xml;
using System.Web;

namespace poswLibrary
{
    public class poswOrderItemCookies
    {
        #region Properties
        public int ItemMasterId { get; set; }
        public short ItemType { get; set; }
        public int Quentity { get; set; }
        public int OrderItemId { get; set; }
        public static string OrderCookies = "OrderList";
        public string Remark { get; set; }
        public int linktoItemMasterIdModifier { get; set; }
        //public string ItemName { get; set; }
        //public double MRP { get; set; }
        //public double Rate { get; set; }
        //public bool IsRateTaxInclusive { get; set; }
        //public string Modifier { get; set; }
        //public double TotalAmount { get; set; }
        //public double Tax { get; set; }
        //public int linktoRegisterUserMasterId { get; set; }
        
        #endregion

        #region Cookies
        public string Serialize<T>(List<T> list)
        {
            XmlSerializer serializer = new XmlSerializer(list.GetType());
            MemoryStream stream = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(stream, Encoding.UTF8);
            serializer.Serialize(writer, list);
            stream = (MemoryStream)writer.BaseStream;
            UTF8Encoding utf8 = new UTF8Encoding();
            return utf8.GetString(stream.ToArray());
        }

        public List<T> Deserialize<T>(string xml)
        {
            //abHelper.StringCompressor obj = new abHelper.StringCompressor("");
            //obj.CompressString()
            XmlSerializer serializer = new XmlSerializer(typeof(List<T>));
            UTF8Encoding utf8 = new UTF8Encoding();
            byte[] bytes = utf8.GetBytes(xml);
            MemoryStream stream = new MemoryStream(bytes);
            XmlTextReader reader = new XmlTextReader(stream);
            return (List<T>)serializer.Deserialize(reader);
        } 

        //Create Order Cookies Value
        public bool CreateCookie(string linktoRegisterUserMasterID)
        {
            if (HttpContext.Current.Request.Cookies[poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID] == null)
            {
                HttpCookie myCookie = new HttpCookie(poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID);
                myCookie.Expires = poswGlobalsDAL.GetCurrentDateTime().AddDays(15);
                HttpContext.Current.Response.Cookies.Add(myCookie);
            }
            return true;
        }

        //Get Order Cookies Value
        public List<poswOrderItemCookies> GetOrderCookies(string linktoRegisterUserMasterID)
        {
            List<poswOrderItemCookies> lstCookieItems = new List<poswOrderItemCookies>();
            if (HttpContext.Current.Request.Cookies[poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID] != null)
            {
                HttpContext.Current.Request.Cookies[poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID].Expires = poswGlobalsDAL.GetCurrentDateTime().AddDays(15);
                if (HttpContext.Current.Request.Cookies[poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID]["OrderItems"] != null)
                {
                    string CookiesData = HttpContext.Current.Request.Cookies[poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID]["OrderItems"].ToString();
                    string xml = poswGlobalsDAL.Decript(CookiesData);
                    abHelper.StringCompressor obj = new abHelper.StringCompressor(poswGlobalsDAL.AuthenticationKey);
                    xml = obj.DecompressString(xml);
                    lstCookieItems = Deserialize<poswOrderItemCookies>(xml);


                    if (lstCookieItems != null)
                    {
                        return lstCookieItems;
                    }

                }
            }
            else
            {
                this.CreateCookie(linktoRegisterUserMasterID);
            }
            return lstCookieItems;
        }

        //Set Order CookiesValue
        public void SetOrderCookies(List<poswOrderItemCookies> lstOrderItems, string linktoRegisterUserMasterID)
        {
            HttpCookie myCookie; string CookiesData;
            if (HttpContext.Current.Request.Cookies[poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID] == null)
            {
                myCookie = new HttpCookie(poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID);
                myCookie.Expires = poswGlobalsDAL.GetCurrentDateTime().AddDays(15);
                HttpContext.Current.Response.Cookies.Add(myCookie);
            }


            CookiesData = Serialize<poswOrderItemCookies>(lstOrderItems);
            abHelper.StringCompressor obj = new abHelper.StringCompressor(poswGlobalsDAL.AuthenticationKey);
            CookiesData = obj.CompressString(CookiesData);
            myCookie = HttpContext.Current.Request.Cookies[poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID];
            myCookie["OrderItems"] = poswGlobalsDAL.Encrypt(CookiesData);
            myCookie.Expires = poswGlobalsDAL.GetCurrentDateTime().AddDays(15);
            HttpContext.Current.Response.Cookies.Set(myCookie);



        }

        //Remove Cookies OF Perticular user

        public static void DeleteUserCookies(string linktoRegisterUserMasterID)
        {
            HttpContext.Current.Response.Cookies[poswOrderItemCookies.OrderCookies + linktoRegisterUserMasterID].Expires = poswGlobalsDAL.GetCurrentDateTime().AddDays(-1);
        }
        #endregion
    }
}

//byte[] b1 = System.Text.Encoding.ASCII.GetBytes(myCookie.ToString());
// string str1 = Convert.ToBase64String(b1);

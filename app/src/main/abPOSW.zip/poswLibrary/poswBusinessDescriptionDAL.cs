﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBusinessDescription
    /// </summary>
    public class poswBusinessDescriptionDAL
    {
        #region Properties
        public short BusinessDescriptionId { get; set; }
        public string Keyword { get; set; }
        public string Description { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDefault { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }

        /// Extra
        public string Business { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BusinessDescriptionId = Convert.ToInt16(sqlRdr["BusinessDescriptionId"]);
                this.Keyword = Convert.ToString(sqlRdr["Keyword"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsDefault = Convert.ToBoolean(sqlRdr["IsDefault"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                /// Extra
                this.Business = Convert.ToString(sqlRdr["Business"]);
                return true;
            }
            return false;
        }

        private List<poswBusinessDescriptionDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswBusinessDescriptionDAL> lstBusinessDescription = new List<poswBusinessDescriptionDAL>();
            poswBusinessDescriptionDAL objBusinessDescription = null;
            while (sqlRdr.Read())
            {
                objBusinessDescription = new poswBusinessDescriptionDAL();
                objBusinessDescription.BusinessDescriptionId = Convert.ToInt16(sqlRdr["BusinessDescriptionId"]);
                objBusinessDescription.Keyword = Convert.ToString(sqlRdr["Keyword"]);
                objBusinessDescription.Description = Convert.ToString(sqlRdr["Description"]);
                objBusinessDescription.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objBusinessDescription.IsDefault = Convert.ToBoolean(sqlRdr["IsDefault"]);
                objBusinessDescription.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                objBusinessDescription.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objBusinessDescription.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objBusinessDescription.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                lstBusinessDescription.Add(objBusinessDescription);
            }
            return lstBusinessDescription;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertBusinessDescription()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessDescription_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessDescriptionId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Keyword", SqlDbType.VarChar).Value = this.Keyword;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDefault", SqlDbType.Bit).Value = this.IsDefault;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BusinessDescriptionId = Convert.ToInt16(SqlCmd.Parameters["@BusinessDescriptionId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateBusinessDescription()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessDescription_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessDescriptionId", SqlDbType.SmallInt).Value = this.BusinessDescriptionId;
                SqlCmd.Parameters.Add("@Keyword", SqlDbType.VarChar).Value = this.Keyword;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteBusinessDescription()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessDescription_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessDescriptionId", SqlDbType.SmallInt).Value = this.BusinessDescriptionId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBusinessDescription()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessDescription_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.BusinessDescriptionId > 0)
                {
                    SqlCmd.Parameters.Add("@BusinessDescriptionId", SqlDbType.SmallInt).Value = this.BusinessDescriptionId;
                }

                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }

                if(this.Keyword!=null)
                {
                    SqlCmd.Parameters.Add("@Keyword", SqlDbType.VarChar).Value = this.Keyword;
                }
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswBusinessDescriptionDAL> SelectBusinessDescriptionKeyword()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessDescriptionKeyword_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessDescriptionDAL> lstBusinessDescriptionDAL = new List<poswBusinessDescriptionDAL>();
                poswBusinessDescriptionDAL objBusinessDescriptionDAL = null;
                while (SqlRdr.Read())
                {
                    objBusinessDescriptionDAL = new poswBusinessDescriptionDAL();
                    objBusinessDescriptionDAL.BusinessDescriptionId = Convert.ToInt16(SqlRdr["BusinessDescriptionId"]);
                    objBusinessDescriptionDAL.Keyword = Convert.ToString(SqlRdr["Keyword"]);
                    lstBusinessDescriptionDAL.Add(objBusinessDescriptionDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessDescriptionDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswBusinessDescriptionDAL> SelectAllBusinessDescriptionPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessDescriptionPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessDescriptionDAL> lstBusinessDescriptionDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstBusinessDescriptionDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

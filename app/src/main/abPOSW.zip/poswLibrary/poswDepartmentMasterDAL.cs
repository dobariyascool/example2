using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswDepartmentMaster
    /// </summary>
    public class poswDepartmentMasterDAL
    {
        #region Properties
        public short DepartmentMasterId { get; set; }
        public string ShortName { get; set; }
        public string DepartmentName { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsSync { get; set; }
        public short? SyncId { get; set; }
        public DateTime? TransactionDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }

        /// Extra
        public string Business { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.DepartmentMasterId = Convert.ToInt16(sqlRdr["DepartmentMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.DepartmentName = Convert.ToString(sqlRdr["DepartmentName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsSync = Convert.ToBoolean(sqlRdr["IsSync"]);
                if (sqlRdr["SyncId"] != DBNull.Value)
                {
                    this.SyncId = Convert.ToInt16(sqlRdr["SyncId"]);
                }
                if (sqlRdr["TransactionDateTime"] != DBNull.Value)
                {
                    this.TransactionDateTime = Convert.ToDateTime(sqlRdr["TransactionDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                /// Extra
                this.Business = Convert.ToString(sqlRdr["Business"]);
                return true;
            }
            return false;
        }

        private List<poswDepartmentMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswDepartmentMasterDAL> lstDepartmentMaster = new List<poswDepartmentMasterDAL>();
            poswDepartmentMasterDAL objDepartmentMaster = null;
            while (sqlRdr.Read())
            {
                objDepartmentMaster = new poswDepartmentMasterDAL();
                objDepartmentMaster.DepartmentMasterId = Convert.ToInt16(sqlRdr["DepartmentMasterId"]);
                objDepartmentMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objDepartmentMaster.DepartmentName = Convert.ToString(sqlRdr["DepartmentName"]);
                objDepartmentMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objDepartmentMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objDepartmentMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objDepartmentMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objDepartmentMaster.IsSync = Convert.ToBoolean(sqlRdr["IsSync"]);
                if (sqlRdr["SyncId"] != DBNull.Value)
                {
                    objDepartmentMaster.SyncId = Convert.ToInt16(sqlRdr["SyncId"]);
                }
                if (sqlRdr["TransactionDateTime"] != DBNull.Value)
                {
                    objDepartmentMaster.TransactionDateTime = Convert.ToDateTime(sqlRdr["TransactionDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objDepartmentMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objDepartmentMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                /// Extra
                objDepartmentMaster.Business = Convert.ToString(sqlRdr["Business"]);
                lstDepartmentMaster.Add(objDepartmentMaster);
            }
            return lstDepartmentMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertDepartmentMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswDepartmentMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@DepartmentName", SqlDbType.VarChar).Value = this.DepartmentName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsSync", SqlDbType.Bit).Value = this.IsSync;
                SqlCmd.Parameters.Add("@SyncId", SqlDbType.SmallInt).Value = this.SyncId;
                SqlCmd.Parameters.Add("@TransactionDateTime", SqlDbType.DateTime).Value = this.TransactionDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.DepartmentMasterId = Convert.ToInt16(SqlCmd.Parameters["@DepartmentMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectDepartmentMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswDepartmentMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Value = this.DepartmentMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswDepartmentMasterDAL> SelectAllDepartmentMasterByBusinessMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswDepartmentMasterByBusinessMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswDepartmentMasterDAL> lstDepartmentMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstDepartmentMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswDepartmentMasterDAL> SelectAllDepartmentMasterDepartmentName()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswDepartmentMasterDepartmentName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswDepartmentMasterDAL> lstDepartmentMasterDAL = new List<poswDepartmentMasterDAL>();
                poswDepartmentMasterDAL objDepartmentMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objDepartmentMasterDAL = new poswDepartmentMasterDAL();
                    objDepartmentMasterDAL.DepartmentMasterId = Convert.ToInt16(SqlRdr["DepartmentMasterId"]);
                    objDepartmentMasterDAL.DepartmentName = Convert.ToString(SqlRdr["DepartmentName"]);
                    lstDepartmentMasterDAL.Add(objDepartmentMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstDepartmentMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Sync
        public bool UpdateDepartmentMaster(List<poswResponseDAL> lstResponseDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswDepartmentMasterSync_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();

                foreach (poswResponseDAL obj in lstResponseDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Value = obj.Id;
                    SqlCmd.Parameters.Add("@SyncId", SqlDbType.SmallInt).Value = obj.SyncId;

                    SqlCmd.ExecuteNonQuery();
                }

                SqlCon.Close();
                return true;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswResponseDAL> SyncAllDepartmentMaster(List<poswDepartmentMasterDAL> lstDeaprtmentMasterDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            poswResponseDAL objResponse;
            List<poswResponseDAL> lstResponse = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswDepartmentMasterSyncId_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();

                lstResponse = new List<poswResponseDAL>();
                foreach (poswDepartmentMasterDAL objDepartmentMasterDAL in lstDeaprtmentMasterDAL)
                {
                    SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Value = objDepartmentMasterDAL.DepartmentMasterId;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = objDepartmentMasterDAL.ShortName;
                    SqlCmd.Parameters.Add("@DepartmentName", SqlDbType.VarChar).Value = objDepartmentMasterDAL.DepartmentName;
                    SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = objDepartmentMasterDAL.Description;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objDepartmentMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = objDepartmentMasterDAL.IsDeleted;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = objDepartmentMasterDAL.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@CurrentDateTime", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                    SqlCmd.Parameters.Add("@TransactionDateTime", SqlDbType.DateTime).Value = objDepartmentMasterDAL.TransactionDateTime;

                    SqlRdr = SqlCmd.ExecuteReader();

                    if (SqlRdr.Read())
                    {
                        objResponse = new poswResponseDAL();
                        objResponse.SyncId = Convert.ToInt16(SqlRdr["posw_DepartmentMasterId"]);
                        objResponse.Id = Convert.ToInt16(SqlRdr["pos_DepartmentMasterId"]);
                        lstResponse.Add(objResponse);
                    }

                    SqlCmd.Parameters.Clear();
                    SqlRdr.Close();
                }

                SqlCon.Close();
                return lstResponse;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

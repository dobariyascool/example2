using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswItemComboTran
	/// </summary>
	public class poswItemComboTranDAL
	{
		#region Properties
		public int ItemComboTranId { get; set; }
		public int linktoItemMasterId { get; set; }
		public int linktoItemMasterIdCombo { get; set; }

        // Extra

        public string ItemName { get; set; }
        public short linktoCategoryMasterId { get; set; }
        public string CategoryName { get; set; }
        public bool IsItemSelected { get; set; }
		#endregion

		#region Class Methods
		private List<poswItemComboTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswItemComboTranDAL> lstItemComboTran = new List<poswItemComboTranDAL>();
			poswItemComboTranDAL objItemComboTran = null;
			while (sqlRdr.Read())
			{
				objItemComboTran = new poswItemComboTranDAL();
                if (sqlRdr["ItemComboTranId"] != DBNull.Value)
                {
                    objItemComboTran.ItemComboTranId = Convert.ToInt32(sqlRdr["ItemComboTranId"]);
                    objItemComboTran.IsItemSelected = true;
                }
                else
                {
                    objItemComboTran.IsItemSelected = false;
                }
				objItemComboTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
				
                // Extra
                objItemComboTran.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                objItemComboTran.linktoCategoryMasterId = Convert.ToInt16(sqlRdr["linktoCategoryMasterId"]);
                objItemComboTran.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);

				lstItemComboTran.Add(objItemComboTran);
			}
			return lstItemComboTran;
		}
		#endregion

		#region Insert
        public poswRecordStatus InsertAllItemComboTran(string linktoItemMasterIdCombos, SqlConnection SqlCon, SqlTransaction SqlTran)
		{
			SqlCommand SqlCmd = null;
			try
			{
				SqlCmd = new SqlCommand("poswItemComboTran_InsertAll", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCmd.Parameters.Add("@linktoItemMasterIdCombos", SqlDbType.VarChar).Value = linktoItemMasterIdCombos;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
			}
		}
		#endregion

		#region SelectAll
		public List<poswItemComboTranDAL> SelectAllItemComboTran(short Itemtype,short linktoBusinessMasterId,SqlConnection sqlCon = null)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				if (sqlCon == null)
				{
					SqlCon = poswObjectFactoryDAL.CreateConnection();
					SqlCmd = new SqlCommand("poswItemComboTran_SelectAll", SqlCon);
				}
				else
				{
					SqlCmd = new SqlCommand("poswItemComboTran_SelectAll", sqlCon);
				}
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@Itemtype", SqlDbType.Int).Value = Itemtype;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

				if (sqlCon == null)
				{
					SqlCon.Open();
				}
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswItemComboTranDAL> lstItemComboTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				if (sqlCon == null)
				{
					SqlCon.Close();
				}

				return lstItemComboTranDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				if (sqlCon == null)
				{
					poswObjectFactoryDAL.DisposeConnection(SqlCon);
				}
			}
		}
		#endregion
	}
}

﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web.Script.Serialization;
using System.Collections.Generic;

namespace poswLibrary
{
    public class poswFCMPushNotificationDAL
    {
        public string SendNotification(string apiKey, string deviceId, string message,string tickerText, string contentTitle, string subTitle,string notificationType, string Id)
        {
            string postDataContentType = "application/json";
            //string apiKey = "AIzaSyBD9E3ZboQX1a9mAblzm7L4WGkYQJYP1rg"; // hardcorded
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "offer/";
            string image = ImageRetrievePath + "lg_Offer_Buy_Get_Free_Items_WMXrS7.jpg";
            //string tickerText = "example test GCM";
            //string contentTitle = "content title GCM";
            string postData =
            "{ \"registration_ids\": [ \"" + deviceId + "\" ], " +
              "\"data\": {\"tickerText\":\"" + tickerText + "\", " +
                         "\"contentTitle\":\"" + contentTitle + "\", " +
                         "\"subtitle\":\"" + subTitle + "\", " +
                         "\"notificationType\":\"" + notificationType + "\", " +
                         "\"itemOfferId\":\"" + Id + "\", " +
                         "\"largeIcon\":\"" + image + "\", " +                     
                         "\"message\": \"" + message + "\"}}";

            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateServerCertificate);

            //
            //  MESSAGE CONTENT
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            //
            //  CREATE REQUEST
            HttpWebRequest Request = (HttpWebRequest)WebRequest.Create("https://android.googleapis.com/gcm/send");
            Request.Method = "POST";
            Request.KeepAlive = false;
            Request.ContentType = postDataContentType;
            Request.Headers.Add(string.Format("Authorization: key={0}", apiKey));
            Request.ContentLength = byteArray.Length;

            Stream dataStream = Request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();

            //
            //  SEND MESSAGE
            try
            {
                WebResponse Response = Request.GetResponse();
                HttpStatusCode ResponseCode = ((HttpWebResponse)Response).StatusCode;
                //if (ResponseCode.Equals(HttpStatusCode.Unauthorized) || ResponseCode.Equals(HttpStatusCode.Forbidden))
                //{
                //    var text = "Unauthorized - need new token";
                //}
                //else if (!ResponseCode.Equals(HttpStatusCode.OK))
                //{
                //    var text = "Response from web service isn't OK";
                //}

                StreamReader Reader = new StreamReader(Response.GetResponseStream());
                string responseLine = Reader.ReadToEnd();
                Reader.Close();

                return responseLine;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
            }
            return "error";
        }

        public string SendFCMNotification(string serverApiKey, string senderId, string deviceId, string message)
        {          
            try
            {
                //result.Successful = false;
                //result.Error = null;
                //string result;

                var value = message;
                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.ContentType = "application/x-www-form-urlencoded;charset=UTF-8";
                tRequest.Headers.Add(string.Format("Authorization: key={0}", serverApiKey));
                tRequest.Headers.Add(string.Format("Sender: id={0}", senderId));

                string postData = "collapse_key=score_update&time_to_live=108&delay_while_idle=1&data.message=" + value + "&data.time=" + System.DateTime.Now.ToString() + "&registration_id=" + deviceId + "";
                //tRequest.ContentType = "application/json";
                //var data = new
                //{
                //    to = deviceId,
                //    notification = new
                //    {
                //        body = "This is the message",
                //        title = "This is the title",
                //        icon = "myicon"
                //    }
                //};

                //var serializer = new JavaScriptSerializer();
                //var json = serializer.Serialize(data);

                //Byte[] byteArray = Encoding.UTF8.GetBytes(json);
                Byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                tRequest.ContentLength = byteArray.Length;

                using (Stream dataStream = tRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                    using (WebResponse tResponse = tRequest.GetResponse())
                    {
                        using (Stream dataStreamResponse = tResponse.GetResponseStream())
                        {
                            using (StreamReader tReader = new StreamReader(dataStreamResponse))
                            {
                                String sResponseFromServer = tReader.ReadToEnd();
                               return sResponseFromServer;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //result.Successful = false;
                //result.Response = null;
                //result.Error = ex;.
                poswGlobalsDAL.SaveError(ex);
            }

            return "error";
        }

        public string SendNotificationLikEat(string DeviceId, string Title, string text, string imageName, string notificationType, string Id)
        {
            try
            {
                String ServerApiKey = poswGlobalsDAL.apiKeyabPOSW;
                String SenderId = poswGlobalsDAL.senderIdabPOSW;
                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.Headers.Add(string.Format("Authorization: key={0}", ServerApiKey));
                tRequest.Headers.Add(string.Format("Sender: id={0}", SenderId));
                tRequest.ContentType = "application/json";
                var data = new
                {
                    //notification = new
                    //{
                    //    body = text,
                    //    title = Title,
                    //},
                    to = DeviceId,
                    data = new
                    {
                        body = text,
                        title = Title,
                        type = notificationType,
                        id = Id,
                        notificationImage = imageName,
                    },
                    content_available = true
                    
                };
                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(data);
                Byte[] byteArray = Encoding.UTF8.GetBytes(json);
                tRequest.ContentLength = byteArray.Length;

                using (Stream dataStream = tRequest.GetRequestStream()) 
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                    using (WebResponse tResponse = tRequest.GetResponse())
                    {
                        using (Stream dataStreamResponse = tResponse.GetResponseStream())
                        {
                            using (StreamReader tReader = new StreamReader(dataStreamResponse))
                            {
                                String sResponseFromServer = tReader.ReadToEnd();
                                return sResponseFromServer;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return ex.ToString();
            }
        }

        public string SendNotification(string DeviceId, string Title, string text)
        {
            try
            {
                String ServerApiKey = poswGlobalsDAL.apiKeyabPOSA;
                String SenderId = poswGlobalsDAL.senderIdabPOSA;
                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.Headers.Add(string.Format("Authorization: key={0}", ServerApiKey));
                tRequest.Headers.Add(string.Format("Sender: id={0}", SenderId));
                tRequest.ContentType = "application/json";
                var data = new
                {
                    notification = new
                    {
                        body = text,
                        title = Title,
                    },
                    data = new
                    {
                        type = "general"
                    },
                    to = DeviceId
                };
                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(data);

                Byte[] byteArray = Encoding.UTF8.GetBytes(json);
                tRequest.ContentLength = byteArray.Length;

                using (Stream dataStream = tRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                    using (WebResponse tResponse = tRequest.GetResponse())
                    {
                        using (Stream dataStreamResponse = tResponse.GetResponseStream())
                        {
                            using (StreamReader tReader = new StreamReader(dataStreamResponse))
                            {
                                String sResponseFromServer = tReader.ReadToEnd();
                                return sResponseFromServer;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        public string SendOrderDetails(string DeviceId, string newOrder, string newBookings, string cancleOrders, string cancleBookings)
        {
            try
            {
                String ServerApiKey = poswGlobalsDAL.apiKeyabPOSA;
                String SenderId = poswGlobalsDAL.senderIdabPOSA;
                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.Headers.Add(string.Format("Authorization: key={0}", ServerApiKey));
                tRequest.Headers.Add(string.Format("Sender: id={0}", SenderId));
                tRequest.ContentType = "application/json";
                String Title = "LikEat Admin";
                string notificationType = "orderSummary", summarytype = null, text = null, Count = null;
                if (newOrder != null && !newOrder.Equals("0"))
                {
                    summarytype = "newOrders";
                    Count = newOrder;
                    text = "New Orders : " + newOrder;
                }
                else if (newBookings != null && !newBookings.Equals("0"))
                {
                    summarytype = "newBookings";
                    Count = newBookings;
                    text = "New Bookings : " + newBookings;
                }
                else if (cancleOrders != null && !cancleOrders.Equals("0"))
                {
                    summarytype = "cancleOrders";
                    Count = cancleOrders;
                    text = "Cancle Orders : " + cancleOrders;
                }
                else if (cancleBookings != null && !cancleBookings.Equals("0"))
                {
                    summarytype = "cancleBookings";
                    Count = cancleBookings;
                    text = "Cancle Bookings : " + cancleBookings;
                }
                var data = new
                {
                    //notification = new
                    //{
                    //    body = text,
                    //    title = Title,
                    //},
                    to = DeviceId,
                    data = new
                    {
                        body = text,
                        title = Title,
                        type = notificationType,
                        summaryType = summarytype,
                        count = Count,
                    },
                    content_available = true

                };
                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(data);
                Byte[] byteArray = Encoding.UTF8.GetBytes(json);
                tRequest.ContentLength = byteArray.Length;

                using (Stream dataStream = tRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                    using (WebResponse tResponse = tRequest.GetResponse())
                    {
                        using (Stream dataStreamResponse = tResponse.GetResponseStream())
                        {
                            using (StreamReader tReader = new StreamReader(dataStreamResponse))
                            {
                                String sResponseFromServer = tReader.ReadToEnd();
                                return sResponseFromServer;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return ex.ToString();
            }         
        }

        public static bool ValidateServerCertificate(
        object sender,
        X509Certificate certificate,
        X509Chain chain,
        SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }


        
    }
}

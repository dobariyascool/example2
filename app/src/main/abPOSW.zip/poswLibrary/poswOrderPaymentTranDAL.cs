using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswOrderPaymentTran
    /// </summary>
    public class poswOrderPaymentTranDAL
    {
        #region Properties
        public long? OrderPaymentTranId { get; set; }
        public long? linktoOrderMasterId { get; set; }
        public short? linktoPaymentTypeMasterId { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public DateTime PaymentDateTime { get; set; }
        public double AmountPaid { get; set; }
        public string Remark { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short? linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public long Order { get; set; }
        public string PaymentType { get; set; }
        public string Customer { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double TotalAmount { get; set; }
        public double BalanceAmount { get; set; }
        public double Discount { get; set; }
        public double TotalTax { get; set; }
        public double? totalAmount { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.OrderPaymentTranId = Convert.ToInt64(sqlRdr["OrderPaymentTranId"]);
                this.linktoOrderMasterId = Convert.ToInt64(sqlRdr["linktoOrderMasterId"]);
                this.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                this.PaymentDateTime = Convert.ToDateTime(sqlRdr["PaymentDateTime"]);
                this.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdCreatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Order = Convert.ToInt64(sqlRdr["Order"]);
                this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                this.Customer = Convert.ToString(sqlRdr["Customer"]);

                return true;
            }
            return false;
        }

        private List<poswOrderPaymentTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswOrderPaymentTranDAL> lstOrderPaymentTran = new List<poswOrderPaymentTranDAL>();
            poswOrderPaymentTranDAL objOrderPaymentTran = null;
            while (sqlRdr.Read())
            {
                objOrderPaymentTran = new poswOrderPaymentTranDAL();

                objOrderPaymentTran.OrderPaymentTranId = Convert.ToInt64(sqlRdr["OrderPaymentTranId"]);


                objOrderPaymentTran.linktoOrderMasterId = Convert.ToInt64(sqlRdr["linktoOrderMasterId"]);

                objOrderPaymentTran.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objOrderPaymentTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                objOrderPaymentTran.PaymentDateTime = Convert.ToDateTime(sqlRdr["PaymentDateTime"]);
                objOrderPaymentTran.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                objOrderPaymentTran.Remark = Convert.ToString(sqlRdr["Remark"]);
                objOrderPaymentTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objOrderPaymentTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdCreatedBy"] != DBNull.Value)
                {
                    objOrderPaymentTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objOrderPaymentTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objOrderPaymentTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objOrderPaymentTran.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                objOrderPaymentTran.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                objOrderPaymentTran.PaidAmount = Convert.ToDouble(sqlRdr["PaidAmount"]);
                objOrderPaymentTran.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objOrderPaymentTran.BalanceAmount = Convert.ToDouble(sqlRdr["BalanceAmount"]);
                objOrderPaymentTran.FirstName = Convert.ToString(sqlRdr["FirstName"]);
                objOrderPaymentTran.LastName = Convert.ToString(sqlRdr["LastName"]);
                objOrderPaymentTran.TotalTax = Convert.ToDouble(sqlRdr["TotalTax"]);
                objOrderPaymentTran.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                lstOrderPaymentTran.Add(objOrderPaymentTran);
            }
            return lstOrderPaymentTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertOrderPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderPaymentTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderPaymentTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = this.linktoOrderMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@PaymentDateTime", SqlDbType.DateTime).Value = this.PaymentDateTime;
                SqlCmd.Parameters.Add("@AmountPaid", SqlDbType.Money).Value = this.AmountPaid;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.OrderPaymentTranId = Convert.ToInt64(SqlCmd.Parameters["@OrderPaymentTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteOrderPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderPaymentTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderPaymentTranId", SqlDbType.BigInt).Value = this.OrderPaymentTranId;
                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = this.linktoOrderMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion    

        #region SelectAll
        public List<poswOrderPaymentTranDAL> SelectAllOrderPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderPaymentTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoOrderMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.Int).Value = this.linktoOrderMasterId;
                }


                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderPaymentTranDAL> lstOrderPaymentTranDAL = new List<poswOrderPaymentTranDAL>();
                poswOrderPaymentTranDAL objOrderPaymentTranDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderPaymentTranDAL = new poswOrderPaymentTranDAL();

                    objOrderPaymentTranDAL.Customer = Convert.ToString(SqlRdr["Customer"]);
                    objOrderPaymentTranDAL.TotalAmount = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    objOrderPaymentTranDAL.Discount = Convert.ToDouble(SqlRdr["Discount"]);
                    objOrderPaymentTranDAL.TotalTax = Convert.ToDouble(SqlRdr["TotalTax"]);
                    objOrderPaymentTranDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    objOrderPaymentTranDAL.PaidAmount = Convert.ToDouble(SqlRdr["PaidAmount"]);
                    objOrderPaymentTranDAL.BalanceAmount = Convert.ToDouble(SqlRdr["BalanceAmount"]);

                    if (SqlRdr["OrderPaymentTranId"] != DBNull.Value)
                    {
                        objOrderPaymentTranDAL.OrderPaymentTranId = Convert.ToInt64(SqlRdr["OrderPaymentTranId"]);
                        objOrderPaymentTranDAL.PaymentType = Convert.ToString(SqlRdr["PaymentType"]);
                        objOrderPaymentTranDAL.PaymentDateTime = Convert.ToDateTime(SqlRdr["PaymentDateTime"]);
                        objOrderPaymentTranDAL.AmountPaid = Convert.ToDouble(SqlRdr["AmountPaid"]);
                        objOrderPaymentTranDAL.Remark = Convert.ToString(SqlRdr["Remark"]);
                        objOrderPaymentTranDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);
                    }
                    lstOrderPaymentTranDAL.Add(objOrderPaymentTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderPaymentTranDAL;

            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }

        }

        public List<poswOrderPaymentTranDAL> SelectAllOrderPaymentTranByOrderMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderPaymentTranByOrderMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.Int).Value = this.linktoOrderMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderPaymentTranDAL> lstOrderPaymentTranDAL = new List<poswOrderPaymentTranDAL>();
                poswOrderPaymentTranDAL objOrderPaymentTranDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderPaymentTranDAL = new poswOrderPaymentTranDAL();

                    objOrderPaymentTranDAL.OrderPaymentTranId = Convert.ToInt64(SqlRdr["OrderPaymentTranId"]);                  
                    objOrderPaymentTranDAL.PaymentDateTime = Convert.ToDateTime(SqlRdr["PaymentDateTime"]);
                    objOrderPaymentTranDAL.AmountPaid = Convert.ToDouble(SqlRdr["AmountPaid"]);
                    objOrderPaymentTranDAL.Remark = Convert.ToString(SqlRdr["Remark"]);
                    objOrderPaymentTranDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);

                    lstOrderPaymentTranDAL.Add(objOrderPaymentTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderPaymentTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public DataTable SelectAllOrderMasterPaymentTypeWiseReport(short linktoBusinessMasterId, DateTime FromDate,DateTime ToDate,short StartRowIndex,short PageSize ,out short TotalRecord)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterPaymentTypeWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = StartRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = PageSize;
                SqlCmd.Parameters.Add("@TotalRecord", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                if (FromDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = FromDate;
                }
                if (ToDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = ToDate;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();

                SqlDataAdapter SqlDa = new SqlDataAdapter(SqlCmd);
                DataTable Dt = new DataTable();
                SqlDa.Fill(Dt);
                SqlCon.Close();

                TotalRecord = 0;

                if (Dt.Rows.Count > 0)
                {
                    TotalRecord = (short)SqlCmd.Parameters["@TotalRecord"].Value;
                }
                
                return Dt;

            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                TotalRecord = 0;
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }

        }


        public List<poswOrderPaymentTranDAL> SelectAllDailySaleDateWise(short linktoBusinessMasterId,DateTime fromDate, DateTime toDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            List<poswOrderPaymentTranDAL> lstOrderPaymentTran = new List<poswOrderPaymentTranDAL>();
            poswOrderPaymentTranDAL objOrderPaymentTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswDailySalesDateWiseByPaymentType_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDateTime", SqlDbType.DateTime).Value = fromDate;
                SqlCmd.Parameters.Add("@ToDateTime", SqlDbType.DateTime).Value = toDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                while (SqlRdr.Read())
                {
                    objOrderPaymentTran = new poswOrderPaymentTranDAL();
                    objOrderPaymentTran.linktoPaymentTypeMasterId = Convert.ToInt16(SqlRdr["PaymentTypeMasterId"]);
                    objOrderPaymentTran.PaymentType = Convert.ToString(SqlRdr["PaymentType"]);
                    objOrderPaymentTran.totalAmount = Convert.ToDouble(SqlRdr["totalAmount"]);
                    lstOrderPaymentTran.Add(objOrderPaymentTran);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderPaymentTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        
        #endregion
    }
}

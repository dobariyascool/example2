using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Reflection;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswOfferItemsTran
	/// </summary>
	public class poswOfferItemsTranDAL
	{
		#region Properties
		public int OfferItemsTranId { get; set; }
		public int linktoOfferMasterId { get; set; }
		public int? linktoItemMasterId { get; set; }
        public short? OfferItemType { get; set; }

        //Extra 
        public string linktoItemMasterIds { get; set; }
        public string OfferItemTypeIds { get; set; }


		#endregion

		#region Class Methods
		private List<poswOfferItemsTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswOfferItemsTranDAL> lstOfferItemsTran = new List<poswOfferItemsTranDAL>();
			poswOfferItemsTranDAL objOfferItemsTran = null;
			while (sqlRdr.Read())
			{
				objOfferItemsTran = new poswOfferItemsTranDAL();
				objOfferItemsTran.OfferItemsTranId = Convert.ToInt32(sqlRdr["OfferItemsTranId"]);
				objOfferItemsTran.linktoOfferMasterId = Convert.ToInt32(sqlRdr["linktoOfferMasterId"]);
				if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
				{
					objOfferItemsTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				}
                objOfferItemsTran.OfferItemType = Convert.ToInt16(sqlRdr["OfferItemType"]);
				lstOfferItemsTran.Add(objOfferItemsTran);
			}
			return lstOfferItemsTran;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertAllOfferItemsTran(string linktoItemMasterIds)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferItemsTran_InsertAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@linktoItemMasterIds", SqlDbType.VarChar).Value = linktoItemMasterIds;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public  poswRecordStatus InsertAllOfferItemsTran(SqlConnection SqlCon, SqlTransaction SqlTran, DataTable dtOfferItem)
        {
            
            SqlCommand SqlCmd = null;
            try
            {
               
                SqlCmd = new SqlCommand("poswOfferItemsTran_InsertAll", SqlCon, SqlTran);//  poswOfferItemsTran_InsertAllByDataTable
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.AddWithValue("@tblOfferItems", dtOfferItem);
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
               
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
		#endregion

        #region Delete
        public poswRecordStatus DeleteOfferItemsTran(SqlConnection SqlCon, SqlTransaction SqlTran)
       {
           
           SqlCommand SqlCmd = null;
           try
           {
               
               SqlCmd = new SqlCommand("poswOfferItemsTran_Delete", SqlCon,SqlTran);
               SqlCmd.CommandType = CommandType.StoredProcedure;

               SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
               SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
               SqlCmd.ExecuteNonQuery();
               poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
               return rs;
           }
           catch (Exception ex)
           {
               poswGlobalsDAL.SaveError(ex);
               return poswRecordStatus.Error;
           }
           finally
           {
               poswObjectFactoryDAL.DisposeCommand(SqlCmd);
              
           }
       }
       #endregion

		#region SelectAll

		public List<poswOfferItemsTranDAL> SelectAllOfferItemsTran(SqlConnection sqlCon = null)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				if (sqlCon == null)
				{
					SqlCon = poswObjectFactoryDAL.CreateConnection();
					SqlCmd = new SqlCommand("poswOfferItemsTran_SelectAll", SqlCon);
				}
				else
				{
					SqlCmd = new SqlCommand("poswOfferItemsTran_SelectAll", sqlCon);
				}
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;

				if (sqlCon == null)
				{
					SqlCon.Open();
				}
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswOfferItemsTranDAL> lstOfferItemsTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				if (sqlCon == null)
				{
					SqlCon.Close();
				}

				return lstOfferItemsTranDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				if (sqlCon == null)
				{
					poswObjectFactoryDAL.DisposeConnection(SqlCon);
				}
			}
		}
		#endregion


        #region Extra

        //public static DataTable ToDataTable<T>(List<T> items, List<string> ExtraCollumns)
        //{
        //    DataTable dataTable = new DataTable(typeof(T).Name);

        //    //Get all the properties
        //    PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
        //    foreach (PropertyInfo prop in Props)
        //    {
        //        //Setting column names as Property names
        //        dataTable.Columns.Add(prop.Name);
        //    }
        //    foreach (T item in items)
        //    {
        //        var values = new object[Props.Length];
        //        for (int i = 0; i < Props.Length; i++)
        //        {
        //            //inserting property values to datatable rows
        //            values[i] = Props[i].GetValue(item, null);
        //        }
        //        dataTable.Rows.Add(values);
        //    }

        //    foreach (string extraCollumn in ExtraCollumns)
        //    {
        //        dataTable.Columns.Remove(extraCollumn);
        //    }

        //    //put a breakpoint here and check datatable
        //    return dataTable;
        //}
        #endregion
    }
}

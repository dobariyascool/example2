using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswTableMaster
    /// </summary>
    [Serializable]
    public class poswTableMasterDAL
    {
        #region Properties
        public short TableMasterId { get; set; }
        public string TableName { get; set; }
        public string ShortName { get; set; }
        public string Description { get; set; }
        public short MinPerson { get; set; }
        public short MaxPerson { get; set; }
        public bool IsBookingAvailable { get; set; }
        public double HourlyBookingRate { get; set; }
        public double DailyBookingRate { get; set; }
        public short linktoOrderTypeMasterId { get; set; }        
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }

        /// Extra
        public string Section { get; set; }
        public string OrderType { get; set; }
        public int TempMasterId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.TableMasterId = Convert.ToInt16(sqlRdr["TableMasterId"]);
                this.TableName = Convert.ToString(sqlRdr["TableName"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.MinPerson = Convert.ToInt16(sqlRdr["MinPerson"]);
                this.MaxPerson = Convert.ToInt16(sqlRdr["MaxPerson"]);
                if (sqlRdr["IsBookingAvailable"] != DBNull.Value)
                {
                    this.IsBookingAvailable = Convert.ToBoolean(sqlRdr["IsBookingAvailable"]);
                }
                if (sqlRdr["HourlyBookingRate"] != DBNull.Value)
                {
                    this.HourlyBookingRate = Convert.ToDouble(sqlRdr["HourlyBookingRate"]);
                }
                if (sqlRdr["DailyBookingRate"] != DBNull.Value)
                {
                    this.DailyBookingRate = Convert.ToDouble(sqlRdr["DailyBookingRate"]);
                }
                this.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                return true;
            }
            return false;
        }

        private List<poswTableMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswTableMasterDAL> lstTableMaster = new List<poswTableMasterDAL>();
            poswTableMasterDAL objTableMaster = null;
            while (sqlRdr.Read())
            {
                objTableMaster = new poswTableMasterDAL();
                objTableMaster.TableMasterId = Convert.ToInt16(sqlRdr["TableMasterId"]);
                objTableMaster.TableName = Convert.ToString(sqlRdr["TableName"]);
                objTableMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objTableMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objTableMaster.MinPerson = Convert.ToInt16(sqlRdr["MinPerson"]);
                objTableMaster.MaxPerson = Convert.ToInt16(sqlRdr["MaxPerson"]);
                objTableMaster.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                objTableMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objTableMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objTableMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objTableMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objTableMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objTableMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                lstTableMaster.Add(objTableMaster);
            }
            return lstTableMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertTableMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTableMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = this.TableName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = this.MinPerson;
                SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = this.MaxPerson;
                SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = this.IsBookingAvailable;
                SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Money).Value = this.HourlyBookingRate;
                SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Money).Value = this.DailyBookingRate;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.TableMasterId = Convert.ToInt16(SqlCmd.Parameters["@TableMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static poswRecordStatus InsertTableMasterBulkEntry(List<poswTableMasterDAL> lstTableMaster)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            bool IsAllreadyExists = false;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                poswRecordStatus rs = poswRecordStatus.RecordAlreadyExist;
                foreach (poswTableMasterDAL obj in lstTableMaster)
                {
                    SqlCmd = new SqlCommand("poswTableMaster_Insert", SqlCon);
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = obj.TableName;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = obj.ShortName;
                    if (obj.Description != null)
                    {
                        SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = obj.Description;
                    }
                    SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = obj.MinPerson;
                    SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = obj.MaxPerson;
                    SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = obj.linktoOrderTypeMasterId;                    
                    SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = obj.IsBookingAvailable;
                    SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Decimal).Value = obj.DailyBookingRate;
                    SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Decimal).Value = obj.HourlyBookingRate;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = obj.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = obj.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = obj.IsEnabled;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    obj.TableMasterId = Convert.ToInt16(SqlCmd.Parameters["@TableMasterId"].Value);

                    rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == poswRecordStatus.RecordAlreadyExist)
                    {
                        IsAllreadyExists = true;
                    }
                }
                SqlCon.Close();
                if (IsAllreadyExists)
                {
                    rs = poswRecordStatus.RecordAlreadyExist;
                }
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateTableMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTableMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Value = this.TableMasterId;
                SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = this.TableName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = this.MinPerson;
                SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = this.MaxPerson;
                SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = this.IsBookingAvailable;
                SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Money).Value = this.HourlyBookingRate;
                SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Money).Value = this.DailyBookingRate;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus UpdateTableMasterAll(List<poswTableMasterDAL> lstTableMasterDAL,out string tables)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            tables = string.Empty;
            bool IsAlreadyExists = false;

            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswTableMaster_UpdateAll", SqlCon,SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                poswRecordStatus rs = poswRecordStatus.RecordAlreadyExist;
                foreach (poswTableMasterDAL obj in lstTableMasterDAL)
                {
                    SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Value = obj.TableMasterId;
                    SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = obj.TableName;
                    SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = obj.MinPerson;
                    SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = obj.MaxPerson;
                    SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = obj.IsBookingAvailable;
                    SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Money).Value = obj.HourlyBookingRate;
                    SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Money).Value = obj.DailyBookingRate;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                    rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == poswRecordStatus.RecordAlreadyExist)
                    {
                        tables += obj.TableName + ", ";
                        IsAlreadyExists = true;
                    }
                    SqlCmd.Parameters.Clear();
                }
                if (!IsAlreadyExists)
                {
                    SqlTran.Commit();
                }
                else
                {
                    SqlTran.Rollback();
                    rs = poswRecordStatus.RecordAlreadyExist;
                }
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {

                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectTableMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTableMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Value = this.TableMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswTableMasterDAL> SelectAllTableMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTableMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = this.TableName;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswTableMasterDAL> lstTableMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswTableMasterDAL> SelectAllTableMasterTableName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTableMasterTableName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswTableMasterDAL> lstTableMasterDAL = new List<poswTableMasterDAL>();
                poswTableMasterDAL objTableMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objTableMasterDAL = new poswTableMasterDAL();
                    objTableMasterDAL.TableMasterId = Convert.ToInt16(SqlRdr["TableMasterId"]);
                    objTableMasterDAL.TableName = Convert.ToString(SqlRdr["TableName"]);
                    lstTableMasterDAL.Add(objTableMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswTableMasterDAL> SelectAllTableMaster(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTableMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswTableMasterDAL> lstTableMasterDAL = new List<poswTableMasterDAL>();
                poswTableMasterDAL objTableMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objTableMasterDAL = new poswTableMasterDAL();
                    objTableMasterDAL.TableMasterId = Convert.ToInt16(SqlRdr["TableMasterId"]);
                    objTableMasterDAL.TableName = Convert.ToString(SqlRdr["TableName"]);
                    objTableMasterDAL.MinPerson = Convert.ToInt16(SqlRdr["MinPerson"]);
                    objTableMasterDAL.MaxPerson = Convert.ToInt16(SqlRdr["MaxPerson"]);
                    objTableMasterDAL.IsBookingAvailable = Convert.ToBoolean(SqlRdr["IsBookingAvailable"]);
                    if (SqlRdr["HourlyBookingRate"] != DBNull.Value)
                    {
                        objTableMasterDAL.HourlyBookingRate = Convert.ToDouble(SqlRdr["HourlyBookingRate"]);
                    }
                    if (SqlRdr["DailyBookingRate"] != DBNull.Value)
                    {
                        objTableMasterDAL.DailyBookingRate = Convert.ToDouble(SqlRdr["DailyBookingRate"]);
                    }
                    lstTableMasterDAL.Add(objTableMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

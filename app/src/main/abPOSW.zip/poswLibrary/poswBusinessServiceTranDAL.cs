using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBusinessServiceTran
    /// </summary>
    public class poswBusinessServiceTranDAL
    {
        #region Properties
        public short BusinessServiceTran { get; set; }
        public short linktoServiceMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }

        //Extra
    
        public string ServiceName { get; set; }
        public string ImageName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string linktoServiceMasterIds { get; set; }
        public bool IsSelected { get; set; }          
        #endregion

        #region Class Methods
        private List<poswBusinessServiceTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "service/";
            List<poswBusinessServiceTranDAL> lstBusinessServiceTran = new List<poswBusinessServiceTranDAL>();
            poswBusinessServiceTranDAL objBusinessServiceTran = null;
            while (sqlRdr.Read())
            {
                objBusinessServiceTran = new poswBusinessServiceTranDAL();
                if (sqlRdr["BusinessServiceTran"] != DBNull.Value)
                {
                    objBusinessServiceTran.BusinessServiceTran = Convert.ToInt16(sqlRdr["BusinessServiceTran"]);
                    objBusinessServiceTran.IsSelected = true;
                }
                if (sqlRdr["ServiceMasterId"] != DBNull.Value)
                {
                    objBusinessServiceTran.linktoServiceMasterId = Convert.ToInt16(sqlRdr["ServiceMasterId"]);
                }        

                //Extra
                objBusinessServiceTran.ServiceName = Convert.ToString(sqlRdr["ServiceName"]);
                if (Convert.ToString(sqlRdr["ImageName"]) != "")
                {
                    objBusinessServiceTran.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                }
                else
                {
                    objBusinessServiceTran.xs_ImagePhysicalName = "img/NoImage.png";
                }

                lstBusinessServiceTran.Add(objBusinessServiceTran);
            }
            return lstBusinessServiceTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertAllBusinessServiceTran(string linktoServiceMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessServiceTran_InsertAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoServiceMasterIds", SqlDbType.VarChar).Value = linktoServiceMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswBusinessServiceTranDAL> SelectAllBusinessServiceTran(short linktoBusinessTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;

            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessServiceTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = linktoBusinessTypeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessServiceTranDAL> lstBusinessServiceTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);

                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessServiceTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
        




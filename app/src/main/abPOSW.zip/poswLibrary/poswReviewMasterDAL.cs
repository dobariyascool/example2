using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswReviewMaster
    /// </summary>
    public class poswReviewMasterDAL
    {
        #region Properties
        public long? ReviewMasterId { get; set; }
        public double StarRating { get; set; }
        public string Review { get; set; }
        public bool? IsShow { get; set; }
        public DateTime ReviewDateTime { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }

        /// Extra
        public string RegisteredUser { get; set; }
        public string UserUpdatedBy { get; set; }
        public string Business { get; set; }
        public string CustomerName { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                if (sqlRdr["ReviewMasterId"] != DBNull.Value)
                {
                    this.ReviewMasterId = Convert.ToInt64(sqlRdr["ReviewMasterId"]);
                }
                this.StarRating = Convert.ToDouble(sqlRdr["StarRating"]);
                this.Review = Convert.ToString(sqlRdr["Review"]);
                if (sqlRdr["IsShow"] != DBNull.Value)
                {
                    this.IsShow = Convert.ToBoolean(sqlRdr["IsShow"]);
                }
                this.ReviewDateTime = Convert.ToDateTime(sqlRdr["ReviewDateTime"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                /// Extra
                this.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
                this.Business = Convert.ToString(sqlRdr["Business"]);
                return true;
            }
            return false;
        }

        private List<poswReviewMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswReviewMasterDAL> lstReviewMaster = new List<poswReviewMasterDAL>();
            poswReviewMasterDAL objReviewMaster = null;
            while (sqlRdr.Read())
            {
                objReviewMaster = new poswReviewMasterDAL();
                if (sqlRdr["ReviewMasterId"] != DBNull.Value)
                {
                    objReviewMaster.ReviewMasterId = Convert.ToInt64(sqlRdr["ReviewMasterId"]);
                }
                objReviewMaster.StarRating = Convert.ToDouble(sqlRdr["StarRating"]);
                objReviewMaster.Review = Convert.ToString(sqlRdr["Review"]);
                if (sqlRdr["IsShow"] != DBNull.Value)
                {
                    objReviewMaster.IsShow = Convert.ToBoolean(sqlRdr["IsShow"]);
                }
                objReviewMaster.ReviewDateTime = Convert.ToDateTime(sqlRdr["ReviewDateTime"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objReviewMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objReviewMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objReviewMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                /// Extra
                objReviewMaster.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
                objReviewMaster.Business = Convert.ToString(sqlRdr["Business"]);
                if (sqlRdr["CustomerName"] != DBNull.Value)
                {
                    objReviewMaster.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                }
                lstReviewMaster.Add(objReviewMaster);
            }
            return lstReviewMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertReviewMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswReviewMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ReviewMasterId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@StarRating", SqlDbType.SmallInt).Value = this.StarRating;
                SqlCmd.Parameters.Add("@Review", SqlDbType.VarChar).Value = this.Review;
                SqlCmd.Parameters.Add("@IsShow", SqlDbType.Bit).Value = this.IsShow;
                SqlCmd.Parameters.Add("@ReviewDateTime", SqlDbType.DateTime).Value = this.ReviewDateTime;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.ReviewMasterId = Convert.ToInt64(SqlCmd.Parameters["@ReviewMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateReviewMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswReviewMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ReviewMasterId", SqlDbType.BigInt).Value = this.ReviewMasterId;
                SqlCmd.Parameters.Add("@StarRating", SqlDbType.SmallInt).Value = this.StarRating;
                SqlCmd.Parameters.Add("@Review", SqlDbType.VarChar).Value = this.Review;
                SqlCmd.Parameters.Add("@IsShow", SqlDbType.Bit).Value = this.IsShow;
                SqlCmd.Parameters.Add("@ReviewDateTime", SqlDbType.DateTime).Value = this.ReviewDateTime;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        public static poswRecordStatus UpdateAllReviewMasterSHOW(List<poswReviewMasterDAL> lstwReviewMasterDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                foreach (poswReviewMasterDAL objReviewMasterDAL in lstwReviewMasterDAL)
                {
                    SqlCmd = new SqlCommand("poswReviewMasterShowReview_UpdateAll", SqlCon);
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlCmd.Parameters.Add("@ReviewMasterId", SqlDbType.SmallInt).Value = objReviewMasterDAL.ReviewMasterId;
                    SqlCmd.Parameters.Add("@IsShow", SqlDbType.Bit).Value = objReviewMasterDAL.IsShow;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                }

                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteReviewMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswReviewMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ReviewMasterId", SqlDbType.BigInt).Value = this.ReviewMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll

        public static poswRecordStatus DeleteAllReviewMaster(string reviewMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswReviewMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ReviewMasterIds", SqlDbType.VarChar).Value = reviewMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectReviewMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswReviewMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ReviewMasterId", SqlDbType.BigInt).Value = this.ReviewMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswReviewMasterDAL> SelectAllReviewMasterPageWise(short startRowIndex, short pageSize, out short totalRecords,bool? IsPreRecordShow = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswReviewMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsShow", SqlDbType.Bit).Value = this.IsShow;
                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }
                if (IsPreRecordShow != null)
                {
                    SqlCmd.Parameters.Add("@IsPreRecordShow", SqlDbType.Bit).Value = IsPreRecordShow;
                }


                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswReviewMasterDAL> lstReviewMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstReviewMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

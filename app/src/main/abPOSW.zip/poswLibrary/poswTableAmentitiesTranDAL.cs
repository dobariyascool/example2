using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswTableAmentitiesTran
    /// </summary>
    public class poswTableAmentitiesTranDAL
    {
        #region Properties
        public int TableAmentitiesTranId { get; set; }
        public short linktoTableMasterId { get; set; }
        public short linktoAmentitiesMasterId { get; set; }

        ///Extras
        public short linktoBusinessMasterId { get; set; }

        #endregion

        #region Class Methods
        private List<poswTableAmentitiesTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswTableAmentitiesTranDAL> lstTableAmentitiesTran = new List<poswTableAmentitiesTranDAL>();
            poswTableAmentitiesTranDAL objTableAmentitiesTran = null;
            while (sqlRdr.Read())
            {
                objTableAmentitiesTran = new poswTableAmentitiesTranDAL();
                objTableAmentitiesTran.TableAmentitiesTranId = Convert.ToInt32(sqlRdr["TableAmentitiesTranId"]);
                objTableAmentitiesTran.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
                objTableAmentitiesTran.linktoAmentitiesMasterId = Convert.ToInt16(sqlRdr["linktoAmentitiesMasterId"]);
                lstTableAmentitiesTran.Add(objTableAmentitiesTran);
            }
            return lstTableAmentitiesTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertAllTableAmentitiesTran(string linktoAmentitiesMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTableAmentitiesTran_InsertAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.SmallInt).Value = this.linktoTableMasterId;
                SqlCmd.Parameters.Add("@linktoAmentitiesMasterIds", SqlDbType.VarChar).Value = linktoAmentitiesMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswTableAmentitiesTranDAL> SelectAllTableAmentitiesTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswTableAmentitiesTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.SmallInt).Value = this.linktoTableMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswTableAmentitiesTranDAL> lstTableAmentitiesTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstTableAmentitiesTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion
    }
}

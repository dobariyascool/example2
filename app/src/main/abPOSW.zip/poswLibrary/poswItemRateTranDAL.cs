using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswItemRateTran
    /// </summary>
    public class poswItemRateTranDAL
    {
        #region Properties
        public int ItemRateTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short? linktoUnitMasterId { get; set; }
        public double MRP { get; set; }
        public double Rate { get; set; }
        public double PurchaseRate { get; set; }
        public bool IsRateTaxInclusive { get; set; }
        public double Tax1 { get; set; }
        public double Tax2 { get; set; }
        public double Tax3 { get; set; }
        public double Tax4 { get; set; }
        public double Tax5 { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string Item { get; set; }
        public string Unit { get; set; }
        public string UserCreatedBy { get; set; }
        public string UserUpdatedBy { get; set; }
        public string linktoItemMasterIds { get; set; }
        public string TaxCaption { get; set; }
        public short TaxIndex { get; set; }
        public double TotalTaxRate { get; set; }
        public double DefaultTaxRate { get; set; }
        public short linktoBusinessMasterId { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.ItemRateTranId = Convert.ToInt32(sqlRdr["ItemRateTranId"]);
                this.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                if (sqlRdr["linktoUnitMasterId"] != DBNull.Value)
                {
                    this.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                }
                this.MRP = Convert.ToDouble(sqlRdr["MRP"]);
                this.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                this.IsRateTaxInclusive = Convert.ToBoolean(sqlRdr["IsRateTaxInclusive"]);
                this.Tax1 = Convert.ToDouble(sqlRdr["Tax1"]);
                this.Tax2 = Convert.ToDouble(sqlRdr["Tax2"]);
                this.Tax3 = Convert.ToDouble(sqlRdr["Tax3"]);
                this.Tax4 = Convert.ToDouble(sqlRdr["Tax4"]);
                this.Tax5 = Convert.ToDouble(sqlRdr["Tax5"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["PurchaseRate"] != DBNull.Value)
                {
                    this.PurchaseRate = Convert.ToDouble(sqlRdr["PurchaseRate"]);
                }

                /// Extra
                this.Item = Convert.ToString(sqlRdr["Item"]);
                this.Unit = Convert.ToString(sqlRdr["Unit"]);
                this.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
                this.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
                return true;
            }
            return false;
        }

        private List<poswItemRateTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswItemRateTranDAL> lstItemRateTran = new List<poswItemRateTranDAL>();
            poswItemRateTranDAL objItemRateTran = null;
            while (sqlRdr.Read())
            {
                objItemRateTran = new poswItemRateTranDAL();
                objItemRateTran.ItemRateTranId = Convert.ToInt32(sqlRdr["ItemRateTranId"]);
                objItemRateTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                if (sqlRdr["linktoUnitMasterId"] != DBNull.Value)
                {
                    objItemRateTran.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                }
                objItemRateTran.MRP = Convert.ToDouble(sqlRdr["MRP"]);
                objItemRateTran.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                objItemRateTran.IsRateTaxInclusive = Convert.ToBoolean(sqlRdr["IsRateTaxInclusive"]);
                objItemRateTran.Tax1 = Convert.ToDouble(sqlRdr["Tax1"]);
                objItemRateTran.Tax2 = Convert.ToDouble(sqlRdr["Tax2"]);
                objItemRateTran.Tax3 = Convert.ToDouble(sqlRdr["Tax3"]);
                objItemRateTran.Tax4 = Convert.ToDouble(sqlRdr["Tax4"]);
                objItemRateTran.Tax5 = Convert.ToDouble(sqlRdr["Tax5"]);
                objItemRateTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objItemRateTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objItemRateTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objItemRateTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objItemRateTran.Item = Convert.ToString(sqlRdr["Item"]);
                objItemRateTran.Unit = Convert.ToString(sqlRdr["Unit"]);
                objItemRateTran.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
                objItemRateTran.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
                lstItemRateTran.Add(objItemRateTran);
            }
            return lstItemRateTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertItemRateTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswItemRateTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                //SqlCmd.Parameters.Add("@ItemRateTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@MRP", SqlDbType.Money).Value = this.MRP;
                SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = this.Rate;
                SqlCmd.Parameters.Add("@PurchaseRate", SqlDbType.Money).Value = this.PurchaseRate;
                SqlCmd.Parameters.Add("@IsRateTaxInclusive", SqlDbType.Bit).Value = this.IsRateTaxInclusive;
                SqlCmd.Parameters.Add("@Tax1", SqlDbType.Money).Value = this.Tax1;
                SqlCmd.Parameters.Add("@Tax2", SqlDbType.Money).Value = this.Tax2;
                SqlCmd.Parameters.Add("@Tax3", SqlDbType.Money).Value = this.Tax3;
                SqlCmd.Parameters.Add("@Tax4", SqlDbType.Money).Value = this.Tax4;
                SqlCmd.Parameters.Add("@Tax5", SqlDbType.Money).Value = this.Tax5;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                //this.ItemRateTranId = Convert.ToInt32(SqlCmd.Parameters["@ItemRateTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateItemRateTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswItemRateTran_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemRateTranId", SqlDbType.Int).Value = this.ItemRateTranId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@MRP", SqlDbType.Money).Value = this.MRP;
                SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = this.Rate;
                SqlCmd.Parameters.Add("@PurchaseRate", SqlDbType.Money).Value = this.PurchaseRate;
                SqlCmd.Parameters.Add("@IsRateTaxInclusive", SqlDbType.Bit).Value = this.IsRateTaxInclusive;
                SqlCmd.Parameters.Add("@Tax1", SqlDbType.Money).Value = this.Tax1;
                SqlCmd.Parameters.Add("@Tax2", SqlDbType.Money).Value = this.Tax2;
                SqlCmd.Parameters.Add("@Tax3", SqlDbType.Money).Value = this.Tax3;
                SqlCmd.Parameters.Add("@Tax4", SqlDbType.Money).Value = this.Tax4;
                SqlCmd.Parameters.Add("@Tax5", SqlDbType.Money).Value = this.Tax5;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region DeleteAll

        public poswRecordStatus DeleteAllItemRateTran(string itemRateTranIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemRateTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemRateTranIds", SqlDbType.VarChar).Value = itemRateTranIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectItemRateTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemRateTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswItemRateTranDAL> SelectAllItemRateTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemRateTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemRateTranDAL> lstItemRateTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemRateTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion
    }
}

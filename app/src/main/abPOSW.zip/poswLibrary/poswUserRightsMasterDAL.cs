using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for crmUserRightsMaster
	/// </summary>
	public class poswUserRightsMasterDAL
	{
		#region Properties
		public short UserRightsMasterId { get; set; }
		public string UserRight { get; set; }
		public short linktoUserRightsGroupMasterId { get; set; }
		#endregion

		#region Class Methods
		private List<poswUserRightsMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswUserRightsMasterDAL> lstUserRightsMaster = new List<poswUserRightsMasterDAL>();
			poswUserRightsMasterDAL objUserRightsMaster = null;
			while (sqlRdr.Read())
			{
				objUserRightsMaster = new poswUserRightsMasterDAL();
				objUserRightsMaster.UserRightsMasterId = Convert.ToInt16(sqlRdr["UserRightsMasterId"]);
				objUserRightsMaster.UserRight = Convert.ToString(sqlRdr["UserRight"]);
				objUserRightsMaster.linktoUserRightsGroupMasterId = Convert.ToInt16(sqlRdr["linktoUserRightsGroupMasterId"]);				
				lstUserRightsMaster.Add(objUserRightsMaster);
			}
			return lstUserRightsMaster;
		}
		#endregion

		#region SelectAll
		public List<poswUserRightsMasterDAL> SelectAllUserRightsMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswUserRightsMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoUserRightsGroupMasterId", SqlDbType.VarChar).Value = this.linktoUserRightsGroupMasterId;                

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswUserRightsMasterDAL> lstUserRightsMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstUserRightsMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

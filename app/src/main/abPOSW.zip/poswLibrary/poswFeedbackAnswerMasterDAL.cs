using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswFeedbackAnswerMaster
    /// </summary>
    /// 

    [Serializable]
    public class poswFeedbackAnswerMasterDAL
    {
        #region Properties
        public int FeedbackAnswerMasterId { get; set; }
        public int linktoFeedbackQuestionMasterId { get; set; }
        public string Answer { get; set; }
        public bool IsDeleted { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.FeedbackAnswerMasterId = Convert.ToInt32(sqlRdr["FeedbackAnswerMasterId"]);
                this.linktoFeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackQuestionMasterId"]);
                this.Answer = Convert.ToString(sqlRdr["Answer"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                return true;
            }
            return false;
        }

        private List<poswFeedbackAnswerMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswFeedbackAnswerMasterDAL> lstFeedbackAnswerMaster = new List<poswFeedbackAnswerMasterDAL>();
            poswFeedbackAnswerMasterDAL objFeedbackAnswerMaster = null;
            while (sqlRdr.Read())
            {
                objFeedbackAnswerMaster = new poswFeedbackAnswerMasterDAL();
                objFeedbackAnswerMaster.FeedbackAnswerMasterId = Convert.ToInt32(sqlRdr["FeedbackAnswerMasterId"]);
                objFeedbackAnswerMaster.linktoFeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackQuestionMasterId"]);
                objFeedbackAnswerMaster.Answer = Convert.ToString(sqlRdr["Answer"]);
                objFeedbackAnswerMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                lstFeedbackAnswerMaster.Add(objFeedbackAnswerMaster);
            }
            return lstFeedbackAnswerMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertFeedbackAnswerMaster(SqlTransaction SqlTran, SqlConnection SqlCon)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswFeedbackAnswerMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackAnswerMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
                SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = this.Answer;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.FeedbackAnswerMasterId = Convert.ToInt32(SqlCmd.Parameters["@FeedbackAnswerMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateFeedbackAnswerMaster(SqlTransaction SqlTran, SqlConnection SqlCon)
        {
            SqlCommand SqlCmd = null;
            try
            {

                SqlCmd = new SqlCommand("poswFeedbackAnswerMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackAnswerMasterId", SqlDbType.Int).Value = this.FeedbackAnswerMasterId;
                SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
                SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = this.Answer;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);

            }
        }
        #endregion

        #region SelectAll
        public List<poswFeedbackAnswerMasterDAL> SelectAllFeedbackAnswerMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackAnswerMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;


                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswFeedbackAnswerMasterDAL> lstFeedbackAnswerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstFeedbackAnswerMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        
        public List<poswFeedbackAnswerMasterDAL> SelectAllFeedbackAnswerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackAnswerMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoFeedbackQuestionMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
                }
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswFeedbackAnswerMasterDAL> lstFeedbackAnswerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstFeedbackAnswerMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Commented
        //#region Delete
        //public poswRecordStatus DeleteFeedbackAnswerMaster()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackAnswerMaster_Delete", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackAnswerMasterId", SqlDbType.Int).Value = this.FeedbackAnswerMasterId;
        //        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        //        SqlCon.Open();
        //        SqlCmd.ExecuteNonQuery();
        //        SqlCon.Close();

        //        poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
        //        return rs;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return poswRecordStatus.Error;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        //#endregion
        //#region Select
        //public bool SelectFeedbackAnswerMaster()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    SqlDataReader SqlRdr = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswFeedbackAnswerMaster_Select", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@FeedbackAnswerMasterId", SqlDbType.Int).Value = this.FeedbackAnswerMasterId;

        //        SqlCon.Open();
        //        SqlRdr = SqlCmd.ExecuteReader();
        //        bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
        //        SqlRdr.Close();
        //        SqlCon.Close();

        //        return IsSelected;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return false;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        #endregion
    }
}
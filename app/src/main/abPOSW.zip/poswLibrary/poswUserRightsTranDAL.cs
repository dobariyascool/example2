﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace poswLibrary
{
    public class poswUserRightsTranDAL
    {
        #region Properties
        public int UserRightsTranId { get; set; }
        public short linktoUserRightsMasterId { get; set; }
        public short linktoRoleMasterId { get; set; }
        #endregion

        #region Class Methods
        private List<poswUserRightsTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswUserRightsTranDAL> lstUserRightsTran = new List<poswUserRightsTranDAL>();
            poswUserRightsTranDAL objUserRightsTran = null;
            while (sqlRdr.Read())
            {
                objUserRightsTran = new poswUserRightsTranDAL();
                objUserRightsTran.UserRightsTranId = Convert.ToInt32(sqlRdr["UserRightsTranId"]);
                objUserRightsTran.linktoUserRightsMasterId = Convert.ToInt16(sqlRdr["linktoUserRightsMasterId"]);
                objUserRightsTran.linktoRoleMasterId = Convert.ToInt16(sqlRdr["linktoRoleMasterId"]);
                lstUserRightsTran.Add(objUserRightsTran);
            }
            return lstUserRightsTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertUserRightsTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserRightsTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserRightsTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoUserRightsMasterId", SqlDbType.SmallInt).Value = this.linktoUserRightsMasterId;
                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.UserRightsTranId = Convert.ToInt32(SqlCmd.Parameters["@UserRightsTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public poswRecordStatus DeleteAllUserRightsTranByRoleMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserRightsTran_DeleteAllByRoleMasterId", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswUserRightsTranDAL> SelectAllUserRightsTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserRightsTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswUserRightsTranDAL> lstUserRightsTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserRightsTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

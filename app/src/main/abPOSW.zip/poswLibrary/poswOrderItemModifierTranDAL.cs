using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswOrderItemModifierTran
    /// </summary>
    public class poswOrderItemModifierTranDAL
    {
        #region Properties
        public long OrderItemModifierTranId { get; set; }
        public long linktoOrderItemTranId { get; set; }
        public int linktoItemMasterModifierId { get; set; }
        public double Rate { get; set; }

        /// Extra
        public long OrderItem { get; set; }
        public string ItemMasterModifierId { get; set; }
        #endregion

        #region Class Methods
        private List<poswOrderItemModifierTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswOrderItemModifierTranDAL> lstOrderItemModifierTran = new List<poswOrderItemModifierTranDAL>();
            poswOrderItemModifierTranDAL objOrderItemModifierTran = null;
            while (sqlRdr.Read())
            {
                objOrderItemModifierTran = new poswOrderItemModifierTranDAL();
                objOrderItemModifierTran.OrderItemModifierTranId = Convert.ToInt64(sqlRdr["OrderItemModifierTranId"]);
                objOrderItemModifierTran.linktoOrderItemTranId = Convert.ToInt64(sqlRdr["linktoOrderItemTranId"]);
                objOrderItemModifierTran.linktoItemMasterModifierId = Convert.ToInt32(sqlRdr["linktoItemMasterModifierId"]);
                objOrderItemModifierTran.Rate = Convert.ToDouble(sqlRdr["Rate"]);

                /// Extra
                objOrderItemModifierTran.OrderItem = Convert.ToInt64(sqlRdr["OrderItem"]);
                objOrderItemModifierTran.ItemMasterModifierId = Convert.ToString(sqlRdr["ItemMasterModifierId"]);
                lstOrderItemModifierTran.Add(objOrderItemModifierTran);
            }
            return lstOrderItemModifierTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertOrderItemModifierTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswOrderItemModifierTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderItemModifierTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOrderItemTranId", SqlDbType.BigInt).Value = this.linktoOrderItemTranId;
                SqlCmd.Parameters.Add("@linktoItemMasterModifierId", SqlDbType.Int).Value = this.linktoItemMasterModifierId;
                SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = this.Rate;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OrderItemModifierTranId = Convert.ToInt64(SqlCmd.Parameters["@OrderItemModifierTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<poswOrderItemModifierTranDAL> SelectAllOrderItemModifierTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderItemModifierTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoOrderItemTranId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderItemTranId", SqlDbType.BigInt).Value = this.linktoOrderItemTranId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderItemModifierTranDAL> lstOrderItemModifierTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderItemModifierTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

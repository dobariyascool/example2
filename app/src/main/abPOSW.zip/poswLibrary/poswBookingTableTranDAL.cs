using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBookingTableTran
    /// </summary>
    public class poswBookingTableTranDAL
    {
        #region Properties
        public int BookingTableTranId { get; set; }
        public int? linktoBookingMasterId { get; set; }
        public short linktoTableMasterId { get; set; }

        //EXTRA
        public bool IsSelected { get; set; }
        public int SectionMasterId { get; set; }
        public string SectionName { get; set; }
        public int TableMasterId { get; set; }
        public string TableName { get; set; }
        public double HourlyBookingRate { get; set; }
        public double DailyBookingRate { get; set; }
        public string TableMasterIds { get; set; }
        #endregion

        #region Class Methods
        private List<poswBookingTableTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswBookingTableTranDAL> lstBookingTableTran = new List<poswBookingTableTranDAL>();
            poswBookingTableTranDAL objBookingTableTran = null;
            while (sqlRdr.Read())
            {
                objBookingTableTran = new poswBookingTableTranDAL();
               
                if (sqlRdr["linktoBookingMasterId"] != DBNull.Value)
                {
                    objBookingTableTran.linktoBookingMasterId = Convert.ToInt32(sqlRdr["linktoBookingMasterId"]);
                    objBookingTableTran.IsSelected = true;
                }
                if (sqlRdr["linktoTableMasterId"] != DBNull.Value)
                {
                    objBookingTableTran.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
                }

                //Extra
                
                objBookingTableTran.TableMasterId = Convert.ToInt32(sqlRdr["TableMasterId"]);
                objBookingTableTran.TableName = Convert.ToString(sqlRdr["TableName"]); 
                objBookingTableTran.HourlyBookingRate = Convert.ToDouble(sqlRdr["HourlyBookingRate"]); 
                objBookingTableTran.DailyBookingRate = Convert.ToDouble(sqlRdr["DailyBookingRate"]); 

                lstBookingTableTran.Add(objBookingTableTran);
            }
            return lstBookingTableTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertAllBookingTableTran(string linktoTableMasterIds, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswBookingTableTran_InsertAll", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = linktoTableMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public poswRecordStatus InsertAllBookingTableTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingTableTran_InsertAll",SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.TableMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswBookingTableTranDAL> SelectAllBookingTableTran(short linktoBusinessMasterId,SqlConnection sqlCon = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                if (sqlCon == null)
                {
                    SqlCon = poswObjectFactoryDAL.CreateConnection();
                    SqlCmd = new SqlCommand("poswBookingTableTran_SelectAll", SqlCon);
                }
                else
                {
                    SqlCmd = new SqlCommand("poswBookingTableTran_SelectAll", sqlCon);
                }
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoBookingMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                if (sqlCon == null)
                {
                    SqlCon.Open();
                }
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBookingTableTranDAL> lstBookingTableTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                if (sqlCon == null)
                {
                    SqlCon.Close();
                }

                return lstBookingTableTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                if (sqlCon == null)
                {
                    poswObjectFactoryDAL.DisposeConnection(SqlCon);
                }
            }
        }
        #endregion
    }
}

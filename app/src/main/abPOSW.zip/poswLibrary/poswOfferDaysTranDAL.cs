using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswOfferDaysTran
	/// </summary>
	public class poswOfferDaysTranDAL
	{
		#region Properties
		public int OfferDaysTranId { get; set; }
		public int linktoOfferMasterId { get; set; }
		public short Day { get; set; }
		public TimeSpan FromTime { get; set; }
		public TimeSpan ToTime { get; set; }
		public bool IsEnabled { get; set; }

		/// Extra
		public string Offer { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.OfferDaysTranId = Convert.ToInt32(sqlRdr["OfferDaysTranId"]);
				this.linktoOfferMasterId = Convert.ToInt32(sqlRdr["linktoOfferMasterId"]);
				this.Day = Convert.ToInt16(sqlRdr["Day"]);
				this.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
				this.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

				/// Extra
				this.Offer = Convert.ToString(sqlRdr["Offer"]);
				return true;
			}
			return false;
		}

		private List<poswOfferDaysTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswOfferDaysTranDAL> lstOfferDaysTran = new List<poswOfferDaysTranDAL>();
			poswOfferDaysTranDAL objOfferDaysTran = null;
			while (sqlRdr.Read())
			{
				objOfferDaysTran = new poswOfferDaysTranDAL();
				objOfferDaysTran.OfferDaysTranId = Convert.ToInt32(sqlRdr["OfferDaysTranId"]);
				objOfferDaysTran.linktoOfferMasterId = Convert.ToInt32(sqlRdr["linktoOfferMasterId"]);
				objOfferDaysTran.Day = Convert.ToInt16(sqlRdr["Day"]);
				objOfferDaysTran.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
				objOfferDaysTran.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
				objOfferDaysTran.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

				/// Extra
				//objOfferDaysTran.Offer = Convert.ToString(sqlRdr["Offer"]);
				lstOfferDaysTran.Add(objOfferDaysTran);
			}
			return lstOfferDaysTran;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertOfferDaysTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferDaysTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferDaysTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@Day", SqlDbType.SmallInt).Value = this.Day;
				SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
				SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.OfferDaysTranId = Convert.ToInt32(SqlCmd.Parameters["@OfferDaysTranId"].Value);
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public poswRecordStatus InsertOfferDaysTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswOfferDaysTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferDaysTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@Day", SqlDbType.SmallInt).Value = this.Day;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OfferDaysTranId = Convert.ToInt32(SqlCmd.Parameters["@OfferDaysTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
		#endregion

		#region Update
        public poswRecordStatus UpdateOfferDaysTran(SqlConnection SqlCon, SqlTransaction sqlTran)
		{
			
			SqlCommand SqlCmd = null;
			try
			{
				//SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferDaysTran_Update", SqlCon,sqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferDaysTranId", SqlDbType.Int).Value = this.OfferDaysTranId;
				SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@Day", SqlDbType.SmallInt).Value = this.Day;
				SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
				SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
			}
		}
		#endregion

		#region Delete
        public poswRecordStatus DeleteOfferDaysTran(SqlConnection SqlCon, SqlTransaction SqlTran)
		{
			
			SqlCommand SqlCmd = null;
			try
			{
				
				SqlCmd = new SqlCommand("poswOfferDaysTran_Delete", SqlCon, SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.ExecuteNonQuery();
				
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
			}
		}
		#endregion

		#region DeleteAll

		public poswRecordStatus DeleteAllOfferDaysTran(string offerDaysTranIds)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferDaysTran_DeleteAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferDaysTranIds", SqlDbType.VarChar).Value = offerDaysTranIds;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectOfferDaysTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferDaysTran_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferDaysTranId", SqlDbType.Int).Value = this.OfferDaysTranId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<poswOfferDaysTranDAL> SelectAllOfferDaysTranPageWise(short startRowIndex, short pageSize, out short totalRecords)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferDaysTranPageWise_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				if (this.linktoOfferMasterId > 0)
				{
					SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				}
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;


				SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
				SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
				SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswOfferDaysTranDAL> lstOfferDaysTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
				return lstOfferDaysTranDAL;
			}
			catch (Exception ex)
			{
				totalRecords = 0;
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public List<poswOfferDaysTranDAL> SelectAllOfferDaysTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOfferDaysTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                //SqlCmd.Parameters.Add("@OfferDaysTranId", SqlDbType.Int).Value = this.OfferDaysTranId;
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOfferDaysTranDAL> lstOfferDaysTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOfferDaysTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
		#endregion
	}
}

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBannerMaster
    /// </summary>
    public class poswBannerMasterDAL
    {
        #region Properties
        public int BannerMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string BannerTitle { get; set; }
        public string BannerDescription { get; set; }
        public string ImageName { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public short? Type { get; set; }
        public int? ID { get; set; }
        public short? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string Business { get; set; }
        public string xsImageName { get; set; }
        public string smImageName { get; set; }
        public string mdImageName { get; set; }
        public string lgImageName { get; set; }
        public string xlImageName { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Banner/";
            if (sqlRdr.Read())
            {
                this.BannerMasterId = Convert.ToInt32(sqlRdr["BannerMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.BannerTitle = Convert.ToString(sqlRdr["BannerTitle"]);
                this.BannerDescription = Convert.ToString(sqlRdr["BannerDescription"]);
                this.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                if (sqlRdr["FromDate"] != DBNull.Value)
                {
                    this.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                }
                if (sqlRdr["ToDate"] != DBNull.Value)
                {
                    this.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                }
                if (sqlRdr["Type"] != DBNull.Value)
                {
                    this.Type = Convert.ToInt16(sqlRdr["Type"]);
                }
                if (sqlRdr["ID"] != DBNull.Value)
                {
                    this.ID = Convert.ToInt32(sqlRdr["ID"]);
                }
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    this.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Business = Convert.ToString(sqlRdr["Business"]);
                this.xsImageName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                this.smImageName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                this.mdImageName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                this.lgImageName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                this.xlImageName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                return true;
            }
            return false;
        }

        private List<poswBannerMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Banner/";
            List<poswBannerMasterDAL> lstBannerMaster = new List<poswBannerMasterDAL>();
            poswBannerMasterDAL objBannerMaster = null;
            while (sqlRdr.Read())
            {
                objBannerMaster = new poswBannerMasterDAL();
                objBannerMaster.BannerMasterId = Convert.ToInt32(sqlRdr["BannerMasterId"]);
                objBannerMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objBannerMaster.BannerTitle = Convert.ToString(sqlRdr["BannerTitle"]);
                objBannerMaster.BannerDescription = Convert.ToString(sqlRdr["BannerDescription"]);
                objBannerMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                if (sqlRdr["FromDate"] != DBNull.Value)
                {
                    objBannerMaster.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                }
                if (sqlRdr["ToDate"] != DBNull.Value)
                {
                    objBannerMaster.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                }
                if (sqlRdr["Type"] != DBNull.Value)
                {
                    objBannerMaster.Type = Convert.ToInt16(sqlRdr["Type"]);
                }
                if (sqlRdr["ID"] != DBNull.Value)
                {
                    objBannerMaster.ID = Convert.ToInt32(sqlRdr["ID"]);
                }
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    objBannerMaster.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                }
                objBannerMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objBannerMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objBannerMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objBannerMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objBannerMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objBannerMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objBannerMaster.Business = Convert.ToString(sqlRdr["Business"]);
                objBannerMaster.xsImageName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                objBannerMaster.smImageName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                objBannerMaster.mdImageName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                objBannerMaster.lgImageName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                objBannerMaster.xlImageName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                lstBannerMaster.Add(objBannerMaster);
            }
            return lstBannerMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertBannerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBannerMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BannerMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@BannerTitle", SqlDbType.VarChar).Value = this.BannerTitle;
                SqlCmd.Parameters.Add("@BannerDescription", SqlDbType.VarChar).Value = this.BannerDescription;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = this.ToDate;
                SqlCmd.Parameters.Add("@Type", SqlDbType.SmallInt).Value = this.Type;
                SqlCmd.Parameters.Add("@ID", SqlDbType.Int).Value = this.ID;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BannerMasterId = Convert.ToInt32(SqlCmd.Parameters["@BannerMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateBannerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBannerMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BannerMasterId", SqlDbType.Int).Value = this.BannerMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@BannerTitle", SqlDbType.VarChar).Value = this.BannerTitle;
                SqlCmd.Parameters.Add("@BannerDescription", SqlDbType.VarChar).Value = this.BannerDescription;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = this.ToDate;
                SqlCmd.Parameters.Add("@Type", SqlDbType.SmallInt).Value = this.Type;
                SqlCmd.Parameters.Add("@ID", SqlDbType.Int).Value = this.ID;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete

        public poswRecordStatus DeleteBanneeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBannerMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BannerMasterId", SqlDbType.Int).Value = this.BannerMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region Select
        public bool SelectBannerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBannerMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BannerMasterId", SqlDbType.Int).Value = this.BannerMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswBannerMasterDAL> SelectAllBannerMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBannerMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBannerMasterDAL> lstBannerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstBannerMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswBannerMasterDAL> SelectAllBannerMasterDateWise()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBannerMasterDateWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBannerMasterDAL> lstBannerMasterDAL = new List<poswBannerMasterDAL>();

                string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Banner/";
                poswBannerMasterDAL objBannerMaster = null;
                while (SqlRdr.Read())
                {
                    objBannerMaster = new poswBannerMasterDAL();
                    objBannerMaster.BannerMasterId = Convert.ToInt32(SqlRdr["BannerMasterId"]);
                    objBannerMaster.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    objBannerMaster.BannerTitle = Convert.ToString(SqlRdr["BannerTitle"]);
                    objBannerMaster.BannerDescription = Convert.ToString(SqlRdr["BannerDescription"]);
                    objBannerMaster.ImageName = Convert.ToString(SqlRdr["ImageName"]);
                    if (SqlRdr["FromDate"] != DBNull.Value)
                    {
                        objBannerMaster.FromDate = Convert.ToDateTime(SqlRdr["FromDate"]);
                    }
                    if (SqlRdr["ToDate"] != DBNull.Value)
                    {
                        objBannerMaster.ToDate = Convert.ToDateTime(SqlRdr["ToDate"]);
                    }
                    if (SqlRdr["Type"] != DBNull.Value)
                    {
                        objBannerMaster.Type = Convert.ToInt16(SqlRdr["Type"]);
                    }
                    if (SqlRdr["ID"] != DBNull.Value)
                    {
                        objBannerMaster.ID = Convert.ToInt32(SqlRdr["ID"]);
                    }
                    if (SqlRdr["SortOrder"] != DBNull.Value)
                    {
                        objBannerMaster.SortOrder = Convert.ToInt16(SqlRdr["SortOrder"]);
                    }

                    /// Extra

                    objBannerMaster.xsImageName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                    objBannerMaster.smImageName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                    objBannerMaster.mdImageName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                    objBannerMaster.lgImageName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                    objBannerMaster.xlImageName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);
                    lstBannerMasterDAL.Add(objBannerMaster);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstBannerMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

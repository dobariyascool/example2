﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace poswLibrary
{
    public class poswUser
    {
        #region Properties
        public short UserMasterId { get; set; }
        public string Username { get; set; }
        public short linktoRoleMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string Phone { get; set; }
        public int CustomerMasterId { get; set; }
        #endregion

        public poswUser(short CustomerMasterId, string userName, short roleMasterId, short businessMasterId, short linktoBusinessTypeMasterId)
        {
            this.UserMasterId = CustomerMasterId;
            this.Username = userName;
            this.linktoRoleMasterId = roleMasterId;
            this.linktoBusinessMasterId = businessMasterId;
            this.linktoBusinessTypeMasterId = linktoBusinessTypeMasterId;
        }

        public poswUser(int CustomerMasterId, string Email, short businessMasterId, short linktoBusinessTypeMasterId, string FirstName, string Phone)
        {
            this.CustomerMasterId = CustomerMasterId;
            this.Email = Email;
            this.linktoBusinessMasterId = businessMasterId;
            this.linktoBusinessTypeMasterId = linktoBusinessTypeMasterId;
            this.FirstName = FirstName;
            this.Phone = Phone;
        }
    }
}

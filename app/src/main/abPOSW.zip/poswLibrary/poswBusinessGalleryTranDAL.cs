using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswBusinessGalleryTran
	/// </summary>
	public class poswBusinessGalleryTranDAL
	{
		#region Properties
		public int BusinessGalleryTranId { get; set; }
		public string ImageTitle { get; set; }
		public string ImageName { get; set; }
		public short linktoBusinessMasterId { get; set; }
		public short? SortOrder { get; set; }

		/// Extra
		public string Business { get; set; }
        public string ImagePhysicalName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "business_gallery/";
			if (sqlRdr.Read())
			{
				this.BusinessGalleryTranId = Convert.ToInt32(sqlRdr["BusinessGalleryTranId"]);
				this.ImageTitle = Convert.ToString(sqlRdr["ImageTitle"]);

                this.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                }
                else
                {
                    this.ImagePhysicalName = "img/NoImage.png";

                    this.xs_ImagePhysicalName = "img/NoImage.png";
                    this.sm_ImagePhysicalName = "img/NoImage.png";
                    this.md_ImagePhysicalName = "img/NoImage.png";
                    this.lg_ImagePhysicalName = "img/NoImage.png";
                    this.xl_ImagePhysicalName = "img/NoImage.png";
                }
				this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				if (sqlRdr["SortOrder"] != DBNull.Value)
				{
					this.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
				}

				/// Extra
				this.Business = Convert.ToString(sqlRdr["Business"]);
				return true;
			}
			return false;
		}

		private List<poswBusinessGalleryTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswBusinessGalleryTranDAL> lstBusinessGalleryTran = new List<poswBusinessGalleryTranDAL>();
			poswBusinessGalleryTranDAL objBusinessGalleryTran = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "business_gallery/";
			while (sqlRdr.Read())
			{
				objBusinessGalleryTran = new poswBusinessGalleryTranDAL();
				objBusinessGalleryTran.BusinessGalleryTranId = Convert.ToInt32(sqlRdr["BusinessGalleryTranId"]);
				objBusinessGalleryTran.ImageTitle = Convert.ToString(sqlRdr["ImageTitle"]);
				objBusinessGalleryTran.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    objBusinessGalleryTran.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);

                    objBusinessGalleryTran.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessGalleryTran.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessGalleryTran.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessGalleryTran.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessGalleryTran.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                }
                else
                {
                    objBusinessGalleryTran.ImagePhysicalName = "img/NoImage.png";

                    objBusinessGalleryTran.xs_ImagePhysicalName = "img/NoImage.png";
                    objBusinessGalleryTran.sm_ImagePhysicalName = "img/NoImage.png";
                    objBusinessGalleryTran.md_ImagePhysicalName = "img/NoImage.png";
                    objBusinessGalleryTran.lg_ImagePhysicalName = "img/NoImage.png";
                    objBusinessGalleryTran.xl_ImagePhysicalName = "img/NoImage.png";

                }

				objBusinessGalleryTran.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				if (sqlRdr["SortOrder"] != DBNull.Value)
				{
					objBusinessGalleryTran.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
				}

				/// Extra
				objBusinessGalleryTran.Business = Convert.ToString(sqlRdr["Business"]);

				lstBusinessGalleryTran.Add(objBusinessGalleryTran);
			}
			return lstBusinessGalleryTran;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertBusinessGalleryTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessGalleryTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@BusinessGalleryTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@ImageTitle", SqlDbType.VarChar).Value = this.ImageTitle;
				SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.BusinessGalleryTranId = Convert.ToInt32(SqlCmd.Parameters["@BusinessGalleryTranId"].Value);
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public poswRecordStatus UpdateBusinessGalleryTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessGalleryTran_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@BusinessGalleryTranId", SqlDbType.Int).Value = this.BusinessGalleryTranId;
				SqlCmd.Parameters.Add("@ImageTitle", SqlDbType.VarChar).Value = this.ImageTitle;
				SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public poswRecordStatus DeleteBusinessGalleryTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessGalleryTran_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@BusinessGalleryTranId", SqlDbType.Int).Value = this.BusinessGalleryTranId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

        #region Select
        public bool SelectBusinessGalleryTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessGalleryTran_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@BusinessGalleryTranId", SqlDbType.Int).Value = this.BusinessGalleryTranId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
        public List<poswBusinessGalleryTranDAL> SelectAllBusinessGalleryTranPageWise(short startRowIndex, short pageSize, out short totalRecords, bool? IsPreRecordShow = null)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessGalleryTranPageWise_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ImageTitle", SqlDbType.VarChar).Value = this.ImageTitle;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

				SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
				SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
				SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswBusinessGalleryTranDAL> lstBusinessGalleryTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
				return lstBusinessGalleryTranDAL;
			}
			catch (Exception ex)
			{
				totalRecords = 0;
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public List<poswBusinessGalleryTranDAL> SelectAllBusinessGalleryTranImageTitle()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswBusinessGalleryTranImageTitle_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();


                List<poswBusinessGalleryTranDAL> lstBusinessGalleryTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
								
				SqlRdr.Close();
				SqlCon.Close();

				return lstBusinessGalleryTranDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

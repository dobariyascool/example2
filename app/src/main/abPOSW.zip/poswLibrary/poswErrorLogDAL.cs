﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using poswLibrary;
using System.Data;

namespace poswLibrary
{
    public class poswErrorLogDAL
    {
        #region Properties
        public short ErrorLogId { get; set; }
        public DateTime ErrorDateTime { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorStackTrace { get; set; }
        #endregion

        #region Class Methods
        private List<poswErrorLogDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswErrorLogDAL> lstErrorLog = new List<poswErrorLogDAL>();
            poswErrorLogDAL objErrorLog = null;
            while (sqlRdr.Read())
            {
                objErrorLog = new poswErrorLogDAL();
                objErrorLog.ErrorLogId = Convert.ToInt16(sqlRdr["ErrorLogId"]);
                objErrorLog.ErrorDateTime = Convert.ToDateTime(sqlRdr["ErrorDateTime"]);
                objErrorLog.ErrorMessage = Convert.ToString(sqlRdr["ErrorMessage"]);
                objErrorLog.ErrorStackTrace = Convert.ToString(sqlRdr["ErrorStackTrace"]);
                lstErrorLog.Add(objErrorLog);
            }
            return lstErrorLog;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertErrorLog()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswErrorLog_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ErrorLogId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ErrorDateTime", SqlDbType.DateTime).Value = this.ErrorDateTime;
                SqlCmd.Parameters.Add("@ErrorMessage", SqlDbType.VarChar).Value = this.ErrorMessage;
                SqlCmd.Parameters.Add("@ErrorStackTrace", SqlDbType.VarChar).Value = this.ErrorStackTrace;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.ErrorLogId = Convert.ToInt16(SqlCmd.Parameters["@ErrorLogId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch
            {
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteErrorLog()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswErrorLog_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ErrorLogId", SqlDbType.SmallInt).Value = this.ErrorLogId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static poswRecordStatus DeleteAllErrorLog(string ids)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswErrorLog_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ids", SqlDbType.VarChar).Value = ids;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }


        #endregion

        #region SelectAll
        public List<poswErrorLogDAL> SelectAllErrorLogPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswErrorLogPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswErrorLogDAL> lstErrorLogDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstErrorLogDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

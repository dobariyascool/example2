using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswOfferCodesTran
	/// </summary>
	public class poswOfferCodesTranDAL
	{
		#region Properties
		public long OfferCodesTranId { get; set; }
		public int linktoOfferMasterId { get; set; }
		public string OfferCode { get; set; }
        public int? linktoCustomerMasterId { get; set; }
		public int? linktoItemMasterId { get; set; }
		public DateTime CreateDateTime { get; set; }
		public short linktoUserMasterIdCreatedBy { get; set; }
		public DateTime? RedeemDateTime { get; set; }
		public int? linktoUserMasterIdRedeemedBy { get; set; }
		public short? linktoSourceMasterId { get; set; }

		/// Extra
		public string Offer { get; set; }
        public string Customer { get; set; }
        public short linktoBusinessMasterId { get; set; }
		public string Item { get; set; }
		public string UserCreatedBy { get; set; }
		public string UserRedeemedBy { get; set; }
		public string Source { get; set; }
        public bool IsOfferCode { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.OfferCodesTranId = Convert.ToInt64(sqlRdr["OfferCodesTranId"]);
				this.linktoOfferMasterId = Convert.ToInt32(sqlRdr["linktoOfferMasterId"]);
				this.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
				{
                    this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
				}
				if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
				{
					this.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				}
				this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
				if (sqlRdr["RedeemDateTime"] != DBNull.Value)
				{
					this.RedeemDateTime = Convert.ToDateTime(sqlRdr["RedeemDateTime"]);
				}
				if (sqlRdr["linktoUserMasterIdRedeemedBy"] != DBNull.Value)
				{
					this.linktoUserMasterIdRedeemedBy = Convert.ToInt32(sqlRdr["linktoUserMasterIdRedeemedBy"]);
				}
				if (sqlRdr["linktoSourceMasterId"] != DBNull.Value)
				{
					this.linktoSourceMasterId = Convert.ToInt16(sqlRdr["linktoSourceMasterId"]);
				}

				/// Extra
				this.Offer = Convert.ToString(sqlRdr["Offer"]);
                this.Customer = Convert.ToString(sqlRdr["CustomerName"]);
				this.Item = Convert.ToString(sqlRdr["Item"]);
				this.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
				this.UserRedeemedBy = Convert.ToString(sqlRdr["UserRedeemedBy"]);
				this.Source = Convert.ToString(sqlRdr["Source"]);
				return true;
			}
			return false;
		}

		private List<poswOfferCodesTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswOfferCodesTranDAL> lstOfferCodesTran = new List<poswOfferCodesTranDAL>();
			poswOfferCodesTranDAL objOfferCodesTran = null;
			while (sqlRdr.Read())
			{
				objOfferCodesTran = new poswOfferCodesTranDAL();
				objOfferCodesTran.OfferCodesTranId = Convert.ToInt64(sqlRdr["OfferCodesTranId"]);
                if (sqlRdr["linktoOfferMasterId"] != DBNull.Value)
                {
                    objOfferCodesTran.linktoOfferMasterId = Convert.ToInt32(sqlRdr["linktoOfferMasterId"]);
                }
				objOfferCodesTran.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
				{
                    objOfferCodesTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
				}
				if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
				{
					objOfferCodesTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				}
				objOfferCodesTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				objOfferCodesTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
				if (sqlRdr["RedeemDateTime"] != DBNull.Value)
				{
					objOfferCodesTran.RedeemDateTime = Convert.ToDateTime(sqlRdr["RedeemDateTime"]);
				}
				if (sqlRdr["linktoUserMasterIdRedeemedBy"] != DBNull.Value)
				{
					objOfferCodesTran.linktoUserMasterIdRedeemedBy = Convert.ToInt32(sqlRdr["linktoUserMasterIdRedeemedBy"]);
				}
				if (sqlRdr["linktoSourceMasterId"] != DBNull.Value)
				{
					objOfferCodesTran.linktoSourceMasterId = Convert.ToInt16(sqlRdr["linktoSourceMasterId"]);
				}

				/// Extra
				objOfferCodesTran.Offer = Convert.ToString(sqlRdr["Offer"]);
                objOfferCodesTran.Customer = Convert.ToString(sqlRdr["CustomerName"]);
				objOfferCodesTran.Item = Convert.ToString(sqlRdr["Item"]);
				objOfferCodesTran.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
				objOfferCodesTran.UserRedeemedBy = Convert.ToString(sqlRdr["UserRedeemedBy"]);
				objOfferCodesTran.Source = Convert.ToString(sqlRdr["Source"]);
				lstOfferCodesTran.Add(objOfferCodesTran);
			}
			return lstOfferCodesTran;
		}
		#endregion

		#region Insert
		public poswRecordStatus InsertOfferCodesTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferCodesTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferCodesTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
				SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
				SqlCmd.Parameters.Add("@RedeemDateTime", SqlDbType.DateTime).Value = this.RedeemDateTime;
				SqlCmd.Parameters.Add("@linktoUserMasterIdRedeemedBy", SqlDbType.Int).Value = this.linktoUserMasterIdRedeemedBy;
				SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.OfferCodesTranId = Convert.ToInt64(SqlCmd.Parameters["@OfferCodesTranId"].Value);
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public poswRecordStatus InsertOfferCodesTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswOfferCodesTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferCodesTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@RedeemDateTime", SqlDbType.DateTime).Value = this.RedeemDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdRedeemedBy", SqlDbType.Int).Value = this.linktoUserMasterIdRedeemedBy;
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OfferCodesTranId = Convert.ToInt64(SqlCmd.Parameters["@OfferCodesTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
		#endregion

		#region Update
		public poswRecordStatus UpdateOfferCodesTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferCodesTran_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferCodesTranId", SqlDbType.BigInt).Value = this.OfferCodesTranId;
				SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
				SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCmd.Parameters.Add("@RedeemDateTime", SqlDbType.DateTime).Value = this.RedeemDateTime;
				SqlCmd.Parameters.Add("@linktoUserMasterIdRedeemedBy", SqlDbType.Int).Value = this.linktoUserMasterIdRedeemedBy;
				SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete

     
        public poswRecordStatus DeleteOfferCodesTran(SqlConnection SqlCon, SqlTransaction SqlTran)
		{
			
			SqlCommand SqlCmd = null;
			try
			{
				
				SqlCmd = new SqlCommand("poswOfferCodesTran_Delete", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.ExecuteNonQuery();
				
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				
			}
		}
		#endregion

		#region DeleteAll

		public poswRecordStatus DeleteAllOfferCodesTran(string offerCodesTranIds)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferCodesTran_DeleteAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferCodesTranIds", SqlDbType.VarChar).Value = offerCodesTranIds;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<poswOfferCodesTranDAL> SelectAllOfferCodesTranPageWise(short startRowIndex, short pageSize, out short totalRecords)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswOfferCodesTranPageWise_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				if (this.linktoOfferMasterId > 0)
				{
					SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				}
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;


				SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
				SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
				SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswOfferCodesTranDAL> lstOfferCodesTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
				return lstOfferCodesTranDAL;
			}
			catch (Exception ex)
			{
				totalRecords = 0;
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public List<poswOfferCodesTranDAL> SelectALLRegisteredUserOfferCodeTran(short CustomerType)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCustomerMasterRegisterUserOfferCodesTran_SelectALL", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoOfferMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = CustomerType;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOfferCodesTranDAL> lstOfferCodesTranDAL = new List<poswOfferCodesTranDAL>();
                poswOfferCodesTranDAL objOfferCodesTranDAL = null;
                while(SqlRdr.Read())
                {
                    objOfferCodesTranDAL = new poswOfferCodesTranDAL();
                    objOfferCodesTranDAL.linktoCustomerMasterId = Convert.ToInt32(SqlRdr["linktoCustomerMasterId"]);
                    objOfferCodesTranDAL.Customer = Convert.ToString(SqlRdr["CustomerName"]);
                    objOfferCodesTranDAL.IsOfferCode = Convert.ToBoolean(SqlRdr["IsOfferCode"]);
                    objOfferCodesTranDAL.OfferCode = Convert.ToString(SqlRdr["OfferCode"]);
                    lstOfferCodesTranDAL.Add(objOfferCodesTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOfferCodesTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
		#endregion
	}
}

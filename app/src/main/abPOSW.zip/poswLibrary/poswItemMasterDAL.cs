using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Text;
using System.Web;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswItemMaster
    /// </summary>
    [Serializable]
    public class poswItemMasterDAL
    {
        #region Properties
        public int ItemMasterId { get; set; }
        public string ShortName { get; set; }
        public string ItemName { get; set; }
        public string ItemCode { get; set; }
        public string BarCode { get; set; }
        public string ShortDescription { get; set; }
        public short? linktoUnitMasterId { get; set; }
        public short linktoCategoryMasterId { get; set; }
        public double MRP { get; set; }
        public double Rate { get; set; }
        public bool IsRateTaxInclusive { get; set; }
        public bool? IsFavourite { get; set; }
        public bool IsDineInOnly { get; set; }
        public string ImageName { get; set; }        
        public short ItemPoint { get; set; }
        public short PriceByPoint { get; set; }
        public string SearchWords { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short ItemType { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public string ImagePhysicalName { get; set; }

        /// Extra
        public string Unit { get; set; }
        public string Category { get; set; }
        public string Business { get; set; }
        public string UserCreatedBy { get; set; }
        public string UserUpdatedBy { get; set; }
        public string linktoItemMasterIdModifiers { get; set; }
        public string linktoItemMasterIdCombos { get; set; }
        public string linktoCategoryMasterIds { get; set; }
        public string linktoOptionMasterIds { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public short OfferItemType { get; set; }
        public int OfferItemsTranId { get; set; }
        public bool IsOfferItems { get; set; }
        public int linktoOfferMasterId { get; set; }
        public int linktoItemMasterIdModifier { get; set; }
        public string OptionValue { get; set; }
        public static string OrderCookies = "OrderList";
        public int Quentity { get; set; }
        public int linktoRegisterUserMasterId { get; set; }
        public string Tax { get; set; }
        public string Modifier { get; set; }
        public double TotalAmount { get; set; }
        public string OptionName { get; set; }
        public short linktoOptionMasterId { get; set; }
        public short linktoOptionValueTranId { get; set; }
        public int OrderItemId { get; set; }
        public string Remark { get; set; }
        public bool IsDiscountPercentage { get; set; }
        public double Discount { get; set; }
        public double TaxRate { get; set; }
        //Extra SetClass(css) Property

        public string ItemNameClass { get; set; }
        public string btnDeleteClass { get; set; }
        public string QuantityClass { get; set; }
        public string visibleInvisibleClass { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = "";
            if (sqlRdr.Read())
            {
                this.ItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                this.ItemCode = Convert.ToString(sqlRdr["ItemCode"]);
                this.BarCode = Convert.ToString(sqlRdr["BarCode"]);
                this.ShortDescription = Convert.ToString(sqlRdr["ShortDescription"]);
                if (sqlRdr["linktoUnitMasterId"] != DBNull.Value)
                {
                    this.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                }
                this.linktoCategoryMasterId = Convert.ToInt16(sqlRdr["linktoCategoryMasterId"]);
                //this.MRP = Convert.ToDouble(sqlRdr["MRP"]);
                //this.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                //this.IsRateTaxInclusive = Convert.ToBoolean(sqlRdr["IsRateTaxInclusive"]);
                if (sqlRdr["IsFavourite"] != DBNull.Value)
                {
                    this.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                }
                if (sqlRdr["IsDineInOnly"] != DBNull.Value)
                {
                    this.IsDineInOnly = Convert.ToBoolean(sqlRdr["IsDineInOnly"]);
                }
                //  this.ImageName =ImageRetrievePath +Convert.ToString(sqlRdr["ImageName"]);
                this.ItemType = Convert.ToInt16(sqlRdr["ItemType"]);
                if (this.ItemType == poswItemType.Modifier.GetHashCode())
                {
                    ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "modifier/";
                }
                else if (this.ItemType == poswItemType.Item.GetHashCode() || this.ItemType == poswItemType.Combo_Item.GetHashCode())
                {
                    ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                }
                this.ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);
                this.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                }
                else
                {
                    this.ImagePhysicalName = "img/NoImage.png";

                    this.xs_ImagePhysicalName = "img/NoImage.png";
                    this.sm_ImagePhysicalName = "img/NoImage.png";
                    this.md_ImagePhysicalName = "img/NoImage.png";
                    this.lg_ImagePhysicalName = "img/NoImage.png";
                    this.xl_ImagePhysicalName = "img/NoImage.png";

                }
               
                this.ItemPoint = Convert.ToInt16(sqlRdr["ItemPoint"]);
                this.PriceByPoint = Convert.ToInt16(sqlRdr["PriceByPoint"]);
                this.SearchWords = Convert.ToString(sqlRdr["SearchWords"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    this.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Unit = Convert.ToString(sqlRdr["Unit"]);
                this.Category = Convert.ToString(sqlRdr["Category"]);
                this.Business = Convert.ToString(sqlRdr["Business"]);
                this.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
                this.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
                return true;
            }
            return false;
        }

        private List<poswItemMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = "";
            List<poswItemMasterDAL> lstItemMaster = new List<poswItemMasterDAL>();
            poswItemMasterDAL objItemMaster = null;
            while (sqlRdr.Read())
            {
                objItemMaster = new poswItemMasterDAL();
                objItemMaster.ItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                objItemMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objItemMaster.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                objItemMaster.ItemCode = Convert.ToString(sqlRdr["ItemCode"]);
                objItemMaster.BarCode = Convert.ToString(sqlRdr["BarCode"]);
                objItemMaster.ShortDescription = Convert.ToString(sqlRdr["ShortDescription"]);
                if (sqlRdr["linktoUnitMasterId"] != DBNull.Value)
                {
                    objItemMaster.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                }
                objItemMaster.linktoCategoryMasterId = Convert.ToInt16(sqlRdr["linktoCategoryMasterId"]);
                //objItemMaster.MRP = Convert.ToDouble(sqlRdr["MRP"]);
                //objItemMaster.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                //objItemMaster.IsRateTaxInclusive = Convert.ToBoolean(sqlRdr["IsRateTaxInclusive"]);
                if (sqlRdr["IsFavourite"] != DBNull.Value)
                {
                    objItemMaster.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                }
                if (sqlRdr["IsDineInOnly"] != DBNull.Value)
                {
                    objItemMaster.IsDineInOnly = Convert.ToBoolean(sqlRdr["IsDineInOnly"]);
                }
                //objItemMaster.ImageName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);
                objItemMaster.ItemType = Convert.ToInt16(sqlRdr["ItemType"]);
                if (objItemMaster.ItemType == poswItemType.Modifier.GetHashCode())
                {
                    ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "modifier/";
                }
                else if (objItemMaster.ItemType == poswItemType.Item.GetHashCode() || objItemMaster.ItemType == poswItemType.Combo_Item.GetHashCode())
                {
                    ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                }
                objItemMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    objItemMaster.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);

                    objItemMaster.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    objItemMaster.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    objItemMaster.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    objItemMaster.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    objItemMaster.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                }
                else
                {
                    objItemMaster.ImagePhysicalName = "img/NoImage.png";

                    objItemMaster.xs_ImagePhysicalName = "img/NoImage.png";
                    objItemMaster.sm_ImagePhysicalName = "img/NoImage.png";
                    objItemMaster.md_ImagePhysicalName = "img/NoImage.png";
                    objItemMaster.lg_ImagePhysicalName = "img/NoImage.png";
                    objItemMaster.xl_ImagePhysicalName = "img/NoImage.png";

                }
               
                objItemMaster.ItemPoint = Convert.ToInt16(sqlRdr["ItemPoint"]);
                objItemMaster.PriceByPoint = Convert.ToInt16(sqlRdr["PriceByPoint"]);
                objItemMaster.SearchWords = Convert.ToString(sqlRdr["SearchWords"]);
                objItemMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    objItemMaster.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
                }
                objItemMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objItemMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                objItemMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objItemMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objItemMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objItemMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objItemMaster.Unit = Convert.ToString(sqlRdr["Unit"]);
                objItemMaster.Category = Convert.ToString(sqlRdr["Category"]);
                objItemMaster.Business = Convert.ToString(sqlRdr["Business"]);
                objItemMaster.UserCreatedBy = Convert.ToString(sqlRdr["UserCreatedBy"]);
                objItemMaster.UserUpdatedBy = Convert.ToString(sqlRdr["UserUpdatedBy"]);
                lstItemMaster.Add(objItemMaster);
            }
            return lstItemMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertItemMaster(poswItemRateTranDAL objItemRateTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswItemMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = this.BarCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;              
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.ItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@ItemMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != poswRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                //else
                //{
                poswItemCategoryTranDAL objItemCategoryTranDAL = new poswItemCategoryTranDAL();
                objItemCategoryTranDAL.linktoItemMasterId = this.ItemMasterId;
                rs = objItemCategoryTranDAL.InsertAllItemCategoryTran(this.linktoCategoryMasterIds, SqlCon, sqlTran);
                if (rs != poswRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                else
                {
                    poswItemMasterDAL objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemType = this.ItemType;
                    if (objItemMasterDAL.ItemType == Convert.ToInt16(poswItemType.Item.GetHashCode()))
                    {
                        if (this.linktoItemMasterIdModifiers != string.Empty)
                        {
                            poswItemModifierTranDAL objItemModifierTranDAL = new poswItemModifierTranDAL();
                            objItemModifierTranDAL.linktoItemMasterId = this.ItemMasterId;
                            rs = objItemModifierTranDAL.InsertAllItemModifierTran(this.linktoItemMasterIdModifiers, SqlCon, sqlTran);
                            if (rs != poswRecordStatus.Success)
                            {
                                sqlTran.Rollback();
                                SqlCon.Close();
                                return rs;
                            }
                        }
                    }
                    else if (objItemMasterDAL.ItemType == Convert.ToInt16(poswItemType.Combo_Item.GetHashCode()))
                    {
                        if (this.linktoItemMasterIdCombos != string.Empty)
                        {
                            poswItemComboTranDAL objItemComboTranDAL = new poswItemComboTranDAL();
                            objItemComboTranDAL.linktoItemMasterId = this.ItemMasterId;
                            rs = objItemComboTranDAL.InsertAllItemComboTran(this.linktoItemMasterIdCombos, SqlCon, sqlTran);
                            if (rs != poswRecordStatus.Success)
                            {
                                sqlTran.Rollback();
                                SqlCon.Close();
                                return rs;
                            }
                        }
                    }
                }
                if (linktoOptionMasterIds != string.Empty)
                {
                    poswItemOptionTranDAL objItemOptionTranDAL = new poswItemOptionTranDAL();
                    objItemOptionTranDAL.linktoItemMasterId = this.ItemMasterId;
                    rs = objItemOptionTranDAL.InsertAllItemOptionTran(this.linktoOptionMasterIds, SqlCon, sqlTran);
                    if (rs != poswRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                objItemRateTranDAL.linktoItemMasterId = this.ItemMasterId;
                rs = objItemRateTranDAL.InsertItemRateTran(SqlCon, sqlTran);
                if (rs != poswRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                //}
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }

        public poswRecordStatus InsertItemMasterItemModifier(poswItemRateTranDAL objItemRateTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswItemMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = this.BarCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;                
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;


                SqlCmd.ExecuteNonQuery();

                this.ItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@ItemMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                if (this.ItemMasterId > 0)
                {
                    objItemRateTranDAL.linktoItemMasterId = this.ItemMasterId;
                    rs = objItemRateTranDAL.InsertItemRateTran(SqlCon, SqlTran);
                    if (rs != poswRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region Update
        public poswRecordStatus UpdateItemMaster(poswItemRateTranDAL objItemRateTranDAL)
        {

            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswItemMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = this.BarCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;                
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.ItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@ItemMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != poswRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                //else
                //{
                poswItemCategoryTranDAL objItemCategoryTranDAL = new poswItemCategoryTranDAL();
                objItemCategoryTranDAL.linktoItemMasterId = this.ItemMasterId;
                rs = objItemCategoryTranDAL.InsertAllItemCategoryTran(this.linktoCategoryMasterIds, SqlCon, sqlTran);
                if (rs != poswRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                //else
                //{
                poswItemMasterDAL objItemMasterDAL = new poswItemMasterDAL();
                objItemMasterDAL.ItemType = this.ItemType;
                if (objItemMasterDAL.ItemType == Convert.ToInt16(poswItemType.Item.GetHashCode()))
                {
                    poswItemModifierTranDAL objItemModifierTranDAL = new poswItemModifierTranDAL();
                    objItemModifierTranDAL.linktoItemMasterId = this.ItemMasterId;
                    rs = objItemModifierTranDAL.InsertAllItemModifierTran(this.linktoItemMasterIdModifiers, SqlCon, sqlTran);
                    if (rs != poswRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                else if (objItemMasterDAL.ItemType == Convert.ToInt16(poswItemType.Combo_Item.GetHashCode()))
                {
                    poswItemComboTranDAL objItemComboTranDAL = new poswItemComboTranDAL();
                    objItemComboTranDAL.linktoItemMasterId = this.ItemMasterId;
                    rs = objItemComboTranDAL.InsertAllItemComboTran(this.linktoItemMasterIdCombos, SqlCon, sqlTran);
                    if (rs != poswRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                // }
                poswItemOptionTranDAL objItemOptionTranDAL = new poswItemOptionTranDAL();
                objItemOptionTranDAL.linktoItemMasterId = this.ItemMasterId;
                rs = objItemOptionTranDAL.InsertAllItemOptionTran(this.linktoOptionMasterIds, SqlCon, sqlTran);
                if (rs != poswRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                objItemRateTranDAL.linktoItemMasterId = this.ItemMasterId;
                rs = objItemRateTranDAL.UpdateItemRateTran(SqlCon, sqlTran);
                if (rs != poswRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                //}
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }

        public poswRecordStatus UpdateItemMasterItemModifier(poswItemRateTranDAL objItemRateTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswItemMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = this.BarCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;                
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                objItemRateTranDAL.linktoItemMasterId = this.ItemMasterId;
                rs = objItemRateTranDAL.UpdateItemRateTran(SqlCon, SqlTran);
                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteItemMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public poswRecordStatus DeleteItemMasterItemModifier()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectItemMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswItemMasterDAL> SelectAllItemMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;

                if (this.linktoCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswItemMasterDAL> SelectAllItemMasterItemName(short ItemType, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterItemName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = ItemType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswItemMasterDAL> SelectAllCategoryItem()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAllCategoryItem_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = ItemType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                if (this.linktoCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;

                }
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    if (SqlRdr["ItemMasterId"] != DBNull.Value)
                    {
                        objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                        objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                        objItemMasterDAL.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                        objItemMasterDAL.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);
                        objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                        objItemMasterDAL.IsDineInOnly = Convert.ToBoolean(SqlRdr["IsDineInOnly"]);
                        if (SqlRdr["ImageName"] != DBNull.Value)
                        {
                            objItemMasterDAL.ImageName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);
                            objItemMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                            objItemMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                            objItemMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                            objItemMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                            objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                        }
                        else
                        {
                            objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";

                            objItemMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                            objItemMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                            objItemMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                            objItemMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                            objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";

                        }
                    }

                    objItemMasterDAL.Category = Convert.ToString(SqlRdr["Category"]);
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["CategoryMasterId"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswItemMasterDAL> SelectAllCategoryOfferItem()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswAllCategoryOfferItem_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = poswItemType.Modifier.GetHashCode();
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                if (this.linktoOfferMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();

                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.Category = Convert.ToString(SqlRdr["Category"]);
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["CategoryMasterId"]);
                    objItemMasterDAL.IsOfferItems = false;
                    if (SqlRdr["OfferItemsTranId"] != DBNull.Value)
                    {
                        objItemMasterDAL.OfferItemsTranId = Convert.ToInt32(SqlRdr["OfferItemsTranId"]);
                        objItemMasterDAL.OfferItemType = Convert.ToInt16(SqlRdr["OfferItemType"]);
                        objItemMasterDAL.IsOfferItems = true;
                    }

                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswItemMasterDAL> SelectAllItemMasterNameFromCatertoryTran(short linktoCategoryMasterId, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterItemNameByCategory_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.linktoCategoryMasterId = linktoCategoryMasterId;
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public Dictionary<string, List<poswItemMasterDAL>> SelectAllItemMasterItemDetailsByItemMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterItemDetailsByItemMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = ItemMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                List<poswItemMasterDAL> lstItemMasterModifierDAL = new List<poswItemMasterDAL>();
                List<poswItemMasterDAL> lstItemMasterOptionvalueDAL = new List<poswItemMasterDAL>();
                List<poswItemMasterDAL> lstItemMasterItemSuggetionDAL = new List<poswItemMasterDAL>();
                List<poswItemMasterDAL> lstItemMasterFavItemsDAL = new List<poswItemMasterDAL>();
                List<poswItemMasterDAL> lstComboItems = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;

                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.Rate = Convert.ToDouble(SqlRdr["Rate"]);

                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    objItemMasterDAL.ItemType = Convert.ToInt16(SqlRdr["Itemtype"]);
                    objItemMasterDAL.IsDineInOnly = Convert.ToBoolean(SqlRdr["IsDineInOnly"]);

                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImageName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                    }
                    else
                    {
                        objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";

                        objItemMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";
                    }

                    if (!(',' + Convert.ToString(SqlRdr["Categories"]) + ',').Contains(',' + Convert.ToString(SqlRdr["CategoryName"]) + ','))
                    {
                        objItemMasterDAL.Category = Convert.ToString(SqlRdr["CategoryName"]) + ',' + Convert.ToString(SqlRdr["Categories"]);
                    }
                    else
                    {
                        objItemMasterDAL.Category = Convert.ToString(SqlRdr["Categories"]);
                    }
                    objItemMasterDAL.Category = objItemMasterDAL.Category.Replace(",", ", ");
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.NextResult();

                ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "modifier/";
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();

                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    objItemMasterDAL.linktoItemMasterIdModifier = Convert.ToInt32(SqlRdr["linktoItemMasterIdModifier"]);
                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImageName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                    }
                    else
                    {
                        objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";

                    }
                    lstItemMasterModifierDAL.Add(objItemMasterDAL);
                }

                SqlRdr.NextResult();

                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();

                    objItemMasterDAL.OptionValue = Convert.ToString(SqlRdr["OptionValue"]);
                    objItemMasterDAL.OptionName = Convert.ToString(SqlRdr["OptionName"]);
                    if (SqlRdr["linktoOptionMasterId"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoOptionMasterId = Convert.ToInt16(SqlRdr["linktoOptionMasterId"]);
                    }
                    if (SqlRdr["linktoOptionValueTranId"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoOptionValueTranId = Convert.ToInt16(SqlRdr["linktoOptionValueTranId"]);
                    }
                    lstItemMasterOptionvalueDAL.Add(objItemMasterDAL);
                }

                SqlRdr.NextResult();

                ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();

                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImageName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);
                    }
                    else
                    {
                        objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";
                    }
                    lstItemMasterItemSuggetionDAL.Add(objItemMasterDAL);
                }

                SqlRdr.NextResult();

                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();

                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);

                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImageName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);
                    }
                    else
                    {
                        objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";

                        objItemMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";
                    }

                    lstItemMasterFavItemsDAL.Add(objItemMasterDAL);
                }
                SqlRdr.NextResult();

                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    lstComboItems.Add(objItemMasterDAL);
                }

                Dictionary<string, List<poswItemMasterDAL>> ItemList = new Dictionary<string, List<poswItemMasterDAL>>();

                ItemList.Add("ItemList", lstItemMasterDAL);
                ItemList.Add("ModifierList", lstItemMasterModifierDAL);
                ItemList.Add("ItemOptionList", lstItemMasterOptionvalueDAL);
                ItemList.Add("ItemSuggestionList", lstItemMasterItemSuggetionDAL);
                ItemList.Add("FavItemList", lstItemMasterFavItemsDAL);
                ItemList.Add("ComboItems", lstComboItems);

                SqlRdr.Close();
                SqlCon.Close();

                return ItemList;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswItemMasterDAL> SelectAllItemsForCookies(string ItemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterItemOrder_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = ItemMasterIds;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;
                string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.Rate = Convert.ToDouble(SqlRdr["Rate"]);

                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImageName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);
                    }
                    else
                    {
                        objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";
                    }

                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }

        }

        public List<poswItemMasterDAL> SelectAllItemMasterByCategoryMasterIdPageWise(short startRowIndex, short pageSize, out short totalRecords,string itemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterByCategoryMasterIdPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                if (this.linktoCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                }
                SqlCmd.Parameters.Add("@OptionValueIds", SqlDbType.VarChar).Value = this.OptionValue;
                if (itemMasterIds != "null")
                {
                    SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = itemMasterIds;
                }

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;
                string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.BarCode = Convert.ToString(SqlRdr["BarCode"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    if (SqlRdr["linktoUnitMasterId"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    }
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    if (SqlRdr["MRP"] != DBNull.Value)
                    {
                        objItemMasterDAL.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    }
                    objItemMasterDAL.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    if (SqlRdr["IsFavourite"] != DBNull.Value)
                    {
                        objItemMasterDAL.IsFavourite = Convert.ToBoolean(SqlRdr["IsFavourite"]);
                    }
                    if (SqlRdr["IsDineInOnly"] != DBNull.Value)
                    {
                        objItemMasterDAL.IsDineInOnly = Convert.ToBoolean(SqlRdr["IsDineInOnly"]);
                    }
                    objItemMasterDAL.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);
                    if (objItemMasterDAL.ItemType == poswItemType.Modifier.GetHashCode())
                    {
                        ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "modifier/";
                    }
                    else if (objItemMasterDAL.ItemType == poswItemType.Item.GetHashCode() || objItemMasterDAL.ItemType == poswItemType.Combo_Item.GetHashCode())
                    {
                        ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                    }
                    objItemMasterDAL.ImageName = Convert.ToString(SqlRdr["ImageName"]);
                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImagePhysicalName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);

                        objItemMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                    }
                    else
                    {
                        objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";

                        objItemMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";

                    }                   
                    objItemMasterDAL.ItemPoint = Convert.ToInt16(SqlRdr["ItemPoint"]);
                    objItemMasterDAL.PriceByPoint = Convert.ToInt16(SqlRdr["PriceByPoint"]);
                    objItemMasterDAL.SearchWords = Convert.ToString(SqlRdr["SearchWords"]);
                    objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    if (SqlRdr["SortOrder"] != DBNull.Value)
                    {
                        objItemMasterDAL.SortOrder = Convert.ToInt32(SqlRdr["SortOrder"]);
                    }
                    objItemMasterDAL.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    objItemMasterDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);

                    objItemMasterDAL.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
                    objItemMasterDAL.linktoUserMasterIdCreatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdCreatedBy"]);
                    if (SqlRdr["UpdateDateTime"] != DBNull.Value)
                    {
                        objItemMasterDAL.UpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
                    }
                    if (SqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoUserMasterIdUpdatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdUpdatedBy"]);
                    }

                    /// Extra
                    objItemMasterDAL.Unit = Convert.ToString(SqlRdr["Unit"]);
                    objItemMasterDAL.Category = Convert.ToString(SqlRdr["Category"]);
                    objItemMasterDAL.Business = Convert.ToString(SqlRdr["Business"]);
                    objItemMasterDAL.UserCreatedBy = Convert.ToString(SqlRdr["UserCreatedBy"]);
                    objItemMasterDAL.UserUpdatedBy = Convert.ToString(SqlRdr["UserUpdatedBy"]);
                    objItemMasterDAL.linktoItemMasterIdModifiers = Convert.ToString(SqlRdr["ItemModifierMasterIds"]);
                    objItemMasterDAL.linktoOptionMasterIds = Convert.ToString(SqlRdr["OptionValueTranIds"]);
                    objItemMasterDAL.Tax = Convert.ToString(SqlRdr["Tax"]);
                    objItemMasterDAL.TaxRate = Convert.ToDouble(SqlRdr["TaxRate"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswItemMasterDAL> SelectAllItemMasterByCategoryMasterId(out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterByCategoryMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                if (this.linktoCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                }
                
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;
                string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.BarCode = Convert.ToString(SqlRdr["BarCode"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);      
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    objItemMasterDAL.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);
                    if (objItemMasterDAL.ItemType == poswItemType.Modifier.GetHashCode())
                    {
                        ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "modifier/";
                    }
                    else if (objItemMasterDAL.ItemType == poswItemType.Item.GetHashCode() || objItemMasterDAL.ItemType == poswItemType.Combo_Item.GetHashCode())
                    {
                        ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                    }
                    objItemMasterDAL.ImageName = Convert.ToString(SqlRdr["ImageName"]);
                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImagePhysicalName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);

                        objItemMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                    }
                    else
                    {
                        objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";

                        objItemMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";

                    }
                    objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    if (SqlRdr["SortOrder"] != DBNull.Value)
                    {
                        objItemMasterDAL.SortOrder = Convert.ToInt32(SqlRdr["SortOrder"]);
                    }
                    objItemMasterDAL.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    objItemMasterDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);

                    /// Extra
                    objItemMasterDAL.Category = Convert.ToString(SqlRdr["Category"]);

                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswItemMasterDAL> SelectAllItemMasterModifier()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterModifier_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = ItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    objItemMasterDAL.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswItemMasterDAL> SelectAllItemSuggested(int linktoItemMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";

            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemSuggested_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = linktoItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemMasterDAL> lstItemMasterDAL = new List<poswItemMasterDAL>();
                poswItemMasterDAL objItemMasterDAL;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.BarCode = Convert.ToString(SqlRdr["BarCode"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    if (SqlRdr["linktoUnitMasterId"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    }
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    objItemMasterDAL.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    objItemMasterDAL.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    if (SqlRdr["IsFavourite"] != DBNull.Value)
                    {
                        objItemMasterDAL.IsFavourite = Convert.ToBoolean(SqlRdr["IsFavourite"]);
                    }
                    if (SqlRdr["IsDineInOnly"] != DBNull.Value)
                    {
                        objItemMasterDAL.IsDineInOnly = Convert.ToBoolean(SqlRdr["IsDineInOnly"]);
                    }
                    objItemMasterDAL.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);
                    if (objItemMasterDAL.ItemType == poswItemType.Modifier.GetHashCode())
                    {
                        ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "modifier/";
                    }
                    else if (objItemMasterDAL.ItemType == poswItemType.Item.GetHashCode() || objItemMasterDAL.ItemType == poswItemType.Combo_Item.GetHashCode())
                    {
                        ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "item/";
                    }
                    objItemMasterDAL.ImageName = Convert.ToString(SqlRdr["ImageName"]);
                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImagePhysicalName = ImageRetrievePath + Convert.ToString(SqlRdr["ImageName"]);

                        objItemMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                    }
                    else
                    {
                        objItemMasterDAL.ImagePhysicalName = "img/NoImage.png";

                        objItemMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                        objItemMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";

                    }                   
                    objItemMasterDAL.ItemPoint = Convert.ToInt16(SqlRdr["ItemPoint"]);
                    objItemMasterDAL.PriceByPoint = Convert.ToInt16(SqlRdr["PriceByPoint"]);
                    objItemMasterDAL.SearchWords = Convert.ToString(SqlRdr["SearchWords"]);
                    objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    if (SqlRdr["SortOrder"] != DBNull.Value)
                    {
                        objItemMasterDAL.SortOrder = Convert.ToInt32(SqlRdr["SortOrder"]);
                    }
                    objItemMasterDAL.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    objItemMasterDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);

                    objItemMasterDAL.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
                    objItemMasterDAL.linktoUserMasterIdCreatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdCreatedBy"]);
                    if (SqlRdr["UpdateDateTime"] != DBNull.Value)
                    {
                        objItemMasterDAL.UpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
                    }
                    if (SqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoUserMasterIdUpdatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdUpdatedBy"]);
                    }

                    /// Extra
                    objItemMasterDAL.Unit = Convert.ToString(SqlRdr["Unit"]);
                    objItemMasterDAL.Category = Convert.ToString(SqlRdr["Category"]);
                    objItemMasterDAL.Business = Convert.ToString(SqlRdr["Business"]);
                    objItemMasterDAL.UserCreatedBy = Convert.ToString(SqlRdr["UserCreatedBy"]);
                    objItemMasterDAL.UserUpdatedBy = Convert.ToString(SqlRdr["UserUpdatedBy"]);
                    objItemMasterDAL.linktoItemMasterIdModifiers = Convert.ToString(SqlRdr["ItemModifierMasterIds"]);
                    objItemMasterDAL.linktoOptionMasterIds = Convert.ToString(SqlRdr["OptionValueTranIds"]);
                    objItemMasterDAL.Tax = Convert.ToString(SqlRdr["Tax"]);
                    objItemMasterDAL.TaxRate = Convert.ToDouble(SqlRdr["TaxRate"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region Order Cookies
        public class poswItemMasterCookies
        {
            #region Properties
            public int ItemMasterId { get; set; }
            public string ItemName { get; set; }
            public double MRP { get; set; }
            public double Rate { get; set; }
            public bool IsRateTaxInclusive { get; set; }
            public short ItemType { get; set; }
            public int Quentity { get; set; }
            public string Modifier { get; set; }
            public double TotalAmount { get; set; }
            public double Tax { get; set; }
            public int OrderItemId { get; set; }
            public int linktoItemMasterIdModifier { get; set; }
            public int linktoRegisterUserMasterId { get; set; }

            #endregion

        }

        public string Serialize<T>(List<T> list)
        {
            XmlSerializer serializer = new XmlSerializer(list.GetType());
            MemoryStream stream = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(stream, Encoding.UTF8);
            serializer.Serialize(writer, list);
            stream = (MemoryStream)writer.BaseStream;
            UTF8Encoding utf8 = new UTF8Encoding();
            return utf8.GetString(stream.ToArray());
        }

        public List<T> Deserialize<T>(string xml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<T>));
            UTF8Encoding utf8 = new UTF8Encoding();
            byte[] bytes = utf8.GetBytes(xml);
            MemoryStream stream = new MemoryStream(bytes);
            XmlTextReader reader = new XmlTextReader(stream);
            return (List<T>)serializer.Deserialize(reader);
        }

        //Create Order Cookies Value
        public bool CreateCookie(string linktoRegisterUserMasterID)
        {
            if (HttpContext.Current.Request.Cookies[poswItemMasterDAL.OrderCookies + linktoRegisterUserMasterID] == null)
            {
                HttpCookie myCookie = new HttpCookie(poswItemMasterDAL.OrderCookies + linktoRegisterUserMasterID);
                myCookie.Expires = poswGlobalsDAL.GetCurrentDateTime().AddDays(15);
                HttpContext.Current.Response.Cookies.Add(myCookie);
            }
            return true;
        }

        //Get Order Cookies Value
        public List<poswItemMasterDAL> GetOrderCookies(string linktoRegisterUserMasterID)
        {
            List<poswItemMasterDAL> lstCookieItems = new List<poswItemMasterDAL>();
            if (HttpContext.Current.Request.Cookies[poswItemMasterDAL.OrderCookies + linktoRegisterUserMasterID] != null)
            {
                if (HttpContext.Current.Request.Cookies[poswItemMasterDAL.OrderCookies + linktoRegisterUserMasterID]["OrderItems"] != null)
                {
                    string xml = poswGlobalsDAL.Decript(HttpContext.Current.Request.Cookies[poswItemMasterDAL.OrderCookies + linktoRegisterUserMasterID]["OrderItems"].ToString());
                    lstCookieItems = Deserialize<poswItemMasterDAL>(xml);


                    if (lstCookieItems != null)
                    {
                        return lstCookieItems;
                    }

                }
            }
            else
            {
                this.CreateCookie(linktoRegisterUserMasterID);
            }
            return lstCookieItems;
        }

        //Set Order CookiesValue
        public void SetOrderCookies(List<poswItemMasterCookies> lstOrderItems, string linktoRegisterUserMasterID)
        {
            HttpCookie myCookie; string CookiesData;
            if (HttpContext.Current.Request.Cookies[poswItemMasterDAL.OrderCookies + linktoRegisterUserMasterID] == null)
            {
                myCookie = new HttpCookie(poswItemMasterDAL.OrderCookies + linktoRegisterUserMasterID);
                myCookie.Expires = poswGlobalsDAL.GetCurrentDateTime().AddDays(15);
                HttpContext.Current.Response.Cookies.Add(myCookie);
            }


            CookiesData = Serialize<poswItemMasterCookies>(lstOrderItems);
            myCookie = HttpContext.Current.Request.Cookies[poswItemMasterDAL.OrderCookies + linktoRegisterUserMasterID];
            //byte[] b1 = System.Text.Encoding.ASCII.GetBytes(myCookie.ToString());
            // string str1 = Convert.ToBase64String(b1);
            myCookie["OrderItems"] = poswGlobalsDAL.Encrypt(CookiesData);
            myCookie.Expires = poswGlobalsDAL.GetCurrentDateTime().AddDays(15);
            HttpContext.Current.Response.Cookies.Set(myCookie);



        }
        #endregion

    }
}

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBookingPaymentTran
    /// </summary>
    public class poswBookingPaymentTranDAL
    {
        #region Properties
        public long BookingPaymentTranId { get; set; }
        public int linktoBookingMasterId { get; set; }
        public short? linktoPaymentTypeMasterId { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public DateTime PaymentDateTime { get; set; }
        public double AmountPaid { get; set; }
        public string Remark { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra

        public string PaymentType { get; set; }
        public string Customer { get; set; }
        // public string RegisteredUser { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double TotalAmount { get; set; }
        public double BalanceAmount { get; set; }
        public double ExtraAmount { get; set; }
        public short DiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double Creditbalance { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BookingPaymentTranId = Convert.ToInt64(sqlRdr["BookingPaymentTranId"]);

                this.linktoBookingMasterId = Convert.ToInt32(sqlRdr["linktoBookingMasterId"]);

                if (sqlRdr["linktoPaymentTypeMasterId"] != DBNull.Value)
                {
                    this.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                }
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                this.PaymentDateTime = Convert.ToDateTime(sqlRdr["PaymentDateTime"]);
                this.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Creditbalance = Convert.ToDouble(sqlRdr["Creditbalance"]);
                this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                this.Customer = Convert.ToString(sqlRdr["Customer"]);

                return true;
            }
            return false;
        }

        private List<poswBookingPaymentTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswBookingPaymentTranDAL> lstBookingPaymentTran = new List<poswBookingPaymentTranDAL>();
            poswBookingPaymentTranDAL objBookingPaymentTran = null;
            while (sqlRdr.Read())
            {
                objBookingPaymentTran = new poswBookingPaymentTranDAL();
                objBookingPaymentTran.BookingPaymentTranId = Convert.ToInt64(sqlRdr["BookingPaymentTranId"]);
                objBookingPaymentTran.linktoBookingMasterId = Convert.ToInt32(sqlRdr["linktoBookingMasterId"]);

                if (sqlRdr["linktoPaymentTypeMasterId"] != DBNull.Value)
                {
                    objBookingPaymentTran.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                }
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objBookingPaymentTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                objBookingPaymentTran.PaymentDateTime = Convert.ToDateTime(sqlRdr["PaymentDateTime"]);
                objBookingPaymentTran.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                objBookingPaymentTran.Remark = Convert.ToString(sqlRdr["Remark"]);
                objBookingPaymentTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objBookingPaymentTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objBookingPaymentTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objBookingPaymentTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objBookingPaymentTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra

                objBookingPaymentTran.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                objBookingPaymentTran.PaidAmount = Convert.ToDouble(sqlRdr["PaidAmount"]);

                objBookingPaymentTran.DiscountPercentage = Convert.ToInt16(sqlRdr["DiscountPercentage"]);
                objBookingPaymentTran.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                objBookingPaymentTran.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objBookingPaymentTran.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                objBookingPaymentTran.BalanceAmount = Convert.ToDouble(sqlRdr["BalanceAmount"]);
                objBookingPaymentTran.Customer = Convert.ToString(sqlRdr["Customer"]);
                objBookingPaymentTran.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                // objBookingPaymentTran.RegisteredUser = Convert.ToString(sqlRdr["RegisteredUser"]);
                lstBookingPaymentTran.Add(objBookingPaymentTran);
            }
            return lstBookingPaymentTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertBookingPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();

                SqlCmd = new SqlCommand("poswBookingPaymentTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingPaymentTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@PaymentDateTime", SqlDbType.DateTime).Value = this.PaymentDateTime;
                SqlCmd.Parameters.Add("@AmountPaid", SqlDbType.Money).Value = this.AmountPaid;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BookingPaymentTranId = Convert.ToInt64(SqlCmd.Parameters["@BookingPaymentTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateBookingPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingPaymentTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingPaymentTranId", SqlDbType.BigInt).Value = this.BookingPaymentTranId;
                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@PaymentDateTime", SqlDbType.DateTime).Value = this.PaymentDateTime;
                SqlCmd.Parameters.Add("@AmountPaid", SqlDbType.Money).Value = this.AmountPaid;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteBookingPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingPaymentTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingPaymentTranId", SqlDbType.BigInt).Value = this.BookingPaymentTranId;
                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.BigInt).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBookingPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingPaymentTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingPaymentTranId", SqlDbType.BigInt).Value = this.BookingPaymentTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswBookingPaymentTranDAL> SelectAllBookingPaymentTranByBookingMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingPaymentTranByBookingMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBookingPaymentTranDAL> lstBookingPaymentTranDAL = new List<poswBookingPaymentTranDAL>();
                poswBookingPaymentTranDAL objBookingPaymentTranDAL = null;
                while (SqlRdr.Read())
                {
                    objBookingPaymentTranDAL = new poswBookingPaymentTranDAL();

                    objBookingPaymentTranDAL.BookingPaymentTranId = Convert.ToInt64(SqlRdr["BookingPaymentTranId"]);
                    objBookingPaymentTranDAL.PaymentDateTime = Convert.ToDateTime(SqlRdr["PaymentDateTime"]);
                    objBookingPaymentTranDAL.AmountPaid = Convert.ToDouble(SqlRdr["AmountPaid"]);
                    objBookingPaymentTranDAL.Remark = Convert.ToString(SqlRdr["Remark"]);
                    objBookingPaymentTranDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);

                    lstBookingPaymentTranDAL.Add(objBookingPaymentTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstBookingPaymentTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswBookingPaymentTranDAL> SelectAllBookingPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBookingPaymentTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                if (this.linktoBookingMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBookingPaymentTranDAL> lstBookingPaymentTranDAL = new List<poswBookingPaymentTranDAL>();
                poswBookingPaymentTranDAL objBookingPaymentTranDAL = null;
                while (SqlRdr.Read())
                {
                    objBookingPaymentTranDAL = new poswBookingPaymentTranDAL();

                    objBookingPaymentTranDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    objBookingPaymentTranDAL.PaidAmount = Convert.ToDouble(SqlRdr["PaidAmount"]);
                    objBookingPaymentTranDAL.BalanceAmount = Convert.ToDouble(SqlRdr["BalanceAmount"]);
                    objBookingPaymentTranDAL.TotalAmount = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    objBookingPaymentTranDAL.ExtraAmount = Convert.ToDouble(SqlRdr["ExtraAmount"]);
                    objBookingPaymentTranDAL.DiscountAmount = Convert.ToDouble(SqlRdr["DiscountAmount"]);
                    objBookingPaymentTranDAL.DiscountPercentage = Convert.ToInt16(SqlRdr["DiscountPercentage"]);

                    if (SqlRdr["BookingPaymentTranId"] != DBNull.Value)
                    {
                        objBookingPaymentTranDAL.BookingPaymentTranId = Convert.ToInt64(SqlRdr["BookingPaymentTranId"]);
                        if (SqlRdr["PaymentType"] != DBNull.Value)
                        {
                            objBookingPaymentTranDAL.PaymentType = Convert.ToString(SqlRdr["PaymentType"]);
                        }
                        {
                            objBookingPaymentTranDAL.PaymentType = Convert.ToString(SqlRdr["Customer"]);
                        }

                        objBookingPaymentTranDAL.PaymentDateTime = Convert.ToDateTime(SqlRdr["PaymentDateTime"]);
                        objBookingPaymentTranDAL.AmountPaid = Convert.ToDouble(SqlRdr["AmountPaid"]);
                        objBookingPaymentTranDAL.Remark = Convert.ToString(SqlRdr["Remark"]);
                        objBookingPaymentTranDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);
                    }
                    lstBookingPaymentTranDAL.Add(objBookingPaymentTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstBookingPaymentTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion
    }
}

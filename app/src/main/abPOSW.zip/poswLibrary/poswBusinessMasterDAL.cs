using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswBusinessMaster
    /// </summary>
    public class poswBusinessMasterDAL
    {
        #region Properties
        public short BusinessMasterId { get; set; }
        public short? linktoBusinessGroupMasterId { get; set; }
        public string BusinessName { get; set; }
        public string BusinessShortName { get; set; }
        public string Address { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Email { get; set; }
        public string Fax { get; set; }
        public string Website { get; set; }
        public short linktoCountryMasterId { get; set; }
        public short linktoStateMasterId { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string ImageName { get; set; }
        public string ExtraText { get; set; }
        public string TIN { get; set; }
        public DateTime? TINRegistrationDate { get; set; }
        public string CST { get; set; }
        public DateTime? CSTRegistrationDate { get; set; }
        public string PAN { get; set; }
        public DateTime? PANRegistrationDate { get; set; }
        public string TDS { get; set; }
        public DateTime? TDSRegistrationDate { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        public string UniqueId { get; set; }
        public bool IsEnabled { get; set; }
        public string ImagePhysicalName { get; set; }
        public DateTime? CreateDateTime { get; set; }

        /// Extra
        public string Country { get; set; }
        public string State { get; set; }
        public string BusinessType { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public string BusinessGroup { get; set; }
       
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Business/";
            if (sqlRdr.Read())
            {
                this.BusinessMasterId = Convert.ToInt16(sqlRdr["BusinessMasterId"]);
                if (sqlRdr["linktoBusinessGroupMasterId"] != DBNull.Value)
                {
                    this.linktoBusinessGroupMasterId = Convert.ToInt16(sqlRdr["linktoBusinessGroupMasterId"]);
                }
                this.BusinessName = Convert.ToString(sqlRdr["BusinessName"]);
                this.BusinessShortName = Convert.ToString(sqlRdr["BusinessShortName"]);
                this.Address = Convert.ToString(sqlRdr["Address"]);
                this.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                this.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                this.Email = Convert.ToString(sqlRdr["Email"]);
                this.Fax = Convert.ToString(sqlRdr["Fax"]);
                this.Website = Convert.ToString(sqlRdr["Website"]);
                this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                this.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                this.City = Convert.ToString(sqlRdr["City"]);
                this.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                this.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                if (Convert.ToString(sqlRdr["ImageName"]) != "")
                {
                    this.ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                }
                else
                {
                    this.ImagePhysicalName = "img/NoImage.png";

                    this.xs_ImagePhysicalName = "img/NoImage.png";
                    this.sm_ImagePhysicalName = "img/NoImage.png";
                    this.md_ImagePhysicalName = "img/NoImage.png";
                    this.lg_ImagePhysicalName = "img/NoImage.png";
                    this.xl_ImagePhysicalName = "img/NoImage.png";

                }
                this.ExtraText = Convert.ToString(sqlRdr["ExtraText"]);
                this.TIN = Convert.ToString(sqlRdr["TIN"]);
                if (sqlRdr["TINRegistrationDate"] != DBNull.Value)
                {
                    this.TINRegistrationDate = Convert.ToDateTime(sqlRdr["TINRegistrationDate"]);
                }
                this.CST = Convert.ToString(sqlRdr["CST"]);
                if (sqlRdr["CSTRegistrationDate"] != DBNull.Value)
                {
                    this.CSTRegistrationDate = Convert.ToDateTime(sqlRdr["CSTRegistrationDate"]);
                }
                this.PAN = Convert.ToString(sqlRdr["PAN"]);
                if (sqlRdr["PANRegistrationDate"] != DBNull.Value)
                {
                    this.PANRegistrationDate = Convert.ToDateTime(sqlRdr["PANRegistrationDate"]);
                }
                this.TDS = Convert.ToString(sqlRdr["TDS"]);
                if (sqlRdr["TDSRegistrationDate"] != DBNull.Value)
                {
                    this.TDSRegistrationDate = Convert.ToDateTime(sqlRdr["TDSRegistrationDate"]);
                }
                this.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
                this.UniqueId = Convert.ToString(sqlRdr["UniqueId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                this.Country = Convert.ToString(sqlRdr["Country"]);
                this.State = Convert.ToString(sqlRdr["State"]);
                this.BusinessType = Convert.ToString(sqlRdr["BusinessType"]);
                this.BusinessGroup = Convert.ToString(sqlRdr["BusinessGroup"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                return true;
            }
            return false;
        }

        private List<poswBusinessMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {

            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Business/";
            List<poswBusinessMasterDAL> lstBusinessMaster = new List<poswBusinessMasterDAL>();
            poswBusinessMasterDAL objBusinessMaster = null;
            while (sqlRdr.Read())
            {
                objBusinessMaster = new poswBusinessMasterDAL();
                objBusinessMaster.BusinessMasterId = Convert.ToInt16(sqlRdr["BusinessMasterId"]);
                if (sqlRdr["linktoBusinessGroupMasterId"] != DBNull.Value)
                {
                    objBusinessMaster.linktoBusinessGroupMasterId = Convert.ToInt16(sqlRdr["linktoBusinessGroupMasterId"]);
                }
                objBusinessMaster.BusinessName = Convert.ToString(sqlRdr["BusinessName"]);
                objBusinessMaster.BusinessShortName = Convert.ToString(sqlRdr["BusinessShortName"]);
                objBusinessMaster.Address = Convert.ToString(sqlRdr["Address"]);
                objBusinessMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                objBusinessMaster.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                objBusinessMaster.Email = Convert.ToString(sqlRdr["Email"]);
                objBusinessMaster.Fax = Convert.ToString(sqlRdr["Fax"]);
                objBusinessMaster.Website = Convert.ToString(sqlRdr["Website"]);
                objBusinessMaster.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                objBusinessMaster.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                objBusinessMaster.City = Convert.ToString(sqlRdr["City"]);
                objBusinessMaster.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                objBusinessMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);


                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    objBusinessMaster.ImagePhysicalName = Convert.ToString(sqlRdr["ImageName"]);

                    objBusinessMaster.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessMaster.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessMaster.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessMaster.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessMaster.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                }
                else
                {
                    objBusinessMaster.ImagePhysicalName = "img/NoImage.png";

                    objBusinessMaster.xs_ImagePhysicalName = "img/NoImage.png";
                    objBusinessMaster.sm_ImagePhysicalName = "img/NoImage.png";
                    objBusinessMaster.md_ImagePhysicalName = "img/NoImage.png";
                    objBusinessMaster.lg_ImagePhysicalName = "img/NoImage.png";
                    objBusinessMaster.xl_ImagePhysicalName = "img/NoImage.png";

                }

                objBusinessMaster.ExtraText = Convert.ToString(sqlRdr["ExtraText"]);
                objBusinessMaster.TIN = Convert.ToString(sqlRdr["TIN"]);
                if (sqlRdr["TINRegistrationDate"] != DBNull.Value)
                {
                    objBusinessMaster.TINRegistrationDate = Convert.ToDateTime(sqlRdr["TINRegistrationDate"]);
                }
                objBusinessMaster.CST = Convert.ToString(sqlRdr["CST"]);
                if (sqlRdr["CSTRegistrationDate"] != DBNull.Value)
                {
                    objBusinessMaster.CSTRegistrationDate = Convert.ToDateTime(sqlRdr["CSTRegistrationDate"]);
                }
                objBusinessMaster.PAN = Convert.ToString(sqlRdr["PAN"]);
                if (sqlRdr["PANRegistrationDate"] != DBNull.Value)
                {
                    objBusinessMaster.PANRegistrationDate = Convert.ToDateTime(sqlRdr["PANRegistrationDate"]);
                }
                objBusinessMaster.TDS = Convert.ToString(sqlRdr["TDS"]);
                if (sqlRdr["TDSRegistrationDate"] != DBNull.Value)
                {
                    objBusinessMaster.TDSRegistrationDate = Convert.ToDateTime(sqlRdr["TDSRegistrationDate"]);
                }
                objBusinessMaster.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
                objBusinessMaster.UniqueId = Convert.ToString(sqlRdr["UniqueId"]);
                objBusinessMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                objBusinessMaster.Country = Convert.ToString(sqlRdr["Country"]);
                objBusinessMaster.State = Convert.ToString(sqlRdr["State"]);
                objBusinessMaster.BusinessType = Convert.ToString(sqlRdr["BusinessType"]);
                objBusinessMaster.BusinessGroup = Convert.ToString(sqlRdr["BusinessGroup"]);
                objBusinessMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                lstBusinessMaster.Add(objBusinessMaster);
            }
            return lstBusinessMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertBusinessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@BusinessName", SqlDbType.VarChar).Value = this.BusinessName;
                SqlCmd.Parameters.Add("@BusinessShortName", SqlDbType.VarChar).Value = this.BusinessShortName;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@Website", SqlDbType.VarChar).Value = this.Website;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@City", SqlDbType.VarChar).Value = this.City;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@ExtraText", SqlDbType.VarChar).Value = this.ExtraText;
                SqlCmd.Parameters.Add("@TIN", SqlDbType.VarChar).Value = this.TIN;
                SqlCmd.Parameters.Add("@TINRegistrationDate", SqlDbType.Date).Value = this.TINRegistrationDate;
                SqlCmd.Parameters.Add("@CST", SqlDbType.VarChar).Value = this.CST;
                SqlCmd.Parameters.Add("@CSTRegistrationDate", SqlDbType.Date).Value = this.CSTRegistrationDate;
                SqlCmd.Parameters.Add("@PAN", SqlDbType.VarChar).Value = this.PAN;
                SqlCmd.Parameters.Add("@PANRegistrationDate", SqlDbType.Date).Value = this.PANRegistrationDate;
                SqlCmd.Parameters.Add("@TDS", SqlDbType.VarChar).Value = this.TDS;
                SqlCmd.Parameters.Add("@TDSRegistrationDate", SqlDbType.Date).Value = this.TDSRegistrationDate;
                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessTypeMasterId;
                SqlCmd.Parameters.Add("@UniqueId", SqlDbType.VarChar).Value = this.UniqueId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BusinessMasterId = Convert.ToInt16(SqlCmd.Parameters["@BusinessMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateBusinessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Value = this.BusinessMasterId;
                SqlCmd.Parameters.Add("@BusinessName", SqlDbType.VarChar).Value = this.BusinessName;
                SqlCmd.Parameters.Add("@BusinessShortName", SqlDbType.VarChar).Value = this.BusinessShortName;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@Website", SqlDbType.VarChar).Value = this.Website;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@City", SqlDbType.VarChar).Value = this.City;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@ExtraText", SqlDbType.VarChar).Value = this.ExtraText;
                SqlCmd.Parameters.Add("@TIN", SqlDbType.VarChar).Value = this.TIN;
                SqlCmd.Parameters.Add("@TINRegistrationDate", SqlDbType.Date).Value = this.TINRegistrationDate;
                SqlCmd.Parameters.Add("@CST", SqlDbType.VarChar).Value = this.CST;
                SqlCmd.Parameters.Add("@CSTRegistrationDate", SqlDbType.Date).Value = this.CSTRegistrationDate;
                SqlCmd.Parameters.Add("@PAN", SqlDbType.VarChar).Value = this.PAN;
                SqlCmd.Parameters.Add("@PANRegistrationDate", SqlDbType.Date).Value = this.PANRegistrationDate;
                SqlCmd.Parameters.Add("@TDS", SqlDbType.VarChar).Value = this.TDS;
                SqlCmd.Parameters.Add("@TDSRegistrationDate", SqlDbType.Date).Value = this.TDSRegistrationDate;
                SqlCmd.Parameters.Add("@UniqueId", SqlDbType.VarChar).Value = this.UniqueId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBusinessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Value = this.BusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswBusinessMasterDAL> SelectAllBusinessMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Value = this.BusinessMasterId;
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessMasterDAL> lstBusinessMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstBusinessMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswBusinessMasterDAL> SelectAllBusinessMasterBusinessName()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessMasterBusinessName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessMasterDAL> lstBusinessMasterDAL = new List<poswBusinessMasterDAL>();
                poswBusinessMasterDAL objBusinessMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objBusinessMasterDAL = new poswBusinessMasterDAL();
                    objBusinessMasterDAL.BusinessMasterId = Convert.ToInt16(SqlRdr["BusinessMasterId"]);
                    objBusinessMasterDAL.BusinessName = Convert.ToString(SqlRdr["BusinessName"]);
                    lstBusinessMasterDAL.Add(objBusinessMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswBusinessMasterDAL> SelectAllBusinessMasterByBusinessGroup()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswBusinessMasterByBusinessGroupId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessGroupMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessGroupMasterId;
                if (City != null)
                {
                    SqlCmd.Parameters.Add("@City", SqlDbType.VarChar).Value = this.City;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswBusinessMasterDAL> lstBusinessMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion
    }
}

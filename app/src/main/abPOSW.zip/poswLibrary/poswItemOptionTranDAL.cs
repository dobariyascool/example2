using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswItemOptionTran
    /// </summary>
    public class poswItemOptionTranDAL
    {
        #region Properties
        public int ItemOptionTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public int linktoOptionValueTranId { get; set; }

        ///Extra
        public bool IsSelected { get; set; }
        public int OptionMasterId { get; set; }
        public string OptionName { get; set; }
        public string OptionValue { get; set; }
        #endregion

        #region Class Methods
        private List<poswItemOptionTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswItemOptionTranDAL> lstItemOptionTran = new List<poswItemOptionTranDAL>();
            poswItemOptionTranDAL objItemOptionTran = null;
            while (sqlRdr.Read())
            {
                objItemOptionTran = new poswItemOptionTranDAL();
                if (sqlRdr["ItemOptionTranId"] != DBNull.Value)
                {
                    objItemOptionTran.ItemOptionTranId = Convert.ToInt32(sqlRdr["ItemOptionTranId"]);
                    objItemOptionTran.IsSelected = true;
                }
                if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
                {
                    objItemOptionTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                }
                objItemOptionTran.linktoOptionValueTranId = Convert.ToInt32(sqlRdr["OptionValueTranId"]);

                ///Extra
                objItemOptionTran.OptionMasterId = Convert.ToInt32(sqlRdr["OptionMasterId"]);
                objItemOptionTran.OptionName = Convert.ToString(sqlRdr["OptionName"]);
                objItemOptionTran.OptionValue = Convert.ToString(sqlRdr["OptionValue"]);
                lstItemOptionTran.Add(objItemOptionTran);
            }
            return lstItemOptionTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertAllItemOptionTran(string linktoOptionValueTranIds, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswItemOptionTran_InsertAll", SqlCon,SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoOptionValueTranIds", SqlDbType.VarChar).Value = linktoOptionValueTranIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<poswItemOptionTranDAL> SelectAllItemOptionTran(short linktoBusinessMasterId,SqlConnection sqlCon = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                if (sqlCon == null)
                {
                    SqlCon = poswObjectFactoryDAL.CreateConnection();
                    SqlCmd = new SqlCommand("poswItemOptionTran_SelectAll", SqlCon);
                }
                else
                {
                    SqlCmd = new SqlCommand("poswItemOptionTran_SelectAll", sqlCon);
                }
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                if (sqlCon == null)
                {
                    SqlCon.Open();
                }
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemOptionTranDAL> lstItemOptionTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                if (sqlCon == null)
                {
                    SqlCon.Close();
                }

                return lstItemOptionTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                if (sqlCon == null)
                {
                    poswObjectFactoryDAL.DisposeConnection(SqlCon);
                }
            }
        }
        #endregion
    }
}

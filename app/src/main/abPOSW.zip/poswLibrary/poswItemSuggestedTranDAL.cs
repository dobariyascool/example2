using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswItemSuggestedTran
    /// </summary>
    public class poswItemSuggestedTranDAL
    {
        #region Properties
        public int ItemSuggestedTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public int linktoItemMasterIdSuggested { get; set; }

        /// Extra
        public int ItemMasterId { get; set; }
        public string ItemName { get; set; }
        public string ItemSuggested { get; set; }
        public string  Category { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short CategoryMasterId { get; set; }
        public short SortOrder { get; set; }
        public short linktoCategoryMasterId { get; set; }
        public bool IsItemSelected { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.ItemSuggestedTranId = Convert.ToInt32(sqlRdr["ItemSuggestedTranId"]);
                this.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                this.linktoItemMasterIdSuggested = Convert.ToInt32(sqlRdr["linktoItemMasterIdSuggested"]);

                /// Extra
                this.ItemName = Convert.ToString(sqlRdr["Item"]);
                this.ItemSuggested = Convert.ToString(sqlRdr["ItemSuggested"]);
                return true;
            }
            return false;
        }

        private List<poswItemSuggestedTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswItemSuggestedTranDAL> lstItemSuggestedTran = new List<poswItemSuggestedTranDAL>();
            poswItemSuggestedTranDAL objItemSuggestedTran = null;
            while (sqlRdr.Read())
            {
                objItemSuggestedTran = new poswItemSuggestedTranDAL();
                objItemSuggestedTran.ItemSuggestedTranId = Convert.ToInt32(sqlRdr["ItemSuggestedTranId"]);
                objItemSuggestedTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                objItemSuggestedTran.linktoItemMasterIdSuggested = Convert.ToInt32(sqlRdr["linktoItemMasterIdSuggested"]);

                /// Extra
                objItemSuggestedTran.ItemName = Convert.ToString(sqlRdr["Item"]);
                objItemSuggestedTran.ItemSuggested = Convert.ToString(sqlRdr["ItemSuggested"]);
                lstItemSuggestedTran.Add(objItemSuggestedTran);
            }
            return lstItemSuggestedTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertAllItemSuggestedTran(string linktoItemMasterIdSuggesteds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemSuggestedTran_InsertAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterIdSuggesteds", SqlDbType.VarChar).Value = linktoItemMasterIdSuggesteds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<poswItemSuggestedTranDAL> SelectAllItemSuggestedTranItem(short ItemType)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemSuggestedTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = ItemType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemSuggestedTranDAL> lstItemSuggestedTranDAL = new List<poswItemSuggestedTranDAL>();
                poswItemSuggestedTranDAL objItemSuggestedTranDAL = null;
                while (SqlRdr.Read())
                {
                    objItemSuggestedTranDAL = new poswItemSuggestedTranDAL();
                    objItemSuggestedTranDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemSuggestedTranDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemSuggestedTranDAL.ItemSuggested = Convert.ToString(SqlRdr["ItemSuggested"]);
                    objItemSuggestedTranDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    lstItemSuggestedTranDAL.Add(objItemSuggestedTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemSuggestedTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswItemSuggestedTranDAL> SelectAllItemMasterItemSuggestedTran(short ItemType,short linktoBusinessMasterId, int linktoItemMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswItemMasterItemSuggestedTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.SmallInt).Value = linktoItemMasterId;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = ItemType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswItemSuggestedTranDAL> lstItemSuggestedTranDAL = new List<poswItemSuggestedTranDAL>();
                poswItemSuggestedTranDAL objItemSuggestedTranDAL = null;
                while (SqlRdr.Read())
                {
                    objItemSuggestedTranDAL = new poswItemSuggestedTranDAL();
                    objItemSuggestedTranDAL.Category = Convert.ToString(SqlRdr["Category"]);
                    objItemSuggestedTranDAL.CategoryMasterId = Convert.ToInt16(SqlRdr["CategoryMasterId"]);
                    objItemSuggestedTranDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemSuggestedTranDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemSuggestedTranDAL.SortOrder = Convert.ToInt16(SqlRdr["SortOrder"]);
                    objItemSuggestedTranDAL.IsItemSelected = Convert.ToBoolean(SqlRdr["IsItemSelected"]);
                    lstItemSuggestedTranDAL.Add(objItemSuggestedTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemSuggestedTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
        
    }
}

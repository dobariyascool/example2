using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswFeedbackQuestionMaster
    /// </summary>
    public class poswFeedbackQuestionMasterDAL
    {
        #region Properties
        public int? FeedbackQuestionMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? linktoFeedbackQuestionGroupMasterId { get; set; }
        public string FeedbackQuestion { get; set; }
        public short QuestionType { get; set; }
        public int? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }

        /// Extra
        public string Business { get; set; }
        public short QuestionCount { get; set; }
        public string GroupName { get; set; }
        public int? linktoFeedbackAnswerMasterId { get; set; }
        public string FeedbackAnswer { get; set; }
        public List<poswFeedbackAnswerMasterDAL> lstFeedbackAnswerMasterDAL { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.FeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["FeedbackQuestionMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["linktoFeedbackQuestionGroupMasterId"] != DBNull.Value)
                {
                    this.linktoFeedbackQuestionGroupMasterId = Convert.ToInt16(sqlRdr["linktoFeedbackQuestionGroupMasterId"]);
                }
                this.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                this.QuestionType = Convert.ToInt16(sqlRdr["QuestionType"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    this.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                this.Business = Convert.ToString(sqlRdr["Business"]);
                return true;
            }
            return false;
        }

        private List<poswFeedbackQuestionMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswFeedbackQuestionMasterDAL> lstFeedbackQuestionMaster = new List<poswFeedbackQuestionMasterDAL>();
            poswFeedbackQuestionMasterDAL objFeedbackQuestionMaster = null;
            while (sqlRdr.Read())
            {
                objFeedbackQuestionMaster = new poswFeedbackQuestionMasterDAL();
                objFeedbackQuestionMaster.FeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["FeedbackQuestionMasterId"]);
                objFeedbackQuestionMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objFeedbackQuestionMaster.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                objFeedbackQuestionMaster.QuestionType = Convert.ToInt16(sqlRdr["QuestionType"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    objFeedbackQuestionMaster.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
                }
                objFeedbackQuestionMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objFeedbackQuestionMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                objFeedbackQuestionMaster.Business = Convert.ToString(sqlRdr["Business"]);
                if (sqlRdr["linktoFeedbackQuestionGroupMasterId"] != DBNull.Value)
                {
                    objFeedbackQuestionMaster.linktoFeedbackQuestionGroupMasterId = Convert.ToInt16(sqlRdr["linktoFeedbackQuestionGroupMasterId"]);
                    objFeedbackQuestionMaster.GroupName = Convert.ToString(sqlRdr["GroupName"]);
                    objFeedbackQuestionMaster.QuestionCount = Convert.ToInt16(sqlRdr["QuestionCount"]);
                }

                lstFeedbackQuestionMaster.Add(objFeedbackQuestionMaster);
            }


            return lstFeedbackQuestionMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertFeedbackQuestionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswFeedbackQuestionMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoFeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Value = this.linktoFeedbackQuestionGroupMasterId;
                SqlCmd.Parameters.Add("@FeedbackQuestion", SqlDbType.VarChar).Value = this.FeedbackQuestion;
                SqlCmd.Parameters.Add("@QuestionType", SqlDbType.SmallInt).Value = this.QuestionType;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.FeedbackQuestionMasterId = Convert.ToInt32(SqlCmd.Parameters["@FeedbackQuestionMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != poswRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                else
                {
                    foreach (poswFeedbackAnswerMasterDAL objFeedbackAnswerMasterDAL in this.lstFeedbackAnswerMasterDAL)
                    {
                        objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId = Convert.ToInt32(this.FeedbackQuestionMasterId);
                        rs = objFeedbackAnswerMasterDAL.InsertFeedbackAnswerMaster(SqlTran, SqlCon);
                        if (rs != poswRecordStatus.Success)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();

                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateFeedbackQuestionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("poswFeedbackQuestionMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterId", SqlDbType.Int).Value = this.FeedbackQuestionMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoFeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Value = this.linktoFeedbackQuestionGroupMasterId;
                SqlCmd.Parameters.Add("@FeedbackQuestion", SqlDbType.VarChar).Value = this.FeedbackQuestion;
                SqlCmd.Parameters.Add("@QuestionType", SqlDbType.SmallInt).Value = this.QuestionType;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (this.QuestionType == Convert.ToInt16(poswFeedbackQuestionType.Single_Select.GetHashCode()) || this.QuestionType == Convert.ToInt16(poswFeedbackQuestionType.Multi_Select.GetHashCode()))
                {
                    foreach (poswFeedbackAnswerMasterDAL objFeedbackAnswerMasterDAL in this.lstFeedbackAnswerMasterDAL)
                    {
                        if (objFeedbackAnswerMasterDAL.FeedbackAnswerMasterId > 0)
                        {
                            objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId = Convert.ToInt32(this.FeedbackQuestionMasterId);
                            rs = objFeedbackAnswerMasterDAL.UpdateFeedbackAnswerMaster(SqlTran, SqlCon);
                            if (rs != poswRecordStatus.Success)
                            {
                                SqlTran.Rollback();
                                SqlCon.Close();
                                return rs;
                            }
                        }
                        else
                        {
                            objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId = Convert.ToInt32(this.FeedbackQuestionMasterId);
                            rs = objFeedbackAnswerMasterDAL.InsertFeedbackAnswerMaster(SqlTran, SqlCon);
                            if (rs != poswRecordStatus.Success)
                            {
                                SqlTran.Rollback();
                                SqlCon.Close();
                                return rs;
                            }
                        }
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
                poswObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteFeedbackQuestionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackQuestionMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterId", SqlDbType.Int).Value = this.FeedbackQuestionMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static poswRecordStatus DeleteAllFeedbackQuestionMaster(string feedbackQuestionMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackQuestionMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterIds", SqlDbType.VarChar).Value = feedbackQuestionMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select

        public bool SelectFeedbackQuestionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackQuestionMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterId", SqlDbType.Int).Value = this.FeedbackQuestionMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region SelectAll
        public List<poswFeedbackQuestionMasterDAL> SelectAllFeedbackQuestionMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackQuestionMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.QuestionType > 0)
                {
                    SqlCmd.Parameters.Add("@QuestionType", SqlDbType.SmallInt).Value = this.QuestionType;
                }
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswFeedbackQuestionMasterDAL> lstFeedbackQuestionMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstFeedbackQuestionMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswFeedbackQuestionMasterDAL> SelectAllFeedbackQuestionMasterFeedbackQuestion()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackQuestionMasterFeedbackQuestion_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswFeedbackQuestionMasterDAL> lstFeedbackQuestionMasterDAL = new List<poswFeedbackQuestionMasterDAL>();
                poswFeedbackQuestionMasterDAL objFeedbackQuestionMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objFeedbackQuestionMasterDAL = new poswFeedbackQuestionMasterDAL();
                    objFeedbackQuestionMasterDAL.FeedbackQuestionMasterId = Convert.ToInt32(SqlRdr["FeedbackQuestionMasterId"]);
                    objFeedbackQuestionMasterDAL.FeedbackQuestion = Convert.ToString(SqlRdr["FeedbackQuestion"]);
                    lstFeedbackQuestionMasterDAL.Add(objFeedbackQuestionMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstFeedbackQuestionMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswFeedbackQuestionMasterDAL> SelectAllFeedbackQuestionAnswer()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswFeedbackQuestionMasterByGroup_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswFeedbackQuestionMasterDAL> lstFeedbackQuestionMasterDAL = new List<poswFeedbackQuestionMasterDAL>();
                poswFeedbackQuestionMasterDAL objFeedbackQuestionMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objFeedbackQuestionMasterDAL = new poswFeedbackQuestionMasterDAL();
                    objFeedbackQuestionMasterDAL.GroupName = Convert.ToString(SqlRdr["GroupName"]);
                    if (SqlRdr["FeedbackQuestionMasterId"] != DBNull.Value)
                    {
                        objFeedbackQuestionMasterDAL.FeedbackQuestionMasterId = Convert.ToInt32(SqlRdr["FeedbackQuestionMasterId"]);
                    }
                    objFeedbackQuestionMasterDAL.FeedbackQuestion = Convert.ToString(SqlRdr["FeedbackQuestion"]);
                    if (SqlRdr["QuestionType"] != DBNull.Value)
                    {
                        objFeedbackQuestionMasterDAL.QuestionType = Convert.ToInt16(SqlRdr["QuestionType"]);
                    }
                    objFeedbackQuestionMasterDAL.FeedbackAnswer = Convert.ToString(SqlRdr["Answer"]);
                    if (SqlRdr["FeedbackAnswerMasterId"] != DBNull.Value)
                    {
                        objFeedbackQuestionMasterDAL.linktoFeedbackAnswerMasterId = Convert.ToInt16(SqlRdr["FeedbackAnswerMasterId"]);
                    }
                    lstFeedbackQuestionMasterDAL.Add(objFeedbackQuestionMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstFeedbackQuestionMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion
    }
}

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswPaymentTypeCateogryMaster
	/// </summary>
	public class poswPaymentTypeCateogryMasterDAL
	{
		#region Properties
		public short PaymentTypeCategoryMasterId { get; set; }
		public string PaymentTypeCategory { get; set; }

		/// Extra
		#endregion

        #region SelectAll
        public static List<poswPaymentTypeCateogryMasterDAL> SelectAllPaymentTypeCateogryMasterPaymentTypeCategory()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswPaymentTypeCateogryMasterPaymentTypeCategory_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswPaymentTypeCateogryMasterDAL> lstPaymentTypeCateogryMasterDAL = new List<poswPaymentTypeCateogryMasterDAL>();
				poswPaymentTypeCateogryMasterDAL objPaymentTypeCateogryMasterDAL = null;
				while (SqlRdr.Read())
				{
					objPaymentTypeCateogryMasterDAL = new poswPaymentTypeCateogryMasterDAL();
					objPaymentTypeCateogryMasterDAL.PaymentTypeCategoryMasterId = Convert.ToInt16(SqlRdr["PaymentTypeCategoryMasterId"]);
					objPaymentTypeCateogryMasterDAL.PaymentTypeCategory = Convert.ToString(SqlRdr["PaymentTypeCategory"]);
					lstPaymentTypeCateogryMasterDAL.Add(objPaymentTypeCateogryMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstPaymentTypeCateogryMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

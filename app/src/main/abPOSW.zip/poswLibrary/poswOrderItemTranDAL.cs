using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswOrderItemTran
    /// </summary>
    public class poswOrderItemTranDAL
    {
        #region Properties
        public long OrderItemTranId { get; set; }
        public long linktoOrderMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short Quantity { get; set; }
        public double Rate { get; set; }
        public short ItemPoint { get; set; }
        public short DeductedPoint { get; set; }
        public string ItemRemark { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public double DiscountAmount { get; set; }
        public double DiscountPercentage { get; set; }

        /// Extra
        public string OrderName { get; set; }
        public string Item { get; set; }
        public string OrderStatus { get; set; }
        public string OrderNumber { get; set; }
        public string OrderRemark { get; set; }
        public string StatusName { get; set; }
        public string ItemCode { get; set; }
        public string Remark { get; set; }
        public DateTime? OrderDateTime { get; set; }
        public int ITEMModifier { get; set; }
        public double TotalRate { get; set; }
        public int linktoOrderItemTranId { get; set; }
        public int linktoItemMasterModifierId { get; set; }
        public int linktoBookingMasterId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public bool IsBookingOrder { get; set; }
        public bool PaymentStatus { get; set; }
        public int TotalItemQuantity { get; set; }
        public double TotalTax { get; set; }
        public double TotalAmount { get; set; }
        public double Cost { get; set; }
        public double TotalCost { get; set; }
        public double TotalProfitOrLoss { get; set; }
        #endregion

        #region Class Methods
        private List<poswOrderItemTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswOrderItemTranDAL> lstOrderItemTran = new List<poswOrderItemTranDAL>();
            poswOrderItemTranDAL objOrderItemTran = null;
            while (sqlRdr.Read())
            {
                objOrderItemTran = new poswOrderItemTranDAL();
                if (sqlRdr["OrderItemTranId"] != DBNull.Value)
                {
                    objOrderItemTran.OrderItemTranId = Convert.ToInt64(sqlRdr["OrderItemTranId"]);
                }
                objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(sqlRdr["linktoOrderMasterId"]);
                objOrderItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                objOrderItemTran.Quantity = Convert.ToInt16(sqlRdr["Quantity"]);
                objOrderItemTran.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                objOrderItemTran.ItemPoint = Convert.ToInt16(sqlRdr["ItemPoint"]);
                objOrderItemTran.DeductedPoint = Convert.ToInt16(sqlRdr["DeductedPoint"]);
                objOrderItemTran.ItemRemark = Convert.ToString(sqlRdr["ItemRemark"]);
                if (sqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                {
                    objOrderItemTran.linktoOrderStatusMasterId = Convert.ToInt16(sqlRdr["linktoOrderStatusMasterId"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objOrderItemTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                /// Extra
                objOrderItemTran.ITEMModifier = Convert.ToInt16(sqlRdr["ITEMModifier"]);
                objOrderItemTran.OrderName = Convert.ToString(sqlRdr["OrderName"]);
                objOrderItemTran.Item = Convert.ToString(sqlRdr["Item"]);
                objOrderItemTran.OrderStatus = Convert.ToString(sqlRdr["OrderStatus"]);
                objOrderItemTran.TotalRate = Convert.ToInt16(sqlRdr["Quantity"]) * Convert.ToDouble(sqlRdr["Rate"]);

                objOrderItemTran.linktoItemMasterModifierId = Convert.ToInt32(sqlRdr["linktoItemMasterModifierId"]);
                objOrderItemTran.linktoOrderItemTranId = Convert.ToInt32(sqlRdr["linktoOrderItemTranId"]);

                lstOrderItemTran.Add(objOrderItemTran);
            }
            return lstOrderItemTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertOrderItemTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswOrderItemTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderItemTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = this.linktoOrderMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@Quantity", SqlDbType.SmallInt).Value = this.Quantity;
                SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = this.Rate;
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@DeductedPoint", SqlDbType.SmallInt).Value = this.DeductedPoint;
                SqlCmd.Parameters.Add("@ItemRemark", SqlDbType.VarChar).Value = this.ItemRemark;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Decimal).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OrderItemTranId = Convert.ToInt64(SqlCmd.Parameters["@OrderItemTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update

        public poswRecordStatus UpdateOrderMasterOrderCancel()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterOrderCancel_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.Int).Value = this.linktoOrderMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region Select

        public bool SelectOrderPaymentCancel()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterForPayment_Verify", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.SmallInt).Value = this.linktoOrderMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                if (SqlRdr.Read())
                {
                    return true;
                }

                SqlRdr.Close();
                SqlCon.Close();

                return false;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region SelectAll
        public List<poswOrderItemTranDAL> SelectAllOrderItemTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderItemTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoOrderMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = this.linktoOrderMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderItemTranDAL> lstOrderItemTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderItemTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public Dictionary<string, List<poswOrderItemTranDAL>> SelectAllOrderItemTranItemNames()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderItemTranByOrderMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoOrderMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = this.linktoOrderMasterId;
                }
                if (this.linktoBookingMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.BigInt).Value = this.linktoBookingMasterId;
                }

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderItemTranDAL> lstOrderItemTran = new List<poswOrderItemTranDAL>();
                List<poswOrderItemTranDAL> lstOrderModifierTran = new List<poswOrderItemTranDAL>();

                poswOrderItemTranDAL objOrderItemTran = null;

                while (sqlRdr.Read())
                {
                    objOrderItemTran = new poswOrderItemTranDAL();

                    objOrderItemTran.OrderItemTranId = Convert.ToInt64(sqlRdr["OrderItemTranId"]);
                    objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(sqlRdr["linktoOrderMasterId"]);
                    objOrderItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                    objOrderItemTran.linktoOrderItemTranId = Convert.ToInt32(sqlRdr["OrderItemTranId"]);
                    objOrderItemTran.Item = Convert.ToString(sqlRdr["Item"]);
                    objOrderItemTran.Quantity = Convert.ToInt16(sqlRdr["Quantity"]);
                    objOrderItemTran.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                    objOrderItemTran.ItemRemark = Convert.ToString(sqlRdr["ItemRemark"]);
                    objOrderItemTran.TotalRate = Convert.ToInt16(sqlRdr["Quantity"]) * Convert.ToDouble(sqlRdr["Rate"]);
                    if (sqlRdr["linktoBookingMasterId"] != DBNull.Value)
                    {
                        objOrderItemTran.linktoBookingMasterId = Convert.ToInt16(sqlRdr["linktoBookingMasterId"]);
                    }

                    lstOrderItemTran.Add(objOrderItemTran);
                }

                sqlRdr.NextResult();

                while (sqlRdr.Read())
                {
                    objOrderItemTran = new poswOrderItemTranDAL();

                    objOrderItemTran.Item = objOrderItemTran.Item = Convert.ToString(sqlRdr["Item"]);
                    objOrderItemTran.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                    objOrderItemTran.linktoItemMasterModifierId = Convert.ToInt32(sqlRdr["linktoItemMasterModifierId"]);
                    objOrderItemTran.linktoOrderItemTranId = Convert.ToInt32(sqlRdr["linktoOrderItemTranId"]);
                    lstOrderModifierTran.Add(objOrderItemTran);
                }
                Dictionary<string, List<poswOrderItemTranDAL>> OrderItemList = new Dictionary<string, List<poswOrderItemTranDAL>>();
                OrderItemList.Add("OrderItemTran", lstOrderItemTran);
                OrderItemList.Add("OrderModifierTran", lstOrderModifierTran);

                sqlRdr.Close();
                SqlCon.Close();

                return OrderItemList;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(sqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public Dictionary<string, List<poswOrderItemTranDAL>> SelectAllOrderItemTranItemNamesByCustomerMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderItemTranByCustomerMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoCustomerMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                }
                SqlCmd.Parameters.Add("@IsBookingOrder", SqlDbType.Bit).Value = this.IsBookingOrder;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderItemTranDAL> lstOrderItemTran = new List<poswOrderItemTranDAL>();
                List<poswOrderItemTranDAL> lstOrderModifierTran = new List<poswOrderItemTranDAL>();

                poswOrderItemTranDAL objOrderItemTran = null;

                while (SqlRdr.Read())
                {
                    objOrderItemTran = new poswOrderItemTranDAL();

                    objOrderItemTran.OrderItemTranId = Convert.ToInt64(SqlRdr["OrderItemTranId"]);
                    objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(SqlRdr["linktoOrderMasterId"]);
                    objOrderItemTran.linktoItemMasterId = Convert.ToInt32(SqlRdr["linktoItemMasterId"]);
                    objOrderItemTran.linktoOrderItemTranId = Convert.ToInt32(SqlRdr["OrderItemTranId"]);
                    objOrderItemTran.Item = Convert.ToString(SqlRdr["ItemName"]);
                    objOrderItemTran.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objOrderItemTran.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    objOrderItemTran.ItemRemark = Convert.ToString(SqlRdr["ItemRemark"]);
                    objOrderItemTran.TotalRate = Convert.ToInt16(SqlRdr["Quantity"]) * Convert.ToDouble(SqlRdr["Rate"]);
                    objOrderItemTran.PaymentStatus = Convert.ToBoolean(SqlRdr["PaymentStatus"]);
                    if (SqlRdr["linktoBookingMasterId"] != DBNull.Value)
                    {
                        objOrderItemTran.linktoBookingMasterId = Convert.ToInt16(SqlRdr["linktoBookingMasterId"]);
                    }
                    if (SqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                    {
                        objOrderItemTran.linktoOrderStatusMasterId = Convert.ToInt16(SqlRdr["linktoOrderStatusMasterId"]);
                        poswOrderStatus enumStatus = (poswOrderStatus)objOrderItemTran.linktoOrderStatusMasterId;
                        if (objOrderItemTran.linktoOrderStatusMasterId == poswOrderStatus.Canceled.GetHashCode())
                        {
                            objOrderItemTran.OrderStatus = enumStatus.ToString();
                        }
                    }
                    else
                    {
                        objOrderItemTran.OrderStatus = "";
                    }

                    objOrderItemTran.linktoCustomerMasterId = Convert.ToInt16(SqlRdr["linktoCustomerMasterId"]);
                    //Extra
                    objOrderItemTran.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    objOrderItemTran.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]);
                    objOrderItemTran.Remark = Convert.ToString(SqlRdr["Remark"]);
                    //objOrderItemTran.OrderRemark = Convert.ToString(SqlRdr["OrderRemark"]);

                    lstOrderItemTran.Add(objOrderItemTran);
                }

                SqlRdr.NextResult();

                while (SqlRdr.Read())
                {
                    objOrderItemTran = new poswOrderItemTranDAL();

                    objOrderItemTran.Item = objOrderItemTran.Item = Convert.ToString(SqlRdr["Item"]);
                    objOrderItemTran.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    objOrderItemTran.linktoItemMasterModifierId = Convert.ToInt32(SqlRdr["linktoItemMasterModifierId"]);
                    objOrderItemTran.linktoOrderItemTranId = Convert.ToInt32(SqlRdr["linktoOrderItemTranId"]);
                    lstOrderModifierTran.Add(objOrderItemTran);
                }
                Dictionary<string, List<poswOrderItemTranDAL>> OrderItemList = new Dictionary<string, List<poswOrderItemTranDAL>>();
                OrderItemList.Add("OrderItemTran", lstOrderItemTran);
                OrderItemList.Add("OrderModifierTran", lstOrderModifierTran);

                SqlRdr.Close();
                SqlCon.Close();

                return OrderItemList;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOrderItemTranDAL> SelectAllOrderItemTranOrderMasterId(string orderMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;

            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderItemTranByOrderMasterIdsSelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = orderMasterIds;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderItemTranDAL> lstOrderItemTran = new List<poswOrderItemTranDAL>();
                poswOrderItemTranDAL objOrderItemTran = null;

                while (SqlRdr.Read())
                {
                    objOrderItemTran = new poswOrderItemTranDAL();
                    objOrderItemTran.OrderItemTranId = Convert.ToInt64(SqlRdr["OrderItemTranId"]);
                    objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(SqlRdr["linktoOrderMasterId"]);
                    objOrderItemTran.linktoItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objOrderItemTran.Item = Convert.ToString(SqlRdr["ItemName"]);
                    objOrderItemTran.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objOrderItemTran.Rate = Convert.ToDouble(SqlRdr["ActualPrice"]);
                    objOrderItemTran.ItemRemark = Convert.ToString(SqlRdr["ItemRemark"]);
                    objOrderItemTran.TotalRate = Convert.ToInt16(SqlRdr["Rate"]);
                    objOrderItemTran.linktoItemMasterModifierId = Convert.ToInt32(SqlRdr["ItemModifierMasterIds"]);
                    objOrderItemTran.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objOrderItemTran.ItemPoint = Convert.ToInt16(SqlRdr["ItemPoint"]);
                    lstOrderItemTran.Add(objOrderItemTran);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {

                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOrderItemTranDAL> SelectAllOrderItemTranMostOrderedItemsChart(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderItemTranMostOrderItems_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                poswOrderItemTranDAL objorderItemTranDAL = null;
                List<poswOrderItemTranDAL> lstOrderItemTranDAL = new List<poswOrderItemTranDAL>();
                while (SqlRdr.Read())
                {
                    objorderItemTranDAL = new poswOrderItemTranDAL();
                    objorderItemTranDAL.Item = Convert.ToString(SqlRdr["ItemName"]);
                    objorderItemTranDAL.TotalItemQuantity = Convert.ToInt32(SqlRdr["OrderItemCount"]);
                    lstOrderItemTranDAL.Add(objorderItemTranDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderItemTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOrderItemTranDAL> SelectAllOrderItemTranLeastOrderedItemsChart(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderItemTranLeastOrderItems_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = poswGlobalsDAL.GetCurrentDateTime();

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                poswOrderItemTranDAL objorderItemTranDAL = null;
                List<poswOrderItemTranDAL> lstOrderItemTranDAL = new List<poswOrderItemTranDAL>();
                while (SqlRdr.Read())
                {
                    objorderItemTranDAL = new poswOrderItemTranDAL();
                    objorderItemTranDAL.Item = Convert.ToString(SqlRdr["ItemName"]);
                    objorderItemTranDAL.TotalItemQuantity = Convert.ToInt32(SqlRdr["OrderItemCount"]);
                    lstOrderItemTranDAL.Add(objorderItemTranDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderItemTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswOrderItemTranDAL> SelectAllOrderMasterItemWiseProfitLoss(short linktoBusinessMasterId, DateTime FromDate, DateTime ToDate, short StartRowIndex, short PageSize, out short TotalRecord)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderMasterItemProfitLossReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = StartRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = PageSize;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@TotalRecord", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderItemTranDAL> lstOrderMasterDAL = new List<poswOrderItemTranDAL>();
                poswOrderItemTranDAL objOrderItemTranDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderItemTranDAL = new poswOrderItemTranDAL();
                    objOrderItemTranDAL.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]);
                    objOrderItemTranDAL.Item = Convert.ToString(SqlRdr["ItemName"]);
                    objOrderItemTranDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objOrderItemTranDAL.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objOrderItemTranDAL.Cost = Convert.ToDouble(SqlRdr["PurchaseRate"]);
                    objOrderItemTranDAL.TotalRate = Convert.ToDouble(SqlRdr["TotalRate"]);
                    objOrderItemTranDAL.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    objOrderItemTranDAL.TotalCost = Convert.ToDouble(SqlRdr["TotalCost"]);
                    objOrderItemTranDAL.TotalProfitOrLoss = Convert.ToDouble(SqlRdr["ProfitORLoss"]);

                    lstOrderMasterDAL.Add(objOrderItemTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();
                TotalRecord = (short)SqlCmd.Parameters["@TotalRecord"].Value;
                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                TotalRecord = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion
    }
}

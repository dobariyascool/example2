﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;

namespace poswLibrary
{
    public class poswUserTypeMasterDAL
    {
        #region Properties
        public short UserTypeMasterId { get; set; }
        public string UserType { get; set; }
        public string Description { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.UserTypeMasterId = Convert.ToInt16(sqlRdr["UserTypeMasterId"]);
                this.UserType = Convert.ToString(sqlRdr["UserType"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
                return true;
            }
            return false;
        }

        private List<poswUserTypeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswUserTypeMasterDAL> lstUserTypeMaster = new List<poswUserTypeMasterDAL>();
            poswUserTypeMasterDAL objUserTypeMaster = null;
            while (sqlRdr.Read())
            {
                objUserTypeMaster = new poswUserTypeMasterDAL();
                objUserTypeMaster.UserTypeMasterId = Convert.ToInt16(sqlRdr["UserTypeMasterId"]);
                objUserTypeMaster.UserType = Convert.ToString(sqlRdr["UserType"]);
                objUserTypeMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objUserTypeMaster.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
                lstUserTypeMaster.Add(objUserTypeMaster);
            }
            return lstUserTypeMaster;
        }
        #endregion

        #region SelectAll
        //public List<poswUserTypeMasterDAL> SelectAllUserTypeMaster()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    SqlDataReader SqlRdr = null;
        //    try
        //    {
        //        SqlCon = poswObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("poswUserTypeMasterUserType_SelectAll", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;


        //        SqlCon.Open();
        //        SqlRdr = SqlCmd.ExecuteReader();
        //        List<poswUserTypeMasterDAL> lstUserTypeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
        //        SqlRdr.Close();
        //        SqlCon.Close();

        //        return lstUserTypeMasterDAL;
        //    }
        //    catch (Exception ex)
        //    {
        //        poswGlobalsDAL.SaveError(ex);
        //        return null;
        //    }
        //    finally
        //    {
        //        poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
        //        poswObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        poswObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}

        public static List<poswUserTypeMasterDAL> SelectAllUserTypeMasterUserType()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswUserTypeMasterUserType_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswUserTypeMasterDAL> lstUserTypeMasterDAL = new List<poswUserTypeMasterDAL>();
                poswUserTypeMasterDAL objUserTypeMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objUserTypeMasterDAL = new poswUserTypeMasterDAL();
                    objUserTypeMasterDAL.UserTypeMasterId = Convert.ToInt16(SqlRdr["UserTypeMasterId"]);
                    objUserTypeMasterDAL.UserType = Convert.ToString(SqlRdr["UserType"]);
                    lstUserTypeMasterDAL.Add(objUserTypeMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserTypeMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
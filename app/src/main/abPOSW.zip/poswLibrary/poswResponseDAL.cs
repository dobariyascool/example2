﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poswLibrary
{
    public class poswResponseDAL
    {
        public int Id { get; set; }
        public int SyncId { get; set; }    
    }
}
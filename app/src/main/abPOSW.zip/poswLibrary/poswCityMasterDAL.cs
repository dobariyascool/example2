using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Class for poswCityMaster
	/// </summary>
	public class poswCityMasterDAL
	{
		#region Properties
		public short CityMasterId { get; set; }
		public string CityName { get; set; }
		public string CityCode { get; set; }
		public short linktoStateMasterId { get; set; }
		public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

		/// Extra
        public string StateName { get; set; }
        public short CountryMasterID { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.CityMasterId = Convert.ToInt16(sqlRdr["CityMasterId"]);
				this.CityName = Convert.ToString(sqlRdr["CityName"]);
				this.CityCode = Convert.ToString(sqlRdr["CityCode"]);
				this.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

				/// Extra
                this.StateName = Convert.ToString(sqlRdr["StateName"]);
                this.CountryMasterID = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
				return true;
			}
			return false;
		}

		private List<poswCityMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<poswCityMasterDAL> lstCityMaster = new List<poswCityMasterDAL>();
			poswCityMasterDAL objCityMaster = null;
			while (sqlRdr.Read())
			{
				objCityMaster = new poswCityMasterDAL();
				objCityMaster.CityMasterId = Convert.ToInt16(sqlRdr["CityMasterId"]);
				objCityMaster.CityName = Convert.ToString(sqlRdr["CityName"]);
				objCityMaster.CityCode = Convert.ToString(sqlRdr["CityCode"]);
				objCityMaster.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
				objCityMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objCityMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objCityMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCityMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCityMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCityMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

				/// Extra
                objCityMaster.StateName = Convert.ToString(sqlRdr["State"]);
				lstCityMaster.Add(objCityMaster);
			}
			return lstCityMaster;
		}
		#endregion
         
		#region Insert
		public poswRecordStatus InsertCityMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswCityMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CityMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = this.CityName;
				SqlCmd.Parameters.Add("@CityCode", SqlDbType.VarChar).Value = this.CityCode;
				SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.CityMasterId = Convert.ToInt16(SqlCmd.Parameters["@CityMasterId"].Value);
				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public poswRecordStatus UpdateCityMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswCityMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CityMasterId", SqlDbType.SmallInt).Value = this.CityMasterId;
				SqlCmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = this.CityName;
				SqlCmd.Parameters.Add("@CityCode", SqlDbType.VarChar).Value = this.CityCode;
				SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return poswRecordStatus.Error;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

        #region Delete
        public poswRecordStatus DeleteCityMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCityMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CityMasterId", SqlDbType.SmallInt).Value = this.CityMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

		#region Select
		public bool SelectCityMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswCityMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CityMasterId", SqlDbType.SmallInt).Value = this.CityMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<poswCityMasterDAL> SelectAllCityMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswCityMasterPageWise_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = this.CityName;
				SqlCmd.Parameters.Add("@CityCode", SqlDbType.VarChar).Value = this.CityCode;
				if (this.linktoStateMasterId > 0)
				{
					SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
				}
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;


				SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
				SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
				SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswCityMasterDAL> lstCityMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
				return lstCityMasterDAL;
			}
			catch (Exception ex)
			{
				totalRecords = 0;
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public static List<poswCityMasterDAL> SelectAllCityMasterCityNameByState(short linktoStateMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCityMasterStatewise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = linktoStateMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCityMasterDAL> lstCityMasterDAL = new List<poswCityMasterDAL>();
                poswCityMasterDAL objCityMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCityMasterDAL = new poswCityMasterDAL();
                    objCityMasterDAL.CityMasterId = Convert.ToInt16(SqlRdr["CityMasterId"]);
                    objCityMasterDAL.CityName = Convert.ToString(SqlRdr["CityName"]);
                    lstCityMasterDAL.Add(objCityMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCityMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

		public static List<poswCityMasterDAL> SelectAllCityMasterCityName()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = poswObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("poswCityMasterCityName_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<poswCityMasterDAL> lstCityMasterDAL = new List<poswCityMasterDAL>();
				poswCityMasterDAL objCityMasterDAL = null;
				while (SqlRdr.Read())
				{
					objCityMasterDAL = new poswCityMasterDAL();
					objCityMasterDAL.CityMasterId = Convert.ToInt16(SqlRdr["CityMasterId"]);
					objCityMasterDAL.CityName = Convert.ToString(SqlRdr["CityName"]);
					lstCityMasterDAL.Add(objCityMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstCityMasterDAL;
			}
			catch (Exception ex)
			{
				poswGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
				poswObjectFactoryDAL.DisposeCommand(SqlCmd);
				poswObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}

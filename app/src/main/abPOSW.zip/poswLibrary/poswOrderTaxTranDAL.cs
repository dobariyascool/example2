using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswOrderTaxTran
    /// </summary>
    public class poswOrderTaxTranDAL
    {
        #region Properties
        public long OrderTaxTranId { get; set; }
        public long linktoOrderMasterId { get; set; }
        public short linktoTaxMasterId { get; set; }
        public string TaxName { get; set; }
        public double TaxRate { get; set; }
        public bool IsPercentage { get; set; }

        /// Extra
        public long Order { get; set; }
        public string Tax { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.OrderTaxTranId = Convert.ToInt64(sqlRdr["OrderTaxTranId"]);
                this.linktoOrderMasterId = Convert.ToInt64(sqlRdr["linktoOrderMasterId"]);
                this.linktoTaxMasterId = Convert.ToInt16(sqlRdr["linktoTaxMasterId"]);
                this.TaxName = Convert.ToString(sqlRdr["TaxName"]);
                this.TaxRate = Convert.ToDouble(sqlRdr["TaxRate"]);
                this.IsPercentage = Convert.ToBoolean(sqlRdr["IsPercentage"]);

                /// Extra
                this.Order = Convert.ToInt64(sqlRdr["Order"]);
                this.Tax = Convert.ToString(sqlRdr["Tax"]);
                return true;
            }
            return false;
        }

        private List<poswOrderTaxTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswOrderTaxTranDAL> lstOrderTaxTran = new List<poswOrderTaxTranDAL>();
            poswOrderTaxTranDAL objOrderTaxTran = null;
            while (sqlRdr.Read())
            {
                objOrderTaxTran = new poswOrderTaxTranDAL();
                objOrderTaxTran.OrderTaxTranId = Convert.ToInt64(sqlRdr["OrderTaxTranId"]);
                objOrderTaxTran.linktoOrderMasterId = Convert.ToInt64(sqlRdr["linktoOrderMasterId"]);
                objOrderTaxTran.linktoTaxMasterId = Convert.ToInt16(sqlRdr["linktoTaxMasterId"]);
                objOrderTaxTran.TaxName = Convert.ToString(sqlRdr["TaxName"]);
                objOrderTaxTran.TaxRate = Convert.ToDouble(sqlRdr["TaxRate"]);
                objOrderTaxTran.IsPercentage = Convert.ToBoolean(sqlRdr["IsPercentage"]);

                /// Extra
                objOrderTaxTran.Order = Convert.ToInt64(sqlRdr["Order"]);
                objOrderTaxTran.Tax = Convert.ToString(sqlRdr["Tax"]);
                lstOrderTaxTran.Add(objOrderTaxTran);
            }
            return lstOrderTaxTran;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertOrderTaxTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("poswOrderTaxTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderTaxTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = this.linktoOrderMasterId;
                SqlCmd.Parameters.Add("@linktoTaxMasterId", SqlDbType.SmallInt).Value = this.linktoTaxMasterId;
                SqlCmd.Parameters.Add("@TaxName", SqlDbType.VarChar).Value = this.TaxName;
                SqlCmd.Parameters.Add("@TaxRate", SqlDbType.Money).Value = this.TaxRate;
                SqlCmd.Parameters.Add("@IsPercentage", SqlDbType.Bit).Value = this.IsPercentage;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OrderTaxTranId = Convert.ToInt64(SqlCmd.Parameters["@OrderTaxTranId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateOrderTaxTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderTaxTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderTaxTranId", SqlDbType.BigInt).Value = this.OrderTaxTranId;
                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = this.linktoOrderMasterId;
                SqlCmd.Parameters.Add("@linktoTaxMasterId", SqlDbType.SmallInt).Value = this.linktoTaxMasterId;
                SqlCmd.Parameters.Add("@TaxName", SqlDbType.VarChar).Value = this.TaxName;
                SqlCmd.Parameters.Add("@TaxRate", SqlDbType.Money).Value = this.TaxRate;
                SqlCmd.Parameters.Add("@IsPercentage", SqlDbType.Bit).Value = this.IsPercentage;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteOrderTaxTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderTaxTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderTaxTranId", SqlDbType.BigInt).Value = this.OrderTaxTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll

        public poswRecordStatus DeleteAllOrderTaxTran(string orderTaxTranIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderTaxTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderTaxTranIds", SqlDbType.VarChar).Value = orderTaxTranIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectOrderTaxTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderTaxTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderTaxTranId", SqlDbType.BigInt).Value = this.OrderTaxTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswOrderTaxTranDAL> SelectAllOrderTaxTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswOrderTaxTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswOrderTaxTranDAL> lstOrderTaxTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderTaxTranDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

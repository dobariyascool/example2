using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswNotificationMaster
    /// </summary>
    public class poswNotificationMasterDAL
    {
        #region Properties
        public int NotificationMasterId { get; set; }
        public string NotificationTitle { get; set; }
        public string NotificationText { get; set; }
        public string NotificationImageName { get; set; }
        public DateTime NotificationDateTime { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public bool IsDeleted { get; set; }
        public short? Type { get; set; }
        public int? ID { get; set; }

        /// Extra
        public short IsRead { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Notification/";
            if (sqlRdr.Read())
            {
                this.NotificationMasterId = Convert.ToInt32(sqlRdr["NotificationMasterId"]);
                this.NotificationTitle = Convert.ToString(sqlRdr["NotificationTitle"]);
                this.NotificationText = Convert.ToString(sqlRdr["NotificationText"]);
                if (sqlRdr["NotificationImageName"] != DBNull.Value)
                {
                    this.NotificationImageName = ImageRetrievePath + Convert.ToString(sqlRdr["NotificationImageName"]);
                }
                this.NotificationDateTime = Convert.ToDateTime(sqlRdr["NotificationDateTime"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                if (sqlRdr["Type"] != DBNull.Value)
                {
                    this.Type = Convert.ToInt16(sqlRdr["Type"]);
                }
                if (sqlRdr["ID"] != DBNull.Value)
                {
                    this.ID = Convert.ToInt32(sqlRdr["ID"]);
                }
                return true;
            }
            return false;
        }

        private List<poswNotificationMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Notification/";
            List<poswNotificationMasterDAL> lstNotificationMaster = new List<poswNotificationMasterDAL>();
            poswNotificationMasterDAL objNotificationMaster = null;
            while (sqlRdr.Read())
            {
                objNotificationMaster = new poswNotificationMasterDAL();
                objNotificationMaster.NotificationMasterId = Convert.ToInt32(sqlRdr["NotificationMasterId"]);
                objNotificationMaster.NotificationTitle = Convert.ToString(sqlRdr["NotificationTitle"]);
                objNotificationMaster.NotificationText = Convert.ToString(sqlRdr["NotificationText"]);
                if (sqlRdr["NotificationImageName"] != DBNull.Value && !sqlRdr["NotificationImageName"].Equals(""))
                {
                    objNotificationMaster.NotificationImageName = ImageRetrievePath + Convert.ToString(sqlRdr["NotificationImageName"]);                    
                }
                objNotificationMaster.NotificationDateTime = Convert.ToDateTime(sqlRdr["NotificationDateTime"]);
                objNotificationMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objNotificationMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objNotificationMaster.IsRead = Convert.ToInt16(sqlRdr["IsRead"]);
                if (sqlRdr["Type"] != DBNull.Value)
                {
                    objNotificationMaster.Type = Convert.ToInt16(sqlRdr["Type"]);
                }
                if (sqlRdr["ID"] != DBNull.Value)
                {
                    objNotificationMaster.ID = Convert.ToInt32(sqlRdr["ID"]);
                }
                lstNotificationMaster.Add(objNotificationMaster);
            }
            return lstNotificationMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertNotificationMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswNotificationMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@NotificationMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@NotificationTitle", SqlDbType.VarChar).Value = this.NotificationTitle;
                SqlCmd.Parameters.Add("@NotificationText", SqlDbType.VarChar).Value = this.NotificationText;
                SqlCmd.Parameters.Add("@NotificationImageName", SqlDbType.VarChar).Value = this.NotificationImageName;
                SqlCmd.Parameters.Add("@NotificationDateTime", SqlDbType.DateTime).Value = this.NotificationDateTime;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Type", SqlDbType.SmallInt).Value = this.Type;
                SqlCmd.Parameters.Add("@ID", SqlDbType.Int).Value = this.ID;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.NotificationMasterId = Convert.ToInt32(SqlCmd.Parameters["@NotificationMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateNotificationMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswNotificationMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@NotificationMasterId", SqlDbType.Int).Value = this.NotificationMasterId;
                SqlCmd.Parameters.Add("@NotificationTitle", SqlDbType.VarChar).Value = this.NotificationTitle;
                SqlCmd.Parameters.Add("@NotificationText", SqlDbType.VarChar).Value = this.NotificationText;
                SqlCmd.Parameters.Add("@NotificationImageName", SqlDbType.VarChar).Value = this.NotificationImageName;
                SqlCmd.Parameters.Add("@NotificationDateTime", SqlDbType.DateTime).Value = this.NotificationDateTime;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteNotificationMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswNotificationMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@NotificationMasterId", SqlDbType.Int).Value = this.NotificationMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectNotificationMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswNotificationMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@NotificationMasterId", SqlDbType.Int).Value = this.NotificationMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswNotificationMasterDAL> SelectAllNotificationMasterPageWise(short startRowIndex, short pageSize, int linktoCustomerMasterId, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswNotificationMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswNotificationMasterDAL> lstNotificationMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstNotificationMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswNotificationMasterDAL> SelectAllNotificationMasterNotificationMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswNotificationMasterNotificationMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswNotificationMasterDAL> lstNotificationMasterDAL = new List<poswNotificationMasterDAL>();
                poswNotificationMasterDAL objNotificationMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objNotificationMasterDAL = new poswNotificationMasterDAL();
                    objNotificationMasterDAL.NotificationMasterId = Convert.ToInt32(SqlRdr["NotificationMasterId"]);
                    //objNotificationMasterDAL.NotificationMasterId = Convert.ToString(SqlRdr["NotificationMasterId"]);
                    lstNotificationMasterDAL.Add(objNotificationMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstNotificationMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

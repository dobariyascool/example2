﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace poswLibrary
{
    public class poswBusiness
    {
        public short BusinessMasterId { get; set; }
        public short BusinessTypeMasterId { get; set; }

        public poswBusiness(poswBusinessMasterDAL obj)
        {
            this.BusinessMasterId = obj.BusinessMasterId;
            this.BusinessTypeMasterId = obj.linktoBusinessTypeMasterId;
        }
    }
}

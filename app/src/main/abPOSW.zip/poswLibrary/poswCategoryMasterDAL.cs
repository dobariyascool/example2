using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Class for poswCategoryMaster
    /// </summary>
    public class poswCategoryMasterDAL
    {
        #region Properties
        public short CategoryMasterId { get; set; }
        public string CategoryName { get; set; }
        public string ImageName { get; set; }
        public string CategoryColor { get; set; }
        public string Description { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? SortOrder { get; set; }
        public string SEOPageTitle { get; set; }
        public string SEOMetaDescription { get; set; }
        public string SEOMetaKeywords { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string CategoryParent { get; set; }
        public string Business { get; set; }
        public string ImagePhysicalName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "category/";
            if (sqlRdr.Read())
            {
                this.CategoryMasterId = Convert.ToInt16(sqlRdr["CategoryMasterId"]);
                this.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                this.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                }
                else
                {
                    this.ImagePhysicalName = "img/NoImage.png";

                    this.xs_ImagePhysicalName = "img/NoImage.png";
                    this.sm_ImagePhysicalName = "img/NoImage.png";
                    this.md_ImagePhysicalName = "img/NoImage.png";
                    this.lg_ImagePhysicalName = "img/NoImage.png";
                    this.xl_ImagePhysicalName = "img/NoImage.png";
                }


                this.CategoryColor = Convert.ToString(sqlRdr["CategoryColor"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    this.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                }
                this.SEOPageTitle = Convert.ToString(sqlRdr["SEOPageTitle"]);
                this.SEOMetaDescription = Convert.ToString(sqlRdr["SEOMetaDescription"]);
                this.SEOMetaKeywords = Convert.ToString(sqlRdr["SEOMetaKeywords"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.CategoryParent = Convert.ToString(sqlRdr["CategoryParent"]);
                this.Business = Convert.ToString(sqlRdr["Business"]);
                return true;
            }
            return false;
        }

        private List<poswCategoryMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<poswCategoryMasterDAL> lstCategoryMaster = new List<poswCategoryMasterDAL>();
            poswCategoryMasterDAL objCategoryMaster = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "category/";
            while (sqlRdr.Read())
            {
                objCategoryMaster = new poswCategoryMasterDAL();
                objCategoryMaster.CategoryMasterId = Convert.ToInt16(sqlRdr["CategoryMasterId"]);
                objCategoryMaster.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                objCategoryMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    objCategoryMaster.ImagePhysicalName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);

                    objCategoryMaster.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    objCategoryMaster.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    objCategoryMaster.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    objCategoryMaster.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    objCategoryMaster.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                }
                else
                {
                    objCategoryMaster.ImagePhysicalName = "img/NoImage.png";

                    objCategoryMaster.xs_ImagePhysicalName = "img/NoImage.png";
                    objCategoryMaster.sm_ImagePhysicalName = "img/NoImage.png";
                    objCategoryMaster.md_ImagePhysicalName = "img/NoImage.png";
                    objCategoryMaster.lg_ImagePhysicalName = "img/NoImage.png";
                    objCategoryMaster.xl_ImagePhysicalName = "img/NoImage.png";
                }
                objCategoryMaster.CategoryColor = Convert.ToString(sqlRdr["CategoryColor"]);
                objCategoryMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objCategoryMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    objCategoryMaster.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                }
                objCategoryMaster.SEOPageTitle = Convert.ToString(sqlRdr["SEOPageTitle"]);
                objCategoryMaster.SEOMetaDescription = Convert.ToString(sqlRdr["SEOMetaDescription"]);
                objCategoryMaster.SEOMetaKeywords = Convert.ToString(sqlRdr["SEOMetaKeywords"]);
                objCategoryMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objCategoryMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objCategoryMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCategoryMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCategoryMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCategoryMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objCategoryMaster.CategoryParent = Convert.ToString(sqlRdr["CategoryParent"]);
                objCategoryMaster.Business = Convert.ToString(sqlRdr["Business"]);
                lstCategoryMaster.Add(objCategoryMaster);
            }
            return lstCategoryMaster;
        }
        #endregion

        #region Insert
        public poswRecordStatus InsertCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCategoryMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@CategoryColor", SqlDbType.VarChar).Value = this.CategoryColor;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@SEOPageTitle", SqlDbType.VarChar).Value = this.SEOPageTitle;
                SqlCmd.Parameters.Add("@SEOMetaDescription", SqlDbType.VarChar).Value = this.SEOMetaDescription;
                SqlCmd.Parameters.Add("@SEOMetaKeywords", SqlDbType.VarChar).Value = this.SEOMetaKeywords;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.CategoryMasterId = Convert.ToInt16(SqlCmd.Parameters["@CategoryMasterId"].Value);
                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public poswRecordStatus UpdateCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCategoryMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = this.CategoryMasterId;
                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@CategoryColor", SqlDbType.VarChar).Value = this.CategoryColor;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@SEOPageTitle", SqlDbType.VarChar).Value = this.SEOPageTitle;
                SqlCmd.Parameters.Add("@SEOMetaDescription", SqlDbType.VarChar).Value = this.SEOMetaDescription;
                SqlCmd.Parameters.Add("@SEOMetaKeywords", SqlDbType.VarChar).Value = this.SEOMetaKeywords;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public poswRecordStatus DeleteCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCategoryMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = this.CategoryMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                poswRecordStatus rs = (poswRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return poswRecordStatus.Error;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCategoryMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = this.CategoryMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<poswCategoryMasterDAL> SelectAllCategoryMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCategoryMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCategoryMasterDAL> lstCategoryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<poswCategoryMasterDAL> SelectAllCategoryMasterCategoryName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCategoryMasterCategoryName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCategoryMasterDAL> lstCategoryMasterDAL = new List<poswCategoryMasterDAL>();
                poswCategoryMasterDAL objCategoryMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCategoryMasterDAL = new poswCategoryMasterDAL();
                    objCategoryMasterDAL.CategoryMasterId = Convert.ToInt16(SqlRdr["CategoryMasterId"]);
                    objCategoryMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    lstCategoryMasterDAL.Add(objCategoryMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<poswCategoryMasterDAL> SelectAllCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = poswObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("poswCategoryMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<poswCategoryMasterDAL> lstCategoryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                poswObjectFactoryDAL.DisposeDataReader(SqlRdr);
                poswObjectFactoryDAL.DisposeCommand(SqlCmd);
                poswObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

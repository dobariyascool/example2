using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for AreaMaster
	/// </summary>
	public class AreaMaster
	{
        public short AreaMasterId { get; set; }
        public string AreaName { get; set; }
        public string ZipCode { get; set; }
        public short linktoCityMasterId { get; set; }
        public bool IsEnabled { get; set; }

		/// Extra
		public string City { get; set; }

		internal void SetClassObject(poswAreaMasterDAL objAreaMasterDAL)
		{
			this.AreaMasterId = Convert.ToInt16(objAreaMasterDAL.AreaMasterId);
			this.AreaName = Convert.ToString(objAreaMasterDAL.AreaName);
			this.ZipCode = Convert.ToString(objAreaMasterDAL.ZipCode);
			this.linktoCityMasterId = Convert.ToInt16(objAreaMasterDAL.linktoCityMasterId);
			this.IsEnabled = Convert.ToBoolean(objAreaMasterDAL.IsEnabled);

			/// Extra
			this.City = Convert.ToString(objAreaMasterDAL.City);
		}

		internal static List<AreaMaster> SetListObject(List<poswAreaMasterDAL> lstAreaMasterDAL)
		{
			List<AreaMaster> lstAreaMaster = new List<AreaMaster>();
			AreaMaster objAreaMaster = null;
			foreach (poswAreaMasterDAL objAreaMasterDAL in lstAreaMasterDAL)
			{
				objAreaMaster = new AreaMaster();
				objAreaMaster.AreaMasterId = Convert.ToInt16(objAreaMasterDAL.AreaMasterId);
				objAreaMaster.AreaName = Convert.ToString(objAreaMasterDAL.AreaName);
				objAreaMaster.ZipCode = Convert.ToString(objAreaMasterDAL.ZipCode);
				objAreaMaster.linktoCityMasterId = Convert.ToInt16(objAreaMasterDAL.linktoCityMasterId);
				objAreaMaster.IsEnabled = Convert.ToBoolean(objAreaMasterDAL.IsEnabled);

				/// Extra
				objAreaMaster.City = Convert.ToString(objAreaMasterDAL.City);
				lstAreaMaster.Add(objAreaMaster);
			}
			return lstAreaMaster;
		}
	}
}

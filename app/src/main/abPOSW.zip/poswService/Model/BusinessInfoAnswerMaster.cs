using System;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Model for BusinessInfoAnswerMaster
    /// </summary>
    public class BusinessInfoAnswerMaster
    {

        public int BusinessInfoAnswerMasterId { get; set; }
        public int linktoBusinessInfoQuestionMasterId { get; set; }
        public string Answer { get; set; }
        public bool IsEnabled { get; set; }

        /// Extra
        public string BusinessInfoQuestion { get; set; }
        public string QuestionType { get; set; }
        public bool IsAnswer { get; set; }


        internal void SetClassObject(poswBusinessInfoAnswerMasterDAL objBusinessInfoAnswerMasterDAL)
        {
            this.BusinessInfoAnswerMasterId = Convert.ToInt32(objBusinessInfoAnswerMasterDAL.BusinessInfoAnswerMasterId);
            this.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(objBusinessInfoAnswerMasterDAL.linktoBusinessInfoQuestionMasterId);
            this.Answer = Convert.ToString(objBusinessInfoAnswerMasterDAL.Answer);
            this.IsEnabled = Convert.ToBoolean(objBusinessInfoAnswerMasterDAL.IsEnabled);

            /// Extra
            this.BusinessInfoQuestion = Convert.ToString(objBusinessInfoAnswerMasterDAL.BusinessInfoQuestion);
            this.QuestionType = Convert.ToString(objBusinessInfoAnswerMasterDAL.QuestionType);
            this.IsAnswer = Convert.ToBoolean(objBusinessInfoAnswerMasterDAL.IsAnswer);
        }

        internal static List<BusinessInfoAnswerMaster> SetListObject(List<poswBusinessInfoAnswerMasterDAL> lstBusinessInfoAnswerMasterDAL)
        {
            List<BusinessInfoAnswerMaster> lstBusinessInfoAnswerMaster = new List<BusinessInfoAnswerMaster>();
            BusinessInfoAnswerMaster objBusinessInfoAnswerMaster = null;
            foreach (poswBusinessInfoAnswerMasterDAL objBusinessInfoAnswerMasterDAL in lstBusinessInfoAnswerMasterDAL)
            {
                objBusinessInfoAnswerMaster = new BusinessInfoAnswerMaster();
                objBusinessInfoAnswerMaster.BusinessInfoAnswerMasterId = Convert.ToInt32(objBusinessInfoAnswerMasterDAL.BusinessInfoAnswerMasterId);
                objBusinessInfoAnswerMaster.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(objBusinessInfoAnswerMasterDAL.linktoBusinessInfoQuestionMasterId);
                objBusinessInfoAnswerMaster.Answer = Convert.ToString(objBusinessInfoAnswerMasterDAL.Answer);
                objBusinessInfoAnswerMaster.IsEnabled = Convert.ToBoolean(objBusinessInfoAnswerMasterDAL.IsEnabled);

                /// Extra
                objBusinessInfoAnswerMaster.BusinessInfoQuestion = Convert.ToString(objBusinessInfoAnswerMasterDAL.BusinessInfoQuestion);
                objBusinessInfoAnswerMaster.QuestionType = Convert.ToString(objBusinessInfoAnswerMasterDAL.QuestionType);
                objBusinessInfoAnswerMaster.IsAnswer = Convert.ToBoolean(objBusinessInfoAnswerMasterDAL.IsAnswer);
                lstBusinessInfoAnswerMaster.Add(objBusinessInfoAnswerMaster);
            }
            return lstBusinessInfoAnswerMaster;
        }
    }
}

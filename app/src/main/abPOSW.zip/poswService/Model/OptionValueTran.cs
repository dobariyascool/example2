using System;
using System.Collections.Generic;

namespace poswLibrary
{
	public class OptionValueTran
	{
        public int OptionValueTranId { get; set; }
        public short linktoOptionMasterId { get; set; }
        public string OptionValue { get; set; }
        public bool IsDeleted { get; set; }

        public string OptionName { get; set; }

		internal void SetClassObject(poswOptionValueTranDAL objOptionValueTranDAL)
		{
			this.OptionValueTranId = Convert.ToInt32(objOptionValueTranDAL.OptionValueTranId);
			this.linktoOptionMasterId = Convert.ToInt16(objOptionValueTranDAL.linktoOptionMasterId);
			this.OptionValue = Convert.ToString(objOptionValueTranDAL.OptionValue);
			this.IsDeleted = Convert.ToBoolean(objOptionValueTranDAL.IsDeleted);

			/// Extra
            this.OptionName = Convert.ToString(objOptionValueTranDAL.OptionName);
		}

		internal static List<OptionValueTran> SetListObject(List<poswOptionValueTranDAL> lstOptionValueTranDAL)
		{
			List<OptionValueTran> lstOptionValueTran = new List<OptionValueTran>();
			OptionValueTran objOptionValueTran = null;
			foreach (poswOptionValueTranDAL objOptionValueTranDAL in lstOptionValueTranDAL)
			{
				objOptionValueTran = new OptionValueTran();
				objOptionValueTran.OptionValueTranId = Convert.ToInt32(objOptionValueTranDAL.OptionValueTranId);
				objOptionValueTran.linktoOptionMasterId = Convert.ToInt16(objOptionValueTranDAL.linktoOptionMasterId);
				objOptionValueTran.OptionValue = Convert.ToString(objOptionValueTranDAL.OptionValue);
				objOptionValueTran.IsDeleted = Convert.ToBoolean(objOptionValueTranDAL.IsDeleted);

				/// Extra
                objOptionValueTran.OptionName = Convert.ToString(objOptionValueTranDAL.OptionName);
				lstOptionValueTran.Add(objOptionValueTran);
			}
			return lstOptionValueTran;
		}
	}
}

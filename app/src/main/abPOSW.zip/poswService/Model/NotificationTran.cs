using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for NotificationTran
	/// </summary>
	public class NotificationTran
	{
        public long NotificationTranId { get; set; }
        public int linktoNotificationMasterId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string ReadDateTime { get; set; }
		/// Extra

		internal void SetClassObject(poswNotificationTranDAL objNotificationTranDAL)
		{
			this.NotificationTranId = Convert.ToInt64(objNotificationTranDAL.NotificationTranId);
			this.linktoNotificationMasterId = Convert.ToInt32(objNotificationTranDAL.linktoNotificationMasterId);
			this.linktoCustomerMasterId = Convert.ToInt32(objNotificationTranDAL.linktoCustomerMasterId);
			this.ReadDateTime = objNotificationTranDAL.ReadDateTime.ToString("s");

			/// Extra
		}

		internal static List<NotificationTran> SetListObject(List<poswNotificationTranDAL> lstNotificationTranDAL)
		{
			List<NotificationTran> lstNotificationTran = new List<NotificationTran>();
			NotificationTran objNotificationTran = null;
			foreach (poswNotificationTranDAL objNotificationTranDAL in lstNotificationTranDAL)
			{
				objNotificationTran = new NotificationTran();
				objNotificationTran.NotificationTranId = Convert.ToInt64(objNotificationTranDAL.NotificationTranId);
				objNotificationTran.linktoNotificationMasterId = Convert.ToInt32(objNotificationTranDAL.linktoNotificationMasterId);
				objNotificationTran.linktoCustomerMasterId = Convert.ToInt32(objNotificationTranDAL.linktoCustomerMasterId);
				objNotificationTran.ReadDateTime = objNotificationTranDAL.ReadDateTime.ToString("s");

				/// Extra
				lstNotificationTran.Add(objNotificationTran);
			}
			return lstNotificationTran;
		}
	}
}

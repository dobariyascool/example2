using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for CategoryMaster
	/// </summary>
	public class CategoryMaster
	{

        public short CategoryMasterId { get; set; }
        public string CategoryName { get; set; }
        public string ImageName { get; set; }
        public string CategoryColor { get; set; }
        public string Description { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? SortOrder { get; set; }
        public string SEOPageTitle { get; set; }
        public string SEOMetaDescription { get; set; }
        public string SEOMetaKeywords { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string CategoryParent { get; set; }
        public string Business { get; set; }
        public string ImagePhysicalName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }


		internal void SetClassObject(poswCategoryMasterDAL objCategoryMasterDAL)
		{
			this.CategoryMasterId = Convert.ToInt16(objCategoryMasterDAL.CategoryMasterId);
			this.CategoryName = Convert.ToString(objCategoryMasterDAL.CategoryName);
			this.ImageName = Convert.ToString(objCategoryMasterDAL.ImageName);
			this.CategoryColor = Convert.ToString(objCategoryMasterDAL.CategoryColor);
			this.Description = Convert.ToString(objCategoryMasterDAL.Description);
			this.linktoBusinessMasterId = Convert.ToInt16(objCategoryMasterDAL.linktoBusinessMasterId);
			if (objCategoryMasterDAL.SortOrder != null)
			{
				this.SortOrder = Convert.ToInt16(objCategoryMasterDAL.SortOrder.Value);
			}
			this.SEOPageTitle = Convert.ToString(objCategoryMasterDAL.SEOPageTitle);
			this.SEOMetaDescription = Convert.ToString(objCategoryMasterDAL.SEOMetaDescription);
			this.SEOMetaKeywords = Convert.ToString(objCategoryMasterDAL.SEOMetaKeywords);
			this.IsEnabled = Convert.ToBoolean(objCategoryMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objCategoryMasterDAL.IsDeleted);
			this.CreateDateTime = objCategoryMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objCategoryMasterDAL.linktoUserMasterIdCreatedBy);
			if (objCategoryMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objCategoryMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objCategoryMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objCategoryMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}

			/// Extra
			this.CategoryParent = Convert.ToString(objCategoryMasterDAL.CategoryParent);
			this.Business = Convert.ToString(objCategoryMasterDAL.Business);
		}

		internal static List<CategoryMaster> SetListObject(List<poswCategoryMasterDAL> lstCategoryMasterDAL)
		{
			List<CategoryMaster> lstCategoryMaster = new List<CategoryMaster>();
			CategoryMaster objCategoryMaster = null;
			foreach (poswCategoryMasterDAL objCategoryMasterDAL in lstCategoryMasterDAL)
			{
				objCategoryMaster = new CategoryMaster();
				objCategoryMaster.CategoryMasterId = Convert.ToInt16(objCategoryMasterDAL.CategoryMasterId);
				objCategoryMaster.CategoryName = Convert.ToString(objCategoryMasterDAL.CategoryName);
				objCategoryMaster.ImageName = Convert.ToString(objCategoryMasterDAL.ImageName);
				objCategoryMaster.CategoryColor = Convert.ToString(objCategoryMasterDAL.CategoryColor);
				objCategoryMaster.Description = Convert.ToString(objCategoryMasterDAL.Description);
				objCategoryMaster.linktoBusinessMasterId = Convert.ToInt16(objCategoryMasterDAL.linktoBusinessMasterId);
				if (objCategoryMasterDAL.SortOrder != null)
				{
					objCategoryMaster.SortOrder = Convert.ToInt16(objCategoryMasterDAL.SortOrder.Value);
				}
				objCategoryMaster.SEOPageTitle = Convert.ToString(objCategoryMasterDAL.SEOPageTitle);
				objCategoryMaster.SEOMetaDescription = Convert.ToString(objCategoryMasterDAL.SEOMetaDescription);
				objCategoryMaster.SEOMetaKeywords = Convert.ToString(objCategoryMasterDAL.SEOMetaKeywords);
				objCategoryMaster.IsEnabled = Convert.ToBoolean(objCategoryMasterDAL.IsEnabled);
				objCategoryMaster.IsDeleted = Convert.ToBoolean(objCategoryMasterDAL.IsDeleted);
				objCategoryMaster.CreateDateTime = objCategoryMasterDAL.CreateDateTime.ToString("s");
				objCategoryMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objCategoryMasterDAL.linktoUserMasterIdCreatedBy);
				if (objCategoryMasterDAL.UpdateDateTime != null)
				{
					objCategoryMaster.UpdateDateTime = objCategoryMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objCategoryMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objCategoryMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objCategoryMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}

				/// Extra
				objCategoryMaster.CategoryParent = Convert.ToString(objCategoryMasterDAL.CategoryParent);
				objCategoryMaster.Business = Convert.ToString(objCategoryMasterDAL.Business);
				lstCategoryMaster.Add(objCategoryMaster);
			}
			return lstCategoryMaster;
		}
	}
}

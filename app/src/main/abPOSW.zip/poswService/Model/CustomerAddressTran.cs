using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for CustomerAddressTran
	/// </summary>
	public class CustomerAddressTran
	{
        public int CustomerAddressTranId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string CustomerName { get; set; }
        public int? linktoRegisteredUserMasterId { get; set; }
        public short AddressType { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public short? linktoCountryMasterId { get; set; }
        public short? linktoStateMasterId { get; set; }
        public short? linktoCityMasterId { get; set; }
        public short? linktoAreaMasterId { get; set; }
        public string ZipCode { get; set; }
        public bool IsPrimary { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public bool IsDeleted { get; set; }

		/// Extra
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
        public string Email { get; set; }
		
		internal void SetClassObject(poswCustomerAddressTranDAL objCustomerAddressTranDAL)
		{
			this.CustomerAddressTranId = Convert.ToInt32(objCustomerAddressTranDAL.CustomerAddressTranId);
            this.linktoCustomerMasterId = Convert.ToInt32(objCustomerAddressTranDAL.linktoCustomerMasterId);
			this.Address = Convert.ToString(objCustomerAddressTranDAL.Address);
			if (objCustomerAddressTranDAL.linktoCountryMasterId != null)
			{
				this.linktoCountryMasterId = Convert.ToInt16(objCustomerAddressTranDAL.linktoCountryMasterId.Value);
			}
			if (objCustomerAddressTranDAL.linktoStateMasterId != null)
			{
				this.linktoStateMasterId = Convert.ToInt16(objCustomerAddressTranDAL.linktoStateMasterId.Value);
			}
			if (objCustomerAddressTranDAL.linktoCityMasterId != null)
			{
				this.linktoCityMasterId = Convert.ToInt16(objCustomerAddressTranDAL.linktoCityMasterId.Value);
			}
			if (objCustomerAddressTranDAL.linktoAreaMasterId != null)
			{
				this.linktoAreaMasterId = Convert.ToInt16(objCustomerAddressTranDAL.linktoAreaMasterId.Value);
			}
			this.ZipCode = Convert.ToString(objCustomerAddressTranDAL.ZipCode);
			this.IsPrimary = Convert.ToBoolean(objCustomerAddressTranDAL.IsPrimary);
			this.CreateDateTime = objCustomerAddressTranDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objCustomerAddressTranDAL.linktoUserMasterIdCreatedBy);
			this.IsDeleted = Convert.ToBoolean(objCustomerAddressTranDAL.IsDeleted);
            this.AddressType = Convert.ToInt16(objCustomerAddressTranDAL.AddressType);
            this.Phone = Convert.ToString(objCustomerAddressTranDAL.Phone);

            this.CustomerName = Convert.ToString(objCustomerAddressTranDAL.CustomerName);
            this.Country = Convert.ToString(objCustomerAddressTranDAL.Country);
            this.State = Convert.ToString(objCustomerAddressTranDAL.State);
            this.City = Convert.ToString(objCustomerAddressTranDAL.City);
            this.Area = Convert.ToString(objCustomerAddressTranDAL.Area);
            this.Email = Convert.ToString(objCustomerAddressTranDAL.Email);
			
		}

		internal static List<CustomerAddressTran> SetListObject(List<poswCustomerAddressTranDAL> lstCustomerAddressTranDAL)
		{
			List<CustomerAddressTran> lstCustomerAddressTran = new List<CustomerAddressTran>();
			CustomerAddressTran objCustomerAddressTran = null;
			foreach (poswCustomerAddressTranDAL objCustomerAddressTranDAL in lstCustomerAddressTranDAL)
			{
				objCustomerAddressTran = new CustomerAddressTran();
				objCustomerAddressTran.CustomerAddressTranId = Convert.ToInt32(objCustomerAddressTranDAL.CustomerAddressTranId);
				objCustomerAddressTran.linktoCustomerMasterId = Convert.ToInt32(objCustomerAddressTranDAL.linktoCustomerMasterId);
				objCustomerAddressTran.Address = Convert.ToString(objCustomerAddressTranDAL.Address);
				if (objCustomerAddressTranDAL.linktoCountryMasterId != null)
				{
					objCustomerAddressTran.linktoCountryMasterId = Convert.ToInt16(objCustomerAddressTranDAL.linktoCountryMasterId.Value);
				}
				if (objCustomerAddressTranDAL.linktoStateMasterId != null)
				{
					objCustomerAddressTran.linktoStateMasterId = Convert.ToInt16(objCustomerAddressTranDAL.linktoStateMasterId.Value);
				}
				if (objCustomerAddressTranDAL.linktoCityMasterId != null)
				{
					objCustomerAddressTran.linktoCityMasterId = Convert.ToInt16(objCustomerAddressTranDAL.linktoCityMasterId.Value);
				}
				if (objCustomerAddressTranDAL.linktoAreaMasterId != null)
				{
					objCustomerAddressTran.linktoAreaMasterId = Convert.ToInt16(objCustomerAddressTranDAL.linktoAreaMasterId.Value);
				}
				objCustomerAddressTran.ZipCode = Convert.ToString(objCustomerAddressTranDAL.ZipCode);
				objCustomerAddressTran.IsPrimary = Convert.ToBoolean(objCustomerAddressTranDAL.IsPrimary);
				objCustomerAddressTran.CreateDateTime = objCustomerAddressTranDAL.CreateDateTime.ToString("s");
				objCustomerAddressTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(objCustomerAddressTranDAL.linktoUserMasterIdCreatedBy);
				objCustomerAddressTran.IsDeleted = Convert.ToBoolean(objCustomerAddressTranDAL.IsDeleted);
                objCustomerAddressTran.AddressType = Convert.ToInt16(objCustomerAddressTranDAL.AddressType);
                objCustomerAddressTran.Phone = Convert.ToString(objCustomerAddressTranDAL.Phone);

				/// Extra
                objCustomerAddressTran.CustomerName = Convert.ToString(objCustomerAddressTranDAL.CustomerName);
                objCustomerAddressTran.Country = Convert.ToString(objCustomerAddressTranDAL.Country);
                if (objCustomerAddressTranDAL.State != null)
                {
                    objCustomerAddressTran.State = Convert.ToString(objCustomerAddressTranDAL.State.Substring(0, objCustomerAddressTranDAL.State.LastIndexOf(", ")));
                }
                if (objCustomerAddressTranDAL.City != null)
                {
                    objCustomerAddressTran.City = Convert.ToString(objCustomerAddressTranDAL.City.Substring(0, objCustomerAddressTranDAL.City.LastIndexOf(", ")));
                }
                if (objCustomerAddressTranDAL.Area != null)
                {
                    objCustomerAddressTran.Area = Convert.ToString(objCustomerAddressTranDAL.Area);
                }
                objCustomerAddressTran.Email = Convert.ToString(objCustomerAddressTranDAL.Email);
				lstCustomerAddressTran.Add(objCustomerAddressTran);
			}
			return lstCustomerAddressTran;
		}
	}

}

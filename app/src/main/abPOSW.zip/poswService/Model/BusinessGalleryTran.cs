using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for BusinessGalleryTran
	/// </summary>
	public class BusinessGalleryTran
	{

        public int BusinessGalleryTranId { get; set; }
        public string ImageTitle { get; set; }
        public string ImageName { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? SortOrder { get; set; }

        /// Extra
        public string Business { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }


		internal void SetClassObject(poswBusinessGalleryTranDAL objBusinessGalleryTranDAL)
		{
			this.BusinessGalleryTranId = Convert.ToInt32(objBusinessGalleryTranDAL.BusinessGalleryTranId);
			this.ImageTitle = Convert.ToString(objBusinessGalleryTranDAL.ImageTitle);
			this.ImageName = Convert.ToString(objBusinessGalleryTranDAL.ImageName);
			this.linktoBusinessMasterId = Convert.ToInt16(objBusinessGalleryTranDAL.linktoBusinessMasterId);
			if (objBusinessGalleryTranDAL.SortOrder != null)
			{
				this.SortOrder = Convert.ToInt16(objBusinessGalleryTranDAL.SortOrder.Value);
			}

			/// Extra
			this.Business = Convert.ToString(objBusinessGalleryTranDAL.Business);
            this.xs_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.xs_ImagePhysicalName);
            this.sm_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.sm_ImagePhysicalName);
            this.md_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.md_ImagePhysicalName);
            this.lg_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.lg_ImagePhysicalName);
            this.xl_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.xl_ImagePhysicalName);
		}

		internal static List<BusinessGalleryTran> SetListObject(List<poswBusinessGalleryTranDAL> lstBusinessGalleryTranDAL)
		{
			List<BusinessGalleryTran> lstBusinessGalleryTran = new List<BusinessGalleryTran>();
			BusinessGalleryTran objBusinessGalleryTran = null;
			foreach (poswBusinessGalleryTranDAL objBusinessGalleryTranDAL in lstBusinessGalleryTranDAL)
			{
				objBusinessGalleryTran = new BusinessGalleryTran();
				objBusinessGalleryTran.BusinessGalleryTranId = Convert.ToInt32(objBusinessGalleryTranDAL.BusinessGalleryTranId);
				objBusinessGalleryTran.ImageTitle = Convert.ToString(objBusinessGalleryTranDAL.ImageTitle);
				objBusinessGalleryTran.ImageName = Convert.ToString(objBusinessGalleryTranDAL.ImageName);
				objBusinessGalleryTran.linktoBusinessMasterId = Convert.ToInt16(objBusinessGalleryTranDAL.linktoBusinessMasterId);
				if (objBusinessGalleryTranDAL.SortOrder != null)
				{
					objBusinessGalleryTran.SortOrder = Convert.ToInt16(objBusinessGalleryTranDAL.SortOrder.Value);
				}

				/// Extra
				objBusinessGalleryTran.Business = Convert.ToString(objBusinessGalleryTranDAL.Business);
                objBusinessGalleryTran.xs_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.xs_ImagePhysicalName);
                objBusinessGalleryTran.sm_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.sm_ImagePhysicalName);
                objBusinessGalleryTran.md_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.md_ImagePhysicalName);
                objBusinessGalleryTran.lg_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.lg_ImagePhysicalName);
                objBusinessGalleryTran.xl_ImagePhysicalName = Convert.ToString(objBusinessGalleryTranDAL.xl_ImagePhysicalName);
				lstBusinessGalleryTran.Add(objBusinessGalleryTran);
			}
			return lstBusinessGalleryTran;
		}
	}
}

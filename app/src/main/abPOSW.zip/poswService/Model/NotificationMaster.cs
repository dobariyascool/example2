using System;
using System.Collections.Generic;


namespace poswLibrary
{
	/// <summary>
	/// Model for NotificationMaster
	/// </summary>
	public class NotificationMaster
	{
        public int NotificationMasterId { get; set; }
        public string NotificationTitle { get; set; }
        public string NotificationText { get; set; }
        public string NotificationImageName { get; set; }
        public string NotificationDateTime { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDeleted { get; set; }
        public short? Type { get; set; }
        public int? ID { get; set; }

		/// Extra
        public string NotificationImageNameBytes { get; set; }
        public short IsRead { get; set; }

		internal void SetClassObject(poswNotificationMasterDAL objNotificationMasterDAL)
		{
			this.NotificationMasterId = Convert.ToInt32(objNotificationMasterDAL.NotificationMasterId);
			this.NotificationTitle = Convert.ToString(objNotificationMasterDAL.NotificationTitle);
			this.NotificationText = Convert.ToString(objNotificationMasterDAL.NotificationText);
			this.NotificationImageName = Convert.ToString(objNotificationMasterDAL.NotificationImageName);
			this.NotificationDateTime = objNotificationMasterDAL.NotificationDateTime.ToString("s");
			this.IsDeleted = Convert.ToBoolean(objNotificationMasterDAL.IsDeleted);
            this.linktoBusinessMasterId = Convert.ToInt16(objNotificationMasterDAL.linktoBusinessMasterId);
            if (objNotificationMasterDAL.Type != null)
            {
                this.Type = Convert.ToInt16(objNotificationMasterDAL.Type.Value);
            }
            if (objNotificationMasterDAL.ID != null)
            {
                this.ID = Convert.ToInt32(objNotificationMasterDAL.ID.Value);
            }
		}

		internal static List<NotificationMaster> SetListObject(List<poswNotificationMasterDAL> lstNotificationMasterDAL)
		{
			List<NotificationMaster> lstNotificationMaster = new List<NotificationMaster>();
			NotificationMaster objNotificationMaster = null;
			foreach (poswNotificationMasterDAL objNotificationMasterDAL in lstNotificationMasterDAL)
			{
				objNotificationMaster = new NotificationMaster();
				objNotificationMaster.NotificationMasterId = Convert.ToInt32(objNotificationMasterDAL.NotificationMasterId);
				objNotificationMaster.NotificationTitle = Convert.ToString(objNotificationMasterDAL.NotificationTitle);
				objNotificationMaster.NotificationText = Convert.ToString(objNotificationMasterDAL.NotificationText);
				objNotificationMaster.NotificationImageName = Convert.ToString(objNotificationMasterDAL.NotificationImageName);
				objNotificationMaster.NotificationDateTime = objNotificationMasterDAL.NotificationDateTime.ToString("s");
				objNotificationMaster.IsDeleted = Convert.ToBoolean(objNotificationMasterDAL.IsDeleted);
                objNotificationMaster.linktoBusinessMasterId = Convert.ToInt16(objNotificationMasterDAL.linktoBusinessMasterId);
                objNotificationMaster.IsRead = Convert.ToInt16(objNotificationMasterDAL.IsRead);
                if (objNotificationMasterDAL.Type != null)
                {
                    objNotificationMaster.Type = Convert.ToInt16(objNotificationMasterDAL.Type.Value);
                }
                if (objNotificationMasterDAL.ID != null)
                {
                    objNotificationMaster.ID = Convert.ToInt32(objNotificationMasterDAL.ID.Value);
                }
				lstNotificationMaster.Add(objNotificationMaster);
			}
			return lstNotificationMaster;
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using poswLibrary;

namespace poswService.Model
{
    public class Events
    {

        #region Properties

        public string UserName { get; set; }
        public string PersonMobile { get; set; }
        public string EventDate { get; set; }
        public short type { get; set; }
        public string EventType { get; set; }
        public short linktoBusinessMasterId { get; set; }

        #endregion


        internal static List<Events> SetListObject(List<poswEventsDAL> lstEventsDAL)
		{
           
			List<Events> lstEvents = new List<Events>();
			Events objEvent = null;

			foreach (poswEventsDAL objEventsDAL in lstEventsDAL)
			{
				objEvent = new Events();
				objEvent.UserName = Convert.ToString(objEventsDAL.UserName);
                objEvent.PersonMobile= Convert.ToString(objEventsDAL.PersonMobile);
                objEvent.EventDate = objEventsDAL.EventDate.Value.ToString("s"); 
                objEvent.type = Convert.ToInt16(objEventsDAL.type);     
                /// Extra
                lstEvents.Add(objEvent);
            }
            return lstEvents;
        }
    }
}
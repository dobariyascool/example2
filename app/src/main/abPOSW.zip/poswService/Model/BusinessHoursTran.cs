using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for BusinessHoursTran
	/// </summary>
	public class BusinessHoursTran
	{

        public short BusinessHoursTranId { get; set; }
        public short DayOfWeek { get; set; }
        public string OpeningTime { get; set; }
        public string ClosingTime { get; set; }
        public string BreakStartTime { get; set; }
        public string BreakEndTime { get; set; }
        public short linktoBusinessMasterId { get; set; }

		/// Extra
		public string Business { get; set; }


		internal void SetClassObject(poswBusinessHoursTranDAL objBusinessHoursTranDAL)
		{
			this.BusinessHoursTranId = Convert.ToInt16(objBusinessHoursTranDAL.BusinessHoursTranId);
			this.DayOfWeek = Convert.ToInt16(objBusinessHoursTranDAL.DayOfWeek);
			this.OpeningTime = new DateTime().Add(objBusinessHoursTranDAL.OpeningTime).ToString("HH:mm:ss");
			this.ClosingTime = new DateTime().Add(objBusinessHoursTranDAL.ClosingTime).ToString("HH:mm:ss");
			if (objBusinessHoursTranDAL.BreakStartTime != null)
			{
				this.BreakStartTime = new DateTime().Add(objBusinessHoursTranDAL.BreakStartTime.Value).ToString("HH:mm:ss");
			}
			if (objBusinessHoursTranDAL.BreakEndTime != null)
			{
				this.BreakEndTime = new DateTime().Add(objBusinessHoursTranDAL.BreakEndTime.Value).ToString("HH:mm:ss");
			}
			this.linktoBusinessMasterId = Convert.ToInt16(objBusinessHoursTranDAL.linktoBusinessMasterId);

			/// Extra
			this.Business = Convert.ToString(objBusinessHoursTranDAL.Business);
		}

		internal static List<BusinessHoursTran> SetListObject(List<poswBusinessHoursTranDAL> lstBusinessHoursTranDAL)
		{
			List<BusinessHoursTran> lstBusinessHoursTran = new List<BusinessHoursTran>();
			BusinessHoursTran objBusinessHoursTran = null;
			foreach (poswBusinessHoursTranDAL objBusinessHoursTranDAL in lstBusinessHoursTranDAL)
			{
				objBusinessHoursTran = new BusinessHoursTran();
				objBusinessHoursTran.BusinessHoursTranId = Convert.ToInt16(objBusinessHoursTranDAL.BusinessHoursTranId);
				objBusinessHoursTran.DayOfWeek = Convert.ToInt16(objBusinessHoursTranDAL.DayOfWeek);
                objBusinessHoursTran.OpeningTime = new DateTime().Add(objBusinessHoursTranDAL.OpeningTime).ToString("HH:mm:ss");
				objBusinessHoursTran.ClosingTime = new DateTime().Add(objBusinessHoursTranDAL.ClosingTime).ToString("HH:mm:ss");
				if (objBusinessHoursTranDAL.BreakStartTime != null)
				{
                    objBusinessHoursTran.BreakStartTime = new DateTime().Add(objBusinessHoursTranDAL.BreakStartTime.Value).ToString("HH:mm:ss");
				}
				if (objBusinessHoursTranDAL.BreakEndTime != null)
				{
                    objBusinessHoursTran.BreakEndTime = new DateTime().Add(objBusinessHoursTranDAL.BreakEndTime.Value).ToString("HH:mm:ss");
				}
				objBusinessHoursTran.linktoBusinessMasterId = Convert.ToInt16(objBusinessHoursTranDAL.linktoBusinessMasterId);

				/// Extra
				objBusinessHoursTran.Business = Convert.ToString(objBusinessHoursTranDAL.Business);
				lstBusinessHoursTran.Add(objBusinessHoursTran);
			}
			return lstBusinessHoursTran;
		}
	}
}

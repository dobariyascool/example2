﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using poswLibrary;

namespace poswService.Model
{
    public class PaymentTypeMaster
    {

        #region Properties
        public short PaymentTypeMasterId { get; set; }
        public string ShortName { get; set; }
        public string PaymentType { get; set; }
        public string Description { get; set; }
        public short linktoPaymentTypeCategoryMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdUpdatedBy { get; set; }
        public string UpdateDateTime { get; set; }

        /// Extra
        public string PaymentTypeCategory { get; set; }
        public string Business { get; set; }
        public string UserCreatedBy { get; set; }
        public string UserUpdatedBy { get; set; }
        #endregion

        internal void SetClassObject(poswPaymentTypeMasterDAL objPaymentTypeMasterDAL)
        {
           this.PaymentTypeMasterId = Convert.ToInt16(objPaymentTypeMasterDAL.PaymentTypeMasterId);
                 
            this.ShortName = Convert.ToString(objPaymentTypeMasterDAL.ShortName);                    
            this.PaymentType = Convert.ToString(objPaymentTypeMasterDAL.PaymentType);
            this.Description = Convert.ToString(objPaymentTypeMasterDAL.Description);
            if (objPaymentTypeMasterDAL.linktoPaymentTypeCategoryMasterId!= null)
            {
                this.linktoPaymentTypeCategoryMasterId= Convert.ToInt16(objPaymentTypeMasterDAL.linktoPaymentTypeCategoryMasterId);
            }
            this.IsEnabled = Convert.ToBoolean(objPaymentTypeMasterDAL.IsEnabled);
            if (objPaymentTypeMasterDAL.linktoBusinessMasterId!= null)
            {
                this.linktoBusinessMasterId  = Convert.ToInt16(objPaymentTypeMasterDAL.linktoBusinessMasterId);
            }                                                          
            if (objPaymentTypeMasterDAL.CreateDateTime != null)
            {
                this.CreateDateTime = objPaymentTypeMasterDAL.CreateDateTime.ToString("yyyy-MM-dd");
            }
            if (objPaymentTypeMasterDAL.linktoUserMasterIdCreatedBy != null)
            {
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objPaymentTypeMasterDAL.linktoUserMasterIdCreatedBy);
            }
            if (objPaymentTypeMasterDAL.linktoUserMasterIdUpdatedBy != null)
            {
                this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objPaymentTypeMasterDAL.linktoUserMasterIdUpdatedBy);
            }
            if (objPaymentTypeMasterDAL.UpdateDateTime != null)
            {
                this.UpdateDateTime = objPaymentTypeMasterDAL.UpdateDateTime.Value.ToString("yyyy-MM-dd");
            }
            this.PaymentTypeCategory = Convert.ToString(objPaymentTypeMasterDAL.PaymentTypeCategory);
            this.Business = Convert.ToString(objPaymentTypeMasterDAL.Business);
            this.UserCreatedBy = Convert.ToString(objPaymentTypeMasterDAL.UserCreatedBy);
            this.UserUpdatedBy = Convert.ToString(objPaymentTypeMasterDAL.UserUpdatedBy);

        }


        internal static List<PaymentTypeMaster> SetListObject(List<poswPaymentTypeMasterDAL> lstPaymentTypeMasterDAL)
        {

            List<PaymentTypeMaster> lstPaymentTypeMaster = new List<PaymentTypeMaster>();
            PaymentTypeMaster objPaymentTypeMaster = null;

            foreach (poswPaymentTypeMasterDAL objPaymentTypeMasterDAL in lstPaymentTypeMasterDAL)
            {
                objPaymentTypeMaster = new PaymentTypeMaster();
objPaymentTypeMaster.PaymentTypeMasterId = Convert.ToInt16(objPaymentTypeMasterDAL.PaymentTypeMasterId);             
                objPaymentTypeMaster.ShortName = Convert.ToString(objPaymentTypeMasterDAL.ShortName);
                objPaymentTypeMaster.PaymentType = Convert.ToString(objPaymentTypeMasterDAL.PaymentType);
                objPaymentTypeMaster.Description = Convert.ToString(objPaymentTypeMasterDAL.Description);
                if (objPaymentTypeMasterDAL.linktoPaymentTypeCategoryMasterId != null)
                {
                    objPaymentTypeMaster.linktoPaymentTypeCategoryMasterId = Convert.ToInt16(objPaymentTypeMasterDAL.linktoPaymentTypeCategoryMasterId);
                }
                objPaymentTypeMaster.IsEnabled = Convert.ToBoolean(objPaymentTypeMasterDAL.IsEnabled);
                if (objPaymentTypeMasterDAL.linktoBusinessMasterId != null)
                {
                    objPaymentTypeMaster.linktoBusinessMasterId = Convert.ToInt16(objPaymentTypeMasterDAL.linktoBusinessMasterId);
                }
                if (objPaymentTypeMasterDAL.CreateDateTime != null)
                {
                    objPaymentTypeMaster.CreateDateTime = objPaymentTypeMasterDAL.CreateDateTime.ToString("yyyy-MM-dd");
                }
                if (objPaymentTypeMasterDAL.linktoUserMasterIdCreatedBy != null)
                {
                    objPaymentTypeMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objPaymentTypeMasterDAL.linktoUserMasterIdCreatedBy);
                }
                if (objPaymentTypeMasterDAL.linktoUserMasterIdUpdatedBy != null)
                {
                    objPaymentTypeMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objPaymentTypeMasterDAL.linktoUserMasterIdUpdatedBy);
                }
                if (objPaymentTypeMasterDAL.UpdateDateTime != null)
                {
                    objPaymentTypeMaster.UpdateDateTime = objPaymentTypeMasterDAL.UpdateDateTime.Value.ToString("yyyy-MM-dd");
                }
                objPaymentTypeMaster.PaymentTypeCategory = Convert.ToString(objPaymentTypeMasterDAL.PaymentTypeCategory);
                objPaymentTypeMaster.Business = Convert.ToString(objPaymentTypeMasterDAL.Business);
                objPaymentTypeMaster.UserCreatedBy = Convert.ToString(objPaymentTypeMasterDAL.UserCreatedBy);
                objPaymentTypeMaster.UserUpdatedBy = Convert.ToString(objPaymentTypeMasterDAL.UserUpdatedBy);

                lstPaymentTypeMaster.Add(objPaymentTypeMaster);
            }
            return lstPaymentTypeMaster;
        }
    }
}
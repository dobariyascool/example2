﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poswLibrary
{
    public class Dashboard
    {
        #region Properties
        public int linktoBusinessMasterId { get; set; }
        public int RegisteredUserBooking { get; set; }
        public int CanceledBooking { get; set; }
        public int CanceledOrder { get; set; }

        public int PreOrder { get; set; }
        #endregion

        internal void SetClassObject(poswDashboardDAL objDashboardDAL)
        {
            this.linktoBusinessMasterId = Convert.ToInt16(objDashboardDAL.linktoBusinessMasterId);
            this.RegisteredUserBooking= Convert.ToInt16(objDashboardDAL.RegisteredUserBooking);
            this.CanceledBooking = Convert.ToInt16(objDashboardDAL.CanceledBooking);
            this.CanceledOrder= Convert.ToInt16(objDashboardDAL.CanceledOrder);
            this.PreOrder= Convert.ToInt16(objDashboardDAL.PreOrder);
        }
    }
}
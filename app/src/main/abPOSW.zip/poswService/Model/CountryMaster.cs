using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for CountryMaster
	/// </summary>
	public class CountryMaster
	{
        #region Properties
        public short CountryMasterId { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public bool IsEnabled { get; set; }
        #endregion

		internal void SetClassObject(poswCountryMasterDAL objCountryMasterDAL)
		{
			this.CountryMasterId = Convert.ToInt16(objCountryMasterDAL.CountryMasterId);
			this.CountryName = Convert.ToString(objCountryMasterDAL.CountryName);
			this.CountryCode = Convert.ToString(objCountryMasterDAL.CountryCode);
			this.IsEnabled = Convert.ToBoolean(objCountryMasterDAL.IsEnabled);
		}

		internal static List<CountryMaster> SetListObject(List<poswCountryMasterDAL> lstCountryMasterDAL)
		{
			List<CountryMaster> lstCountryMaster = new List<CountryMaster>();
			CountryMaster objCountryMaster = null;
			foreach (poswCountryMasterDAL objCountryMasterDAL in lstCountryMasterDAL)
			{
				objCountryMaster = new CountryMaster();
				objCountryMaster.CountryMasterId = Convert.ToInt16(objCountryMasterDAL.CountryMasterId);
				objCountryMaster.CountryName = Convert.ToString(objCountryMasterDAL.CountryName);
				objCountryMaster.CountryCode = Convert.ToString(objCountryMasterDAL.CountryCode);
				objCountryMaster.IsEnabled = Convert.ToBoolean(objCountryMasterDAL.IsEnabled);
				lstCountryMaster.Add(objCountryMaster);
			}
			return lstCountryMaster;
		}
	}
}

using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for FeedbackQuestionMaster
	/// </summary>
	public class FeedbackQuestionMaster
	{
        public int? FeedbackQuestionMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? linktoFeedbackQuestionGroupMasterId { get; set; }
        public string FeedbackQuestion { get; set; }
        public short QuestionType { get; set; }
        public int? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }

        /// Extra
        public string Business { get; set; }
        public short QuestionCount { get; set; }
        public string GroupName { get; set; }
        public int? linktoFeedbackAnswerMasterId { get; set; }
        public string FeedbackAnswer { get; set; }

		internal void SetClassObject(poswFeedbackQuestionMasterDAL objFeedbackQuestionMasterDAL)
		{
            if (objFeedbackQuestionMasterDAL.FeedbackQuestionMasterId != null)
            {
                this.FeedbackQuestionMasterId = Convert.ToInt32(objFeedbackQuestionMasterDAL.FeedbackQuestionMasterId);
            }
			this.linktoBusinessMasterId = Convert.ToInt16(objFeedbackQuestionMasterDAL.linktoBusinessMasterId);
			if (objFeedbackQuestionMasterDAL.linktoFeedbackQuestionGroupMasterId != null)
			{
				this.linktoFeedbackQuestionGroupMasterId = Convert.ToInt16(objFeedbackQuestionMasterDAL.linktoFeedbackQuestionGroupMasterId.Value);
			}
			this.FeedbackQuestion = Convert.ToString(objFeedbackQuestionMasterDAL.FeedbackQuestion);
            this.QuestionType = Convert.ToInt16(objFeedbackQuestionMasterDAL.QuestionType);
			if (objFeedbackQuestionMasterDAL.SortOrder != null)
			{
				this.SortOrder = Convert.ToInt32(objFeedbackQuestionMasterDAL.SortOrder.Value);
			}
			this.IsEnabled = Convert.ToBoolean(objFeedbackQuestionMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objFeedbackQuestionMasterDAL.IsDeleted);

			/// Extra
			this.Business = Convert.ToString(objFeedbackQuestionMasterDAL.Business);
            this.GroupName = Convert.ToString(objFeedbackQuestionMasterDAL.GroupName);
            if (objFeedbackQuestionMasterDAL.linktoFeedbackAnswerMasterId != null)
            {
                this.linktoFeedbackAnswerMasterId = Convert.ToInt32(objFeedbackQuestionMasterDAL.linktoFeedbackAnswerMasterId);
            }
            this.FeedbackAnswer = Convert.ToString(objFeedbackQuestionMasterDAL.FeedbackAnswer);
		}

		internal static List<FeedbackQuestionMaster> SetListObject(List<poswFeedbackQuestionMasterDAL> lstFeedbackQuestionMasterDAL)
		{
			List<FeedbackQuestionMaster> lstFeedbackQuestionMaster = new List<FeedbackQuestionMaster>();
			FeedbackQuestionMaster objFeedbackQuestionMaster = null;
			foreach (poswFeedbackQuestionMasterDAL objFeedbackQuestionMasterDAL in lstFeedbackQuestionMasterDAL)
			{
				objFeedbackQuestionMaster = new FeedbackQuestionMaster();
                if (objFeedbackQuestionMasterDAL.FeedbackQuestionMasterId != null)
                {
                    objFeedbackQuestionMaster.FeedbackQuestionMasterId = Convert.ToInt32(objFeedbackQuestionMasterDAL.FeedbackQuestionMasterId);
                }
				objFeedbackQuestionMaster.linktoBusinessMasterId = Convert.ToInt16(objFeedbackQuestionMasterDAL.linktoBusinessMasterId);
				if (objFeedbackQuestionMasterDAL.linktoFeedbackQuestionGroupMasterId != null)
				{
					objFeedbackQuestionMaster.linktoFeedbackQuestionGroupMasterId = Convert.ToInt16(objFeedbackQuestionMasterDAL.linktoFeedbackQuestionGroupMasterId.Value);
				}
				objFeedbackQuestionMaster.FeedbackQuestion = Convert.ToString(objFeedbackQuestionMasterDAL.FeedbackQuestion);
                 objFeedbackQuestionMaster.QuestionType = Convert.ToInt16(objFeedbackQuestionMasterDAL.QuestionType);
				if (objFeedbackQuestionMasterDAL.SortOrder != null)
				{
					objFeedbackQuestionMaster.SortOrder = Convert.ToInt32(objFeedbackQuestionMasterDAL.SortOrder.Value);
				}
				objFeedbackQuestionMaster.IsEnabled = Convert.ToBoolean(objFeedbackQuestionMasterDAL.IsEnabled);
				objFeedbackQuestionMaster.IsDeleted = Convert.ToBoolean(objFeedbackQuestionMasterDAL.IsDeleted);

				/// Extra
				objFeedbackQuestionMaster.Business = Convert.ToString(objFeedbackQuestionMasterDAL.Business);
                objFeedbackQuestionMaster.GroupName = Convert.ToString(objFeedbackQuestionMasterDAL.GroupName);
                if (objFeedbackQuestionMasterDAL.linktoFeedbackAnswerMasterId != null)
                {
                    objFeedbackQuestionMaster.linktoFeedbackAnswerMasterId = Convert.ToInt32(objFeedbackQuestionMasterDAL.linktoFeedbackAnswerMasterId);
                }
                objFeedbackQuestionMaster.FeedbackAnswer = Convert.ToString(objFeedbackQuestionMasterDAL.FeedbackAnswer);
				lstFeedbackQuestionMaster.Add(objFeedbackQuestionMaster);
			}
			return lstFeedbackQuestionMaster;
		}
	}
}

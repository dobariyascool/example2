using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for BusinessDescription
	/// </summary>
	public class BusinessDescription
	{

        public short BusinessDescriptionId { get; set; }
        public string Keyword { get; set; }
        public string Description { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDefault { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdUpdatedBy { get; set; }
        public string UpdateDateTime { get; set; }

		/// Extra
        //public string Business { get; set; }


		internal void SetClassObject(poswBusinessDescriptionDAL objBusinessDescriptionDAL)
		{
			this.BusinessDescriptionId = Convert.ToInt16(objBusinessDescriptionDAL.BusinessDescriptionId);
			this.Keyword = Convert.ToString(objBusinessDescriptionDAL.Keyword);
			this.Description = Convert.ToString(objBusinessDescriptionDAL.Description);
			this.linktoBusinessMasterId = Convert.ToInt16(objBusinessDescriptionDAL.linktoBusinessMasterId);
			this.IsDefault = Convert.ToBoolean(objBusinessDescriptionDAL.IsDefault);
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objBusinessDescriptionDAL.linktoUserMasterIdCreatedBy);
			this.CreateDateTime = objBusinessDescriptionDAL.CreateDateTime.ToString("s");
			if (objBusinessDescriptionDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objBusinessDescriptionDAL.linktoUserMasterIdUpdatedBy.Value);
			}
			if (objBusinessDescriptionDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objBusinessDescriptionDAL.UpdateDateTime.Value.ToString("s");
			}

			/// Extra
            //this.Business = Convert.ToString(objBusinessDescriptionDAL.Business);
		}

		internal static List<BusinessDescription> SetListObject(List<poswBusinessDescriptionDAL> lstBusinessDescriptionDAL)
		{
			List<BusinessDescription> lstBusinessDescription = new List<BusinessDescription>();
			BusinessDescription objBusinessDescription = null;
			foreach (poswBusinessDescriptionDAL objBusinessDescriptionDAL in lstBusinessDescriptionDAL)
			{
				objBusinessDescription = new BusinessDescription();
				objBusinessDescription.BusinessDescriptionId = Convert.ToInt16(objBusinessDescriptionDAL.BusinessDescriptionId);
				objBusinessDescription.Keyword = Convert.ToString(objBusinessDescriptionDAL.Keyword);
				objBusinessDescription.Description = Convert.ToString(objBusinessDescriptionDAL.Description);
				objBusinessDescription.linktoBusinessMasterId = Convert.ToInt16(objBusinessDescriptionDAL.linktoBusinessMasterId);
				objBusinessDescription.IsDefault = Convert.ToBoolean(objBusinessDescriptionDAL.IsDefault);
				objBusinessDescription.linktoUserMasterIdCreatedBy = Convert.ToInt16(objBusinessDescriptionDAL.linktoUserMasterIdCreatedBy);
				objBusinessDescription.CreateDateTime = objBusinessDescriptionDAL.CreateDateTime.ToString("s");
				if (objBusinessDescriptionDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objBusinessDescription.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objBusinessDescriptionDAL.linktoUserMasterIdUpdatedBy.Value);
				}
				if (objBusinessDescriptionDAL.UpdateDateTime != null)
				{
					objBusinessDescription.UpdateDateTime = objBusinessDescriptionDAL.UpdateDateTime.Value.ToString("s");
				}

				/// Extra
				//objBusinessDescription.Business = Convert.ToString(objBusinessDescriptionDAL.Business);
				lstBusinessDescription.Add(objBusinessDescription);
			}
			return lstBusinessDescription;
		}
	}
}

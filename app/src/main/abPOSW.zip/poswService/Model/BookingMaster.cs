using System;
using System.Collections.Generic;

namespace poswLibrary
{
	public class BookingMaster
	{
        public int BookingMasterId { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
        public bool IsHourly { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string BookingPersonName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public short NoOfAdults { get; set; }
        public short NoOfChildren { get; set; }
        public double TotalAmount { get; set; }
        public short DiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double ExtraAmount { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double BalanceAmount { get; set; }
        public string Remark { get; set; }
        public bool IsPreOrder { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDeleted { get; set; }
        public short BookingStatus { get; set; }
        public string TimeSlot { get; set; }
		/// Extra
        //public string UserCreatedBy { get; set; }
        //public string UserUpdatedBy { get; set; }
        //public string Business { get; set; }


		internal void SetClassObject(poswBookingMasterDAL objBookingMasterDAL)
		{
			this.BookingMasterId = Convert.ToInt32(objBookingMasterDAL.BookingMasterId);
			this.FromDate = objBookingMasterDAL.FromDate.ToString("yyyy-MM-dd");
			this.ToDate = objBookingMasterDAL.ToDate.ToString("yyyy-MM-dd");
			if (objBookingMasterDAL.FromTime != null)
			{
				this.FromTime = new DateTime().Add(objBookingMasterDAL.FromTime.Value).ToString("HH:mm:ss");
			}
			if (objBookingMasterDAL.ToTime != null)
			{
				this.ToTime = new DateTime().Add(objBookingMasterDAL.ToTime.Value).ToString("HH:mm:ss");
			}
			if (objBookingMasterDAL.IsHourly != null)
			{
				this.IsHourly = Convert.ToBoolean(objBookingMasterDAL.IsHourly.Value);
			}
			if (objBookingMasterDAL.linktoCustomerMasterId != null)
			{
				this.linktoCustomerMasterId = Convert.ToInt32(objBookingMasterDAL.linktoCustomerMasterId.Value);
			}
			this.BookingPersonName = Convert.ToString(objBookingMasterDAL.BookingPersonName);
			this.Email = Convert.ToString(objBookingMasterDAL.Email);
			this.Phone = Convert.ToString(objBookingMasterDAL.Phone);
			this.NoOfAdults = Convert.ToInt16(objBookingMasterDAL.NoOfAdults);
			this.NoOfChildren = Convert.ToInt16(objBookingMasterDAL.NoOfChildren);
			this.TotalAmount = Convert.ToDouble(objBookingMasterDAL.TotalAmount);
			this.DiscountPercentage = Convert.ToInt16(objBookingMasterDAL.DiscountPercentage);
			this.DiscountAmount = Convert.ToDouble(objBookingMasterDAL.DiscountAmount);
			this.ExtraAmount = Convert.ToDouble(objBookingMasterDAL.ExtraAmount);
			this.NetAmount = Convert.ToDouble(objBookingMasterDAL.NetAmount);
			this.PaidAmount = Convert.ToDouble(objBookingMasterDAL.PaidAmount);
			this.BalanceAmount = Convert.ToDouble(objBookingMasterDAL.BalanceAmount);
			this.Remark = Convert.ToString(objBookingMasterDAL.Remark);
			if (objBookingMasterDAL.IsPreOrder != null)
			{
				this.IsPreOrder = Convert.ToBoolean(objBookingMasterDAL.IsPreOrder.Value);
			}
			this.CreateDateTime = objBookingMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objBookingMasterDAL.linktoUserMasterIdCreatedBy);
			if (objBookingMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objBookingMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objBookingMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objBookingMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}
			this.linktoBusinessMasterId = Convert.ToInt16(objBookingMasterDAL.linktoBusinessMasterId);
			this.IsDeleted = Convert.ToBoolean(objBookingMasterDAL.IsDeleted);
			if (objBookingMasterDAL.BookingStatus != null)
			{
				this.BookingStatus = Convert.ToInt16(objBookingMasterDAL.BookingStatus.Value);
			}
            this.TimeSlot = new DateTime().Add(objBookingMasterDAL.TimeSlot).ToString("HH:mm:ss");

			/// Extra
            //this.UserCreatedBy = Convert.ToString(objBookingMasterDAL.UserCreatedBy);
            //this.UserUpdatedBy = Convert.ToString(objBookingMasterDAL.UserUpdatedBy);
            //this.Business = Convert.ToString(objBookingMasterDAL.Business);
		}

		internal static List<BookingMaster> SetListObject(List<poswBookingMasterDAL> lstBookingMasterDAL)
		{
			List<BookingMaster> lstBookingMaster = new List<BookingMaster>();
			BookingMaster objBookingMaster = null;
			foreach (poswBookingMasterDAL objBookingMasterDAL in lstBookingMasterDAL)
			{
				objBookingMaster = new BookingMaster();
				objBookingMaster.BookingMasterId = Convert.ToInt32(objBookingMasterDAL.BookingMasterId);
				objBookingMaster.FromDate = objBookingMasterDAL.FromDate.ToString("yyyy-MM-dd");
				objBookingMaster.ToDate = objBookingMasterDAL.ToDate.ToString("yyyy-MM-dd");
				if (objBookingMasterDAL.FromTime != null)
				{
                    objBookingMaster.FromTime = new DateTime().Add(objBookingMasterDAL.FromTime.Value).ToString("HH:mm:ss");
				}
				if (objBookingMasterDAL.ToTime != null)
				{
                    objBookingMaster.ToTime = new DateTime().Add(objBookingMasterDAL.ToTime.Value).ToString("HH:mm:ss");
				}
				if (objBookingMasterDAL.IsHourly != null)
				{
					objBookingMaster.IsHourly = Convert.ToBoolean(objBookingMasterDAL.IsHourly.Value);
				}
				if (objBookingMasterDAL.linktoCustomerMasterId != null)
				{
					objBookingMaster.linktoCustomerMasterId = Convert.ToInt32(objBookingMasterDAL.linktoCustomerMasterId.Value);
				}
				objBookingMaster.BookingPersonName = Convert.ToString(objBookingMasterDAL.BookingPersonName);
				objBookingMaster.Email = Convert.ToString(objBookingMasterDAL.Email);
				objBookingMaster.Phone = Convert.ToString(objBookingMasterDAL.Phone);
				objBookingMaster.NoOfAdults = Convert.ToInt16(objBookingMasterDAL.NoOfAdults);
				objBookingMaster.NoOfChildren = Convert.ToInt16(objBookingMasterDAL.NoOfChildren);
				objBookingMaster.TotalAmount = Convert.ToDouble(objBookingMasterDAL.TotalAmount);
				objBookingMaster.DiscountPercentage = Convert.ToInt16(objBookingMasterDAL.DiscountPercentage);
				objBookingMaster.DiscountAmount = Convert.ToDouble(objBookingMasterDAL.DiscountAmount);
				objBookingMaster.ExtraAmount = Convert.ToDouble(objBookingMasterDAL.ExtraAmount);
				objBookingMaster.NetAmount = Convert.ToDouble(objBookingMasterDAL.NetAmount);
				objBookingMaster.PaidAmount = Convert.ToDouble(objBookingMasterDAL.PaidAmount);
				objBookingMaster.BalanceAmount = Convert.ToDouble(objBookingMasterDAL.BalanceAmount);
				objBookingMaster.Remark = Convert.ToString(objBookingMasterDAL.Remark);
				if (objBookingMasterDAL.IsPreOrder != null)
				{
					objBookingMaster.IsPreOrder = Convert.ToBoolean(objBookingMasterDAL.IsPreOrder.Value);
				}
				objBookingMaster.CreateDateTime = objBookingMasterDAL.CreateDateTime.ToString("s");
				objBookingMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objBookingMasterDAL.linktoUserMasterIdCreatedBy);
				if (objBookingMasterDAL.UpdateDateTime != null)
				{
					objBookingMaster.UpdateDateTime = objBookingMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objBookingMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objBookingMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objBookingMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}
				objBookingMaster.linktoBusinessMasterId = Convert.ToInt16(objBookingMasterDAL.linktoBusinessMasterId);
				objBookingMaster.IsDeleted = Convert.ToBoolean(objBookingMasterDAL.IsDeleted);
				if (objBookingMasterDAL.BookingStatus != null)
				{
					objBookingMaster.BookingStatus = Convert.ToInt16(objBookingMasterDAL.BookingStatus.Value);
				}
                objBookingMaster.TimeSlot = new DateTime().Add(objBookingMasterDAL.TimeSlot).ToString("HH:mm:ss");

				/// Extra
                //objBookingMaster.UserCreatedBy = Convert.ToString(objBookingMasterDAL.UserCreatedBy);
                //objBookingMaster.UserUpdatedBy = Convert.ToString(objBookingMasterDAL.UserUpdatedBy);
                //objBookingMaster.Business = Convert.ToString(objBookingMasterDAL.Business);
				lstBookingMaster.Add(objBookingMaster);
			}
			return lstBookingMaster;
		}
	}
}

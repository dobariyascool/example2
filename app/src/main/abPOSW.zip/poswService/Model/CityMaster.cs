using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for CityMaster
	/// </summary>
	public class CityMaster
	{
        public short CityMasterId { get; set; }
        public string CityName { get; set; }
        public string CityCode { get; set; }
        public short linktoStateMasterId { get; set; }
        public bool IsEnabled { get; set; }
		/// Extra
        public string StateName { get; set; }
        public short CountryMasterID { get; set; }


		internal void SetClassObject(poswCityMasterDAL objCityMasterDAL)
		{
			this.CityMasterId = Convert.ToInt16(objCityMasterDAL.CityMasterId);
			this.CityName = Convert.ToString(objCityMasterDAL.CityName);
			this.CityCode = Convert.ToString(objCityMasterDAL.CityCode);
			this.linktoStateMasterId = Convert.ToInt16(objCityMasterDAL.linktoStateMasterId);
			this.IsEnabled = Convert.ToBoolean(objCityMasterDAL.IsEnabled);

			/// Extra
            this.StateName = Convert.ToString(objCityMasterDAL.StateName);
            this.CountryMasterID = Convert.ToInt16(objCityMasterDAL.CountryMasterID);
		}

		internal static List<CityMaster> SetListObject(List<poswCityMasterDAL> lstCityMasterDAL)
		{
			List<CityMaster> lstCityMaster = new List<CityMaster>();
			CityMaster objCityMaster = null;
			foreach (poswCityMasterDAL objCityMasterDAL in lstCityMasterDAL)
			{
				objCityMaster = new CityMaster();
				objCityMaster.CityMasterId = Convert.ToInt16(objCityMasterDAL.CityMasterId);
				objCityMaster.CityName = Convert.ToString(objCityMasterDAL.CityName);
				objCityMaster.CityCode = Convert.ToString(objCityMasterDAL.CityCode);
				objCityMaster.linktoStateMasterId = Convert.ToInt16(objCityMasterDAL.linktoStateMasterId);
				objCityMaster.IsEnabled = Convert.ToBoolean(objCityMasterDAL.IsEnabled);

				/// Extra
                objCityMaster.StateName = Convert.ToString(objCityMasterDAL.StateName);
                objCityMaster.CountryMasterID = Convert.ToInt16(objCityMasterDAL.CountryMasterID);
				lstCityMaster.Add(objCityMaster);
			}
			return lstCityMaster;
		}
	}
}

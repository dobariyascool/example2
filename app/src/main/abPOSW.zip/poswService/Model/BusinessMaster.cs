using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for BusinessMaster
	/// </summary>
	public class BusinessMaster
	{
        public short BusinessMasterId { get; set; }
        public short linktoBusinessGroupMasterId { get; set; }
        public string BusinessName { get; set; }
        public string BusinessShortName { get; set; }
        public string Address { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Email { get; set; }
        public string Fax { get; set; }
        public string Website { get; set; }
        public short linktoCountryMasterId { get; set; }
        public short linktoStateMasterId { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string ImageName { get; set; }
        public string ExtraText { get; set; }
        public string TIN { get; set; }
        public string TINRegistrationDate { get; set; }
        public string CST { get; set; }
        public string CSTRegistrationDate { get; set; }
        public string PAN { get; set; }
        public string PANRegistrationDate { get; set; }
        public string TDS { get; set; }
        public string TDSRegistrationDate { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        public string UniqueId { get; set; }
        public bool IsEnabled { get; set; }
        public string ImagePhysicalName { get; set; }
        public string CreateDateTime { get; set; }

        /// Extra
        public string Country { get; set; }
        public string State { get; set; }
        public string BusinessType { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public string BusinessGroup { get; set; }

		internal void SetClassObject(poswBusinessMasterDAL objBusinessMasterDAL)
		{
			this.BusinessMasterId = Convert.ToInt16(objBusinessMasterDAL.BusinessMasterId);
            if (objBusinessMasterDAL.linktoBusinessGroupMasterId != null)
            {
                this.linktoBusinessGroupMasterId = Convert.ToInt16(objBusinessMasterDAL.linktoBusinessGroupMasterId);
            }
			this.BusinessName = Convert.ToString(objBusinessMasterDAL.BusinessName);
			this.BusinessShortName = Convert.ToString(objBusinessMasterDAL.BusinessShortName);
			this.Address = Convert.ToString(objBusinessMasterDAL.Address);
			this.Phone1 = Convert.ToString(objBusinessMasterDAL.Phone1);
			this.Phone2 = Convert.ToString(objBusinessMasterDAL.Phone2);
			this.Email = Convert.ToString(objBusinessMasterDAL.Email);
			this.Fax = Convert.ToString(objBusinessMasterDAL.Fax);
			this.Website = Convert.ToString(objBusinessMasterDAL.Website);
			this.linktoCountryMasterId = Convert.ToInt16(objBusinessMasterDAL.linktoCountryMasterId);
			this.linktoStateMasterId = Convert.ToInt16(objBusinessMasterDAL.linktoStateMasterId);
			this.City = Convert.ToString(objBusinessMasterDAL.City);
			this.ZipCode = Convert.ToString(objBusinessMasterDAL.ZipCode);
			this.ImageName = Convert.ToString(objBusinessMasterDAL.ImageName);
			this.ExtraText = Convert.ToString(objBusinessMasterDAL.ExtraText);
			this.TIN = Convert.ToString(objBusinessMasterDAL.TIN);
			if (objBusinessMasterDAL.TINRegistrationDate != null)
			{
				this.TINRegistrationDate = objBusinessMasterDAL.TINRegistrationDate.Value.ToString("yyyy-MM-dd");
			}
			this.CST = Convert.ToString(objBusinessMasterDAL.CST);
			if (objBusinessMasterDAL.CSTRegistrationDate != null)
			{
				this.CSTRegistrationDate = objBusinessMasterDAL.CSTRegistrationDate.Value.ToString("yyyy-MM-dd");
			}
			this.PAN = Convert.ToString(objBusinessMasterDAL.PAN);
			if (objBusinessMasterDAL.PANRegistrationDate != null)
			{
				this.PANRegistrationDate = objBusinessMasterDAL.PANRegistrationDate.Value.ToString("yyyy-MM-dd");
			}
			this.TDS = Convert.ToString(objBusinessMasterDAL.TDS);
			if (objBusinessMasterDAL.TDSRegistrationDate != null)
			{
				this.TDSRegistrationDate = objBusinessMasterDAL.TDSRegistrationDate.Value.ToString("yyyy-MM-dd");
			}
			this.linktoBusinessTypeMasterId = Convert.ToInt16(objBusinessMasterDAL.linktoBusinessTypeMasterId);
			this.UniqueId = Convert.ToString(objBusinessMasterDAL.UniqueId);
			this.IsEnabled = Convert.ToBoolean(objBusinessMasterDAL.IsEnabled);
            this.CreateDateTime = objBusinessMasterDAL.CreateDateTime.Value.ToString("yyyy-MM-dd");

			/// Extra
			this.Country = Convert.ToString(objBusinessMasterDAL.Country);
			this.State = Convert.ToString(objBusinessMasterDAL.State);
			this.BusinessType = Convert.ToString(objBusinessMasterDAL.BusinessType);
            this.xs_ImagePhysicalName = objBusinessMasterDAL.xs_ImagePhysicalName;
            this.sm_ImagePhysicalName = objBusinessMasterDAL.sm_ImagePhysicalName;
            this.md_ImagePhysicalName = objBusinessMasterDAL.md_ImagePhysicalName;
            this.lg_ImagePhysicalName = objBusinessMasterDAL.lg_ImagePhysicalName;
            this.xl_ImagePhysicalName = objBusinessMasterDAL.xl_ImagePhysicalName;
            this.BusinessGroup = objBusinessMasterDAL.BusinessGroup;

		}

		internal static List<BusinessMaster> SetListObject(List<poswBusinessMasterDAL> lstBusinessMasterDAL)
		{
			List<BusinessMaster> lstBusinessMaster = new List<BusinessMaster>();
			BusinessMaster objBusinessMaster = null;
			foreach (poswBusinessMasterDAL objBusinessMasterDAL in lstBusinessMasterDAL)
			{
				objBusinessMaster = new BusinessMaster();
				objBusinessMaster.BusinessMasterId = Convert.ToInt16(objBusinessMasterDAL.BusinessMasterId);
                if (objBusinessMasterDAL.linktoBusinessGroupMasterId != null)
                {
                    objBusinessMaster.linktoBusinessGroupMasterId = Convert.ToInt16(objBusinessMasterDAL.linktoBusinessGroupMasterId);
                }
				objBusinessMaster.BusinessName = Convert.ToString(objBusinessMasterDAL.BusinessName);
				objBusinessMaster.BusinessShortName = Convert.ToString(objBusinessMasterDAL.BusinessShortName);
				objBusinessMaster.Address = Convert.ToString(objBusinessMasterDAL.Address);
				objBusinessMaster.Phone1 = Convert.ToString(objBusinessMasterDAL.Phone1);
				objBusinessMaster.Phone2 = Convert.ToString(objBusinessMasterDAL.Phone2);
				objBusinessMaster.Email = Convert.ToString(objBusinessMasterDAL.Email);
				objBusinessMaster.Fax = Convert.ToString(objBusinessMasterDAL.Fax);
				objBusinessMaster.Website = Convert.ToString(objBusinessMasterDAL.Website);
				objBusinessMaster.linktoCountryMasterId = Convert.ToInt16(objBusinessMasterDAL.linktoCountryMasterId);
				objBusinessMaster.linktoStateMasterId = Convert.ToInt16(objBusinessMasterDAL.linktoStateMasterId);
				objBusinessMaster.City = Convert.ToString(objBusinessMasterDAL.City);
				objBusinessMaster.ZipCode = Convert.ToString(objBusinessMasterDAL.ZipCode);
				objBusinessMaster.ImageName = Convert.ToString(objBusinessMasterDAL.ImageName);
				objBusinessMaster.ExtraText = Convert.ToString(objBusinessMasterDAL.ExtraText);
				objBusinessMaster.TIN = Convert.ToString(objBusinessMasterDAL.TIN);
				if (objBusinessMasterDAL.TINRegistrationDate != null)
				{
					objBusinessMaster.TINRegistrationDate = objBusinessMasterDAL.TINRegistrationDate.Value.ToString("yyyy-MM-dd");
				}
				objBusinessMaster.CST = Convert.ToString(objBusinessMasterDAL.CST);
				if (objBusinessMasterDAL.CSTRegistrationDate != null)
				{
					objBusinessMaster.CSTRegistrationDate = objBusinessMasterDAL.CSTRegistrationDate.Value.ToString("yyyy-MM-dd");
				}
				objBusinessMaster.PAN = Convert.ToString(objBusinessMasterDAL.PAN);
				if (objBusinessMasterDAL.PANRegistrationDate != null)
				{
					objBusinessMaster.PANRegistrationDate = objBusinessMasterDAL.PANRegistrationDate.Value.ToString("yyyy-MM-dd");
				}
				objBusinessMaster.TDS = Convert.ToString(objBusinessMasterDAL.TDS);
				if (objBusinessMasterDAL.TDSRegistrationDate != null)
				{
					objBusinessMaster.TDSRegistrationDate = objBusinessMasterDAL.TDSRegistrationDate.Value.ToString("yyyy-MM-dd");
				}
				objBusinessMaster.linktoBusinessTypeMasterId = Convert.ToInt16(objBusinessMasterDAL.linktoBusinessTypeMasterId);
				objBusinessMaster.UniqueId = Convert.ToString(objBusinessMasterDAL.UniqueId);
				objBusinessMaster.IsEnabled = Convert.ToBoolean(objBusinessMasterDAL.IsEnabled);
                objBusinessMaster.CreateDateTime = objBusinessMasterDAL.CreateDateTime.Value.ToString("yyyy-MM-dd");

				/// Extra
				objBusinessMaster.Country = Convert.ToString(objBusinessMasterDAL.Country);
				objBusinessMaster.State = Convert.ToString(objBusinessMasterDAL.State);
				objBusinessMaster.BusinessType = Convert.ToString(objBusinessMasterDAL.BusinessType);
                objBusinessMaster.xs_ImagePhysicalName = objBusinessMasterDAL.xs_ImagePhysicalName;
                objBusinessMaster.sm_ImagePhysicalName = objBusinessMasterDAL.sm_ImagePhysicalName;
                objBusinessMaster.md_ImagePhysicalName = objBusinessMasterDAL.md_ImagePhysicalName;
                objBusinessMaster.lg_ImagePhysicalName = objBusinessMasterDAL.lg_ImagePhysicalName;
                objBusinessMaster.xl_ImagePhysicalName = objBusinessMasterDAL.xl_ImagePhysicalName;
                objBusinessMaster.BusinessGroup = objBusinessMasterDAL.BusinessGroup;
				lstBusinessMaster.Add(objBusinessMaster);
			}
			return lstBusinessMaster;
		}
	}
}

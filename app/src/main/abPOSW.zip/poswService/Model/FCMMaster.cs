using System;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Model for FCMMaster
    /// </summary>
    public class FCMMaster
    {
        public long FCMMasterId { get; set; }
        public string FCMToken { get; set; }
        public string CreateDateTime { get; set; }
        public string UpdateDateTime { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }

        /// Extra


        internal void SetClassObject(poswFCMMasterDAL objFCMMasterDAL)
        {
            this.FCMMasterId = Convert.ToInt64(objFCMMasterDAL.FCMMasterId);
            this.FCMToken = Convert.ToString(objFCMMasterDAL.FCMToken);
            this.CreateDateTime = objFCMMasterDAL.CreateDateTime.ToString("s");
            this.UpdateDateTime = objFCMMasterDAL.UpdateDateTime.ToString("s");
            if (objFCMMasterDAL.linktoCustomerMasterId != null)
            {
                this.linktoCustomerMasterId = Convert.ToInt32(objFCMMasterDAL.linktoCustomerMasterId.Value);
            }
            this.linktoBusinessMasterId = objFCMMasterDAL.linktoBusinessMasterId;
            /// Extra

        }

        internal static List<FCMMaster> SetListObject(List<poswFCMMasterDAL> lstFCMMasterDAL)
        {
            List<FCMMaster> lstFCMMaster = new List<FCMMaster>();
            FCMMaster objFCMMaster = null;
            foreach (poswFCMMasterDAL objFCMMasterDAL in lstFCMMasterDAL)
            {
                objFCMMaster = new FCMMaster();
                objFCMMaster.FCMMasterId = Convert.ToInt64(objFCMMasterDAL.FCMMasterId);
                objFCMMaster.FCMToken = Convert.ToString(objFCMMasterDAL.FCMToken);
                objFCMMaster.CreateDateTime = objFCMMasterDAL.CreateDateTime.ToString("s");
                objFCMMaster.UpdateDateTime = objFCMMasterDAL.UpdateDateTime.ToString("s");
                if (objFCMMasterDAL.linktoCustomerMasterId != null)
                {
                    objFCMMaster.linktoCustomerMasterId = Convert.ToInt32(objFCMMasterDAL.linktoCustomerMasterId.Value);
                }
                objFCMMaster.linktoBusinessMasterId = objFCMMasterDAL.linktoBusinessMasterId;
                /// Extra

                lstFCMMaster.Add(objFCMMaster);
            }
            return lstFCMMaster;
        }
    }
}

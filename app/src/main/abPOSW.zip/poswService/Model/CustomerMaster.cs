using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for CustomerMaster
	/// </summary>
	public class CustomerMaster
	{
        public int CustomerMasterId { get; set; }
        public string ShortName { get; set; }
        public string CustomerName { get; set; }
        public string Password { get; set; }
        public string Description { get; set; }
        public string ContactPersonName { get; set; }
        public string Designation { get; set; }
        public string Address { get; set; }
        public short? linktoCountryMasterId { get; set; }
        public short? linktoStateMasterId { get; set; }
        public short? linktoCityMasterId { get; set; }
        public short? linktoAreaMasterId { get; set; }
        public string ZipCode { get; set; }
        public string Phone1 { get; set; }
        public bool IsPhone1DND { get; set; }
        public string Phone2 { get; set; }
        public bool? IsPhone2DND { get; set; }
        public string Email1 { get; set; }
        public string Email2 { get; set; }
        public string Fax { get; set; }
        public string ImageName { get; set; }
        public string BirthDate { get; set; }
        public string AnniversaryDate { get; set; }
        public short CustomerType { get; set; }
        public bool? IsFavourite { get; set; }
        public bool? IsCredit { get; set; }
        public double OpeningBalance { get; set; }
        public short CreditDays { get; set; }
        public double CreditBalance { get; set; }
        public double CreditLimit { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public string LastLoginDateTime { get; set; }
        public short linktoSourceMasterId { get; set; }
        public string Gender { get; set; }
        public string Remark { get; set; }
		
        /// Extra
        public string oldPassword { get; set; }
        public bool IsPrimary { get; set; }
        public string ImageNamePhysicalNameBytes { get; set; }
        public string ImagePhysicalName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public string PrimaryAddress { get; set; }
        public string GooglePlusUserId { get; set; }
        public string FacebookUserId { get; set; }
        public int? AgeMinRange { get; set; }
        public int? AgeMaxRange { get; set; }
        public bool? IsVerified { get; set; }
        public string ErrorCode { get; set; }
        public bool IsSignIn { get; set; }
        public string FCMToken { get; set; }

		internal void SetClassObject(poswCustomerMasterDAL objCustomerMasterDAL)
		{
			this.CustomerMasterId = Convert.ToInt32(objCustomerMasterDAL.CustomerMasterId);
			this.ShortName = Convert.ToString(objCustomerMasterDAL.ShortName);
			this.CustomerName = Convert.ToString(objCustomerMasterDAL.CustomerName);
			this.Description = Convert.ToString(objCustomerMasterDAL.Description);
			this.ContactPersonName = Convert.ToString(objCustomerMasterDAL.ContactPersonName);
			this.Designation = Convert.ToString(objCustomerMasterDAL.Designation);
			this.Phone1 = Convert.ToString(objCustomerMasterDAL.Phone1);
			this.IsPhone1DND = Convert.ToBoolean(objCustomerMasterDAL.IsPhone1DND);
			this.Phone2 = Convert.ToString(objCustomerMasterDAL.Phone2);
			if (objCustomerMasterDAL.IsPhone2DND != null)
			{
				this.IsPhone2DND = Convert.ToBoolean(objCustomerMasterDAL.IsPhone2DND.Value);
			}
			this.Email1 = Convert.ToString(objCustomerMasterDAL.Email1);
			this.Email2 = Convert.ToString(objCustomerMasterDAL.Email2);
			this.Fax = Convert.ToString(objCustomerMasterDAL.Fax);
			if (objCustomerMasterDAL.BirthDate != null)
			{
				this.BirthDate = objCustomerMasterDAL.BirthDate.Value.ToString("yyyy-MM-dd");
			}
			if (objCustomerMasterDAL.AnniversaryDate != null)
			{
                this.AnniversaryDate = objCustomerMasterDAL.AnniversaryDate.Value.ToString("yyyy-MM-dd");
			}
			this.CustomerType = Convert.ToInt16(objCustomerMasterDAL.CustomerType);
			if (objCustomerMasterDAL.IsFavourite != null)
			{
				this.IsFavourite = Convert.ToBoolean(objCustomerMasterDAL.IsFavourite.Value);
			}
			if (objCustomerMasterDAL.IsCredit != null)
			{
				this.IsCredit = Convert.ToBoolean(objCustomerMasterDAL.IsCredit.Value);
			}
			this.OpeningBalance = Convert.ToDouble(objCustomerMasterDAL.OpeningBalance);
			this.CreditDays = Convert.ToInt16(objCustomerMasterDAL.CreditDays);
			this.CreditBalance = Convert.ToDouble(objCustomerMasterDAL.CreditBalance);
			this.CreditLimit = Convert.ToDouble(objCustomerMasterDAL.CreditLimit);
			this.linktoBusinessMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoBusinessMasterId);
            this.CreateDateTime = objCustomerMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objCustomerMasterDAL.linktoUserMasterIdCreatedBy);
			if (objCustomerMasterDAL.UpdateDateTime != null)
			{
                this.UpdateDateTime = objCustomerMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objCustomerMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objCustomerMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}
			this.IsEnabled = Convert.ToBoolean(objCustomerMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objCustomerMasterDAL.IsDeleted);
			this.Gender = Convert.ToString(objCustomerMasterDAL.Gender);
			this.Password = Convert.ToString(objCustomerMasterDAL.Password);
			this.linktoSourceMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoSourceMasterId);			
			if (objCustomerMasterDAL.LastLoginDateTime != null)
			{
				this.LastLoginDateTime = objCustomerMasterDAL.LastLoginDateTime.Value.ToString("s");
			}
            this.ImageName = objCustomerMasterDAL.ImageName;
            if(!objCustomerMasterDAL.ImagePhysicalName.Equals("img/NoImage.png"))
            {
                this.ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImagePhysicalName);
                this.xs_ImagePhysicalName = objCustomerMasterDAL.xs_ImagePhysicalName;
                this.sm_ImagePhysicalName = objCustomerMasterDAL.sm_ImagePhysicalName;
                this.md_ImagePhysicalName = objCustomerMasterDAL.md_ImagePhysicalName;
                this.lg_ImagePhysicalName = objCustomerMasterDAL.lg_ImagePhysicalName;
                this.xl_ImagePhysicalName = objCustomerMasterDAL.xl_ImagePhysicalName;
            }
            if (objCustomerMasterDAL.AgeMaxRange != null)
            {
                this.AgeMaxRange = Convert.ToInt32(objCustomerMasterDAL.AgeMaxRange);
            }
            else
            {
                this.AgeMaxRange = 0;
            }

            if (objCustomerMasterDAL.AgeMinRange != null)
            {
                this.AgeMinRange = Convert.ToInt32(objCustomerMasterDAL.AgeMinRange);
            }
            else
            {
                this.AgeMinRange = 0;
            }

            this.FacebookUserId = objCustomerMasterDAL.FacebookUserId;
            this.GooglePlusUserId = objCustomerMasterDAL.GooglePlusUserId;
            if (objCustomerMasterDAL.IsVerified != null)
            {
                this.IsVerified = objCustomerMasterDAL.IsVerified;
            }
            else
            {

                this.IsVerified = false;
            }
			/// Extra
			
		}

		internal static List<CustomerMaster> SetListObject(List<poswCustomerMasterDAL> lstCustomerMasterDAL)
		{
			List<CustomerMaster> lstCustomerMaster = new List<CustomerMaster>();
			CustomerMaster objCustomerMaster = null;
			foreach (poswCustomerMasterDAL objCustomerMasterDAL in lstCustomerMasterDAL)
			{
				objCustomerMaster = new CustomerMaster();
				objCustomerMaster.CustomerMasterId = Convert.ToInt32(objCustomerMasterDAL.CustomerMasterId);
				objCustomerMaster.ShortName = Convert.ToString(objCustomerMasterDAL.ShortName);
				objCustomerMaster.CustomerName = Convert.ToString(objCustomerMasterDAL.CustomerName);
				objCustomerMaster.Description = Convert.ToString(objCustomerMasterDAL.Description);
				objCustomerMaster.ContactPersonName = Convert.ToString(objCustomerMasterDAL.ContactPersonName);
				objCustomerMaster.Designation = Convert.ToString(objCustomerMasterDAL.Designation);
				objCustomerMaster.Phone1 = Convert.ToString(objCustomerMasterDAL.Phone1);
				objCustomerMaster.IsPhone1DND = Convert.ToBoolean(objCustomerMasterDAL.IsPhone1DND);
				objCustomerMaster.Phone2 = Convert.ToString(objCustomerMasterDAL.Phone2);
				if (objCustomerMasterDAL.IsPhone2DND != null)
				{
					objCustomerMaster.IsPhone2DND = Convert.ToBoolean(objCustomerMasterDAL.IsPhone2DND.Value);
				}
				objCustomerMaster.Email1 = Convert.ToString(objCustomerMasterDAL.Email1);
				objCustomerMaster.Email2 = Convert.ToString(objCustomerMasterDAL.Email2);
				objCustomerMaster.Fax = Convert.ToString(objCustomerMasterDAL.Fax);
				objCustomerMaster.ImageName = Convert.ToString(objCustomerMasterDAL.ImageName);
				if (objCustomerMasterDAL.BirthDate != null)
				{
					objCustomerMaster.BirthDate = objCustomerMasterDAL.BirthDate.Value.ToString("yyyy-MM-dd");
				}
				if (objCustomerMasterDAL.AnniversaryDate != null)
				{
					objCustomerMaster.AnniversaryDate = objCustomerMasterDAL.AnniversaryDate.Value.ToString("yyyy-MM-dd");
				}
				objCustomerMaster.CustomerType = Convert.ToInt16(objCustomerMasterDAL.CustomerType);
                objCustomerMaster.ImageName = objCustomerMasterDAL.ImageName;
				if (objCustomerMasterDAL.IsFavourite != null)
				{
					objCustomerMaster.IsFavourite = Convert.ToBoolean(objCustomerMasterDAL.IsFavourite.Value);
				}
				if (objCustomerMasterDAL.IsCredit != null)
				{
					objCustomerMaster.IsCredit = Convert.ToBoolean(objCustomerMasterDAL.IsCredit.Value);
				}
				objCustomerMaster.OpeningBalance = Convert.ToDouble(objCustomerMasterDAL.OpeningBalance);
				objCustomerMaster.CreditDays = Convert.ToInt16(objCustomerMasterDAL.CreditDays);
				objCustomerMaster.CreditBalance = Convert.ToDouble(objCustomerMasterDAL.CreditBalance);
				objCustomerMaster.CreditLimit = Convert.ToDouble(objCustomerMasterDAL.CreditLimit);
				objCustomerMaster.linktoBusinessMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoBusinessMasterId);
				objCustomerMaster.CreateDateTime = objCustomerMasterDAL.CreateDateTime.ToString("s");
				objCustomerMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objCustomerMasterDAL.linktoUserMasterIdCreatedBy);
				if (objCustomerMasterDAL.UpdateDateTime != null)
				{
					objCustomerMaster.UpdateDateTime = objCustomerMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objCustomerMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objCustomerMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objCustomerMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}
				objCustomerMaster.IsEnabled = Convert.ToBoolean(objCustomerMasterDAL.IsEnabled);
				objCustomerMaster.IsDeleted = Convert.ToBoolean(objCustomerMasterDAL.IsDeleted);
				objCustomerMaster.Gender = Convert.ToString(objCustomerMasterDAL.Gender);
				objCustomerMaster.Password = Convert.ToString(objCustomerMasterDAL.Password);
				objCustomerMaster.linktoSourceMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoSourceMasterId);
				if (objCustomerMasterDAL.LastLoginDateTime != null)
				{
					objCustomerMaster.LastLoginDateTime = objCustomerMasterDAL.LastLoginDateTime.Value.ToString("s");
				}
                if (!objCustomerMasterDAL.ImagePhysicalName.Equals("img/NoImage.png"))
                {
                    objCustomerMaster.ImageName = Convert.ToString(objCustomerMasterDAL.ImagePhysicalName);
                    objCustomerMaster.xs_ImagePhysicalName = objCustomerMasterDAL.xs_ImagePhysicalName;
                    objCustomerMaster.sm_ImagePhysicalName = objCustomerMasterDAL.sm_ImagePhysicalName;
                    objCustomerMaster.md_ImagePhysicalName = objCustomerMasterDAL.md_ImagePhysicalName;
                    objCustomerMaster.lg_ImagePhysicalName = objCustomerMasterDAL.lg_ImagePhysicalName;
                    objCustomerMaster.xl_ImagePhysicalName = objCustomerMasterDAL.xl_ImagePhysicalName;
                }

				/// Extra
                if (objCustomerMasterDAL.AgeMaxRange != null)
                {
                    objCustomerMaster.AgeMaxRange = Convert.ToInt32(objCustomerMasterDAL.AgeMaxRange);
                }
                else
                {
                    objCustomerMaster.AgeMaxRange = 0;
                }

                if (objCustomerMasterDAL.AgeMinRange != null)
                {
                    objCustomerMaster.AgeMinRange = Convert.ToInt32(objCustomerMasterDAL.AgeMinRange);
                }
                else
                {
                    objCustomerMaster.AgeMinRange = 0;
                }
                objCustomerMaster.FacebookUserId = objCustomerMasterDAL.FacebookUserId;
                objCustomerMaster.GooglePlusUserId = objCustomerMasterDAL.GooglePlusUserId;
                if (objCustomerMasterDAL.IsVerified != null)
                {
                    objCustomerMaster.IsVerified = objCustomerMasterDAL.IsVerified;
                }
                else
                {

                    objCustomerMaster.IsVerified = false;
                }
				lstCustomerMaster.Add(objCustomerMaster);
			}
			return lstCustomerMaster;
		}
    }
}

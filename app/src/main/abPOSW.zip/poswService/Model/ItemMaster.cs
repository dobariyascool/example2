using System;
using System.Collections.Generic;

namespace poswLibrary
{

	public class ItemMaster
	{

        public int ItemMasterId { get; set; }
        public string ShortName { get; set; }
        public string ItemName { get; set; }
        public string ItemCode { get; set; }
        public string BarCode { get; set; }
        public string ShortDescription { get; set; }
        public short? linktoUnitMasterId { get; set; }
        public short linktoCategoryMasterId { get; set; }
        public double MRP { get; set; }
        public double Rate { get; set; }
        public bool IsRateTaxInclusive { get; set; }
        public bool? IsFavourite { get; set; }
        public bool IsDineInOnly { get; set; }
        public string ImageName { get; set; }
        public short ItemPoint { get; set; }
        public short PriceByPoint { get; set; }
        public string SearchWords { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short ItemType { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public string ImagePhysicalName { get; set; }

		/// Extra
		public string Unit { get; set; }
		public string Category { get; set; }
		public string Business { get; set; }
		public string UserCreatedBy { get; set; }
		public string UserUpdatedBy { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public string linktoOptionMasterIds { get; set; }
        public string linktoItemMasterIdModifiers { get; set; }
        public string Tax { get; set; }
        public int Quantity { get; set; }
        public string Remark { get; set; }
        public double TaxRate { get; set; }
        public List<ItemMaster> lstOrderItemModifierTran { get; set; }


		internal void SetClassObject(poswItemMasterDAL objItemMasterDAL)
		{
			this.ItemMasterId = Convert.ToInt32(objItemMasterDAL.ItemMasterId);
			this.ShortName = Convert.ToString(objItemMasterDAL.ShortName);
			this.ItemName = Convert.ToString(objItemMasterDAL.ItemName);
			this.ItemCode = Convert.ToString(objItemMasterDAL.ItemCode);
			this.BarCode = Convert.ToString(objItemMasterDAL.BarCode);
			this.ShortDescription = Convert.ToString(objItemMasterDAL.ShortDescription);
			if (objItemMasterDAL.linktoUnitMasterId != null)
			{
				this.linktoUnitMasterId = Convert.ToInt16(objItemMasterDAL.linktoUnitMasterId.Value);
			}
			this.linktoCategoryMasterId = Convert.ToInt16(objItemMasterDAL.linktoCategoryMasterId);
			if (objItemMasterDAL.IsFavourite != null)
			{
				this.IsFavourite = Convert.ToBoolean(objItemMasterDAL.IsFavourite.Value);
			}
            if (objItemMasterDAL.ImagePhysicalName!= null && !objItemMasterDAL.ImagePhysicalName.Equals("img/NoImage.png"))
            {
                this.ImageName = Convert.ToString(objItemMasterDAL.ImageName);
                this.ImagePhysicalName = Convert.ToString(objItemMasterDAL.ImagePhysicalName);
                this.xs_ImagePhysicalName = Convert.ToString(objItemMasterDAL.xs_ImagePhysicalName);
                this.sm_ImagePhysicalName = Convert.ToString(objItemMasterDAL.sm_ImagePhysicalName);
                this.lg_ImagePhysicalName = Convert.ToString(objItemMasterDAL.lg_ImagePhysicalName);
                this.md_ImagePhysicalName = Convert.ToString(objItemMasterDAL.md_ImagePhysicalName);
                this.xl_ImagePhysicalName = Convert.ToString(objItemMasterDAL.xl_ImagePhysicalName);
            }
			this.ItemPoint = Convert.ToInt16(objItemMasterDAL.ItemPoint);
			this.PriceByPoint = Convert.ToInt16(objItemMasterDAL.PriceByPoint);
			this.SearchWords = Convert.ToString(objItemMasterDAL.SearchWords);
			this.linktoBusinessMasterId = Convert.ToInt16(objItemMasterDAL.linktoBusinessMasterId);
            this.MRP = Convert.ToDouble(objItemMasterDAL.MRP);
            this.Rate = Convert.ToDouble(objItemMasterDAL.Rate);
			if (objItemMasterDAL.SortOrder != null)
			{
				this.SortOrder = Convert.ToInt32(objItemMasterDAL.SortOrder.Value);
			}
			this.IsEnabled = Convert.ToBoolean(objItemMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objItemMasterDAL.IsDeleted);
			this.IsDineInOnly = Convert.ToBoolean(objItemMasterDAL.IsDineInOnly);
			this.ItemType = Convert.ToInt16(objItemMasterDAL.ItemType);
			this.CreateDateTime = objItemMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objItemMasterDAL.linktoUserMasterIdCreatedBy);
			if (objItemMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objItemMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objItemMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objItemMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}

			/// Extra
			this.Unit = Convert.ToString(objItemMasterDAL.Unit);
			this.Category = Convert.ToString(objItemMasterDAL.Category);
			this.Business = Convert.ToString(objItemMasterDAL.Business);
			this.UserCreatedBy = Convert.ToString(objItemMasterDAL.UserCreatedBy);
			this.UserUpdatedBy = Convert.ToString(objItemMasterDAL.UserUpdatedBy);
            this.linktoOptionMasterIds = Convert.ToString(objItemMasterDAL.linktoOptionMasterIds);
            this.linktoItemMasterIdModifiers = Convert.ToString(objItemMasterDAL.linktoItemMasterIdModifiers);
            this.Tax = Convert.ToString(objItemMasterDAL.Tax);
            this.TaxRate = Convert.ToDouble(objItemMasterDAL.TaxRate);
            this.Quantity = Convert.ToInt32(objItemMasterDAL.Quentity);
		}

		internal static List<ItemMaster> SetListObject(List<poswItemMasterDAL> lstItemMasterDAL)
		{
			List<ItemMaster> lstItemMaster = new List<ItemMaster>();
			ItemMaster objItemMaster = null;
			foreach (poswItemMasterDAL objItemMasterDAL in lstItemMasterDAL)
			{
				objItemMaster = new ItemMaster();
				objItemMaster.ItemMasterId = Convert.ToInt32(objItemMasterDAL.ItemMasterId);
				objItemMaster.ShortName = Convert.ToString(objItemMasterDAL.ShortName);
				objItemMaster.ItemName = Convert.ToString(objItemMasterDAL.ItemName);
				objItemMaster.ItemCode = Convert.ToString(objItemMasterDAL.ItemCode);
				objItemMaster.BarCode = Convert.ToString(objItemMasterDAL.BarCode);
				objItemMaster.ShortDescription = Convert.ToString(objItemMasterDAL.ShortDescription);
				if (objItemMasterDAL.linktoUnitMasterId != null)
				{
					objItemMaster.linktoUnitMasterId = Convert.ToInt16(objItemMasterDAL.linktoUnitMasterId.Value);
				}
				objItemMaster.linktoCategoryMasterId = Convert.ToInt16(objItemMasterDAL.linktoCategoryMasterId);
				if (objItemMasterDAL.IsFavourite != null)
				{
					objItemMaster.IsFavourite = Convert.ToBoolean(objItemMasterDAL.IsFavourite.Value);
				}
                if (objItemMasterDAL.ImagePhysicalName!= null && !objItemMasterDAL.ImagePhysicalName.Equals("img/NoImage.png"))
                {
                    objItemMaster.ImageName = Convert.ToString(objItemMasterDAL.ImageName);
                    objItemMaster.ImagePhysicalName = Convert.ToString(objItemMasterDAL.ImagePhysicalName);
                    objItemMaster.xs_ImagePhysicalName = Convert.ToString(objItemMasterDAL.xs_ImagePhysicalName);
                    objItemMaster.sm_ImagePhysicalName = Convert.ToString(objItemMasterDAL.sm_ImagePhysicalName);
                    objItemMaster.lg_ImagePhysicalName = Convert.ToString(objItemMasterDAL.lg_ImagePhysicalName);
                    objItemMaster.md_ImagePhysicalName = Convert.ToString(objItemMasterDAL.md_ImagePhysicalName);
                    objItemMaster.xl_ImagePhysicalName = Convert.ToString(objItemMasterDAL.xl_ImagePhysicalName);
                }
				objItemMaster.ItemPoint = Convert.ToInt16(objItemMasterDAL.ItemPoint);
				objItemMaster.PriceByPoint = Convert.ToInt16(objItemMasterDAL.PriceByPoint);
				objItemMaster.SearchWords = Convert.ToString(objItemMasterDAL.SearchWords);
				objItemMaster.linktoBusinessMasterId = Convert.ToInt16(objItemMasterDAL.linktoBusinessMasterId);
                objItemMaster.MRP = Convert.ToDouble(objItemMasterDAL.MRP);
                objItemMaster.Rate = Convert.ToDouble(objItemMasterDAL.Rate);
				if (objItemMasterDAL.SortOrder != null)
				{
					objItemMaster.SortOrder = Convert.ToInt32(objItemMasterDAL.SortOrder.Value);
				}
				objItemMaster.IsEnabled = Convert.ToBoolean(objItemMasterDAL.IsEnabled);
				objItemMaster.IsDeleted = Convert.ToBoolean(objItemMasterDAL.IsDeleted);
				objItemMaster.IsDineInOnly = Convert.ToBoolean(objItemMasterDAL.IsDineInOnly);
				objItemMaster.ItemType = Convert.ToInt16(objItemMasterDAL.ItemType);
				objItemMaster.CreateDateTime = objItemMasterDAL.CreateDateTime.ToString("s");
				objItemMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objItemMasterDAL.linktoUserMasterIdCreatedBy);
				if (objItemMasterDAL.UpdateDateTime != null)
				{
					objItemMaster.UpdateDateTime = objItemMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objItemMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objItemMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objItemMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}

				/// Extra
				objItemMaster.Unit = Convert.ToString(objItemMasterDAL.Unit);
				objItemMaster.Category = Convert.ToString(objItemMasterDAL.Category);
				objItemMaster.Business = Convert.ToString(objItemMasterDAL.Business);
				objItemMaster.UserCreatedBy = Convert.ToString(objItemMasterDAL.UserCreatedBy);
				objItemMaster.UserUpdatedBy = Convert.ToString(objItemMasterDAL.UserUpdatedBy);
                objItemMaster.linktoOptionMasterIds = Convert.ToString(objItemMasterDAL.linktoOptionMasterIds);
                objItemMaster.linktoItemMasterIdModifiers = Convert.ToString(objItemMasterDAL.linktoItemMasterIdModifiers);
                objItemMaster.Tax = Convert.ToString(objItemMasterDAL.Tax);
                objItemMaster.Quantity = Convert.ToInt32(objItemMasterDAL.Quentity);
                objItemMaster.TaxRate = Convert.ToDouble(objItemMasterDAL.TaxRate);
				lstItemMaster.Add(objItemMaster);
			}
			return lstItemMaster;
		}
	}
}

using System;
using System.Collections.Generic;

namespace poswLibrary
{

	public class BusinessServiceTran
	{
        public short BusinessServiceTranId { get; set; }
        public int linktoServiceMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }

        //Extra
        public string ServiceName { get; set; }
        public string ImageName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string linktoServiceMasterIds { get; set; }
        public bool IsSelected { get; set; }     

		internal void SetClassObject(poswBusinessServiceTranDAL objBusinessServiceTranDAL)
		{
            this.BusinessServiceTranId = Convert.ToInt16(objBusinessServiceTranDAL.BusinessServiceTran);
			this.linktoServiceMasterId = Convert.ToInt16(objBusinessServiceTranDAL.linktoServiceMasterId);
			this.linktoBusinessMasterId = Convert.ToInt16(objBusinessServiceTranDAL.linktoBusinessMasterId);

			/// Extra
            this.ServiceName = Convert.ToString(objBusinessServiceTranDAL.ServiceName);
            this.ImageName = Convert.ToString(objBusinessServiceTranDAL.ImageName);
		}

		internal static List<BusinessServiceTran> SetListObject(List<poswBusinessServiceTranDAL> lstBusinessServiceTranDAL)
		{
			List<BusinessServiceTran> lstBusinessServiceTran = new List<BusinessServiceTran>();
			BusinessServiceTran objBusinessServiceTran = null;
			foreach (poswBusinessServiceTranDAL objBusinessServiceTranDAL in lstBusinessServiceTranDAL)
			{
				objBusinessServiceTran = new BusinessServiceTran();
                objBusinessServiceTran.BusinessServiceTranId = Convert.ToInt16(objBusinessServiceTranDAL.BusinessServiceTran);
				objBusinessServiceTran.linktoServiceMasterId = Convert.ToInt16(objBusinessServiceTranDAL.linktoServiceMasterId);
				objBusinessServiceTran.linktoBusinessMasterId = Convert.ToInt16(objBusinessServiceTranDAL.linktoBusinessMasterId);

				/// Extra
                objBusinessServiceTran.ServiceName = Convert.ToString(objBusinessServiceTranDAL.ServiceName);
                objBusinessServiceTran.ImageName = Convert.ToString(objBusinessServiceTranDAL.ImageName);
                if (!objBusinessServiceTranDAL.xs_ImagePhysicalName.Equals("img/NoImage.png"))
                {
                    objBusinessServiceTran.xs_ImagePhysicalName = objBusinessServiceTranDAL.xs_ImagePhysicalName;
                }
                objBusinessServiceTran.IsSelected = objBusinessServiceTranDAL.IsSelected;
				lstBusinessServiceTran.Add(objBusinessServiceTran);
			}
			return lstBusinessServiceTran;
		}
	}
}

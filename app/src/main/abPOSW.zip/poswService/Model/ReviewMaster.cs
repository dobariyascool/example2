using System;
using System.Collections.Generic;

namespace poswLibrary
{

    public class ReviewMaster
    {
        #region Properties
        public long ReviewMasterId { get; set; }
        public double StarRating { get; set; }
        public string Review { get; set; }
        public bool IsShow { get; set; }
        public string ReviewDateTime { get; set; }
        public string UpdateDateTime { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public short linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }

        /// Extra
        public string RegisteredUser { get; set; }
        public string UserUpdatedBy { get; set; }
        public string Business { get; set; }
        #endregion

        internal void SetClassObject(poswReviewMasterDAL objReviewMasterDAL)
        {
            this.ReviewMasterId = Convert.ToInt64(objReviewMasterDAL.ReviewMasterId);
            this.StarRating = Convert.ToDouble(objReviewMasterDAL.StarRating);
            this.Review = Convert.ToString(objReviewMasterDAL.Review);
            if (objReviewMasterDAL.IsShow != null)
            {
                this.IsShow = Convert.ToBoolean(objReviewMasterDAL.IsShow.Value);
            }
            this.ReviewDateTime = objReviewMasterDAL.ReviewDateTime.ToString("s");
            if (objReviewMasterDAL.UpdateDateTime != null)
            {
                this.UpdateDateTime = objReviewMasterDAL.UpdateDateTime.Value.ToString("s");
            }
            this.linktoCustomerMasterId = Convert.ToInt32(objReviewMasterDAL.linktoCustomerMasterId);
            if (objReviewMasterDAL.linktoUserMasterIdUpdatedBy != null)
            {
                this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objReviewMasterDAL.linktoUserMasterIdUpdatedBy.Value);
            }
            this.linktoBusinessMasterId = Convert.ToInt16(objReviewMasterDAL.linktoBusinessMasterId);

            /// Extra
            this.RegisteredUser = Convert.ToString(objReviewMasterDAL.RegisteredUser);
            this.UserUpdatedBy = Convert.ToString(objReviewMasterDAL.UserUpdatedBy);
            this.Business = Convert.ToString(objReviewMasterDAL.Business);
        }

        internal static List<ReviewMaster> SetListObject(List<poswReviewMasterDAL> lstReviewMasterDAL)
        {
            List<ReviewMaster> lstReviewMaster = new List<ReviewMaster>();
            ReviewMaster objReviewMaster = null;
            foreach (poswReviewMasterDAL objReviewMasterDAL in lstReviewMasterDAL)
            {
                objReviewMaster = new ReviewMaster();
                objReviewMaster.ReviewMasterId = Convert.ToInt64(objReviewMasterDAL.ReviewMasterId);
                objReviewMaster.StarRating = Convert.ToDouble(objReviewMasterDAL.StarRating);
                objReviewMaster.Review = Convert.ToString(objReviewMasterDAL.Review);
                if (objReviewMasterDAL.IsShow != null)
                {
                    objReviewMaster.IsShow = Convert.ToBoolean(objReviewMasterDAL.IsShow.Value);
                }
                objReviewMaster.ReviewDateTime = objReviewMasterDAL.ReviewDateTime.ToString("s");
                if (objReviewMasterDAL.UpdateDateTime != null)
                {
                    objReviewMaster.UpdateDateTime = objReviewMasterDAL.UpdateDateTime.Value.ToString("s");
                }
                objReviewMaster.linktoCustomerMasterId = Convert.ToInt32(objReviewMasterDAL.linktoCustomerMasterId);
                if (objReviewMasterDAL.linktoUserMasterIdUpdatedBy != null)
                {
                    objReviewMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objReviewMasterDAL.linktoUserMasterIdUpdatedBy.Value);
                }
                objReviewMaster.linktoBusinessMasterId = Convert.ToInt16(objReviewMasterDAL.linktoBusinessMasterId);

                /// Extra
                objReviewMaster.RegisteredUser = Convert.ToString(objReviewMasterDAL.RegisteredUser);
                objReviewMaster.UserUpdatedBy = Convert.ToString(objReviewMasterDAL.UserUpdatedBy);
                objReviewMaster.Business = Convert.ToString(objReviewMasterDAL.Business);
                lstReviewMaster.Add(objReviewMaster);
            }
            return lstReviewMaster;
        }
    }
}

using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for BannerMaster
	/// </summary>
	public class BannerMaster
	{
        public int BannerMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string BannerTitle { get; set; }
        public string BannerDescription { get; set; }
        public string ImageName { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public short? Type { get; set; }
        public int? ID { get; set; }
        public short? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string Business { get; set; }
        public string xsImageName { get; set; }
        public string smImageName { get; set; }
        public string mdImageName { get; set; }
        public string lgImageName { get; set; }
        public string xlImageName { get; set; }


		internal void SetClassObject(poswBannerMasterDAL objBannerMasterDAL)
		{
			this.BannerMasterId = Convert.ToInt32(objBannerMasterDAL.BannerMasterId);
			this.linktoBusinessMasterId = Convert.ToInt16(objBannerMasterDAL.linktoBusinessMasterId);
			this.BannerTitle = Convert.ToString(objBannerMasterDAL.BannerTitle);
			this.BannerDescription = Convert.ToString(objBannerMasterDAL.BannerDescription);
			this.ImageName = Convert.ToString(objBannerMasterDAL.ImageName);
			if (objBannerMasterDAL.FromDate != null)
			{
				this.FromDate = objBannerMasterDAL.FromDate.Value.ToString("s");
			}
			if (objBannerMasterDAL.ToDate != null)
			{
				this.ToDate = objBannerMasterDAL.ToDate.Value.ToString("s");
			}
			if (objBannerMasterDAL.Type != null)
			{
				this.Type = Convert.ToInt16(objBannerMasterDAL.Type.Value);
			}
			if (objBannerMasterDAL.ID != null)
			{
				this.ID = Convert.ToInt32(objBannerMasterDAL.ID.Value);
			}
			if (objBannerMasterDAL.SortOrder != null)
			{
				this.SortOrder = Convert.ToInt16(objBannerMasterDAL.SortOrder.Value);
			}
			this.IsEnabled = Convert.ToBoolean(objBannerMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objBannerMasterDAL.IsDeleted);
			this.CreateDateTime = objBannerMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objBannerMasterDAL.linktoUserMasterIdCreatedBy);
			if (objBannerMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objBannerMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objBannerMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objBannerMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}

			/// Extra
			this.Business = Convert.ToString(objBannerMasterDAL.Business);
            this.xsImageName = Convert.ToString(objBannerMasterDAL.xsImageName);
            this.smImageName = Convert.ToString(objBannerMasterDAL.smImageName);
            this.mdImageName = Convert.ToString(objBannerMasterDAL.mdImageName);
            this.lgImageName = Convert.ToString(objBannerMasterDAL.lgImageName);
            this.xlImageName = Convert.ToString(objBannerMasterDAL.xlImageName); 
		}

		internal static List<BannerMaster> SetListObject(List<poswBannerMasterDAL> lstBannerMasterDAL)
		{
			List<BannerMaster> lstBannerMaster = new List<BannerMaster>();
			BannerMaster objBannerMaster = null;
			foreach (poswBannerMasterDAL objBannerMasterDAL in lstBannerMasterDAL)
			{
				objBannerMaster = new BannerMaster();
				objBannerMaster.BannerMasterId = Convert.ToInt32(objBannerMasterDAL.BannerMasterId);
				objBannerMaster.linktoBusinessMasterId = Convert.ToInt16(objBannerMasterDAL.linktoBusinessMasterId);
				objBannerMaster.BannerTitle = Convert.ToString(objBannerMasterDAL.BannerTitle);
				objBannerMaster.BannerDescription = Convert.ToString(objBannerMasterDAL.BannerDescription);
				objBannerMaster.ImageName = Convert.ToString(objBannerMasterDAL.ImageName);
				if (objBannerMasterDAL.FromDate != null)
				{
					objBannerMaster.FromDate = objBannerMasterDAL.FromDate.Value.ToString("s");
				}
				if (objBannerMasterDAL.ToDate != null)
				{
					objBannerMaster.ToDate = objBannerMasterDAL.ToDate.Value.ToString("s");
				}
				if (objBannerMasterDAL.Type != null)
				{
					objBannerMaster.Type = Convert.ToInt16(objBannerMasterDAL.Type.Value);
				}
				if (objBannerMasterDAL.ID != null)
				{
					objBannerMaster.ID = Convert.ToInt32(objBannerMasterDAL.ID.Value);
				}
				if (objBannerMasterDAL.SortOrder != null)
				{
					objBannerMaster.SortOrder = Convert.ToInt16(objBannerMasterDAL.SortOrder.Value);
				}
				objBannerMaster.IsEnabled = Convert.ToBoolean(objBannerMasterDAL.IsEnabled);
				objBannerMaster.IsDeleted = Convert.ToBoolean(objBannerMasterDAL.IsDeleted);
				objBannerMaster.CreateDateTime = objBannerMasterDAL.CreateDateTime.ToString("s");
				objBannerMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objBannerMasterDAL.linktoUserMasterIdCreatedBy);
				if (objBannerMasterDAL.UpdateDateTime != null)
				{
					objBannerMaster.UpdateDateTime = objBannerMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objBannerMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objBannerMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objBannerMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}

				/// Extra
				objBannerMaster.Business = Convert.ToString(objBannerMasterDAL.Business);
                objBannerMaster.xsImageName = Convert.ToString(objBannerMasterDAL.xsImageName);
                objBannerMaster.smImageName = Convert.ToString(objBannerMasterDAL.smImageName);
                objBannerMaster.mdImageName = Convert.ToString(objBannerMasterDAL.mdImageName);
                objBannerMaster.lgImageName = Convert.ToString(objBannerMasterDAL.lgImageName);
                objBannerMaster.xlImageName = Convert.ToString(objBannerMasterDAL.xlImageName); 
				lstBannerMaster.Add(objBannerMaster);
			}
			return lstBannerMaster;
		}
	}
}

using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for TaxMaster
	/// </summary>
	public class TaxMaster
	{

        public short TaxMasterId { get; set; }
        public string TaxName { get; set; }
        public string TaxCaption { get; set; }
        public short TaxIndex { get; set; }
        public double TaxRate { get; set; }
        public bool IsPercentage { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public string CreatedDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

		/// Extra
        public double DefaultTaxRate { get; set; }
        public int linktoItemMasterId { get; set; }


		internal void SetClassObject(poswTaxMasterDAL objTaxMasterDAL)
		{
			this.TaxMasterId = Convert.ToInt16(objTaxMasterDAL.TaxMasterId);
			this.TaxName = Convert.ToString(objTaxMasterDAL.TaxName);
			this.TaxCaption = Convert.ToString(objTaxMasterDAL.TaxCaption);
			this.TaxIndex = Convert.ToInt16(objTaxMasterDAL.TaxIndex);
			this.TaxRate = Convert.ToDouble(objTaxMasterDAL.TaxRate);
			this.IsPercentage = Convert.ToBoolean(objTaxMasterDAL.IsPercentage);
			this.linktoBusinessMasterId = Convert.ToInt16(objTaxMasterDAL.linktoBusinessMasterId);
			this.IsEnabled = Convert.ToBoolean(objTaxMasterDAL.IsEnabled);
			this.CreatedDateTime = objTaxMasterDAL.CreatedDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objTaxMasterDAL.linktoUserMasterIdCreatedBy);
			if (objTaxMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objTaxMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objTaxMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objTaxMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}

			/// Extra
            this.DefaultTaxRate = Convert.ToDouble(objTaxMasterDAL.DefaultTaxRate);
			this.linktoItemMasterId = Convert.ToInt16(objTaxMasterDAL.linktoItemMasterId);
		}

		internal static List<TaxMaster> SetListObject(List<poswTaxMasterDAL> lstTaxMasterDAL)
		{
			List<TaxMaster> lstTaxMaster = new List<TaxMaster>();
			TaxMaster objTaxMaster = null;
			foreach (poswTaxMasterDAL objTaxMasterDAL in lstTaxMasterDAL)
			{
				objTaxMaster = new TaxMaster();
				objTaxMaster.TaxMasterId = Convert.ToInt16(objTaxMasterDAL.TaxMasterId);
				objTaxMaster.TaxName = Convert.ToString(objTaxMasterDAL.TaxName);
				objTaxMaster.TaxCaption = Convert.ToString(objTaxMasterDAL.TaxCaption);
				objTaxMaster.TaxIndex = Convert.ToInt16(objTaxMasterDAL.TaxIndex);
				objTaxMaster.TaxRate = Convert.ToDouble(objTaxMasterDAL.TaxRate);
				objTaxMaster.IsPercentage = Convert.ToBoolean(objTaxMasterDAL.IsPercentage);
				objTaxMaster.linktoBusinessMasterId = Convert.ToInt16(objTaxMasterDAL.linktoBusinessMasterId);
				objTaxMaster.IsEnabled = Convert.ToBoolean(objTaxMasterDAL.IsEnabled);
				objTaxMaster.CreatedDateTime = objTaxMasterDAL.CreatedDateTime.ToString("s");
				objTaxMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objTaxMasterDAL.linktoUserMasterIdCreatedBy);
				if (objTaxMasterDAL.UpdateDateTime != null)
				{
					objTaxMaster.UpdateDateTime = objTaxMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objTaxMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objTaxMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objTaxMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}

                /// Extra
                objTaxMaster.DefaultTaxRate = Convert.ToDouble(objTaxMasterDAL.DefaultTaxRate);
                objTaxMaster.linktoItemMasterId = Convert.ToInt16(objTaxMasterDAL.linktoItemMasterId);
				lstTaxMaster.Add(objTaxMaster);
			}
			return lstTaxMaster;
		}
	}
}

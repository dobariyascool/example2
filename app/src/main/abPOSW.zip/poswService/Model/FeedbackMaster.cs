using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for FeedbackMaster
	/// </summary>
	public class FeedbackMaster
	{
        public int FeedbackMasterId  { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Feedback { get; set; }
        public string FeedbackDateTime { get; set; }
        public short FeedbackType { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
		/// Extra
		public string Business { get; set; }


		internal void SetClassObject(poswFeedbackMasterDAL objFeedbackMasterDAL)
		{
			this.FeedbackMasterId = Convert.ToInt32(objFeedbackMasterDAL.FeedbackMasterId);
			this.Name = Convert.ToString(objFeedbackMasterDAL.Name);
			this.Email = Convert.ToString(objFeedbackMasterDAL.Email);
			this.Phone = Convert.ToString(objFeedbackMasterDAL.Phone);
			this.Feedback = Convert.ToString(objFeedbackMasterDAL.Feedback);
			this.FeedbackDateTime = objFeedbackMasterDAL.FeedbackDateTime.ToString("s");
			this.FeedbackType = Convert.ToInt16(objFeedbackMasterDAL.FeedbackType);
			if (objFeedbackMasterDAL.linktoCustomerMasterId != null)
			{
				this.linktoCustomerMasterId = Convert.ToInt32(objFeedbackMasterDAL.linktoCustomerMasterId.Value);
			}
			this.linktoBusinessMasterId = Convert.ToInt16(objFeedbackMasterDAL.linktoBusinessMasterId);

			/// Extra
			this.Business = Convert.ToString(objFeedbackMasterDAL.Business);
		}

		internal static List<FeedbackMaster> SetListObject(List<poswFeedbackMasterDAL> lstFeedbackMasterDAL)
		{
			List<FeedbackMaster> lstFeedbackMaster = new List<FeedbackMaster>();
			FeedbackMaster objFeedbackMaster = null;
			foreach (poswFeedbackMasterDAL objFeedbackMasterDAL in lstFeedbackMasterDAL)
			{
				objFeedbackMaster = new FeedbackMaster();
				objFeedbackMaster.FeedbackMasterId = Convert.ToInt32(objFeedbackMasterDAL.FeedbackMasterId);
				objFeedbackMaster.Name = Convert.ToString(objFeedbackMasterDAL.Name);
				objFeedbackMaster.Email = Convert.ToString(objFeedbackMasterDAL.Email);
				objFeedbackMaster.Phone = Convert.ToString(objFeedbackMasterDAL.Phone);
				objFeedbackMaster.Feedback = Convert.ToString(objFeedbackMasterDAL.Feedback);
				objFeedbackMaster.FeedbackDateTime = objFeedbackMasterDAL.FeedbackDateTime.ToString("s");
				objFeedbackMaster.FeedbackType = Convert.ToInt16(objFeedbackMasterDAL.FeedbackType);
				if (objFeedbackMasterDAL.linktoCustomerMasterId != null)
				{
					objFeedbackMaster.linktoCustomerMasterId = Convert.ToInt32(objFeedbackMasterDAL.linktoCustomerMasterId.Value);
				}
				objFeedbackMaster.linktoBusinessMasterId = Convert.ToInt16(objFeedbackMasterDAL.linktoBusinessMasterId);

				/// Extra
				objFeedbackMaster.Business = Convert.ToString(objFeedbackMasterDAL.Business);
				lstFeedbackMaster.Add(objFeedbackMaster);
			}
			return lstFeedbackMaster;
		}
	}
}

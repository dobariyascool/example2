using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for FeedbackTran
	/// </summary>
	public class FeedbackTran
	{
        public int FeedbackTranId { get; set; }
        public int linktoFeedbackMasterId { get; set; }
        public int linktoFeedbackQuestionMasterId { get; set; }
        public int linktoFeedbackAnswerMasterId { get; set; }
        public string Answer { get; set; }
		/// Extra
		public string FeedbackQuestion { get; set; }
		public int FeedbackAnswer { get; set; }


		internal void SetClassObject(poswFeedbackTranDAL objFeedbackTranDAL)
		{
			this.FeedbackTranId = Convert.ToInt32(objFeedbackTranDAL.FeedbackTranId);
			this.linktoFeedbackMasterId = Convert.ToInt32(objFeedbackTranDAL.linktoFeedbackMasterId);
			this.linktoFeedbackQuestionMasterId = Convert.ToInt32(objFeedbackTranDAL.linktoFeedbackQuestionMasterId);
			if (objFeedbackTranDAL.linktoFeedbackAnswerMasterId != null)
			{
				this.linktoFeedbackAnswerMasterId = Convert.ToInt32(objFeedbackTranDAL.linktoFeedbackAnswerMasterId.Value);
			}
			this.Answer = Convert.ToString(objFeedbackTranDAL.Answer);

			/// Extra
			this.FeedbackQuestion = Convert.ToString(objFeedbackTranDAL.FeedbackQuestion);
			this.FeedbackAnswer = Convert.ToInt32(objFeedbackTranDAL.FeedbackAnswer);
		}

		internal static List<FeedbackTran> SetListObject(List<poswFeedbackTranDAL> lstFeedbackTranDAL)
		{
			List<FeedbackTran> lstFeedbackTran = new List<FeedbackTran>();
			FeedbackTran objFeedbackTran = null;
			foreach (poswFeedbackTranDAL objFeedbackTranDAL in lstFeedbackTranDAL)
			{
				objFeedbackTran = new FeedbackTran();
				objFeedbackTran.FeedbackTranId = Convert.ToInt32(objFeedbackTranDAL.FeedbackTranId);
				objFeedbackTran.linktoFeedbackMasterId = Convert.ToInt32(objFeedbackTranDAL.linktoFeedbackMasterId);
				objFeedbackTran.linktoFeedbackQuestionMasterId = Convert.ToInt32(objFeedbackTranDAL.linktoFeedbackQuestionMasterId);
				if (objFeedbackTranDAL.linktoFeedbackAnswerMasterId != null)
				{
					objFeedbackTran.linktoFeedbackAnswerMasterId = Convert.ToInt32(objFeedbackTranDAL.linktoFeedbackAnswerMasterId.Value);
				}
				objFeedbackTran.Answer = Convert.ToString(objFeedbackTranDAL.Answer);

				/// Extra
				objFeedbackTran.FeedbackQuestion = Convert.ToString(objFeedbackTranDAL.FeedbackQuestion);
				objFeedbackTran.FeedbackAnswer = Convert.ToInt32(objFeedbackTranDAL.FeedbackAnswer);
				lstFeedbackTran.Add(objFeedbackTran);
			}
			return lstFeedbackTran;
		}
	}
}

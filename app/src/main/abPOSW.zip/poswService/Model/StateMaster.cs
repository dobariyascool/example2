using System;
using System.Collections.Generic;

namespace poswLibrary
{
	/// <summary>
	/// Model for StateMaster
	/// </summary>
	public class StateMaster
	{
        public short StateMasterId { get; set; }
        public string StateName { get; set; }
        public string StateCode { get; set; }
        public short linktoCountryMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

		/// Extra
		public string Country { get; set; }

		internal void SetClassObject(poswStateMasterDAL objStateMasterDAL)
		{
			this.StateMasterId = Convert.ToInt16(objStateMasterDAL.StateMasterId);
			this.StateName = Convert.ToString(objStateMasterDAL.StateName);
			this.StateCode = Convert.ToString(objStateMasterDAL.StateCode);
			this.linktoCountryMasterId = Convert.ToInt16(objStateMasterDAL.linktoCountryMasterId);
			this.IsEnabled = Convert.ToBoolean(objStateMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objStateMasterDAL.IsDeleted);
			this.CreateDateTime = objStateMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objStateMasterDAL.linktoUserMasterIdCreatedBy);
			if (objStateMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objStateMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objStateMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objStateMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}

			/// Extra
			this.Country = Convert.ToString(objStateMasterDAL.Country);
		}

		internal static List<StateMaster> SetListObject(List<poswStateMasterDAL> lstStateMasterDAL)
		{
			List<StateMaster> lstStateMaster = new List<StateMaster>();
			StateMaster objStateMaster = null;
			foreach (poswStateMasterDAL objStateMasterDAL in lstStateMasterDAL)
			{
				objStateMaster = new StateMaster();
				objStateMaster.StateMasterId = Convert.ToInt16(objStateMasterDAL.StateMasterId);
				objStateMaster.StateName = Convert.ToString(objStateMasterDAL.StateName);
				objStateMaster.StateCode = Convert.ToString(objStateMasterDAL.StateCode);
				objStateMaster.linktoCountryMasterId = Convert.ToInt16(objStateMasterDAL.linktoCountryMasterId);
				objStateMaster.IsEnabled = Convert.ToBoolean(objStateMasterDAL.IsEnabled);
				objStateMaster.IsDeleted = Convert.ToBoolean(objStateMasterDAL.IsDeleted);
				objStateMaster.CreateDateTime = objStateMasterDAL.CreateDateTime.ToString("s");
				objStateMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objStateMasterDAL.linktoUserMasterIdCreatedBy);
				if (objStateMasterDAL.UpdateDateTime != null)
				{
					objStateMaster.UpdateDateTime = objStateMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objStateMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objStateMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objStateMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}

				/// Extra
				objStateMaster.Country = Convert.ToString(objStateMasterDAL.Country);
				lstStateMaster.Add(objStateMaster);
			}
			return lstStateMaster;
		}
	}
}

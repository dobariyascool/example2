﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poswLibrary
{
    public class UserRightsTran
    {
        #region Properties
        public int UserRightsTranId { get; set; }
        public short linktoUserRightsMasterId { get; set; }
        public short linktoRoleMasterId { get; set; }
        #endregion

        internal void SetClassObject(poswUserRightsTranDAL objUserRightsTranDAL)
        {
            this.UserRightsTranId = Convert.ToInt16(objUserRightsTranDAL.UserRightsTranId);
            this.linktoUserRightsMasterId = Convert.ToInt16(objUserRightsTranDAL.linktoUserRightsMasterId);
            this.linktoRoleMasterId = Convert.ToInt16(objUserRightsTranDAL.linktoRoleMasterId);         
        }

        internal static List<UserRightsTran> SetListObject(List<poswUserRightsTranDAL> lstUserRightsTranDAL)
        {
            List<UserRightsTran> lstUserRightsTran= new List<UserRightsTran>();
            UserRightsTran objUserRightsTran= null;
            foreach (poswUserRightsTranDAL objUserRightsTranDAL in lstUserRightsTranDAL)
            {
                objUserRightsTran = new UserRightsTran();
                objUserRightsTran.UserRightsTranId = Convert.ToInt16(objUserRightsTranDAL.UserRightsTranId);
                objUserRightsTran.linktoUserRightsMasterId = Convert.ToInt16(objUserRightsTranDAL.linktoUserRightsMasterId);
                objUserRightsTran.linktoRoleMasterId = Convert.ToInt16(objUserRightsTranDAL.linktoRoleMasterId);
                lstUserRightsTran.Add(objUserRightsTran);
            }
            return lstUserRightsTran;
        }
    }
}
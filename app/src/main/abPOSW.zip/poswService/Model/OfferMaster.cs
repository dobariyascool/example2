using System;
using System.Collections.Generic;
using poswLibrary;

namespace poswLibrary
{
	/// <summary>
	/// Model for OfferMaster
	/// </summary>
	public class OfferMaster
	{

        public int OfferMasterId { get; set; }
        public short linktoOfferTypeMasterId { get; set; }
        public string OfferTitle { get; set; }
        public string OfferContent { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
        public double MinimumBillAmount { get; set; }
        public double Discount { get; set; }
        public bool IsDiscountPercentage { get; set; }
        public int? RedeemCount { get; set; }
        public string OfferCode { get; set; }
        public string ImagePhysicalName { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string TermsAndConditions { get; set; }
        public bool IsForCustomers { get; set; }
        public int? BuyItemCount { get; set; }
        public int? GetItemCount { get; set; }
        public string linktoOrderTypeMasterIds { get; set; }
        public bool? IsOnline { get; set; }
        public bool? IsForApp { get; set; }
        public bool IsForAllDays { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }

        /// Extra
        public string ImageName { get; set; }
        public string xsImagePhysicalName { get; set; }
        public string smImagePhysicalName { get; set; }
        public string mdImagePhysicalName { get; set; }
        public string lgImagePhysicalName { get; set; }
        public string xlImagePhysicalName { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string ValidDays { get; set; }
        public string ValidItems { get; set; }
        public string ValidBuyItems { get; set; }
        public string ValidGetItems { get; set; }

		internal void SetClassObject(poswOfferMasterDAL objOfferMasterDAL)
		{
            //string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["poswImageRetrievePath"] + "/offer/";

			this.OfferMasterId = Convert.ToInt32(objOfferMasterDAL.OfferMasterId);
			this.linktoOfferTypeMasterId = Convert.ToInt16(objOfferMasterDAL.linktoOfferTypeMasterId);
			this.OfferTitle = Convert.ToString(objOfferMasterDAL.OfferTitle);
			this.OfferContent = Convert.ToString(objOfferMasterDAL.OfferContent);
			if (objOfferMasterDAL.FromDate != null)
			{
				this.FromDate = objOfferMasterDAL.FromDate.Value.ToString("yyyy-MM-dd");
			}
			if (objOfferMasterDAL.ToDate != null)
			{
				this.ToDate = objOfferMasterDAL.ToDate.Value.ToString("yyyy-MM-dd");
			}
			if (objOfferMasterDAL.FromTime != null)
			{
				this.FromTime = new DateTime().Add(objOfferMasterDAL.FromTime.Value).ToString("HH:mm:ss");
			}
			if (objOfferMasterDAL.ToTime != null)
			{
				this.ToTime = new DateTime().Add(objOfferMasterDAL.ToTime.Value).ToString("HH:mm:ss");
			}
			if (objOfferMasterDAL.MinimumBillAmount != null)
			{
				this.MinimumBillAmount = Convert.ToDouble(objOfferMasterDAL.MinimumBillAmount.Value);
			}
			this.Discount = Convert.ToDouble(objOfferMasterDAL.Discount);
            this.IsDiscountPercentage = Convert.ToBoolean(objOfferMasterDAL.IsDiscountPercentage);
			if (objOfferMasterDAL.RedeemCount != null)
			{
				this.RedeemCount = Convert.ToInt32(objOfferMasterDAL.RedeemCount.Value);
			}
			this.OfferCode = Convert.ToString(objOfferMasterDAL.OfferCode);
            if (objOfferMasterDAL.xlImagePhysicalName != null && !objOfferMasterDAL.xlImagePhysicalName.Equals(""))
            {
                this.ImagePhysicalName = Convert.ToString(objOfferMasterDAL.xlImagePhysicalName);
            }
            if (objOfferMasterDAL.mdImagePhysicalName != null && !objOfferMasterDAL.mdImagePhysicalName.Equals(""))
            {
                this.mdImagePhysicalName = Convert.ToString(objOfferMasterDAL.mdImagePhysicalName);
            }
            if (objOfferMasterDAL.lgImagePhysicalName != null && !objOfferMasterDAL.lgImagePhysicalName.Equals(""))
            {
                this.lgImagePhysicalName = Convert.ToString(objOfferMasterDAL.lgImagePhysicalName);
            }
            if (objOfferMasterDAL.smImagePhysicalName != null && !objOfferMasterDAL.smImagePhysicalName.Equals(""))
            {
                this.smImagePhysicalName = Convert.ToString(objOfferMasterDAL.smImagePhysicalName);
            }
            if (objOfferMasterDAL.xsImagePhysicalName != null && !objOfferMasterDAL.xsImagePhysicalName.Equals(""))
            {
                this.xsImagePhysicalName = Convert.ToString(objOfferMasterDAL.xsImagePhysicalName);
            }
			this.CreateDateTime = objOfferMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objOfferMasterDAL.linktoUserMasterIdCreatedBy);
			if (objOfferMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objOfferMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objOfferMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOfferMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}
			this.linktoBusinessMasterId = Convert.ToInt16(objOfferMasterDAL.linktoBusinessMasterId);
			this.TermsAndConditions = Convert.ToString(objOfferMasterDAL.TermsAndConditions);
			this.IsEnabled = Convert.ToBoolean(objOfferMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objOfferMasterDAL.IsDeleted);
            this.IsForAllDays = Convert.ToBoolean(objOfferMasterDAL.IsForAllDays);
            this.IsForApp = Convert.ToBoolean(objOfferMasterDAL.IsForApp);
            this.IsOnline = Convert.ToBoolean(objOfferMasterDAL.IsOnline);
			this.IsForCustomers = Convert.ToBoolean(objOfferMasterDAL.IsForCustomers);
		    this.BuyItemCount = Convert.ToInt32(objOfferMasterDAL.BuyItemCount);
		    this.GetItemCount = Convert.ToInt32(objOfferMasterDAL.GetItemCount);
		    this.linktoOrderTypeMasterIds = Convert.ToString(objOfferMasterDAL.linktoOrderTypeMasterIds);
            this.linktoCustomerMasterId = objOfferMasterDAL.linktoCustomerMasterId;
            this.ValidBuyItems = objOfferMasterDAL.ValidBuyItems;
            this.ValidDays = objOfferMasterDAL.ValidDays;
            this.ValidGetItems = objOfferMasterDAL.ValidGetItems;
            this.ValidItems = objOfferMasterDAL.ValidItems;
		}

		internal static List<OfferMaster> SetListObject(List<poswOfferMasterDAL> lstOfferMasterDAL)
		{
           
			List<OfferMaster> lstOfferMaster = new List<OfferMaster>();
			OfferMaster objOfferMaster = null;

            //string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["poswImageRetrievePath"] + "/offer/";

			foreach (poswOfferMasterDAL objOfferMasterDAL in lstOfferMasterDAL)
			{
				objOfferMaster = new OfferMaster();
				objOfferMaster.OfferMasterId = Convert.ToInt32(objOfferMasterDAL.OfferMasterId);
				objOfferMaster.linktoOfferTypeMasterId = Convert.ToInt16(objOfferMasterDAL.linktoOfferTypeMasterId);
				objOfferMaster.OfferTitle = Convert.ToString(objOfferMasterDAL.OfferTitle);
				objOfferMaster.OfferContent = Convert.ToString(objOfferMasterDAL.OfferContent);
				if (objOfferMasterDAL.FromDate != null)
				{
					objOfferMaster.FromDate = objOfferMasterDAL.FromDate.Value.ToString("yyyy-MM-dd");
				}
				if (objOfferMasterDAL.ToDate != null)
				{
					objOfferMaster.ToDate = objOfferMasterDAL.ToDate.Value.ToString("yyyy-MM-dd");
				}
				if (objOfferMasterDAL.FromTime != null)
				{
                    objOfferMaster.FromTime = new DateTime().Add(objOfferMasterDAL.FromTime.Value).ToString("HH:mm:ss");
				}
				if (objOfferMasterDAL.ToTime != null)
				{
                    objOfferMaster.ToTime = new DateTime().Add(objOfferMasterDAL.ToTime.Value).ToString("HH:mm:ss");
				}
				if (objOfferMasterDAL.MinimumBillAmount != null)
				{
					objOfferMaster.MinimumBillAmount = Convert.ToDouble(objOfferMasterDAL.MinimumBillAmount.Value);
				}
				objOfferMaster.Discount = Convert.ToDouble(objOfferMasterDAL.Discount);
				objOfferMaster.IsDiscountPercentage = Convert.ToBoolean(objOfferMasterDAL.IsDiscountPercentage);
				if (objOfferMasterDAL.RedeemCount != null)
				{
					objOfferMaster.RedeemCount = Convert.ToInt32(objOfferMasterDAL.RedeemCount.Value);
				}
				objOfferMaster.OfferCode = Convert.ToString(objOfferMasterDAL.OfferCode);
                if (objOfferMasterDAL.xlImagePhysicalName != null && !objOfferMasterDAL.xlImagePhysicalName.Equals(""))
                {
                    objOfferMaster.ImagePhysicalName = Convert.ToString(objOfferMasterDAL.xlImagePhysicalName);
                }
                if (objOfferMasterDAL.mdImagePhysicalName != null && !objOfferMasterDAL.mdImagePhysicalName.Equals(""))
                {
                    objOfferMaster.mdImagePhysicalName = Convert.ToString(objOfferMasterDAL.mdImagePhysicalName);
                }
                if (objOfferMasterDAL.lgImagePhysicalName != null && !objOfferMasterDAL.lgImagePhysicalName.Equals(""))
                {
                    objOfferMaster.lgImagePhysicalName = Convert.ToString(objOfferMasterDAL.lgImagePhysicalName);
                }
                if (objOfferMasterDAL.smImagePhysicalName != null && !objOfferMasterDAL.smImagePhysicalName.Equals(""))
                {
                    objOfferMaster.smImagePhysicalName = Convert.ToString(objOfferMasterDAL.smImagePhysicalName);
                }
                if (objOfferMasterDAL.xsImagePhysicalName != null && !objOfferMasterDAL.xsImagePhysicalName.Equals(""))
                {
                    objOfferMaster.xsImagePhysicalName = Convert.ToString(objOfferMasterDAL.xsImagePhysicalName);
                }
				objOfferMaster.CreateDateTime = objOfferMasterDAL.CreateDateTime.ToString("s");
				objOfferMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objOfferMasterDAL.linktoUserMasterIdCreatedBy);
				if (objOfferMasterDAL.UpdateDateTime != null)
				{
					objOfferMaster.UpdateDateTime = objOfferMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objOfferMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objOfferMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOfferMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}
				objOfferMaster.linktoBusinessMasterId = Convert.ToInt16(objOfferMasterDAL.linktoBusinessMasterId);
				objOfferMaster.TermsAndConditions = Convert.ToString(objOfferMasterDAL.TermsAndConditions);
				objOfferMaster.IsEnabled = Convert.ToBoolean(objOfferMasterDAL.IsEnabled);
				objOfferMaster.IsDeleted = Convert.ToBoolean(objOfferMasterDAL.IsDeleted);
				objOfferMaster.IsForCustomers = Convert.ToBoolean(objOfferMasterDAL.IsForCustomers);
		        objOfferMaster.BuyItemCount = Convert.ToInt32(objOfferMasterDAL.BuyItemCount);
		        objOfferMaster.GetItemCount = Convert.ToInt16(objOfferMasterDAL.GetItemCount);
                objOfferMaster.linktoOrderTypeMasterIds = Convert.ToString(objOfferMasterDAL.linktoOrderTypeMasterIds);
                objOfferMaster.linktoCustomerMasterId = objOfferMasterDAL.linktoCustomerMasterId;
				
				
				/// Extra
				lstOfferMaster.Add(objOfferMaster);
			}
			return lstOfferMaster;
		}
	}
}

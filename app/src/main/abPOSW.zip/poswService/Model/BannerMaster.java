package abPOS_Web;

import android.os.Parcel;
import android.os.Parcelable;

/// <summary>
/// Model for BannerMaster
/// </summary>
public class BannerMaster implements Parcelable {
	//region Properties

	int BannerMasterId;
	public int getBannerMasterId() { return this.BannerMasterId; }
	public void setBannerMasterId(int bannerMasterId) { this.BannerMasterId = bannerMasterId; }

	short linktoBusinessMasterId;
	public short getlinktoBusinessMasterId() { return this.linktoBusinessMasterId; }
	public void setlinktoBusinessMasterId(short linktoBusinessMasterId) { this.linktoBusinessMasterId = linktoBusinessMasterId; }

	String BannerTitle;
	public String getBannerTitle() { return this.BannerTitle; }
	public void setBannerTitle(String bannerTitle) { this.BannerTitle = bannerTitle; }

	String BannerDescription;
	public String getBannerDescription() { return this.BannerDescription; }
	public void setBannerDescription(String bannerDescription) { this.BannerDescription = bannerDescription; }

	String ImageNameBytes;
	public String getImageNameBytes() { return this.ImageNameBytes; }
	public void setImageNameBytes(String imageNameBytes) { this.ImageNameBytes = imageNameBytes; }

	String ImageName;
	public String getImageName() { return this.ImageName; }
	public void setImageName(String imageName) { this.ImageName = imageName; }

	String FromDate;
	public String getFromDate() { return this.FromDate; }
	public void setFromDate(String fromDate) { this.FromDate = fromDate; }

	String ToDate;
	public String getToDate() { return this.ToDate; }
	public void setToDate(String toDate) { this.ToDate = toDate; }

	short Type;
	public short getType() { return this.Type; }
	public void setType(short type) { this.Type = type; }

	int ID;
	public int getID() { return this.ID; }
	public void setID(int iD) { this.ID = iD; }

	short SortOrder;
	public short getSortOrder() { return this.SortOrder; }
	public void setSortOrder(short sortOrder) { this.SortOrder = sortOrder; }

	boolean IsEnabled;
	public boolean getIsEnabled() { return this.IsEnabled; }
	public void setIsEnabled(boolean isEnabled) { this.IsEnabled = isEnabled; }

	boolean IsDeleted;
	public boolean getIsDeleted() { return this.IsDeleted; }
	public void setIsDeleted(boolean isDeleted) { this.IsDeleted = isDeleted; }

	String CreateDateTime;
	public String getCreateDateTime() { return this.CreateDateTime; }
	public void setCreateDateTime(String createDateTime) { this.CreateDateTime = createDateTime; }

	short linktoUserMasterIdCreatedBy;
	public short getlinktoUserMasterIdCreatedBy() { return this.linktoUserMasterIdCreatedBy; }
	public void setlinktoUserMasterIdCreatedBy(short linktoUserMasterIdCreatedBy) { this.linktoUserMasterIdCreatedBy = linktoUserMasterIdCreatedBy; }

	String UpdateDateTime;
	public String getUpdateDateTime() { return this.UpdateDateTime; }
	public void setUpdateDateTime(String updateDateTime) { this.UpdateDateTime = updateDateTime; }

	short linktoUserMasterIdUpdatedBy;
	public short getlinktoUserMasterIdUpdatedBy() { return this.linktoUserMasterIdUpdatedBy; }
	public void setlinktoUserMasterIdUpdatedBy(short linktoUserMasterIdUpdatedBy) { this.linktoUserMasterIdUpdatedBy = linktoUserMasterIdUpdatedBy; }


	/// Extra
	String Business;
	public String getBusiness() { return this.Business; }
	public void setBusiness(String business) { this.Business = business; }

	//endregion

	public static final Parcelable.Creator<BannerMaster> CREATOR = new Creator<BannerMaster>() {
		public BannerMaster createFromParcel(Parcel source) {
			BannerMaster objBannerMaster = new BannerMaster();
			objBannerMaster.BannerMasterId = source.readInt();
			objBannerMaster.linktoBusinessMasterId = (short)source.readInt();
			objBannerMaster.BannerTitle = source.readString();
			objBannerMaster.BannerDescription = source.readString();
			objBannerMaster.ImageNameBytes = source.readString();
			objBannerMaster.ImageName = source.readString();
			objBannerMaster.FromDate = source.readString();
			objBannerMaster.ToDate = source.readString();
			objBannerMaster.Type = (short)source.readInt();
			objBannerMaster.ID = source.readInt();
			objBannerMaster.SortOrder = (short)source.readInt();
			objBannerMaster.IsEnabled = source.readByte() != 0;
			objBannerMaster.IsDeleted = source.readByte() != 0;
			objBannerMaster.CreateDateTime = source.readString();
			objBannerMaster.linktoUserMasterIdCreatedBy = (short)source.readInt();
			objBannerMaster.UpdateDateTime = source.readString();
			objBannerMaster.linktoUserMasterIdUpdatedBy = (short)source.readInt();

			/// Extra
			objBannerMaster.Business = source.readString();
			return objBannerMaster;
		}

		public BannerMaster[] newArray(int size) {
			return new BannerMaster[size];
		}
	};

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel parcel, int flags) {
		parcel.writeInt(BannerMasterId);
		parcel.writeInt(linktoBusinessMasterId);
		parcel.writeString(BannerTitle);
		parcel.writeString(BannerDescription);
		parcel.writeString(ImageNameBytes);
		parcel.writeString(ImageName);
		parcel.writeString(FromDate);
		parcel.writeString(ToDate);
		parcel.writeInt(Type);
		parcel.writeInt(ID);
		parcel.writeInt(SortOrder);
		parcel.writeByte((byte)(IsEnabled ? 1 : 0));
		parcel.writeByte((byte)(IsDeleted ? 1 : 0));
		parcel.writeString(CreateDateTime);
		parcel.writeInt(linktoUserMasterIdCreatedBy);
		parcel.writeString(UpdateDateTime);
		parcel.writeInt(linktoUserMasterIdUpdatedBy);

		/// Extra
		parcel.writeString(Business);
	}
}

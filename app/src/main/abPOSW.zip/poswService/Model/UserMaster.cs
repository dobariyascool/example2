﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poswLibrary
{
    public class UserMaster
    {

        #region Properties
        public short UserMasterId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public short linktoRoleMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public string LastLoginDateTime { get; set; }
        public short LoginFailCount { get; set; }
        public string LastLockoutDateTime { get; set; }
        public string LastPasswordChangedDateTime { get; set; }
        public string Comment { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        public short linktoBusinessGroupMasterId { get; set; }

        //Extra
        public string Role { get; set; }
        #endregion

        internal void SetClassObject(poswUserMasterDAL objUserMasterDAL)
        {
            this.UserMasterId = Convert.ToInt16(objUserMasterDAL.UserMasterId);
            this.Username = Convert.ToString(objUserMasterDAL.Username);
            this.Password = Convert.ToString(objUserMasterDAL.Password);
            this.linktoRoleMasterId = Convert.ToInt16(objUserMasterDAL.linktoRoleMasterId);
            this.CreateDateTime = objUserMasterDAL.CreateDateTime.ToString("s");
            this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objUserMasterDAL.linktoUserMasterIdCreatedBy);
            if (objUserMasterDAL.UpdateDateTime != null)
            {
                this.UpdateDateTime = objUserMasterDAL.UpdateDateTime.Value.ToString("s");
            }
            if (objUserMasterDAL.linktoUserMasterIdUpdatedBy != null)
            {
                this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objUserMasterDAL.linktoUserMasterIdUpdatedBy);
            }
            if (objUserMasterDAL.LastLoginDateTime != null)
            {
                this.LastLoginDateTime = objUserMasterDAL.LastLoginDateTime.Value.ToString("s");
            }
            this.LoginFailCount = Convert.ToInt16(objUserMasterDAL.LoginFailCount);
            if (objUserMasterDAL.LastLockoutDateTime != null)
            {
                this.LastLockoutDateTime = objUserMasterDAL.LastLockoutDateTime.Value.ToString("s");
            }
            if (objUserMasterDAL.LastPasswordChangedDateTime!= null)
            {
                this.LastPasswordChangedDateTime = objUserMasterDAL.LastPasswordChangedDateTime.Value.ToString("s");
            }
            this.Comment = Convert.ToString(objUserMasterDAL.Comment);
            this.linktoBusinessMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessMasterId);
            this.IsEnabled = Convert.ToBoolean(objUserMasterDAL.IsEnabled);
            this.IsDeleted = Convert.ToBoolean(objUserMasterDAL.IsDeleted);
            this.linktoBusinessTypeMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessTypeMasterId);
            this.linktoBusinessGroupMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessGroupMasterId);
            /// Extra
            this.Role = Convert.ToString(objUserMasterDAL.Role);
        }

        internal static List<UserMaster> SetListObject(List<poswUserMasterDAL> lstUserMasterDAL)
        {
            List<UserMaster> lstUserMaster = new List<UserMaster>();
            UserMaster objUserMaster = null;
            foreach (poswUserMasterDAL objUserMasterDAL in lstUserMasterDAL)
            {
                objUserMaster = new UserMaster();
                objUserMaster.UserMasterId = Convert.ToInt16(objUserMasterDAL.UserMasterId);
                objUserMaster.Username = Convert.ToString(objUserMasterDAL.Username);
                objUserMaster.Password = Convert.ToString(objUserMasterDAL.Password);
                objUserMaster.linktoRoleMasterId = Convert.ToInt16(objUserMasterDAL.linktoRoleMasterId);
                objUserMaster.CreateDateTime = objUserMasterDAL.CreateDateTime.ToString("s");
                objUserMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objUserMasterDAL.linktoUserMasterIdCreatedBy);
                if (objUserMasterDAL.UpdateDateTime != null)
                {
                    objUserMaster.UpdateDateTime = objUserMasterDAL.UpdateDateTime.Value.ToString("s");
                }
                if (objUserMasterDAL.linktoUserMasterIdUpdatedBy != null)
                {
                    objUserMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objUserMasterDAL.linktoUserMasterIdUpdatedBy);
                }
                if (objUserMasterDAL.LastLoginDateTime != null)
                {
                    objUserMaster.LastLoginDateTime = objUserMasterDAL.LastLoginDateTime.Value.ToString("s");
                }
                objUserMaster.LoginFailCount = Convert.ToInt16(objUserMasterDAL.LoginFailCount);
                if (objUserMasterDAL.LastLockoutDateTime != null)
                {
                    objUserMaster.LastLockoutDateTime = objUserMasterDAL.LastLockoutDateTime.Value.ToString("s");
                }
                if (objUserMasterDAL.LastPasswordChangedDateTime != null)
                {
                    objUserMaster.LastPasswordChangedDateTime = objUserMasterDAL.LastPasswordChangedDateTime.Value.ToString("s");
                }
                objUserMaster.Comment = Convert.ToString(objUserMasterDAL.Comment);
                objUserMaster.linktoBusinessMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessMasterId);
                objUserMaster.IsEnabled = Convert.ToBoolean(objUserMasterDAL.IsEnabled);
                objUserMaster.IsDeleted = Convert.ToBoolean(objUserMasterDAL.IsDeleted);
                objUserMaster.linktoBusinessTypeMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessTypeMasterId);
                objUserMaster.linktoBusinessGroupMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessGroupMasterId); 
                /// Extra
                objUserMaster.Role = Convert.ToString(objUserMasterDAL.Role);
                lstUserMaster.Add(objUserMaster);
            }
            return lstUserMaster;
        }
    }
}
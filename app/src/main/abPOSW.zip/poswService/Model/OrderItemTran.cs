using System;
using System.Collections.Generic;

namespace poswLibrary
{
    /// <summary>
    /// Model for OrderItemTran
    /// </summary>
    public class OrderItemTran
    {

        public long OrderItemTranId { get; set; }
        public long linktoOrderMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short Quantity { get; set; }
        public double Rate { get; set; }
        public short ItemPoint { get; set; }
        public short DeductedPoint { get; set; }
        public string ItemRemark { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public string UpdateDateTime { get; set; }
        public double DiscountAmount { get; set; }
        public double DiscountPercentage { get; set; }

        /// Extra
        public string Item { get; set; }
        public string OrderRemark { get; set; }
        public string ItemCode { get; set; }
        public string Remark { get; set; }
        public string OrderDateTime { get; set; }
        public double TotalRate { get; set; }
        public int linktoItemMasterModifierId { get; set; }
        public double TotalTax { get; set; }
        public double TotalAmount { get; set; }
        public string OrderNumber { get; set; }
        public bool PaymentStatus { get; set; }
        public int TotalItemQuantity { get; set; }

        internal void SetClassObject(poswOrderItemTranDAL objOrderItemTranDAL)
        {
            this.OrderItemTranId = Convert.ToInt64(objOrderItemTranDAL.OrderItemTranId);
            this.linktoOrderMasterId = Convert.ToInt64(objOrderItemTranDAL.linktoOrderMasterId);
            this.linktoItemMasterId = Convert.ToInt32(objOrderItemTranDAL.linktoItemMasterId);
            this.Quantity = Convert.ToInt16(objOrderItemTranDAL.Quantity);
            this.Rate = Convert.ToDouble(objOrderItemTranDAL.Rate);
            this.ItemCode = Convert.ToString(objOrderItemTranDAL.ItemCode);
            this.DiscountPercentage = Convert.ToDouble(objOrderItemTranDAL.DiscountPercentage);
            this.DiscountAmount = Convert.ToDouble(objOrderItemTranDAL.DiscountAmount);
            this.ItemPoint = Convert.ToInt16(objOrderItemTranDAL.ItemPoint);
            this.DeductedPoint = Convert.ToInt16(objOrderItemTranDAL.DeductedPoint);
            this.ItemRemark = Convert.ToString(objOrderItemTranDAL.ItemRemark);
            if (objOrderItemTranDAL.linktoOrderStatusMasterId != null)
            {
                this.linktoOrderStatusMasterId = Convert.ToInt16(objOrderItemTranDAL.linktoOrderStatusMasterId.Value);
            }
            this.TotalTax = Convert.ToDouble(objOrderItemTranDAL.TotalTax);
            this.linktoItemMasterModifierId = Convert.ToInt32(objOrderItemTranDAL.linktoItemMasterModifierId);

            /// Extra
            this.Item = Convert.ToString(objOrderItemTranDAL.Item);
            this.TotalAmount = Convert.ToDouble(objOrderItemTranDAL.TotalAmount);
            this.TotalRate = Convert.ToDouble(objOrderItemTranDAL.TotalRate);
            this.OrderNumber = Convert.ToString(objOrderItemTranDAL.OrderNumber);
            if (objOrderItemTranDAL.OrderDateTime != null)
            {
                this.OrderDateTime = objOrderItemTranDAL.OrderDateTime.Value.ToString("s");
            }
            this.PaymentStatus = Convert.ToBoolean(objOrderItemTranDAL.IsBookingOrder);
            this.TotalItemQuantity = Convert.ToInt32(objOrderItemTranDAL.TotalItemQuantity);
        }

        internal static List<OrderItemTran> SetListObject(List<poswOrderItemTranDAL> lstOrderItemTranDAL)
        {
            List<OrderItemTran> lstOrderItemTran = new List<OrderItemTran>();
            OrderItemTran objOrderItemTran = null;
            foreach (poswOrderItemTranDAL objOrderItemTranDAL in lstOrderItemTranDAL)
            {
                objOrderItemTran = new OrderItemTran();
                objOrderItemTran.OrderItemTranId = Convert.ToInt64(objOrderItemTranDAL.OrderItemTranId);
                objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(objOrderItemTranDAL.linktoOrderMasterId);
                objOrderItemTran.linktoItemMasterId = Convert.ToInt32(objOrderItemTranDAL.linktoItemMasterId);
                objOrderItemTran.Quantity = Convert.ToInt16(objOrderItemTranDAL.Quantity);
                objOrderItemTran.Rate = Convert.ToDouble(objOrderItemTranDAL.Rate);
                objOrderItemTran.ItemCode = Convert.ToString(objOrderItemTranDAL.ItemCode);
           
                objOrderItemTran.DiscountPercentage = Convert.ToDouble(objOrderItemTranDAL.DiscountPercentage);
                objOrderItemTran.DiscountAmount = Convert.ToDouble(objOrderItemTranDAL.DiscountAmount);
             
                objOrderItemTran.ItemPoint = Convert.ToInt16(objOrderItemTranDAL.ItemPoint);
                objOrderItemTran.DeductedPoint = Convert.ToInt16(objOrderItemTranDAL.DeductedPoint);
                objOrderItemTran.ItemRemark = Convert.ToString(objOrderItemTranDAL.ItemRemark);
                if (objOrderItemTranDAL.linktoOrderStatusMasterId != null)
                {
                    objOrderItemTran.linktoOrderStatusMasterId = Convert.ToInt16(objOrderItemTranDAL.linktoOrderStatusMasterId.Value);
                }
                objOrderItemTran.TotalTax = Convert.ToDouble(objOrderItemTranDAL.TotalTax);
                objOrderItemTran.linktoItemMasterModifierId = Convert.ToInt32(objOrderItemTranDAL.linktoItemMasterModifierId);

                /// Extra
                objOrderItemTran.Item = Convert.ToString(objOrderItemTranDAL.Item);
                objOrderItemTran.TotalRate = Convert.ToDouble(objOrderItemTranDAL.TotalRate);
                objOrderItemTran.TotalAmount = Convert.ToDouble(objOrderItemTranDAL.TotalAmount);
                objOrderItemTran.OrderNumber = Convert.ToString(objOrderItemTranDAL.OrderNumber);
                if (objOrderItemTranDAL.OrderDateTime != null)
                {
                    objOrderItemTran.OrderDateTime = objOrderItemTranDAL.OrderDateTime.Value.ToString("s");
                }
                objOrderItemTran.PaymentStatus = objOrderItemTranDAL.IsBookingOrder;
                objOrderItemTran.TotalItemQuantity = Convert.ToInt32(objOrderItemTranDAL.TotalItemQuantity);
                lstOrderItemTran.Add(objOrderItemTran);
            }
            return lstOrderItemTran;
        }
    }
}

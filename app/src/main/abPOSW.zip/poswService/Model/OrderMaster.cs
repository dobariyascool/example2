using System;
using System.Collections.Generic;

namespace poswLibrary
{
	
	public class OrderMaster
	{
        public long OrderMasterId { get; set; }
        public string OrderNumber { get; set; }
        public string OrderDateTime { get; set; }
        public string linktoTableMasterIds { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public int? linktoBookingMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public double TotalAmount { get; set; }
        public double TotalTax { get; set; }
        public double Discount { get; set; }
        public double ExtraAmount { get; set; }
        public short TotalItemPoint { get; set; }
        public short TotalDeductedPoint { get; set; }
        public string Remark { get; set; }
        public bool IsPreOrder { get; set; }
        public long? linktoSalesMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public string UpdateDateTime { get; set; }
        public int? linktoCustomerAddressTranId { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double BalanceAmount { get; set; }

		/// Extra
		public string OrderType { get; set; }
        public string OrderStatus { get; set; }
        public int linktoOfferMasterId { get; set; }
        public string OfferCode { get; set; }
        public double DailyOrder { get; set; }
        public double WeeklyOrder { get; set; }
        public double MonthlyOrder { get; set; }
        public string Month { get; set; }
        public string Year { get; set; }
        public string LeastSellingDayName { get; set; }
        public string OrderDateTimeString { get; set; }

		internal void SetClassObject(poswOrderMasterDAL objOrderMasterDAL)
		{
			this.OrderMasterId = Convert.ToInt64(objOrderMasterDAL.OrderMasterId);
			this.OrderNumber = Convert.ToString(objOrderMasterDAL.OrderNumber);
			this.OrderDateTime = objOrderMasterDAL.OrderDateTime.ToString("s");
			this.linktoTableMasterIds = Convert.ToString(objOrderMasterDAL.linktoTableMasterIds);
			if (objOrderMasterDAL.linktoCustomerMasterId != null)
			{
				this.linktoCustomerMasterId = Convert.ToInt32(objOrderMasterDAL.linktoCustomerMasterId.Value);
			}
			this.linktoOrderTypeMasterId = Convert.ToInt16(objOrderMasterDAL.linktoOrderTypeMasterId);
			if (objOrderMasterDAL.linktoOrderStatusMasterId != null)
			{
				this.linktoOrderStatusMasterId = Convert.ToInt16(objOrderMasterDAL.linktoOrderStatusMasterId.Value);
			}
			if (objOrderMasterDAL.linktoBookingMasterId != null)
			{
				this.linktoBookingMasterId = Convert.ToInt32(objOrderMasterDAL.linktoBookingMasterId.Value);
			}
            this.linktoBusinessMasterId = Convert.ToInt16(objOrderMasterDAL.linktoBusinessMasterId);
			this.TotalAmount = Convert.ToDouble(objOrderMasterDAL.TotalAmount);
			this.TotalTax = Convert.ToDouble(objOrderMasterDAL.TotalTax);
			this.Discount = Convert.ToDouble(objOrderMasterDAL.Discount);
			this.ExtraAmount = Convert.ToDouble(objOrderMasterDAL.ExtraAmount);
			this.NetAmount = Convert.ToDouble(objOrderMasterDAL.NetAmount);
			this.PaidAmount = Convert.ToDouble(objOrderMasterDAL.PaidAmount);
			this.BalanceAmount = Convert.ToDouble(objOrderMasterDAL.BalanceAmount);
			this.TotalItemPoint = Convert.ToInt16(objOrderMasterDAL.TotalItemPoint);
			this.TotalDeductedPoint = Convert.ToInt16(objOrderMasterDAL.TotalDeductedPoint);
			this.Remark = Convert.ToString(objOrderMasterDAL.Remark);
			this.IsPreOrder = Convert.ToBoolean(objOrderMasterDAL.IsPreOrder);
			if (objOrderMasterDAL.linktoCustomerAddressTranId != null)
			{
				this.linktoCustomerAddressTranId = Convert.ToInt32(objOrderMasterDAL.linktoCustomerAddressTranId.Value);
			}
            if (objOrderMasterDAL.OrderDateTimeString!= null)
            {
                this.OrderDateTimeString = Convert.ToString(objOrderMasterDAL.OrderDateTimeString);
            }
			if (objOrderMasterDAL.linktoSalesMasterId != null)
			{
				this.linktoSalesMasterId = Convert.ToInt64(objOrderMasterDAL.linktoSalesMasterId.Value);
			}
            //if (objOrderMasterDAL.linktoOfferMasterId != null)
            //{
            //    this.linktoOfferMasterId = Convert.ToInt32(objOrderMasterDAL.linktoOfferMasterId);
            //}
            this.OfferCode = Convert.ToString(objOrderMasterDAL.OfferCode);
            this.CreateDateTime = objOrderMasterDAL.CreateDateTime.ToString("s");
			if (objOrderMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objOrderMasterDAL.UpdateDateTime.Value.ToString("s");
			}

			/// Extra
            this.OrderType = Convert.ToString(objOrderMasterDAL.OrderType);
            this.OrderStatus = Convert.ToString(objOrderMasterDAL.OrderStatus);
            this.DailyOrder = Convert.ToDouble(objOrderMasterDAL.DailyOrder);
            this.MonthlyOrder= Convert.ToDouble(objOrderMasterDAL.MonthlyOrder);
            this.WeeklyOrder = Convert.ToDouble(objOrderMasterDAL.WeeklyOrder);
            this.Month = Convert.ToString(objOrderMasterDAL.Month);
            this.Year = Convert.ToString(objOrderMasterDAL.Year);
            this.LeastSellingDayName = Convert.ToString(objOrderMasterDAL.LeastSellingDayName);
		}

		internal static List<OrderMaster> SetListObject(List<poswOrderMasterDAL> lstOrderMasterDAL)
		{
			List<OrderMaster> lstOrderMaster = new List<OrderMaster>();
			OrderMaster objOrderMaster = null;
			foreach (poswOrderMasterDAL objOrderMasterDAL in lstOrderMasterDAL)
			{
				objOrderMaster = new OrderMaster();
				objOrderMaster.OrderMasterId = Convert.ToInt64(objOrderMasterDAL.OrderMasterId);
				objOrderMaster.OrderNumber = Convert.ToString(objOrderMasterDAL.OrderNumber);
				objOrderMaster.OrderDateTime = objOrderMasterDAL.OrderDateTime.ToString("s");
				objOrderMaster.linktoTableMasterIds = Convert.ToString(objOrderMasterDAL.linktoTableMasterIds);
				if (objOrderMasterDAL.linktoCustomerMasterId != null)
				{
					objOrderMaster.linktoCustomerMasterId = Convert.ToInt32(objOrderMasterDAL.linktoCustomerMasterId.Value);
				}				
				objOrderMaster.linktoOrderTypeMasterId = Convert.ToInt16(objOrderMasterDAL.linktoOrderTypeMasterId);
				if (objOrderMasterDAL.linktoOrderStatusMasterId != null)
				{
					objOrderMaster.linktoOrderStatusMasterId = Convert.ToInt16(objOrderMasterDAL.linktoOrderStatusMasterId.Value);
				}
				if (objOrderMasterDAL.linktoBookingMasterId != null)
				{
					objOrderMaster.linktoBookingMasterId = Convert.ToInt32(objOrderMasterDAL.linktoBookingMasterId.Value);
				}
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(objOrderMasterDAL.linktoBusinessMasterId);
				objOrderMaster.TotalAmount = Convert.ToDouble(objOrderMasterDAL.TotalAmount);
				objOrderMaster.TotalTax = Convert.ToDouble(objOrderMasterDAL.TotalTax);
				objOrderMaster.Discount = Convert.ToDouble(objOrderMasterDAL.Discount);
				objOrderMaster.ExtraAmount = Convert.ToDouble(objOrderMasterDAL.ExtraAmount);
				objOrderMaster.NetAmount = Convert.ToDouble(objOrderMasterDAL.NetAmount);
				objOrderMaster.PaidAmount = Convert.ToDouble(objOrderMasterDAL.PaidAmount);
				objOrderMaster.BalanceAmount = Convert.ToDouble(objOrderMasterDAL.BalanceAmount);
				objOrderMaster.TotalItemPoint = Convert.ToInt16(objOrderMasterDAL.TotalItemPoint);
				objOrderMaster.TotalDeductedPoint = Convert.ToInt16(objOrderMasterDAL.TotalDeductedPoint);
				objOrderMaster.Remark = Convert.ToString(objOrderMasterDAL.Remark);
				objOrderMaster.IsPreOrder = Convert.ToBoolean(objOrderMasterDAL.IsPreOrder);
				if (objOrderMasterDAL.linktoCustomerAddressTranId != null)
				{
					objOrderMaster.linktoCustomerAddressTranId = Convert.ToInt32(objOrderMasterDAL.linktoCustomerAddressTranId.Value);
				}
				if (objOrderMasterDAL.linktoSalesMasterId != null)
				{
					objOrderMaster.linktoSalesMasterId = Convert.ToInt64(objOrderMasterDAL.linktoSalesMasterId.Value);
				}
                //if (objOrderMasterDAL.linktoOfferMasterId != null)
                //{
                //    objOrderMaster.linktoOfferMasterId = Convert.ToInt32(objOrderMasterDAL.linktoOfferMasterId);
                //}
                objOrderMaster.OfferCode = Convert.ToString(objOrderMasterDAL.OfferCode);
                objOrderMaster.CreateDateTime = objOrderMasterDAL.CreateDateTime.ToString("s");
				if (objOrderMasterDAL.UpdateDateTime != null)
				{
					objOrderMaster.UpdateDateTime = objOrderMasterDAL.UpdateDateTime.Value.ToString("s");
				}

				/// Extra
                objOrderMaster.OrderType = Convert.ToString(objOrderMasterDAL.OrderType);
                objOrderMaster.OrderStatus = Convert.ToString(objOrderMasterDAL.OrderStatus);
                objOrderMaster.DailyOrder = Convert.ToDouble(objOrderMasterDAL.DailyOrder);
                objOrderMaster.MonthlyOrder = Convert.ToDouble(objOrderMasterDAL.MonthlyOrder);
                objOrderMaster.WeeklyOrder = Convert.ToDouble(objOrderMasterDAL.WeeklyOrder);
                objOrderMaster.Month = Convert.ToString(objOrderMasterDAL.Month);
                objOrderMaster.Year = Convert.ToString(objOrderMasterDAL.Year);
                objOrderMaster.LeastSellingDayName = Convert.ToString(objOrderMasterDAL.LeastSellingDayName);
				lstOrderMaster.Add(objOrderMaster);
			}
			return lstOrderMaster;
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using poswLibrary;

namespace poswService.Model
{
    public class OrderPaymentTran
    {
        #region Properties

        public long OrderPaymentTranId { get; set; }
        public long linktoOrderMasterId { get; set; }
        public short linktoPaymentTypeMasterId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string PaymentDateTime { get; set; }
        public double AmountPaid { get; set; }
        public string Remark { get; set; }
        public bool IsDeleted { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short linktoUserMasterIdUpdatedBy { get; set; }

        //Extras
        public string PaymentType { get; set; }
        public double totalAmount { get; set; }

        #endregion


        internal void SetClassObject(poswOrderPaymentTranDAL objOrderPaymentTranDAL)
        {
            if (objOrderPaymentTranDAL.OrderPaymentTranId != null)
            {
                this.OrderPaymentTranId = Convert.ToInt64(objOrderPaymentTranDAL.OrderPaymentTranId);
            }
            if (objOrderPaymentTranDAL.linktoOrderMasterId != null)
            {
                this.linktoOrderMasterId = Convert.ToInt64(objOrderPaymentTranDAL.linktoOrderMasterId);
            }
            if (objOrderPaymentTranDAL.linktoPaymentTypeMasterId != null)
            {
                this.linktoPaymentTypeMasterId = Convert.ToInt16(objOrderPaymentTranDAL.linktoPaymentTypeMasterId);
            }
            if (objOrderPaymentTranDAL.linktoCustomerMasterId!= null)
            {
                this.linktoCustomerMasterId = Convert.ToInt32(objOrderPaymentTranDAL.linktoCustomerMasterId);
            }
           this.AmountPaid = Convert.ToDouble(objOrderPaymentTranDAL.AmountPaid);
            if (objOrderPaymentTranDAL.PaymentDateTime != null)
            {
                this.PaymentDateTime = objOrderPaymentTranDAL.PaymentDateTime.ToString("yyyy-MM-dd");
            }
            if (objOrderPaymentTranDAL.Remark != null)
            {
                this.Remark = Convert.ToString(objOrderPaymentTranDAL.Remark);
            }           
                this.IsDeleted = Convert.ToBoolean(objOrderPaymentTranDAL.IsDeleted);         
            if (objOrderPaymentTranDAL.CreateDateTime != null)
            {
                this.CreateDateTime = objOrderPaymentTranDAL.CreateDateTime.ToString("yyyy-MM-dd");
            }
            if (objOrderPaymentTranDAL.linktoUserMasterIdCreatedBy != null)
            {
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objOrderPaymentTranDAL.linktoUserMasterIdCreatedBy);
            }
            if (objOrderPaymentTranDAL.linktoUserMasterIdUpdatedBy != null)
            {
                this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOrderPaymentTranDAL.linktoUserMasterIdUpdatedBy);
            }
            if (objOrderPaymentTranDAL.UpdateDateTime != null)
            {
                this.UpdateDateTime = objOrderPaymentTranDAL.UpdateDateTime.Value.ToString("yyyy-MM-dd");
            }
            if (objOrderPaymentTranDAL.PaymentType != null)
            {
                this.PaymentType = Convert.ToString(objOrderPaymentTranDAL.PaymentType);
            }
            if (objOrderPaymentTranDAL.totalAmount != null)
            {
                this.totalAmount = Convert.ToDouble(objOrderPaymentTranDAL.totalAmount);
            }
            
        }


        internal static List<OrderPaymentTran> SetListObject(List<poswOrderPaymentTranDAL> lstOrderPaymentTranDAL)
        {

            List<OrderPaymentTran> lstOrderPaymentTrans = new List<OrderPaymentTran>();
            OrderPaymentTran objOrderPaymentTran = null;

            foreach (poswOrderPaymentTranDAL objOrderPaymentTranDAL in lstOrderPaymentTranDAL)
            {
                objOrderPaymentTran = new OrderPaymentTran();

                if (objOrderPaymentTranDAL.OrderPaymentTranId != null)
                {
                    objOrderPaymentTran.OrderPaymentTranId = Convert.ToInt64(objOrderPaymentTranDAL.OrderPaymentTranId);
                }
                if (objOrderPaymentTranDAL.linktoOrderMasterId != null)
                {
                    objOrderPaymentTran.linktoOrderMasterId = Convert.ToInt64(objOrderPaymentTranDAL.linktoOrderMasterId);
                }
                if (objOrderPaymentTranDAL.linktoPaymentTypeMasterId != null)
                {
                    objOrderPaymentTran.linktoPaymentTypeMasterId = Convert.ToInt16(objOrderPaymentTranDAL.linktoPaymentTypeMasterId);
                }
                if (objOrderPaymentTranDAL.linktoCustomerMasterId != null)
                {
                    objOrderPaymentTran.linktoCustomerMasterId = Convert.ToInt32(objOrderPaymentTranDAL.linktoCustomerMasterId);
                }
               objOrderPaymentTran.AmountPaid = Convert.ToDouble(objOrderPaymentTranDAL.AmountPaid);             
                if (objOrderPaymentTranDAL.PaymentDateTime != null)
                {
                    objOrderPaymentTran.PaymentDateTime = objOrderPaymentTranDAL.PaymentDateTime.ToString("yyyy-MM-dd");
                }
                if (objOrderPaymentTranDAL.Remark != null)
                {
                    objOrderPaymentTran.Remark = Convert.ToString(objOrderPaymentTranDAL.Remark);
                }
              objOrderPaymentTran.IsDeleted = Convert.ToBoolean(objOrderPaymentTranDAL.IsDeleted);
                if (objOrderPaymentTranDAL.CreateDateTime != null)
                {
                    objOrderPaymentTran.CreateDateTime = objOrderPaymentTranDAL.CreateDateTime.ToString("yyyy-MM-dd");
                }
                if (objOrderPaymentTranDAL.linktoUserMasterIdCreatedBy != null)
                {
                    objOrderPaymentTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(objOrderPaymentTranDAL.linktoUserMasterIdCreatedBy);
                }
                if (objOrderPaymentTranDAL.linktoUserMasterIdUpdatedBy != null)
                {
                    objOrderPaymentTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOrderPaymentTranDAL.linktoUserMasterIdUpdatedBy);
                }
                if (objOrderPaymentTranDAL.UpdateDateTime != null)
                {
                    objOrderPaymentTran.UpdateDateTime = objOrderPaymentTranDAL.UpdateDateTime.Value.ToString("yyyy-MM-dd");
                }
                if (objOrderPaymentTranDAL.PaymentType != null)
                {
                    objOrderPaymentTran.PaymentType = Convert.ToString(objOrderPaymentTranDAL.PaymentType);
                }
                if (objOrderPaymentTranDAL.totalAmount != null)
                {
                    objOrderPaymentTran.totalAmount = Convert.ToDouble(objOrderPaymentTranDAL.totalAmount);
                }

                lstOrderPaymentTrans.Add(objOrderPaymentTran);
            }
            return lstOrderPaymentTrans;
        }
    }
}
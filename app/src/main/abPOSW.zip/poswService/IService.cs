﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using poswLibrary;
using poswService.Model;

namespace poswService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService" in both code and config file together.
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        [WebGet(UriTemplate = "SelectAllCityMasterByState/{linktoStateMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<CityMaster> SelectAllCityMasterByState(string linktoStateMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllAreaMasterByCity/{linktoCityMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<AreaMaster> SelectAllAreaMasterByCity(string linktoCityMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOfferMasterPageWise/{currentPage}/{linktoBusinessMasterId}/{fromday}/{frommonth}/{fromyear}/{fromhour}/{fromminute}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OfferMaster> SelectAllOfferMasterPageWise(string currentPage, string linktoBusinessMasterId, string fromday, string frommonth, string fromyear, string fromhour, string fromminute);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOfferMaster/{linktoBusinessMasterId}/{fromday}/{frommonth}/{fromyear}/{fromhour}/{fromminute}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OfferMaster> SelectAllOfferMaster(string linktoBusinessMasterId, string fromday, string frommonth, string fromyear, string fromhour, string fromminute);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessHoursTranByBusinessMasterId/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessHoursTran> SelectAllBusinessHoursTranByBusinessMasterId(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessGalleryTranPageWise/{currentPage}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessGalleryTran> SelectAllBusinessGalleryTranPageWise(string currentPage, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllCategoryMaster/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<CategoryMaster> SelectAllCategoryMaster(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemMasterByCategoryMasterId/{currentPage}/{linktoCatgoryMasterId}/{optionValueId}/{linktoBusinessMasterId}/{itemMasterIds}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemMaster> SelectAllItemMasterByCategoryMasterId(string currentPage, string linktoCatgoryMasterId, string optionValueId, string linktoBusinessMasterId, string itemMasterIds);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemMasterIdByCategoryMasterId/{linktoCatgoryMasterId}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemMaster> SelectAllItemMasterIdByCategoryMasterId(string linktoCatgoryMasterId, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemModifier/{linktoItemMasterId}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemMaster> SelectAllItemModifier(string linktoItemMasterId, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemOption/{linktoItemMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OptionValueTran> SelectAllItemOption(string linktoItemMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemSuggested/{linktoItemMasterId}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemMaster> SelectAllItemSuggested(string linktoItemMasterId, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllReviewMaster/{currentPage}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ReviewMaster> SelectAllReviewMaster(string currentPage, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllTaxMaster/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<TaxMaster> SelectAllTaxMaster(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllQuestionAnswer/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<FeedbackQuestionMaster> SelectAllQuestionAnswer(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessInfoAnswerMaster/{linktoBusinessTypeMasterId}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessInfoAnswerMaster> SelectAllBusinessInfoAnswerMaster(string linktoBusinessTypeMasterId, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderMasterWithOrderItem/{currentPage}/{linktoBusinessMasterId}/{customerMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderItemTran> SelectAllOrderMasterWithOrderItem(string currentPage, string linktoBusinessMasterId, string customerMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBookingMaster/{currentPage}/{linktoBusinessMasterId}/{customerMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BookingMaster> SelectAllBookingMaster(string currentPage, string linktoBusinessMasterId, string customerMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllTimeSlots/{linktoBusinessMasterId}/{fromday}/{frommonth}/{fromyear}/{timeDuration}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BookingMaster> SelectAllTimeSlots(string linktoBusinessMasterId, string fromday, string frommonth, string fromyear, string timeDuration);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllStateMasterStateNameByCountry/{linktoCountryMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<StateMaster> SelectAllStateMasterStateNameByCountry(string linktoCountryMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllCustomerAddressTran/{linktoCustomerMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<CustomerAddressTran> SelectAllCustomerAddressTran(string linktoCustomerMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessService/{businessTypeMasterId}/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessServiceTran> SelectAllBusinessService(string businessTypeMasterId,string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessMasterByBusinessGroup/{linktoBusinessGroupMasterId}/{city}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessMaster> SelectAllBusinessMasterByBusinessGroup(string linktoBusinessGroupMasterId,string city);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBannerMaster/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BannerMaster> SelectAllBannerMaster(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllUserRightsTran/{linktoRoleMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<UserRightsTran> SelectAllUserRightsTran(string linktoRoleMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderMasterOrderTypeWiseChart/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderMaster> SelectAllOrderMasterOrderTypeWiseChart(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderMasterYearlyRevenueChart/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderMaster> SelectAllOrderMasterYearlyRevenueChart(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderItemTranMostOrderedItemsChart/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderItemTran> SelectAllOrderItemTranMostOrderedItemsChart(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderItemTranLeastOrderedItemsChart/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderItemTran> SelectAllOrderItemTranLeastOrderedItemsChart(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllEventsPageWise/{linktoBusinessMasterId}/{currentPage}/{eventType}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<Events> SelectAllEventsPageWise(string linktoBusinessMasterId, string currentPage, string eventType);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllDailySaleDateWise/{linktoBusinessMasterId}/{fromDate}/{toDate}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderPaymentTran> SelectAllDailySaleDateWise(string linktoBusinessMasterId, string fromDate, string toDate);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderMasterWithOrderItemByStatus/{currentPage}/{linktoBusinessMasterId}/{statusCancel}/{fromDate}/{toDate}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderItemTran> SelectAllOrderMasterWithOrderItemByStatus(string currentPage, string linktoBusinessMasterId, string statusCancel, string fromDate, string toDate);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBookingMasterByStatus/{currentPage}/{linktoBusinessMasterId}/{statusCancel}/{fromDate}/{toDate}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BookingMaster> SelectAllBookingMasterByStatus(string currentPage, string linktoBusinessMasterId, string statusCancel, string fromDate, string toDate);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllNotificationMasterPageWise/{currentPage}/{linktoBusinessMasterId}/{linktoCustomerMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<NotificationMaster> SelectAllNotificationMasterPageWise(string currentPage, string linktoBusinessMasterId, string linktoCustomerMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectCustomerMaster/{userName}/{password}/{customerMasterId}/{businessMasterId}/{FCMToken}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        CustomerMaster SelectCustomerMaster(string userName, string password, string customerMasterId, string businessMasterId, string FCMToken);

        [OperationContract]
        [WebGet(UriTemplate = "SelectUserMaster/{userName}/{password}/{FCMToken}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        UserMaster SelectUserMaster(string userName, string password, string FCMToken);

        [OperationContract]
        [WebGet(UriTemplate = "SelectBusinessMasterByBusinessMasterId/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        BusinessMaster SelectBusinessMasterByBusinessMasterId(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectBusinessDescription/{businessMasterId}/{keyword}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        BusinessDescription SelectBusinessDescription(string businessMasterId, string keyword);

        [OperationContract]
        [WebInvoke(UriTemplate = "SelectBookingMasterIfBookingAvailable", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        bool SelectBookingMasterIfBookingAvailable(BookingMaster objBookingMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "SelectOfferMasterOfferCodeVerification", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        OfferMaster SelectOfferMasterOfferCodeVerification(OfferMaster objOfferMaster);

        [OperationContract]
        [WebGet(UriTemplate = "SelectOfferMaster/{offerMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        OfferMaster SelectOfferMaster(string offerMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectCategoryMaster/{linktoBusinessMasterId}/{CategoryMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        CategoryMaster SelectCategoryMaster(string linktoBusinessMasterId, string CategoryMasterId);
       
        [OperationContract]
        [WebGet(UriTemplate = "SelectDashBoardCounter/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        Dashboard SelectDashBoardCounter(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectOrderMasterDailyWeeklyMonthlyOrders/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        OrderMaster SelectOrderMasterDailyWeeklyMonthlyOrders(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectOrderMasterLeastSellingDayOfLastWeek/{linktoBusinessMasterId}/{fromDate}/{currentDate}/{DateRange}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        OrderMaster SelectOrderMasterLeastSellingDayOfLastWeek(string linktoBusinessMasterId, string fromDate, string currentDate, string DateRange);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertCustomerMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        CustomerMaster InsertCustomerMaster(CustomerMaster customerMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertOrderMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertOrderMaster(OrderMaster orderMaster, List<ItemMaster> lstOrderItemTran, List<TaxMaster> lstTaxMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertReviewMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertReviewMaster(ReviewMaster reviewMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertFeedbackQuestionMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertFeedbackQuestionMaster(FeedbackMaster feedbackMaster, List<FeedbackTran> lstFeedbackTran);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertBookingMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertBookingMaster(BookingMaster bookingMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertContactUsMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertContactUsMaster(ContactUsMaster contactUsMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertCustomerAddressTran", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertCustomerAddressTran(CustomerAddressTran customerAddressTran);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertNotificationMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        NotificationMaster InsertNotificationMaster(NotificationMaster notificationMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertFCMMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertFCMMaster(FCMMaster fCMMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertNotificationTran", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertNotificationTran(NotificationTran notificationTran);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateCustomerMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        CustomerMaster UpdateCustomerMaster(CustomerMaster customerMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateCustomerAddressTran", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateCustomerAddressTran(CustomerAddressTran customerAddressTran);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateCustomerMasterPassword", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateCustomerMasterPassword(CustomerMaster customerMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateBookingMasterStatus", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateBookingMasterStatus(BookingMaster bookingMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateOrderMasterStatus", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateOrderMasterStatus(OrderMaster orderMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateFCMMasterByCustomerId", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateFCMMasterByCustomerId(FCMMaster fCMMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "DeleteCustomerAddressTran/{customerAddressTranId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus DeleteCustomerAddressTran(string customerAddressTranId);

        [OperationContract]
        [WebGet(UriTemplate = "UpdateUserMasterPassword/{userMasterId}/{userPassword}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateUserMasterPassword(string userMasterId, string userPassword);

        [OperationContract]
        [WebGet(UriTemplate = "SendNotificationsToAll/{linktoBusinessMasterId}/{notificationMasterId}/{customerType}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        void SendNotificationsToAll(string linktoBusinessMasterId, string notificationMasterId, string customerType);
    }
}

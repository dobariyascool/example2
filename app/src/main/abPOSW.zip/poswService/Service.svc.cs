﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using poswLibrary;
using System.Globalization;
using System.IO;
using poswService.Model;
using System.Drawing;
using System.Drawing.Imaging;

namespace poswService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
    public class Service : IService
    {
        #region posw

        #region Insert

        public CustomerMaster InsertCustomerMaster(CustomerMaster customerMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            CustomerMaster objCustomerMaster = new CustomerMaster();
            poswCustomerAddressTranDAL objCustomerAddressTranDAL = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "customer/";
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "customer\\";
            try
            {
                poswCustomerMasterDAL objCustomerMasterDAL = new poswCustomerMasterDAL();

                objCustomerMasterDAL.CustomerName = customerMaster.CustomerName;
                objCustomerMasterDAL.ShortName = customerMaster.ShortName;
                objCustomerMasterDAL.Email1 = customerMaster.Email1;
                objCustomerMasterDAL.Password = customerMaster.Password;
                objCustomerMasterDAL.Phone1 = customerMaster.Phone1;
                if (customerMaster.BirthDate != null)
                {
                    objCustomerMasterDAL.BirthDate = DateTime.ParseExact(customerMaster.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                }
                objCustomerMasterDAL.Gender = customerMaster.Gender;
                objCustomerMasterDAL.CreateDateTime = DateTime.ParseExact(customerMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerMasterDAL.LastLoginDateTime = DateTime.ParseExact(customerMaster.LastLoginDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerMasterDAL.CustomerType = customerMaster.CustomerType;
                objCustomerMasterDAL.linktoSourceMasterId = customerMaster.linktoSourceMasterId;
                objCustomerMasterDAL.linktoBusinessMasterId = customerMaster.linktoBusinessMasterId;
                objCustomerMasterDAL.IsFavourite = false;
                objCustomerMasterDAL.IsCredit = false;
                objCustomerMasterDAL.IsPhone1DND = false;
                objCustomerMasterDAL.IsEnabled = customerMaster.IsEnabled;
                objCustomerMasterDAL.FacebookUserId = customerMaster.FacebookUserId;
                objCustomerMasterDAL.GooglePlusUserId = customerMaster.GooglePlusUserId;
                if (customerMaster.FCMToken != null)
                {
                    objCustomerMasterDAL.FCMToken = customerMaster.FCMToken.Replace("2E2", ":").Replace("3E3", "-").Replace("4E4", "_");
                }
                if (customerMaster.IsVerified != null)
                {
                    objCustomerMasterDAL.IsVerified = customerMaster.IsVerified;
                }
                objCustomerMasterDAL.IsSignIn = customerMaster.IsSignIn;
                if (customerMaster.AgeMinRange > 0)
                {
                    objCustomerMasterDAL.AgeMinRange = customerMaster.AgeMinRange;
                }
                if (customerMaster.AgeMaxRange > 0)
                {
                    objCustomerMasterDAL.AgeMaxRange = customerMaster.AgeMaxRange;
                }
                if ((customerMaster.ImageName != null) && (customerMaster.ImageNamePhysicalNameBytes != null) && (objCustomerMasterDAL.GooglePlusUserId == null || objCustomerMasterDAL.FacebookUserId == null))
                {
                    if (!Directory.Exists(ImageSavePath))
                    {
                        Directory.CreateDirectory(ImageSavePath);
                    }
                    byte[] buffer = Convert.FromBase64String(customerMaster.ImageNamePhysicalNameBytes);
                    MemoryStream ms = new MemoryStream(buffer);
                    Image image = Image.FromStream(ms);
                    image.Save(ImageSavePath + customerMaster.ImageName);
                    poswGlobalsDAL.CreateThumbImages(customerMaster.ImageName, ImageSavePath);
                    objCustomerMasterDAL.ImageName = customerMaster.ImageName;
                }
                else
                {
                    objCustomerMasterDAL.ImageName = customerMaster.ImageName;
                }

                if (customerMaster.linktoCountryMasterId != null)
                {
                    objCustomerAddressTranDAL = new poswCustomerAddressTranDAL();
                    objCustomerAddressTranDAL.linktoCountryMasterId = customerMaster.linktoCountryMasterId;
                    objCustomerAddressTranDAL.linktoStateMasterId = customerMaster.linktoStateMasterId;
                    objCustomerAddressTranDAL.linktoCityMasterId = customerMaster.linktoCityMasterId;
                    objCustomerAddressTranDAL.linktoAreaMasterId = customerMaster.linktoAreaMasterId;
                    objCustomerAddressTranDAL.IsPrimary = customerMaster.IsPrimary;
                    objCustomerAddressTranDAL.CustomerName = customerMaster.CustomerName;
                    objCustomerAddressTranDAL.CreateDateTime = DateTime.ParseExact(customerMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                }


                poswRecordStatus rs = objCustomerMasterDAL.InsertCustomerMaster(objCustomerAddressTranDAL);
                if (rs == poswRecordStatus.Success || rs == poswRecordStatus.RecordAlreadyExist)
                {
                    if (objCustomerMasterDAL.GooglePlusUserId == null && objCustomerMasterDAL.FacebookUserId == null)
                    {
                        if (objCustomerMasterDAL.ImageName != null)
                        {
                            objCustomerMasterDAL.ImagePhysicalName = ImageRetrievePath + Convert.ToString(objCustomerMasterDAL.ImageName);

                            objCustomerMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                        }
                        else
                        {
                            objCustomerMasterDAL.ImagePhysicalName = "img/NoImage.png";

                            objCustomerMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";
                        }
                    }
                    else
                    {
                        if (objCustomerMasterDAL.ImageName != null)
                        {
                            objCustomerMasterDAL.ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);

                            objCustomerMasterDAL.xs_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.sm_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.md_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.lg_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.xl_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                        }
                        else
                        {
                            objCustomerMasterDAL.ImagePhysicalName = "img/NoImage.png";

                            objCustomerMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";
                        }

                    }
                    objCustomerMaster.SetClassObject(objCustomerMasterDAL);
                    if (rs == poswRecordStatus.Success)
                    {
                        objCustomerMaster.ErrorCode = Convert.ToString("0");
                    }
                    else
                    {
                        if (customerMaster.IsSignIn)
                        {
                            objCustomerMasterDAL.LastLoginDateTime = poswGlobalsDAL.GetCurrentDateTime();
                            objCustomerMasterDAL.UpdateCustomerMasterLastLoginDateTime();
                        }
                        objCustomerMaster.ErrorCode = Convert.ToString("-2");
                    }

                }
                return objCustomerMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return null;
            }
        }

        public ErrorStatus InsertReviewMaster(ReviewMaster reviewMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswReviewMasterDAL objReviewMasterDAL = new poswReviewMasterDAL();

                objReviewMasterDAL.StarRating = reviewMaster.StarRating;
                objReviewMasterDAL.Review = reviewMaster.Review;
                objReviewMasterDAL.IsShow = reviewMaster.IsShow;
                objReviewMasterDAL.ReviewDateTime = DateTime.ParseExact(reviewMaster.ReviewDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objReviewMasterDAL.linktoCustomerMasterId = reviewMaster.linktoCustomerMasterId;
                objReviewMasterDAL.linktoBusinessMasterId = reviewMaster.linktoBusinessMasterId;

                poswRecordStatus rs = objReviewMasterDAL.InsertReviewMaster();
                objErrorStatus.ErrorCode = (int)rs;

                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertOrderMaster(OrderMaster orderMaster, List<ItemMaster> lstOrderItemTran, List<TaxMaster> lstTaxMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            List<poswItemMasterDAL> lstOrderItemTranDAL = new List<poswItemMasterDAL>();
            List<poswOrderTaxTranDAL> lstOrderTaxTranDAL = new List<poswOrderTaxTranDAL>();
            poswItemMasterDAL objItemMasterDAL;
            try
            {
                poswOrderMasterDAL objOrderMasterDAL = new poswOrderMasterDAL();
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(orderMaster.linktoBusinessMasterId);
                objOrderMasterDAL.OrderDateTime = DateTime.ParseExact(orderMaster.OrderDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objOrderMasterDAL.linktoCustomerMasterId = orderMaster.linktoCustomerMasterId;
                objOrderMasterDAL.linktoOrderTypeMasterId = orderMaster.linktoOrderTypeMasterId;
                objOrderMasterDAL.linktoOrderStatusMasterId = orderMaster.linktoOrderStatusMasterId;
                objOrderMasterDAL.TotalAmount = orderMaster.TotalAmount;
                objOrderMasterDAL.NetAmount = orderMaster.NetAmount;
                objOrderMasterDAL.PaidAmount = orderMaster.PaidAmount;
                objOrderMasterDAL.BalanceAmount = orderMaster.BalanceAmount;
                objOrderMasterDAL.TotalTax = orderMaster.TotalTax;
                objOrderMasterDAL.TotalItemPoint = orderMaster.TotalItemPoint;
                objOrderMasterDAL.TotalDeductedPoint = orderMaster.TotalDeductedPoint;
                if (orderMaster.Remark != null && !orderMaster.Remark.Equals("") && orderMaster.Remark.EndsWith(" "))
                {
                    objOrderMasterDAL.Remark = orderMaster.Remark.Substring(0, orderMaster.Remark.Length - 2);
                }
                else if (orderMaster.Remark != null && !orderMaster.Remark.Equals("") && orderMaster.Remark.EndsWith(","))
                {
                    objOrderMasterDAL.Remark = orderMaster.Remark.Substring(0, orderMaster.Remark.Length - 1);
                }
                else
                {
                    objOrderMasterDAL.Remark = orderMaster.Remark;
                }
                objOrderMasterDAL.IsPreOrder = orderMaster.IsPreOrder;
                objOrderMasterDAL.CreateDateTime = DateTime.ParseExact(orderMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objOrderMasterDAL.linktoOfferMasterId = orderMaster.linktoOfferMasterId;
                objOrderMasterDAL.OfferCode = orderMaster.OfferCode;
                if (orderMaster.linktoCustomerAddressTranId > 0)
                {
                    objOrderMasterDAL.linktoCustomerAddressTranId = orderMaster.linktoCustomerAddressTranId;
                }

                foreach (ItemMaster objItemMaster in lstOrderItemTran)
                {
                    objItemMasterDAL = new poswItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = objItemMaster.ItemMasterId;
                    objItemMasterDAL.Quentity = objItemMaster.Quantity;
                    objItemMasterDAL.Rate = objItemMaster.Rate;
                    objItemMasterDAL.ItemPoint = objItemMaster.ItemPoint;
                    if (objItemMaster.Remark != null && !objItemMaster.Remark.Equals("") && objItemMaster.Remark.EndsWith(" "))
                    {
                        objItemMasterDAL.Remark = objItemMaster.Remark.Substring(0, objItemMaster.Remark.Length - 2);
                    }
                    else if (objItemMaster.Remark != null && !objItemMaster.Remark.Equals("") && objItemMaster.Remark.EndsWith(","))
                    {
                        objItemMasterDAL.Remark = objItemMaster.Remark.Substring(0, objItemMaster.Remark.Length - 1);
                    }
                    else
                    {
                        objItemMasterDAL.Remark = objItemMaster.Remark;
                    }
                    objItemMasterDAL.ItemType = Convert.ToInt16(poswItemType.Item.GetHashCode());
                    lstOrderItemTranDAL.Add(objItemMasterDAL);

                    if (objItemMaster.lstOrderItemModifierTran != null)
                    {
                        foreach (ItemMaster objModifierItemMaster in objItemMaster.lstOrderItemModifierTran)
                        {
                            objItemMasterDAL = new poswItemMasterDAL();
                            objItemMasterDAL.linktoItemMasterIdModifier = objModifierItemMaster.ItemMasterId;
                            objItemMasterDAL.Rate = objModifierItemMaster.Rate;
                            objItemMasterDAL.ItemType = Convert.ToInt16(poswItemType.Modifier.GetHashCode());
                            lstOrderItemTranDAL.Add(objItemMasterDAL);
                        }
                    }
                }

                foreach (TaxMaster objTaxMaster in lstTaxMaster)
                {
                    poswOrderTaxTranDAL objOrderTaxTranDAL = new poswOrderTaxTranDAL();
                    objOrderTaxTranDAL.linktoTaxMasterId = objTaxMaster.TaxMasterId;
                    objOrderTaxTranDAL.TaxName = objTaxMaster.TaxName;
                    objOrderTaxTranDAL.TaxRate = objTaxMaster.TaxRate;
                    objOrderTaxTranDAL.IsPercentage = objTaxMaster.IsPercentage;
                    lstOrderTaxTranDAL.Add(objOrderTaxTranDAL);
                }

                poswRecordStatus rs = objOrderMasterDAL.InsertOrderMaster(lstOrderItemTranDAL, lstOrderTaxTranDAL);
                //poswRecordStatus rs = poswRecordStatus.Error;
                objErrorStatus.ErrorCode = (int)rs;
                objErrorStatus.ErrorNumber = objOrderMasterDAL.OrderMasterId;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertFeedbackQuestionMaster(FeedbackMaster feedbackMaster, List<FeedbackTran> lstFeedbackTran)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswFeedbackMasterDAL objFeedbackMasterDAL = new poswFeedbackMasterDAL();
                List<poswFeedbackTranDAL> lstFeedbackTranDAL = new List<poswFeedbackTranDAL>();
                poswFeedbackTranDAL objFeedbackTranDAL;

                objFeedbackMasterDAL.Name = feedbackMaster.Name;
                objFeedbackMasterDAL.Email = feedbackMaster.Email;
                objFeedbackMasterDAL.Phone = feedbackMaster.Phone;
                objFeedbackMasterDAL.Feedback = feedbackMaster.Feedback;
                objFeedbackMasterDAL.FeedbackDateTime = DateTime.ParseExact(feedbackMaster.FeedbackDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objFeedbackMasterDAL.FeedbackType = feedbackMaster.FeedbackType;
                if (feedbackMaster.linktoCustomerMasterId > 0)
                {
                    objFeedbackMasterDAL.linktoCustomerMasterId = feedbackMaster.linktoCustomerMasterId;
                }
                objFeedbackMasterDAL.linktoBusinessMasterId = feedbackMaster.linktoBusinessMasterId;

                foreach (FeedbackTran objFeedbackTran in lstFeedbackTran)
                {
                    objFeedbackTranDAL = new poswFeedbackTranDAL();
                    objFeedbackTranDAL.linktoFeedbackQuestionMasterId = objFeedbackTran.linktoFeedbackQuestionMasterId;
                    objFeedbackTranDAL.linktoFeedbackAnswerMasterId = objFeedbackTran.linktoFeedbackAnswerMasterId;
                    objFeedbackTranDAL.Answer = objFeedbackTran.Answer;
                    lstFeedbackTranDAL.Add(objFeedbackTranDAL);
                }

                poswRecordStatus rs = objFeedbackMasterDAL.InsertFeedbackMaster(lstFeedbackTranDAL);
                objErrorStatus.ErrorCode = (int)rs;

                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertBookingMaster(BookingMaster bookingMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswBookingMasterDAL objBookingMasterDAL = new poswBookingMasterDAL();

                objBookingMasterDAL.FromDate = DateTime.ParseExact(bookingMaster.FromDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objBookingMasterDAL.ToDate = DateTime.ParseExact(bookingMaster.ToDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objBookingMasterDAL.FromTime = TimeSpan.Parse(bookingMaster.FromTime);
                objBookingMasterDAL.ToTime = TimeSpan.Parse(bookingMaster.ToTime);
                objBookingMasterDAL.IsHourly = bookingMaster.IsHourly;
                objBookingMasterDAL.linktoCustomerMasterId = bookingMaster.linktoCustomerMasterId;
                objBookingMasterDAL.BookingPersonName = bookingMaster.BookingPersonName;
                objBookingMasterDAL.Email = bookingMaster.Email;
                objBookingMasterDAL.Phone = bookingMaster.Phone;
                objBookingMasterDAL.NoOfAdults = bookingMaster.NoOfAdults;
                objBookingMasterDAL.NoOfChildren = bookingMaster.NoOfChildren;
                objBookingMasterDAL.TotalAmount = bookingMaster.TotalAmount;
                objBookingMasterDAL.DiscountPercentage = bookingMaster.DiscountPercentage;
                objBookingMasterDAL.DiscountAmount = bookingMaster.DiscountAmount;
                objBookingMasterDAL.ExtraAmount = bookingMaster.ExtraAmount;
                objBookingMasterDAL.NetAmount = bookingMaster.NetAmount;
                objBookingMasterDAL.PaidAmount = bookingMaster.PaidAmount;
                objBookingMasterDAL.BalanceAmount = bookingMaster.BalanceAmount;
                objBookingMasterDAL.Remark = bookingMaster.Remark;
                objBookingMasterDAL.IsPreOrder = bookingMaster.IsPreOrder;
                objBookingMasterDAL.CreateDateTime = DateTime.ParseExact(bookingMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objBookingMasterDAL.linktoUserMasterIdCreatedBy = bookingMaster.linktoUserMasterIdCreatedBy;
                objBookingMasterDAL.linktoBusinessMasterId = bookingMaster.linktoBusinessMasterId;
                objBookingMasterDAL.IsDeleted = bookingMaster.IsDeleted;
                objBookingMasterDAL.BookingStatus = bookingMaster.BookingStatus;

                poswRecordStatus rs = objBookingMasterDAL.InsertBookingMasterBookingDetails();
                if (rs == poswRecordStatus.Success)
                {
                    objErrorStatus.ErrorCode = objBookingMasterDAL.BookingMasterId;
                }
                else
                {
                    objErrorStatus.ErrorCode = (int)rs;
                }
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertContactUsMaster(ContactUsMaster contactUsMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                string ToEmailAddress, EmailBody, ToEmailBody;
                ToEmailAddress = System.Configuration.ConfigurationManager.AppSettings["ToMailAddress"];

                EmailBody = File.ReadAllText(System.Configuration.ConfigurationManager.AppSettings["emailtemplates"] + "ContactUs.html");
                EmailBody = EmailBody.Replace("#NAME#", contactUsMaster.Name);
                EmailBody = EmailBody.Replace("#EMAIL#", contactUsMaster.Email);
                EmailBody = EmailBody.Replace("#PHONE#", contactUsMaster.Mobile);
                EmailBody = EmailBody.Replace("#SUBJECT#", "");
                EmailBody = EmailBody.Replace("#MESSAGE#", contactUsMaster.Message);

                poswGlobalsDAL.SendEmail(ToEmailAddress, "You have one email", EmailBody);
                ToEmailBody = File.ReadAllText(System.Configuration.ConfigurationManager.AppSettings["emailtemplates"] + "ThankYouEmail.html");
                poswGlobalsDAL.SendEmail(contactUsMaster.Email, "You have one email", EmailBody);

                objErrorStatus.ErrorCode = 0;

                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertCustomerAddressTran(CustomerAddressTran customerAddressTran)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswCustomerAddressTranDAL objCustomerAddressTranDAL = new poswCustomerAddressTranDAL();

                objCustomerAddressTranDAL.CustomerName = customerAddressTran.CustomerName;
                objCustomerAddressTranDAL.Address = customerAddressTran.Address;
                objCustomerAddressTranDAL.AddressType = customerAddressTran.AddressType;
                objCustomerAddressTranDAL.linktoCountryMasterId = customerAddressTran.linktoCountryMasterId;
                objCustomerAddressTranDAL.linktoStateMasterId = customerAddressTran.linktoStateMasterId;
                objCustomerAddressTranDAL.linktoCityMasterId = customerAddressTran.linktoCityMasterId;
                objCustomerAddressTranDAL.linktoAreaMasterId = customerAddressTran.linktoAreaMasterId;
                objCustomerAddressTranDAL.ZipCode = customerAddressTran.ZipCode;
                objCustomerAddressTranDAL.Phone = customerAddressTran.Phone;
                objCustomerAddressTranDAL.IsPrimary = customerAddressTran.IsPrimary;
                objCustomerAddressTranDAL.IsDeleted = customerAddressTran.IsDeleted;
                objCustomerAddressTranDAL.CreateDateTime = DateTime.ParseExact(customerAddressTran.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerAddressTranDAL.linktoCustomerMasterId = customerAddressTran.linktoCustomerMasterId;
                objCustomerAddressTranDAL.linktoUserMasterIdCreatedBy = Convert.ToInt16(customerAddressTran.linktoCustomerMasterId);

                poswRecordStatus rs = objCustomerAddressTranDAL.InsertCustomerAddressTran();

                if (rs == poswRecordStatus.Success)
                {
                    objErrorStatus.ErrorCode = objCustomerAddressTranDAL.CustomerAddressTranId;
                }
                else
                {
                    objErrorStatus.ErrorCode = (int)rs;
                }
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertFCMMaster(FCMMaster fCMMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswFCMMasterDAL objFCMMasterDAL = new poswFCMMasterDAL();

                objFCMMasterDAL.FCMToken = fCMMaster.FCMToken;
                objFCMMasterDAL.CreateDateTime = DateTime.ParseExact(fCMMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                if (fCMMaster.linktoCustomerMasterId != null)
                {
                    objFCMMasterDAL.linktoCustomerMasterId = fCMMaster.linktoCustomerMasterId;
                }
                objFCMMasterDAL.linktoBusinessMasterId = fCMMaster.linktoBusinessMasterId;
                poswRecordStatus rs = objFCMMasterDAL.InsertFCMMaster();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertNotificationTran(NotificationTran notificationTran)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswNotificationTranDAL objNotificationTranDAL = new poswNotificationTranDAL();

                objNotificationTranDAL.linktoNotificationMasterId = notificationTran.linktoNotificationMasterId;
                objNotificationTranDAL.linktoCustomerMasterId = notificationTran.linktoCustomerMasterId;
                objNotificationTranDAL.ReadDateTime = DateTime.ParseExact(notificationTran.ReadDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);

                poswRecordStatus rs = objNotificationTranDAL.InsertNotificationTran();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        #endregion

        #region Update
        public ErrorStatus UpdateCustomerMasterPassword(CustomerMaster customerMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswCustomerMasterDAL objCustomerMasterDAL = new poswCustomerMasterDAL();

                objCustomerMasterDAL.CustomerMasterId = customerMaster.CustomerMasterId;
                objCustomerMasterDAL.Password = customerMaster.Password;
                objCustomerMasterDAL.UpdateDateTime = DateTime.ParseExact(customerMaster.UpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = Convert.ToInt16(customerMaster.CustomerMasterId);

                poswRecordStatus rs = objCustomerMasterDAL.UpdateCustomerMasterPassword();
                if (rs == poswRecordStatus.Success)
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
                else
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }

            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public CustomerMaster UpdateCustomerMaster(CustomerMaster customerMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "customer/";
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "customer\\";
            CustomerMaster objCustomerMaster = new CustomerMaster();
            try
            {
                poswCustomerMasterDAL objCustomerMasterDAL = new poswCustomerMasterDAL();

                objCustomerMasterDAL.CustomerMasterId = customerMaster.CustomerMasterId;
                objCustomerMasterDAL.CustomerName = customerMaster.CustomerName;
                objCustomerMasterDAL.Phone1 = customerMaster.Phone1;
                objCustomerMasterDAL.Gender = customerMaster.Gender;
                if (customerMaster.BirthDate != null)
                {
                    objCustomerMasterDAL.BirthDate = DateTime.ParseExact(customerMaster.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                }
                objCustomerMasterDAL.UpdateDateTime = DateTime.ParseExact(customerMaster.UpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = Convert.ToInt16(customerMaster.CustomerMasterId);
                objCustomerMasterDAL.FacebookUserId = customerMaster.FacebookUserId;
                objCustomerMasterDAL.GooglePlusUserId = customerMaster.GooglePlusUserId;
                if ((customerMaster.ImageName != null))
                {
                    if (customerMaster.ImageNamePhysicalNameBytes != null)
                    {
                        if (!Directory.Exists(ImageSavePath))
                        {
                            Directory.CreateDirectory(ImageSavePath);
                        }
                        byte[] buffer = Convert.FromBase64String(customerMaster.ImageNamePhysicalNameBytes);
                        MemoryStream ms = new MemoryStream(buffer);
                        Image image = Image.FromStream(ms);
                        image.Save(ImageSavePath + customerMaster.ImageName);
                        poswGlobalsDAL.CreateThumbImages(customerMaster.ImageName, ImageSavePath);
                    }
                    objCustomerMasterDAL.ImageName = customerMaster.ImageName;
                }


                poswRecordStatus rs = objCustomerMasterDAL.UpdateCustomerMasterbyId();
                if (rs == poswRecordStatus.Success)
                {
                    if (objCustomerMasterDAL.GooglePlusUserId == null && objCustomerMasterDAL.FacebookUserId == null)
                    {
                        if (objCustomerMasterDAL.ImageName != null)
                        {
                            objCustomerMasterDAL.ImagePhysicalName = ImageRetrievePath + Convert.ToString(objCustomerMasterDAL.ImageName);

                            objCustomerMasterDAL.xs_ImagePhysicalName = ImageRetrievePath + "xs_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.sm_ImagePhysicalName = ImageRetrievePath + "sm_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.md_ImagePhysicalName = ImageRetrievePath + "md_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.lg_ImagePhysicalName = ImageRetrievePath + "lg_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.xl_ImagePhysicalName = ImageRetrievePath + "xl_" + Convert.ToString(objCustomerMasterDAL.ImageName);
                        }
                        else
                        {
                            objCustomerMasterDAL.ImagePhysicalName = "img/NoImage.png";

                            objCustomerMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";
                        }
                    }
                    else
                    {
                        if (objCustomerMasterDAL.ImageName != null)
                        {
                            objCustomerMasterDAL.ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);

                            objCustomerMasterDAL.xs_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.sm_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.md_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.lg_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                            objCustomerMasterDAL.xl_ImagePhysicalName = Convert.ToString(objCustomerMasterDAL.ImageName);
                        }
                        else
                        {
                            objCustomerMasterDAL.ImagePhysicalName = "img/NoImage.png";

                            objCustomerMasterDAL.xs_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.sm_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.md_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.lg_ImagePhysicalName = "img/NoImage.png";
                            objCustomerMasterDAL.xl_ImagePhysicalName = "img/NoImage.png";
                        }

                    }
                    objCustomerMaster.SetClassObject(objCustomerMasterDAL);

                }
                return objCustomerMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objCustomerMaster;
            }
        }

        public ErrorStatus UpdateCustomerAddressTran(CustomerAddressTran customerAddressTran)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswCustomerAddressTranDAL objCustomerAddressTranDAL = new poswCustomerAddressTranDAL();

                objCustomerAddressTranDAL.CustomerAddressTranId = customerAddressTran.CustomerAddressTranId;
                objCustomerAddressTranDAL.CustomerName = customerAddressTran.CustomerName;
                objCustomerAddressTranDAL.AddressType = customerAddressTran.AddressType;
                objCustomerAddressTranDAL.Phone = customerAddressTran.Phone;
                objCustomerAddressTranDAL.linktoCustomerMasterId = customerAddressTran.linktoCustomerMasterId;
                objCustomerAddressTranDAL.Address = customerAddressTran.Address;
                objCustomerAddressTranDAL.linktoCountryMasterId = customerAddressTran.linktoCountryMasterId;
                objCustomerAddressTranDAL.linktoStateMasterId = customerAddressTran.linktoStateMasterId;
                objCustomerAddressTranDAL.linktoCityMasterId = customerAddressTran.linktoCityMasterId;
                objCustomerAddressTranDAL.linktoAreaMasterId = customerAddressTran.linktoAreaMasterId;
                objCustomerAddressTranDAL.IsPrimary = customerAddressTran.IsPrimary;
                objCustomerAddressTranDAL.ZipCode = customerAddressTran.ZipCode;
                objCustomerAddressTranDAL.IsDeleted = customerAddressTran.IsDeleted;

                poswRecordStatus rs = objCustomerAddressTranDAL.UpdateCustomerAddressTran();
                if (rs == poswRecordStatus.Success)
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
                else
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateBookingMasterStatus(BookingMaster bookingMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswBookingMasterDAL objBookingMasterDAL = new poswBookingMasterDAL();

                objBookingMasterDAL.BookingMasterId = Convert.ToInt16(bookingMaster.BookingMasterId);
                objBookingMasterDAL.BookingStatus = Convert.ToInt16(poswBookingStatus.Canceled.GetHashCode());
                objBookingMasterDAL.OrderStatus = Convert.ToInt16(poswOrderStatus.Canceled.GetHashCode());

                if (!objBookingMasterDAL.SelectBookingPaymentCancel())
                {
                    poswRecordStatus rs = objBookingMasterDAL.UpdateBookingMasterBookingCancel();
                    if (rs == poswRecordStatus.Success)
                    {
                        objErrorStatus.ErrorCode = (int)rs;
                        return objErrorStatus;
                    }
                    else
                    {
                        objErrorStatus.ErrorCode = (int)rs;
                        return objErrorStatus;
                    }
                }
                else
                {
                    objErrorStatus.ErrorCode = 1;
                    return objErrorStatus;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateOrderMasterStatus(OrderMaster orderMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswOrderItemTranDAL objOrderItemTranDAL = new poswOrderItemTranDAL();

                objOrderItemTranDAL.linktoOrderMasterId = orderMaster.OrderMasterId;
                objOrderItemTranDAL.linktoOrderStatusMasterId = orderMaster.linktoOrderStatusMasterId;

                if (!objOrderItemTranDAL.SelectOrderPaymentCancel())
                {
                    poswRecordStatus rs = objOrderItemTranDAL.UpdateOrderMasterOrderCancel();
                    if (rs == poswRecordStatus.Success)
                    {
                        objErrorStatus.ErrorCode = (int)rs;
                        return objErrorStatus;
                    }
                    else
                    {
                        objErrorStatus.ErrorCode = (int)rs;
                        return objErrorStatus;
                    }
                }
                else
                {
                    objErrorStatus.ErrorCode = 1;
                    return objErrorStatus;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateFCMMasterByCustomerId(FCMMaster fCMMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswFCMMasterDAL objFCMMasterDAL = new poswFCMMasterDAL();

                objFCMMasterDAL.FCMToken = fCMMaster.FCMToken;
                objFCMMasterDAL.UpdateDateTime = DateTime.ParseExact(fCMMaster.UpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                if (fCMMaster.linktoCustomerMasterId != null)
                {
                    objFCMMasterDAL.linktoCustomerMasterId = fCMMaster.linktoCustomerMasterId;
                }
                objFCMMasterDAL.linktoBusinessMasterId = fCMMaster.linktoBusinessMasterId;
                poswRecordStatus rs = objFCMMasterDAL.UpdateFCMMasterByCustomerId();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        #endregion

        #region Delete

        public ErrorStatus DeleteCustomerAddressTran(string customerAddressTranId)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswCustomerAddressTranDAL objCustomerAddressTranDAL = new poswCustomerAddressTranDAL();

                objCustomerAddressTranDAL.CustomerAddressTranId = Convert.ToInt32(customerAddressTranId);

                poswRecordStatus rs = objCustomerAddressTranDAL.DeleteCustomerAddressTran();
                if (rs == poswRecordStatus.Success)
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
                else
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        #endregion

        #region Select

        public CustomerMaster SelectCustomerMaster(string userName, string password, string customerMasterId, string businessMasterId, string FCMToken)
        {
            string Name = null;
            string Password = null;
            try
            {
                poswCustomerMasterDAL objCustomerMasterDAL = null;
                try
                {
                    objCustomerMasterDAL = new poswCustomerMasterDAL();
                    if (customerMasterId != "null")
                    {
                        objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(customerMasterId);
                        objCustomerMasterDAL.SelectCustomerMaster();
                        CustomerMaster objCustomerMaster = new CustomerMaster();
                        objCustomerMaster.SetClassObject(objCustomerMasterDAL);
                        return objCustomerMaster;
                    }
                    else
                    {
                        Name = userName.Replace("2E", ".");
                        Password = password.Replace("2E", ".");

                        objCustomerMasterDAL.Email1 = System.Web.HttpUtility.UrlDecode(Name.ToString());
                        objCustomerMasterDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                        objCustomerMasterDAL.CustomerType = Convert.ToInt16(poswCustomerType.Registered_User.GetHashCode());
                        if (objCustomerMasterDAL.SelectCustomerMasterByEmail())
                        {
                            if (objCustomerMasterDAL.Password == Password)
                            {
                                if (FCMToken != null)
                                {
                                    objCustomerMasterDAL.FCMToken = FCMToken.Replace("2E2", ":").Replace("3E3", "-").Replace("4E4", "_");
                                    poswFCMMasterDAL objFCMMasterDAL = new poswFCMMasterDAL();

                                    objFCMMasterDAL.FCMToken = objCustomerMasterDAL.FCMToken;
                                    objFCMMasterDAL.CreateDateTime = poswGlobalsDAL.GetCurrentDateTime();
                                    if (objCustomerMasterDAL.CustomerMasterId != null)
                                    {
                                        objFCMMasterDAL.linktoCustomerMasterId = objCustomerMasterDAL.CustomerMasterId;
                                    }
                                    poswRecordStatus rs = objFCMMasterDAL.InsertFCMMaster();
                                }

                                objCustomerMasterDAL.LastLoginDateTime = poswGlobalsDAL.GetCurrentDateTime();
                                objCustomerMasterDAL.UpdateCustomerMasterLastLoginDateTime();

                                CustomerMaster objCustomerMaster = new CustomerMaster();
                                objCustomerMaster.SetClassObject(objCustomerMasterDAL);
                                objCustomerMaster.ErrorCode = "0";
                                return objCustomerMaster;
                            }
                            else
                            {
                                return null;
                            }
                        }
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    poswGlobalsDAL.SaveError(ex);
                    return null;
                }
                finally
                {
                    objCustomerMasterDAL = null;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public BusinessMaster SelectBusinessMasterByBusinessMasterId(string businessMasterId)
        {
            try
            {
                poswBusinessMasterDAL objBusinessMasterDAL = new poswBusinessMasterDAL();
                objBusinessMasterDAL.BusinessMasterId = Convert.ToInt16(businessMasterId);

                objBusinessMasterDAL.SelectBusinessMaster();

                BusinessMaster objBusinessMaster = new BusinessMaster();
                objBusinessMaster.SetClassObject(objBusinessMasterDAL);
                return objBusinessMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public BusinessDescription SelectBusinessDescription(string businessMasterId, string keyword)
        {
            try
            {
                poswBusinessDescriptionDAL objBusinessDescriptionDAL = new poswBusinessDescriptionDAL();
                objBusinessDescriptionDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                objBusinessDescriptionDAL.Keyword = System.Web.HttpUtility.UrlDecode(keyword);

                objBusinessDescriptionDAL.SelectBusinessDescription();

                BusinessDescription objBusinessDescription = new BusinessDescription();
                objBusinessDescription.SetClassObject(objBusinessDescriptionDAL);
                return objBusinessDescription;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public bool SelectBookingMasterIfBookingAvailable(BookingMaster objBookingMaster)
        {
            poswBookingMasterDAL objBookingMasterDAL = new poswBookingMasterDAL();
            try
            {
                objBookingMasterDAL.FromDate = DateTime.ParseExact(objBookingMaster.FromDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                objBookingMasterDAL.ToDate = DateTime.ParseExact(objBookingMaster.FromDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                objBookingMasterDAL.FromTime = TimeSpan.Parse(objBookingMaster.FromTime);
                objBookingMasterDAL.ToTime = TimeSpan.Parse(objBookingMaster.ToTime);
                objBookingMasterDAL.NoOfAdults = Convert.ToInt16(objBookingMaster.NoOfAdults);
                objBookingMasterDAL.NoOfChildren = Convert.ToInt16(objBookingMaster.NoOfChildren);
                if (objBookingMasterDAL.SelectBookingMasterIfBookingAvailable())
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return true;
            }
        }

        public OfferMaster SelectOfferMasterOfferCodeVerification(OfferMaster objOfferMaster)
        {
            poswOfferMasterDAL objOfferMasterDAL = new poswOfferMasterDAL();
            try
            {
                objOfferMasterDAL.OfferCode = objOfferMaster.OfferCode;
                objOfferMasterDAL.MinimumBillAmount = objOfferMaster.MinimumBillAmount;
                objOfferMasterDAL.linktoBusinessMasterId = objOfferMaster.linktoBusinessMasterId;
                objOfferMasterDAL.linktoCustomerMasterId = objOfferMaster.linktoCustomerMasterId;

                if (objOfferMasterDAL.SelectOfferMasterOfferCodeVerification(Convert.ToInt16(objOfferMaster.linktoOrderTypeMasterIds)))
                {
                    OfferMaster objOffer = new OfferMaster();
                    objOffer.SetClassObject(objOfferMasterDAL);
                    return objOffer;
                }
                return null;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public OfferMaster SelectOfferMaster(string offerMasterId)
        {
            poswOfferMasterDAL objOfferMasterDAL = new poswOfferMasterDAL();
            try
            {
                objOfferMasterDAL.OfferMasterId = Convert.ToInt16(offerMasterId);
                if (objOfferMasterDAL.SelectOfferMaster())
                {
                    OfferMaster objOffer = new OfferMaster();
                    objOffer.SetClassObject(objOfferMasterDAL);
                    return objOffer;
                }
                return null;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public CategoryMaster SelectCategoryMaster(string linktoBusinessMasterId, string CategoryMasterId)
        {
            try
            {
                poswCategoryMasterDAL objCategoryMasterDAL = new poswCategoryMasterDAL();
                objCategoryMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objCategoryMasterDAL.CategoryMasterId= Convert.ToInt16(CategoryMasterId);
                if (objCategoryMasterDAL.SelectCategoryMaster())
                {
                    CategoryMaster objCategory = new CategoryMaster();
                    objCategory.SetClassObject(objCategoryMasterDAL);
                    return objCategory;
                }
                return null;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        #endregion

        #region SelectAll

        public List<CityMaster> SelectAllCityMasterByState(string linktoStateMasterId)
        {
            List<CityMaster> lstCityMaster = new List<CityMaster>();
            try
            {
                lstCityMaster = CityMaster.SetListObject(poswCityMasterDAL.SelectAllCityMasterCityNameByState(Convert.ToInt16(linktoStateMasterId)));
                return lstCityMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<AreaMaster> SelectAllAreaMasterByCity(string linktoCityMasterId)
        {
            List<AreaMaster> lstAreaMaster = new List<AreaMaster>();
            try
            {
                lstAreaMaster = AreaMaster.SetListObject(poswAreaMasterDAL.SelectAllAreaMasterAreaNameByCity(Convert.ToInt16(linktoCityMasterId)));
                return lstAreaMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OfferMaster> SelectAllOfferMasterPageWise(string currentPage, string linktoBusinessMasterId, string fromday, string frommonth, string fromyear, string fromhour, string fromminute)
        {
            List<OfferMaster> lstOfferMaster = new List<OfferMaster>();
            try
            {
                short pageSize = 10;
                short startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                short totalRecords = 0;
                poswOfferMasterDAL objOfferMasterDAL = new poswOfferMasterDAL();
                objOfferMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objOfferMasterDAL.FromDate = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear + " " + fromhour + ":" + fromminute, "M/d/yyyy H:m", DateTimeFormatInfo.InvariantInfo);
                lstOfferMaster = OfferMaster.SetListObject(objOfferMasterDAL.SelectAllOfferMasterByFormDateTimePageWise(startRowIndex, pageSize, out totalRecords));
                return lstOfferMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BusinessGalleryTran> SelectAllBusinessGalleryTranPageWise(string currentPage, string linktoBusinessMasterId)
        {
            List<BusinessGalleryTran> lstBusinessGalleryTran = new List<BusinessGalleryTran>();
            try
            {
                short pageSize = 10;
                short startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                short totalRecords = 0;
                poswBusinessGalleryTranDAL objPosBusinessGalleryTranDAL = new poswBusinessGalleryTranDAL();
                objPosBusinessGalleryTranDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objPosBusinessGalleryTranDAL.ImageTitle = "";
                lstBusinessGalleryTran = BusinessGalleryTran.SetListObject(objPosBusinessGalleryTranDAL.SelectAllBusinessGalleryTranPageWise(startRowIndex, pageSize, out totalRecords, true));
                return lstBusinessGalleryTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BusinessHoursTran> SelectAllBusinessHoursTranByBusinessMasterId(string businessMasterId)
        {
            List<BusinessHoursTran> lstBusinessHoursTran = new List<BusinessHoursTran>();
            try
            {
                poswBusinessHoursTranDAL objBusinessHoursTranDAL = new poswBusinessHoursTranDAL();
                objBusinessHoursTranDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                lstBusinessHoursTran = BusinessHoursTran.SetListObject(objBusinessHoursTranDAL.SelectAllBusinessHoursTran());

                return lstBusinessHoursTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<CategoryMaster> SelectAllCategoryMaster(string linktoBusinessMasterId)
        {
            List<CategoryMaster> lstCategoryMaster = new List<CategoryMaster>();
            try
            {
                poswCategoryMasterDAL objCategoryMasterDAL = new poswCategoryMasterDAL();
                objCategoryMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstCategoryMaster = CategoryMaster.SetListObject(objCategoryMasterDAL.SelectAllCategoryMaster());

                return lstCategoryMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ItemMaster> SelectAllItemMasterByCategoryMasterId(string currentPage, string linktoCatgoryMasterId, string optionValueId, string linktoBusinessMasterId, string itemMasterIds)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            short pageSize, startRowIndex, totalRecords;
            string[] strArray;
            try
            {
                if (itemMasterIds == "null")
                {
                    pageSize = 10;
                }
                else
                {
                    strArray = itemMasterIds.Split(',').ToArray();
                    pageSize = Convert.ToInt16(strArray.Length);
                }
                startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                totalRecords = 0;
                poswItemMasterDAL objItemMasterDAL = new poswItemMasterDAL();
                if (linktoCatgoryMasterId != "null")
                {
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(linktoCatgoryMasterId);
                }
                if (optionValueId != "null")
                {
                    objItemMasterDAL.OptionValue = optionValueId;
                }
                objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstItemMaster = ItemMaster.SetListObject(objItemMasterDAL.SelectAllItemMasterByCategoryMasterIdPageWise(startRowIndex, pageSize, out totalRecords, itemMasterIds));
                return lstItemMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ItemMaster> SelectAllItemModifier(string linktoItemMasterId, string linktoBusinessMasterId)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            try
            {
                poswItemMasterDAL objItemMasterDAL = new poswItemMasterDAL();
                objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objItemMasterDAL.ItemMasterId = Convert.ToInt32(linktoItemMasterId);
                lstItemMaster = ItemMaster.SetListObject(objItemMasterDAL.SelectAllItemMasterModifier());
                return lstItemMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OptionValueTran> SelectAllItemOption(string linktoItemMasterId)
        {
            List<OptionValueTran> lstOptionValueTran = new List<OptionValueTran>();
            try
            {
                poswOptionValueTranDAL objOptionValueTranDAL = new poswOptionValueTranDAL();
                lstOptionValueTran = OptionValueTran.SetListObject(objOptionValueTranDAL.SelectAllOptionValueTranByItemMasterId(Convert.ToInt32(linktoItemMasterId)));
                return lstOptionValueTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ItemMaster> SelectAllItemSuggested(string linktoItemMasterId, string linktoBusinessMasterId)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            try
            {
                poswItemMasterDAL objItemMasterDAL = new poswItemMasterDAL();
                objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstItemMaster = ItemMaster.SetListObject(objItemMasterDAL.SelectAllItemSuggested(Convert.ToInt32(linktoItemMasterId)));
                return lstItemMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ReviewMaster> SelectAllReviewMaster(string currentPage, string linktoBusinessMasterId)
        {
            List<ReviewMaster> lstReviewMaster = new List<ReviewMaster>();
            try
            {
                short pageSize = 10;
                short startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                short totalRecords = 0;

                poswReviewMasterDAL objReviewMasterDAL = new poswReviewMasterDAL();
                objReviewMasterDAL.IsShow = true;
                objReviewMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstReviewMaster = ReviewMaster.SetListObject(objReviewMasterDAL.SelectAllReviewMasterPageWise(startRowIndex, pageSize, out totalRecords, true));

                return lstReviewMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<TaxMaster> SelectAllTaxMaster(string businessMasterId)
        {
            List<TaxMaster> lstTaxMaster = new List<TaxMaster>();
            try
            {
                poswTaxMasterDAL objTaxMasterDAL = new poswTaxMasterDAL();
                objTaxMasterDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                lstTaxMaster = TaxMaster.SetListObject(objTaxMasterDAL.SelectAllTaxMasterByBusinessMasterId());
                return lstTaxMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BusinessInfoAnswerMaster> SelectAllBusinessInfoAnswerMaster(string linktoBusinessTypeMasterId, string linktoBusinessMasterId)
        {
            List<BusinessInfoAnswerMaster> lstBusinessInfoAnswerMaster = new List<BusinessInfoAnswerMaster>();
            try
            {
                lstBusinessInfoAnswerMaster = BusinessInfoAnswerMaster.SetListObject(poswBusinessInfoAnswerMasterDAL.SelectAllBusinessInfoAnswerMasterByBusinessMasterId(Convert.ToInt16(linktoBusinessTypeMasterId), Convert.ToInt16(linktoBusinessMasterId)));
                return lstBusinessInfoAnswerMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<FeedbackQuestionMaster> SelectAllQuestionAnswer(string businessMasterId)
        {
            List<FeedbackQuestionMaster> lstFeedbackQuestionMaster = new List<FeedbackQuestionMaster>();
            try
            {
                poswFeedbackQuestionMasterDAL objFeedbackQuestionMasterDAL = new poswFeedbackQuestionMasterDAL();
                objFeedbackQuestionMasterDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                lstFeedbackQuestionMaster = FeedbackQuestionMaster.SetListObject(objFeedbackQuestionMasterDAL.SelectAllFeedbackQuestionAnswer());
                return lstFeedbackQuestionMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderItemTran> SelectAllOrderMasterWithOrderItem(string currentPage, string linktoBusinessMasterId, string customerMasterId)
        {
            List<OrderItemTran> lstOrderItemTran = new List<OrderItemTran>();
            List<poswOrderMasterDAL> lstOrderMasterDAL = new List<poswOrderMasterDAL>();
            StringBuilder sb;
            try
            {
                short pageSize = 10;
                short startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                short totalRecords = 0;

                poswOrderMasterDAL objOrderMasterDAL = new poswOrderMasterDAL();
                poswOrderItemTranDAL objOrderItemTranDAL = new poswOrderItemTranDAL();
                if (customerMasterId != "null")
                {
                    objOrderMasterDAL.linktoCustomerMasterId = Convert.ToInt32(customerMasterId);
                }
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstOrderMasterDAL = objOrderMasterDAL.SelectAllOrderMasterByCustomerIdPageWise(startRowIndex, pageSize, out totalRecords);

                sb = new StringBuilder();
                lstOrderMasterDAL.ForEach(i => sb.Append(i.OrderMasterId + ","));
                lstOrderItemTran = OrderItemTran.SetListObject(objOrderItemTranDAL.SelectAllOrderItemTranOrderMasterId(sb.ToString()));

                foreach (poswOrderMasterDAL orderMasterDAL in lstOrderMasterDAL)
                {
                    foreach (OrderItemTran objOrderItemTran in lstOrderItemTran)
                    {
                        if (objOrderItemTran.linktoOrderMasterId == orderMasterDAL.OrderMasterId)
                        {
                            objOrderItemTran.TotalTax = orderMasterDAL.TotalTax;
                            objOrderItemTran.TotalAmount = orderMasterDAL.TotalAmount;
                            objOrderItemTran.OrderNumber = orderMasterDAL.OrderNumber;
                            objOrderItemTran.OrderDateTime = orderMasterDAL.OrderDateTime.ToString("s");
                            ///IsPreOrder is used whether any amount is paid or not for Order 
                            objOrderItemTran.PaymentStatus = orderMasterDAL.IsPreOrder;
                            objOrderItemTran.linktoOrderStatusMasterId = orderMasterDAL.linktoOrderStatusMasterId;
                        }
                    }
                }

                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BookingMaster> SelectAllTimeSlots(string linktoBusinessMasterId, string fromday, string frommonth, string fromyear, string timeDuration)
        {
            List<BookingMaster> lstBookingMaster = new List<BookingMaster>();
            try
            {
                poswBookingMasterDAL objBookingMasterDAL = new poswBookingMasterDAL();
                objBookingMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objBookingMasterDAL.TimeDuration = Convert.ToInt16(timeDuration);
                objBookingMasterDAL.FromDate = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear, "M/d/yyyy", DateTimeFormatInfo.InvariantInfo);
                lstBookingMaster = BookingMaster.SetListObject(objBookingMasterDAL.SelectAllBookingMasterGetTimeSlots());
                return lstBookingMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BookingMaster> SelectAllBookingMaster(string currentPage, string linktoBusinessMasterId, string customerMasterId)
        {
            List<BookingMaster> lstBookingMaster = new List<BookingMaster>();
            try
            {
                short pageSize = 10;
                short startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                short totalRecords = 0;
                poswBookingMasterDAL objBookingMasterDAL = new poswBookingMasterDAL();
                objBookingMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objBookingMasterDAL.linktoCustomerMasterId = Convert.ToInt32(customerMasterId);
                lstBookingMaster = BookingMaster.SetListObject(objBookingMasterDAL.SelectAllBookingMasterByCustomerMasterIdPageWise(startRowIndex, pageSize, out totalRecords));
                return lstBookingMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<StateMaster> SelectAllStateMasterStateNameByCountry(string linktoCountryMasterId)
        {
            List<StateMaster> lstStateMaster = new List<StateMaster>();
            try
            {
                lstStateMaster = StateMaster.SetListObject(poswStateMasterDAL.SelectAllStateMasterStateNameByCountry(Convert.ToInt16(linktoCountryMasterId)));
                return lstStateMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<CustomerAddressTran> SelectAllCustomerAddressTran(string linktoCustomerMasterId)
        {
            List<CustomerAddressTran> lstCustomerAddressTran = new List<CustomerAddressTran>();
            try
            {
                poswCustomerAddressTranDAL objCustomerAddressTranDAL = new poswCustomerAddressTranDAL();
                objCustomerAddressTranDAL.linktoCustomerMasterId = Convert.ToInt16(linktoCustomerMasterId);
                lstCustomerAddressTran = CustomerAddressTran.SetListObject(objCustomerAddressTranDAL.SelectAllCustomerAddressTran());
                return lstCustomerAddressTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BusinessServiceTran> SelectAllBusinessService(string businessTypeMasterId, string businessMasterId)
        {
            List<BusinessServiceTran> lstBusinessServiceTran = new List<BusinessServiceTran>();
            try
            {
                poswBusinessServiceTranDAL objBusinessServiceTranDAL = new poswBusinessServiceTranDAL();
                objBusinessServiceTranDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                lstBusinessServiceTran = BusinessServiceTran.SetListObject(objBusinessServiceTranDAL.SelectAllBusinessServiceTran(Convert.ToInt16(businessTypeMasterId)));
                return lstBusinessServiceTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }

        }

        public List<BusinessMaster> SelectAllBusinessMasterByBusinessGroup(string linktoBusinessGroupMasterId, string city)
        {
            List<BusinessMaster> lstBusinessMaster = new List<BusinessMaster>();
            try
            {
                poswBusinessMasterDAL objBusinessMasterDAL = new poswBusinessMasterDAL();
                objBusinessMasterDAL.linktoBusinessGroupMasterId = Convert.ToInt16(linktoBusinessGroupMasterId);
                if (city != "null")
                {
                    objBusinessMasterDAL.City = System.Web.HttpUtility.UrlDecode(city);
                }
                lstBusinessMaster = BusinessMaster.SetListObject(objBusinessMasterDAL.SelectAllBusinessMasterByBusinessGroup());
                return lstBusinessMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }

        }

        public List<BannerMaster> SelectAllBannerMaster(string linktoBusinessMasterId)
        {
            List<BannerMaster> lstBannerMaster = new List<BannerMaster>();
            try
            {
                poswBannerMasterDAL objBannerMasterDAL = new poswBannerMasterDAL();
                objBannerMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstBannerMaster = BannerMaster.SetListObject(objBannerMasterDAL.SelectAllBannerMasterDateWise());
                return lstBannerMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }

        }
        #endregion

        #endregion


        #region poswAdmin

        #region Insert
        public NotificationMaster InsertNotificationMaster(NotificationMaster notificationMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Notification/";
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "Notification\\";
            try
            {
                poswNotificationMasterDAL objNotificationMasterDAL = new poswNotificationMasterDAL();

                objNotificationMasterDAL.NotificationTitle = notificationMaster.NotificationTitle;
                objNotificationMasterDAL.NotificationText = notificationMaster.NotificationText;
                if (notificationMaster.NotificationImageNameBytes != null)
                {
                    if (!Directory.Exists(ImageSavePath))
                    {
                        Directory.CreateDirectory(ImageSavePath);
                    }
                    byte[] buffer = Convert.FromBase64String(notificationMaster.NotificationImageNameBytes);
                    MemoryStream ms = new MemoryStream(buffer);
                    Image image = Image.FromStream(ms);
                    image.Save(ImageSavePath + notificationMaster.NotificationImageName);
                }
                objNotificationMasterDAL.NotificationImageName = notificationMaster.NotificationImageName;
                objNotificationMasterDAL.NotificationDateTime = DateTime.ParseExact(notificationMaster.NotificationDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objNotificationMasterDAL.CreateDateTime = DateTime.ParseExact(notificationMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objNotificationMasterDAL.linktoUserMasterIdCreatedBy = notificationMaster.linktoUserMasterIdCreatedBy;
                objNotificationMasterDAL.IsDeleted = notificationMaster.IsDeleted;
                objNotificationMasterDAL.linktoBusinessMasterId = notificationMaster.linktoBusinessMasterId;
                objNotificationMasterDAL.Type = notificationMaster.Type;
                objNotificationMasterDAL.ID = notificationMaster.ID;

                poswRecordStatus rs = objNotificationMasterDAL.InsertNotificationMaster();
                objErrorStatus.ErrorCode = (int)rs;
                if (rs == poswRecordStatus.Success || rs == poswRecordStatus.RecordAlreadyExist)
                {
                    notificationMaster.SetClassObject(objNotificationMasterDAL);
                }
                return notificationMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return null;
            }
        }

        #endregion

        #region Update

        public ErrorStatus UpdateUserMasterPassword(string userMasterId, string userPassword)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                poswUserMasterDAL objUserMasterDAL = new poswUserMasterDAL();

                objUserMasterDAL.UserMasterId = Convert.ToInt16(userMasterId);
                objUserMasterDAL.Password = Convert.ToString(userPassword);
                objUserMasterDAL.UpdateDateTime = poswGlobalsDAL.GetCurrentDateTime();
                objUserMasterDAL.linktoUserMasterIdUpdatedBy = Convert.ToInt16(userMasterId);

                poswRecordStatus rs = objUserMasterDAL.UpdateUserMasterPassword();

                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;


            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)poswRecordStatus.Error;
                return objErrorStatus;
            }
        }

        #endregion

        #region Select
        public UserMaster SelectUserMaster(string userName, string password, string FCMToken)
        {
            try
            {
                poswUserMasterDAL objUserMasterDAL = null;
                try
                {
                    objUserMasterDAL = new poswUserMasterDAL();

                    objUserMasterDAL.Username = userName;
                    if (objUserMasterDAL.SelectUserMasterByUsername())
                    {
                        if (!objUserMasterDAL.Password.Equals(password, StringComparison.InvariantCulture))
                        {
                            if (objUserMasterDAL.UserMasterId != 1)
                            {
                                objUserMasterDAL.UpdateUserMasterLoginFailedCount();
                            }
                            return null;
                        }
                        else
                        {
                            if (!objUserMasterDAL.IsEnabled || objUserMasterDAL.LoginFailCount >= 7)
                            {
                                UserMaster objUserMaster = new UserMaster();
                                objUserMaster.SetClassObject(objUserMasterDAL);
                                return objUserMaster;
                            }
                            else
                            {
                                objUserMasterDAL.LastLoginDateTime = poswGlobalsDAL.GetCurrentDateTime();
                                objUserMasterDAL.UpdateUserMasterLastLoginDateTime();

                                if (FCMToken != null)
                                {
                                    objUserMasterDAL.FCMToken = FCMToken.Replace("2E2", ":").Replace("3E3", "-").Replace("4E4", "_");
                                }
                                objUserMasterDAL.UpdateUserMasterFCMToken();

                                UserMaster objUserMaster = new UserMaster();
                                objUserMaster.SetClassObject(objUserMasterDAL);
                                return objUserMaster;
                            }
                        }
                    }
                    else
                    {
                        return null;

                    }
                }
                catch (Exception ex)
                {
                    poswGlobalsDAL.SaveError(ex);
                    return null;
                }
                finally
                {
                    objUserMasterDAL = null;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public Dashboard SelectDashBoardCounter(string linktoBusinessMasterId)
        {
            try
            {
                poswDashboardDAL objDashboardDAL = new poswDashboardDAL();
                objDashboardDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);

                objDashboardDAL.SelectDashBoardCounter();

                Dashboard objDashboard = new Dashboard();
                objDashboard.SetClassObject(objDashboardDAL);
                return objDashboard;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public OrderMaster SelectOrderMasterDailyWeeklyMonthlyOrders(string linktoBusinessMasterId)
        {
            try
            {
                poswOrderMasterDAL objOrderMasterDAL = null;
                try
                {
                    objOrderMasterDAL = new poswOrderMasterDAL();

                    objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                    objOrderMasterDAL.linktoOrderStatusMasterId = Convert.ToInt16(poswOrderStatus.Canceled.GetHashCode()); ;
                    if (objOrderMasterDAL.SelectOrderMasterDailyWeeklyMonthlyOrders())
                    {
                        OrderMaster objOrderMaster = new OrderMaster();
                        objOrderMaster.SetClassObject(objOrderMasterDAL);
                        return objOrderMaster;
                    }
                    else
                    {
                        return null;

                    }
                }
                catch (Exception ex)
                {
                    poswGlobalsDAL.SaveError(ex);
                    return null;
                }
                finally
                {
                    objOrderMasterDAL = null;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public OrderMaster SelectOrderMasterLeastSellingDayOfLastWeek(string linktoBusinessMasterId, string fromDate, string currentDate, string DateRange)
        {
            try
            {
                poswOrderMasterDAL objOrderMasterDAL = null;
                try
                {
                    bool IsDateRange = false;
                    DateTime? FromDate = null;
                    DateTime? CurrentDate = null;
                    objOrderMasterDAL = new poswOrderMasterDAL();

                    if (Convert.ToBoolean(DateRange))
                    {
                        IsDateRange = true;
                    }

                    if (fromDate != "null")
                    {
                        FromDate = DateTime.ParseExact(fromDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                    }

                    if (currentDate != "null")
                    {
                        CurrentDate = DateTime.ParseExact(currentDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                    }

                    objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                    objOrderMasterDAL.linktoOrderStatusMasterId = Convert.ToInt16(poswOrderStatus.Canceled.GetHashCode()); ;
                    if (objOrderMasterDAL.SelectOrderMasterLeastSellingDayOfLastWeek(FromDate, CurrentDate, IsDateRange))
                    {
                        OrderMaster objOrderMaster = new OrderMaster();
                        objOrderMaster.SetClassObject(objOrderMasterDAL);
                        return objOrderMaster;
                    }
                    else
                    {
                        return null;

                    }
                }
                catch (Exception ex)
                {
                    poswGlobalsDAL.SaveError(ex);
                    return null;
                }
                finally
                {
                    objOrderMasterDAL = null;
                }
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        #endregion

        #region SelectAll

        public List<UserRightsTran> SelectAllUserRightsTran(string linktoRoleMasterId)
        {
            List<UserRightsTran> lstUserRightsTran = new List<UserRightsTran>();
            try
            {
                poswUserRightsTranDAL objUserRightsTranDAL = new poswUserRightsTranDAL();
                objUserRightsTranDAL.linktoRoleMasterId = Convert.ToInt16(linktoRoleMasterId);
                lstUserRightsTran = UserRightsTran.SetListObject(objUserRightsTranDAL.SelectAllUserRightsTran());
                return lstUserRightsTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderMaster> SelectAllOrderMasterOrderTypeWiseChart(string linktoBusinessMasterId)
        {
            List<OrderMaster> lstOrderMaster = new List<OrderMaster>();
            try
            {
                DateTime Firstday = new DateTime(poswGlobalsDAL.GetCurrentDateTime().Year, poswGlobalsDAL.GetCurrentDateTime().Month, 1);
                DateTime Endaday = Firstday.AddMonths(1).AddDays(-1);

                poswGlobalsDAL.FromDate = Convert.ToDateTime(Firstday);
                poswGlobalsDAL.ToDate = Convert.ToDateTime(Endaday);
                poswOrderMasterDAL objOrderMasterDAL = new poswOrderMasterDAL();
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstOrderMaster = OrderMaster.SetListObject(objOrderMasterDAL.SelectAllOrderMasterOrderTypeWiseChart());
                return lstOrderMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderMaster> SelectAllOrderMasterYearlyRevenueChart(string linktoBusinessMasterId)
        {
            List<OrderMaster> lstOrderMaster = new List<OrderMaster>();
            try
            {
                poswOrderMasterDAL objOrderMasterDAL = new poswOrderMasterDAL();
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstOrderMaster = OrderMaster.SetListObject(objOrderMasterDAL.SelectAllOrderMasterYearlyRevenueChart(DateTime.Today.Year.ToString()));
                return lstOrderMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderItemTran> SelectAllOrderItemTranMostOrderedItemsChart(string linktoBusinessMasterId)
        {
            List<OrderItemTran> lstOrderItemTran = new List<OrderItemTran>();
            try
            {
                poswOrderItemTranDAL objOrderItemTranDAL = new poswOrderItemTranDAL();
                objOrderItemTranDAL.linktoOrderStatusMasterId = Convert.ToInt16(poswOrderStatus.Canceled.GetHashCode());
                lstOrderItemTran = OrderItemTran.SetListObject(objOrderItemTranDAL.SelectAllOrderItemTranMostOrderedItemsChart(Convert.ToInt16(linktoBusinessMasterId)));
                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderItemTran> SelectAllOrderItemTranLeastOrderedItemsChart(string linktoBusinessMasterId)
        {
            List<OrderItemTran> lstOrderItemTran = new List<OrderItemTran>();
            try
            {
                poswOrderItemTranDAL objOrderItemTranDAL = new poswOrderItemTranDAL();
                objOrderItemTranDAL.linktoOrderStatusMasterId = Convert.ToInt16(poswOrderStatus.Canceled.GetHashCode());
                lstOrderItemTran = OrderItemTran.SetListObject(objOrderItemTranDAL.SelectAllOrderItemTranLeastOrderedItemsChart(Convert.ToInt16(linktoBusinessMasterId)));
                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<Events> SelectAllEventsPageWise(string linktoBusinessMasterId, string currentPage, string eventType)
        {
            List<Events> lstEvents = new List<Events>();
            try
            {
                short pageSize = 10;
                short startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                short totalRecords = 0;
                poswEventsDAL objEventsDAL = new poswEventsDAL();
                objEventsDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objEventsDAL.EventType = eventType;
                lstEvents = Events.SetListObject(objEventsDAL.SelectEventsPageWise(startRowIndex, pageSize, out totalRecords));
                return lstEvents;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderPaymentTran> SelectAllDailySaleDateWise(string linktoBusinessMasterId, string fromDate, string toDate)
        {
            List<OrderPaymentTran> lstOrderPaymentTrans = new List<OrderPaymentTran>();
            try
            {
                poswOrderPaymentTranDAL objOrderPaymentTranDAL = new poswOrderPaymentTranDAL();
                DateTime fromDate1 = DateTime.ParseExact(fromDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                DateTime toDate1 = DateTime.ParseExact(toDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                lstOrderPaymentTrans = OrderPaymentTran.SetListObject(objOrderPaymentTranDAL.SelectAllDailySaleDateWise(Convert.ToInt16(linktoBusinessMasterId), fromDate1, toDate1));

                return lstOrderPaymentTrans;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderItemTran> SelectAllOrderMasterWithOrderItemByStatus(string currentPage, string linktoBusinessMasterId, string statusCancel, string fromDate, string toDate)
        {
            List<OrderItemTran> lstOrderItemTran = new List<OrderItemTran>();
            List<poswOrderMasterDAL> lstOrderMasterDAL = new List<poswOrderMasterDAL>();
            StringBuilder sb;
            try
            {
                short pageSize = 10;
                short startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                short totalRecords = 0;
                bool IsCancelled;

                if (Convert.ToBoolean(statusCancel))
                {
                    IsCancelled = true;
                }
                else
                {
                    IsCancelled = false;
                }

                poswOrderMasterDAL objOrderMasterDAL = new poswOrderMasterDAL();
                poswOrderItemTranDAL objOrderItemTranDAL = new poswOrderItemTranDAL();

                objOrderMasterDAL.OrderNumber = "";
                objOrderMasterDAL.IsPreOrder = false;
                objOrderMasterDAL.linktoOrderStatusMasterId = Convert.ToInt16(poswOrderStatus.Canceled.GetHashCode());
                objOrderMasterDAL.OrderDateTime = DateTime.ParseExact(fromDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                objOrderMasterDAL.OrderToDateTime = DateTime.ParseExact(toDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstOrderMasterDAL = objOrderMasterDAL.SelectAllOrderMasterPageWise(startRowIndex, pageSize, IsCancelled, out totalRecords);

                sb = new StringBuilder();
                lstOrderMasterDAL.ForEach(i => sb.Append(i.OrderMasterId + ","));
                lstOrderItemTran = OrderItemTran.SetListObject(objOrderItemTranDAL.SelectAllOrderItemTranOrderMasterId(sb.ToString()));

                foreach (poswOrderMasterDAL orderMasterDAL in lstOrderMasterDAL)
                {
                    foreach (OrderItemTran objOrderItemTran in lstOrderItemTran)
                    {
                        if (objOrderItemTran.linktoOrderMasterId == orderMasterDAL.OrderMasterId)
                        {
                            objOrderItemTran.TotalTax = orderMasterDAL.TotalTax;
                            objOrderItemTran.TotalAmount = orderMasterDAL.TotalAmount;
                            objOrderItemTran.OrderNumber = orderMasterDAL.OrderNumber;
                            objOrderItemTran.OrderDateTime = orderMasterDAL.OrderDateTime.ToString("s");
                            ///IsPreOrder is used whether any amount is paid or not for Order 
                            objOrderItemTran.PaymentStatus = orderMasterDAL.IsPreOrder;
                            objOrderItemTran.linktoOrderStatusMasterId = orderMasterDAL.linktoOrderStatusMasterId;
                        }
                    }
                }

                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BookingMaster> SelectAllBookingMasterByStatus(string currentPage, string linktoBusinessMasterId, string statusCancel, string fromDate, string toDate)
        {
            List<BookingMaster> lstBookingMaster = new List<BookingMaster>();
            try
            {
                short pageSize = 10;
                short startRowIndex = (short)(pageSize * (Convert.ToInt16(currentPage) - 1));
                short totalRecords = 0;
                poswBookingMasterDAL objBookingMasterDAL = new poswBookingMasterDAL();
                if (Convert.ToBoolean(statusCancel))
                {
                    objBookingMasterDAL.IsCancelled = true;
                    objBookingMasterDAL.IsAssigned = true;
                    objBookingMasterDAL.BookingStatus = Convert.ToInt16(poswBookingStatus.Canceled.GetHashCode());
                }
                else
                {
                    objBookingMasterDAL.IsCancelled = false;
                    objBookingMasterDAL.IsAssigned = false;
                    objBookingMasterDAL.BookingStatus = Convert.ToInt16(poswBookingStatus.New.GetHashCode());
                }
                objBookingMasterDAL.FromDate = DateTime.ParseExact(fromDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                objBookingMasterDAL.ToDate = DateTime.ParseExact(toDate, "yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo);
                objBookingMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstBookingMaster = BookingMaster.SetListObject(objBookingMasterDAL.SelectAllBookingMasterByCustomerMasterRegisteredUserPageWise(startRowIndex, pageSize, out totalRecords));
                return lstBookingMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<NotificationMaster> SelectAllNotificationMasterPageWise(string currentPage, string linktoBusinessMasterId, string linktoCustomerMasterId)
        {
            List<NotificationMaster> lstNotificationMaster = new List<NotificationMaster>();
            try
            {
                short PageSize = 10;
                short StartRowIndex = (short)(PageSize * (Convert.ToInt16(currentPage) - 1));
                short TotalRecords = 0;
                poswNotificationMasterDAL objNotificationMasterDAL = new poswNotificationMasterDAL();
                objNotificationMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstNotificationMaster = NotificationMaster.SetListObject(objNotificationMasterDAL.SelectAllNotificationMasterPageWise(StartRowIndex, PageSize, Convert.ToInt32(linktoCustomerMasterId), out TotalRecords));
                return lstNotificationMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }


        public List<OfferMaster> SelectAllOfferMaster(string linktoBusinessMasterId, string fromday, string frommonth, string fromyear, string fromhour, string fromminute)
        {
            List<OfferMaster> lstOfferMaster = new List<OfferMaster>();
            try
            {
                short totalRecords = 0;
                poswOfferMasterDAL objOfferMasterDAL = new poswOfferMasterDAL();
                objOfferMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objOfferMasterDAL.FromDate = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear + " " + fromhour + ":" + fromminute, "M/d/yyyy H:m", DateTimeFormatInfo.InvariantInfo);
                lstOfferMaster = OfferMaster.SetListObject(objOfferMasterDAL.SelectAllOfferMasterByFormDateTime(out totalRecords));
                return lstOfferMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }


        public List<ItemMaster> SelectAllItemMasterIdByCategoryMasterId(string linktoCatgoryMasterId, string linktoBusinessMasterId)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            short totalRecords = 0;
            string[] strArray;
            try
            {
                poswItemMasterDAL objItemMasterDAL = new poswItemMasterDAL();
                if (linktoCatgoryMasterId != "null")
                {
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(linktoCatgoryMasterId);
                }
                objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstItemMaster = ItemMaster.SetListObject(objItemMasterDAL.SelectAllItemMasterByCategoryMasterId(out totalRecords));
                return lstItemMaster;
            }
            catch (Exception ex)
            {
                poswGlobalsDAL.SaveError(ex);
                return null;
            }
        }
        #endregion

        #region SendNotifications

        public void SendNotificationsToAll(string linktoBusinessMasterId, string notificationMasterId, string customerType)
        {
            poswFCMPushNotificationDAL apnGCM = new poswFCMPushNotificationDAL();
            poswFCMMasterDAL objFCMMaster = new poswFCMMasterDAL();
            poswNotificationMasterDAL notificationMaster = new poswNotificationMasterDAL();
            List<poswFCMMasterDAL> lstFCMMaster = new List<poswFCMMasterDAL>();
            notificationMaster.NotificationMasterId = Convert.ToInt16(notificationMasterId);
            notificationMaster.SelectNotificationMaster();
            objFCMMaster.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
            int customertype = Convert.ToInt32(customerType);
            lstFCMMaster = objFCMMaster.SelectAllFCMMaster(customertype);

            string imageName = null;
            imageName = notificationMaster.NotificationImageName;         

            if (imageName == null)
            {
                if (notificationMaster.Type == poswBannerType.Item.GetHashCode())
                {
                    poswItemMasterDAL itemMaster = new poswItemMasterDAL();
                    itemMaster.ItemMasterId = Convert.ToInt32(notificationMaster.ID);
                    if (itemMaster.SelectItemMaster())
                    {
                        imageName = itemMaster.md_ImagePhysicalName;
                    }
                }
                else if (notificationMaster.Type == poswBannerType.Offer.GetHashCode())
                {
                    poswOfferMasterDAL offerMaster = new poswOfferMasterDAL();
                    offerMaster.OfferMasterId = Convert.ToInt32(notificationMaster.ID);
                    if (offerMaster.SelectOfferMaster())
                    {
                        imageName = offerMaster.mdImagePhysicalName;
                    }
                }
                else
                {
                    imageName = notificationMaster.NotificationImageName;
                }
            }

            if (lstFCMMaster != null && lstFCMMaster.Count > 0)
            {
                foreach (poswFCMMasterDAL fCMMaster in lstFCMMaster)
                {
                    if (fCMMaster.FCMToken != null)
                    {
                        //string strResponse = apnGCM.SendOrderDetails(poswGlobalsDAL.apiKeyabPOSA, userMaster.FCMToken, newOrders, newBookings, cancleOrders, cancleBookings);
                        string strResponse = apnGCM.SendNotificationLikEat(fCMMaster.FCMToken, notificationMaster.NotificationTitle, notificationMaster.NotificationText, imageName, Convert.ToString(notificationMaster.Type), Convert.ToString(notificationMaster.ID));
                    }
                }
            }
        }

        #endregion

        #endregion
    }
}
